/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.MinecraftClient
 */
package recovered.core;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_gc_4c0dfe20;
import recovered.internal.Class_gf_c6fc2a98;
import recovered.internal.Class_gh_ecfd0cde;
import recovered.internal.Class_hF_7bd1921e;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mZ_07f59a29;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public abstract class ModuleBase
extends Class_iS_888f260e {
    protected int XWrfQ;
    protected int[] RcFWc;
    protected int[] lRvVv;
    protected Class_gc_4c0dfe20 GfFkt;
    protected boolean RliRe;
    protected boolean tZRhp;
    protected boolean dktTQ;
    protected boolean EDndy;
    protected Class_gh_ecfd0cde utKrA;
    protected Class_rk_bf8630d1 vGSNX;
    protected Class_rk_bf8630d1 bKydN;
    protected Class_ri_288534d5 GYAAa;
    private static String[] rWBfw;
    private static final long sxSiM;
    private static final String jdjGT;
    private static final long[] KVEqq;
    private static final Integer[] LTRAw;
    private static final Map BXJbv;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public ModuleBase(Class_gf_c6fc2a98 class_gf_c6fc2a98) {
        block0: {
            long l = sxSiM ^ 0x7E0CC9D7680L;
            this.GfFkt = new Class_gc_4c0dfe20();
            this.vGSNX = new Class_rk_bf8630d1((int)ModuleBase.baF("s", (int)12464, (long)(0x1226F0CDF9239F0FL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
            this.bKydN = new Class_rk_bf8630d1((int)ModuleBase.baF("s", (int)30186, (long)(0x59EBD302A4925A54L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
            this.GYAAa = new Class_ri_288534d5((int)ModuleBase.baF("s", (int)30186, (long)(0x59EBD302A4925A54L ^ l)));
            class_gf_c6fc2a98 = Objects.requireNonNull(class_gf_c6fc2a98, jdjGT);
            this.XWrfQ = class_gf_c6fc2a98.aZM();
            this.RliRe = class_gf_c6fc2a98.aZN();
            this.tZRhp = class_gf_c6fc2a98.aZR();
            this.dktTQ = class_gf_c6fc2a98.aZT();
            String[] stringArray = ModuleBase.baA();
            this.EDndy = class_gf_c6fc2a98.aZV();
            this.utKrA = class_gf_c6fc2a98.aZO();
            this.GfFkt.aZj(class_gf_c6fc2a98.aZP());
            if (Class_iS_888f260e.bwL() != null) break block0;
            ModuleBase.baz(new String[1]);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        sxSiM = Class_gb_9d201141.aYR(-4690808252542375339L, -5296510176118890153L, MethodHandles.lookup().lookupClass()).a(83809520359028L);
        long l = sxSiM ^ 0x68D8589376B3L;
        ModuleBase.baz(null);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        byte[] byArray3 = cipher.doFinal("\u00e3\u008a\u00bb\u000b\u00e6\u0083E\u0092".getBytes("ISO-8859-1"));
        jdjGT = ModuleBase.baC(byArray3).intern();
        BXJbv = new HashMap(13);
        Cipher cipher2 = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory2 = SecretKeyFactory.getInstance("DES");
        byte[] byArray4 = new byte[8];
        byte[] byArray5 = byArray4;
        byArray4[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray5 = byArray5;
            byArray5[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher2.init(2, (Key)secretKeyFactory2.generateSecret(new DESKeySpec(byArray5)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "/\u00bbV=\u0084\u00e5\u00b0\u00ff\u0019T\u0099\u00c6\u008b.\u00e6s";
        int n2 = "/\u00bbV=\u0084\u00e5\u00b0\u00ff\u0019T\u0099\u00c6\u008b.\u00e6s".length();
        int n3 = 0;
        do {
            byte[] byArray6 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray6[0] & 0xFFL) << 56 | ((long)byArray6[1] & 0xFFL) << 48 | ((long)byArray6[2] & 0xFFL) << 40 | ((long)byArray6[3] & 0xFFL) << 32 | ((long)byArray6[4] & 0xFFL) << 24 | ((long)byArray6[5] & 0xFFL) << 16 | ((long)byArray6[6] & 0xFFL) << 8 | (long)byArray6[7] & 0xFFL;
            byte[] byArray7 = cipher2.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray7[0] & 0xFFL) << 56 | ((long)byArray7[1] & 0xFFL) << 48 | ((long)byArray7[2] & 0xFFL) << 40 | ((long)byArray7[3] & 0xFFL) << 32 | ((long)byArray7[4] & 0xFFL) << 24 | ((long)byArray7[5] & 0xFFL) << 16 | ((long)byArray7[6] & 0xFFL) << 8 | (long)byArray7[7] & 0xFFL;
        } while (n3 < n2);
        KVEqq = lArray;
        LTRAw = new Integer[2];
    }

    public static void baz(String[] stringArray) {
        rWBfw = stringArray;
    }

    private static int baD(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x60C6;
        if (LTRAw[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = KVEqq[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])BXJbv.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    BXJbv.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/core/ModuleBase", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            ModuleBase.LTRAw[n2] = n3;
        }
        return LTRAw[n2];
    }

    public ModuleBase bau(boolean bl) {
        this.EDndy = bl;
        return this;
    }

    public ModuleBase bav(Class_gh_ecfd0cde class_gh_ecfd0cde) {
        this.utKrA = class_gh_ecfd0cde;
        return this;
    }

    public Class_gc_4c0dfe20 baf() {
        return this.GfFkt;
    }

    private static CallSite baF(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/core/ModuleBase" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public void baa(boolean bl) {
        block9: {
            ModuleBase moduleBase;
            block7: {
                block8: {
                    boolean bl2;
                    String[] stringArray;
                    block6: {
                        long l = sxSiM ^ 0x7ABD8E847BD9L;
                        stringArray = ModuleBase.baA();
                        bl2 = Class_mZ_07f59a29.css();
                        if (stringArray == null) {
                            if (!bl2) {
                                return;
                            }
                            bl2 = this.RliRe;
                        }
                        if (stringArray != null) break block6;
                        if (bl2 == bl) {
                            return;
                        }
                        this.RliRe = bl;
                        moduleBase = this;
                        if (stringArray != null) break block7;
                        bl2 = moduleBase.RliRe;
                    }
                    if (!bl2) break block8;
                    this.aaj();
                    if (stringArray == null) break block9;
                }
                moduleBase = this;
            }
            moduleBase.YO();
        }
    }

    public Class_rk_bf8630d1 bal() {
        return this.vGSNX;
    }

    public Class_rk_bf8630d1 bam() {
        return this.bKydN;
    }

    public Class_ri_288534d5 ban() {
        return this.GYAAa;
    }

    public ModuleBase baq(int[] nArray) {
        this.lRvVv = nArray;
        return this;
    }

    public ModuleBase bas(boolean bl) {
        this.tZRhp = bl;
        return this;
    }

    private static MatchException baB(MatchException matchException) {
        return matchException;
    }

    public ModuleBase bap(int[] nArray) {
        this.RcFWc = nArray;
        return this;
    }

    public ModuleBase baw(Class_rk_bf8630d1 class_rk_bf8630d1) {
        this.vGSNX = class_rk_bf8630d1;
        return this;
    }

    public boolean bai() {
        return this.dktTQ;
    }

    public static String[] baA() {
        return rWBfw;
    }

    public void aZZ() {
        block6: {
            ModuleBase moduleBase;
            block4: {
                block5: {
                    long l = sxSiM ^ 0x47173E679F8CL;
                    String[] stringArray = ModuleBase.baA();
                    boolean bl = this.RliRe;
                    if (stringArray == null) {
                        bl = !bl;
                    }
                    this.RliRe = bl;
                    moduleBase = this;
                    if (stringArray != null) break block4;
                    if (!moduleBase.RliRe) break block5;
                    ClientMain.dmd().daT();
                    this.aaj();
                    if (stringArray == null) break block6;
                }
                ClientMain.dmd().daU();
                moduleBase = this;
            }
            moduleBase.YO();
        }
    }

    public int bac() {
        return this.XWrfQ;
    }

    public int[] bad() {
        return this.RcFWc;
    }

    public int[] bae() {
        return this.lRvVv;
    }

    public boolean bah() {
        return this.tZRhp;
    }

    public boolean baj() {
        return this.EDndy;
    }

    public void aaj() {
        Class_hF_7bd1921e.bdI(this);
    }

    public ModuleBase bao(int n) {
        this.XWrfQ = n;
        return this;
    }

    public ModuleBase bar(Class_gc_4c0dfe20 class_gc_4c0dfe20) {
        this.GfFkt = class_gc_4c0dfe20;
        return this;
    }

    public Class_gh_ecfd0cde bak() {
        return this.utKrA;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean bab() {
        long l = sxSiM ^ 0x11E5104FB7E2L;
        String[] stringArray = ModuleBase.baA();
        MinecraftClient minecraftClient = ClientMain.dlmvG;
        if (stringArray == null) {
            if (minecraftClient.player == null) return false;
            minecraftClient = ClientMain.dlmvG;
        }
        if (stringArray == null) {
            if (minecraftClient.world == null) return false;
            minecraftClient = ClientMain.dlmvG;
        }
        if (stringArray == null) {
            if (minecraftClient.interactionManager == null) return false;
            minecraftClient = ClientMain.dlmvG;
        }
        if (minecraftClient.getNetworkHandler() == null) return false;
        return true;
    }

    private static int baE(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = ModuleBase.baD(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public ModuleBase bax(Class_rk_bf8630d1 class_rk_bf8630d1) {
        this.bKydN = class_rk_bf8630d1;
        return this;
    }

    public ModuleBase bay(Class_ri_288534d5 class_ri_288534d5) {
        this.GYAAa = class_ri_288534d5;
        return this;
    }

    private static String baC(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public ModuleBase bat(boolean bl) {
        this.dktTQ = bl;
        return this;
    }

    public boolean bag() {
        return this.RliRe;
    }

    public void YO() {
        Class_hF_7bd1921e.bdM(this);
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(ModuleBase.class, "baE", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

