/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.texture.AbstractTexture
 */
package recovered.core;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.AbstractTexture;
import recovered.core.NativeLoader;
import recovered.internal.Class_cq_827f2687;
import recovered.internal.Class_ge_83bda88c;
import recovered.internal.Class_iB_7f1bc3b4;
import recovered.internal.Class_iG_eb56e55f;
import recovered.internal.Class_iQ_3442de41;
import recovered.internal.Class_ia_2444a159;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_iq_8b66b50c;
import recovered.internal.Class_iu_bf2db566;
import recovered.internal.Class_iv_eaeaeb9a;
import recovered.internal.Class_jL_e8aba6a1;
import recovered.internal.Class_lv_518bbba3;
import recovered.internal.Class_nY_1f8d9382;
import recovered.internal.Class_nZ_7f5c8a11;
import recovered.internal.Class_oa_c8aff8df;
import recovered.internal.Class_pI_5da41a7d;
import recovered.internal.Class_qF_02c80225;
import recovered.internal.Class_qG_e4a9ff86;
import recovered.internal.Class_qH_138eb7c7;
import recovered.internal.Class_qI_70d2c8e1;
import recovered.internal.Class_qJ_4d58c8cc;
import recovered.internal.Class_qK_9b5a4a78;
import recovered.internal.Class_qL_ab99a11b;
import recovered.internal.Class_qM_6b1487d3;
import recovered.internal.Class_qN_e1ec62a1;
import recovered.internal.Class_qO_d37ef529;
import recovered.internal.Class_qP_6fc6715d;
import recovered.internal.Class_qQ_f3f3a6dc;
import recovered.internal.Class_qR_3aff413f;
import recovered.internal.Class_qS_342030d4;
import recovered.modules.AntiBotModule;

public final class ClientMain {
    public static MinecraftClient dlmvG;
    static ClientMain ckleu;
    private final AtomicReference<CompletableFuture<Void>> esvJP = new AtomicReference();
    private AbstractTexture ponOV;
    private Class_jL_e8aba6a1 JPfAx;
    private Class_ge_83bda88c dIwNo;
    private Class_cq_827f2687 Krytu;
    private Class_ia_2444a159 ymZXb;
    private Class_qF_02c80225 EzLxl;
    private Class_qG_e4a9ff86 gCddb;
    private Class_pI_5da41a7d YaUxu;
    private Class_iv_eaeaeb9a NkOrm;
    private Class_ii_9b427eda HAhie;
    private Class_iQ_3442de41 nTDxJ;
    private Class_iB_7f1bc3b4 TFKhB;
    private Class_iG_eb56e55f nsAeF;
    private Class_iq_8b66b50c UgciD;
    private Class_qP_6fc6715d JzJeP;
    private Class_qL_ab99a11b aLVRu;
    private Class_qR_3aff413f yYpAe;
    private Class_qJ_4d58c8cc LQlXr;
    private Class_qN_e1ec62a1 rNQhQ;
    private Class_qM_6b1487d3 ZMMDH;
    private Class_qQ_f3f3a6dc tfojL;
    private Class_qI_70d2c8e1 QOBpa;
    private Class_qS_342030d4 OQqWJ;
    private Class_qH_138eb7c7 rtAXF;
    private Class_qO_d37ef529 MQyGh;
    private Class_qK_9b5a4a78 kuvoG;
    private Class_oa_c8aff8df MIrKO;
    private Class_nY_1f8d9382 jQBjc;
    private Class_nZ_7f5c8a11 hTzMw;
    private static int[] dLmYF;
    private static long wueCa;
    private static String JSVca;
    private static long IzDvT;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(ClientMain.class);
        ClientMain._2c446001dd787cb011ca4363782d7f45();
    }

    public static native Class_qK_9b5a4a78 dmh();

    public static native int[] dmw();

    private static native String dmy(byte[] var0);

    private native CompletableFuture<Void> dlC(int var1, Supplier<CompletableFuture<Void>> var2);

    public static ClientMain dmn() {
        return ckleu;
    }

    public static native Class_pI_5da41a7d dlS();

    public static native Class_qN_e1ec62a1 dma();

    public static native Class_qM_6b1487d3 dmb();

    public native CompletableFuture<Void> dlz(String var1);

    public static native Class_nZ_7f5c8a11 dmk();

    public static Class_qO_d37ef529 dmg() {
        return ClientMain.dmn().MQyGh;
    }

    private native /* synthetic */ Void dmq(int var1, Throwable var2);

    private native /* synthetic */ void dmt(String var1);

    public static native Class_iQ_3442de41 dlN();

    public static native Class_ia_2444a159 dlL();

    private native /* synthetic */ CompletionStage dmp(Class_iu_bf2db566 var1);

    private native /* synthetic */ CompletionStage dmu(Void var1);

    public static Class_qH_138eb7c7 dmf() {
        return ClientMain.dmn().rtAXF;
    }

    private native void dlE();

    public static native Class_jL_e8aba6a1 dlQ();

    private native CompletableFuture<Void> dlF();

    public static native Class_qR_3aff413f dlY();

    public static native Class_qI_70d2c8e1 dmd();

    public static native Class_iv_eaeaeb9a dlV();

    public static Class_qF_02c80225 dlR() {
        return ClientMain.dmn().EzLxl;
    }

    public static native AbstractTexture dmm();

    private native /* synthetic */ CompletionStage dms(Void var1);

    public static native void dmv(int[] var0);

    public static native Class_iB_7f1bc3b4 dlO();

    public static Class_ii_9b427eda dlM() {
        return ClientMain.dmn().HAhie;
    }

    public static Class_qG_e4a9ff86 dlT() {
        return ClientMain.dmn().gCddb;
    }

    public static Class_qQ_f3f3a6dc dmc() {
        return ClientMain.dmn().tfojL;
    }

    private native CompletableFuture<Void> dlA();

    private native CompletableFuture<Void> dlB();

    private native void dlG();

    public static Class_cq_827f2687 dlK() {
        return ClientMain.dmn().Krytu;
    }

    public static native Class_iG_eb56e55f dlP();

    private native void dlD(String var1);

    private native Throwable dlI(Throwable var1);

    public static native Class_qP_6fc6715d dlW();

    public static Class_nY_1f8d9382 dmj() {
        return ClientMain.dmn().jQBjc;
    }

    public static native Class_iq_8b66b50c dlU();

    public static AntiBotModule dml() {
        return ClientMain.dmn().dIwNo.aZv();
    }

    private static native /* synthetic */ void dmo(Class_lv_518bbba3 var0);

    private native /* synthetic */ void dmr(CompletableFuture var1, Void var2, Throwable var3);

    private native Throwable dlH(int var1, Throwable var2);

    public static native Class_qS_342030d4 dme();

    public static Class_qJ_4d58c8cc dlZ() {
        return ClientMain.dmn().LQlXr;
    }

    private static native Throwable dmx(Throwable var0);

    public static Class_qL_ab99a11b dlX() {
        return ClientMain.dmn().aLVRu;
    }

    public static Class_oa_c8aff8df dmi() {
        return ClientMain.dmn().MIrKO;
    }

    private static native void _2c446001dd787cb011ca4363782d7f45();

    public static Class_ge_83bda88c dlJ() {
        return ClientMain.dmn().dIwNo;
    }
}

