/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_ah_02444db4;
import recovered.internal.Class_ak_2ff604c7;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bg_0a91641c;
import recovered.internal.Class_bk_fda2cc3f;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.internal.Class_v_5eec8686;

public class Class_bd_8faff9cb
extends Class_az_a4990dcf {
    private final Class_bg_0a91641c gLpse;
    private final List<Class_ak_2ff604c7<?>> iWGks;
    private final Class_rk_bf8630d1 lWwPB;
    private final Class_rk_bf8630d1 JrgcS;
    private final Class_rk_bf8630d1 qicmf;
    private final Class_v_5eec8686 jyYNO;
    private final Class_bk_fda2cc3f TUcNz;
    private final Class_ah_02444db4 WmfRJ;
    private boolean MqINl;
    private boolean qMYan;
    private float fNXMn;
    private float LaFgq;
    private Class_cB_67aec11c Wmfur;
    private boolean UUEVR;
    private static float Pblor = 18.0f;
    private static long aAWpI;
    private static long[] HPoXz;
    private static Integer[] HhdWQ;
    private static Map SSEbJ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bd_8faff9cb(Class_bg_0a91641c class_bg_0a91641c, float f, float f2, Class_cB_67aec11c class_cB_67aec11c) {
        block7: {
            boolean bl;
            long l = aAWpI ^ 0x26D3D2F10863L;
            int n = Class_bg_0a91641c.Dd();
            int n2 = n;
            try {
                this.iWGks = new ArrayList();
                this.lWwPB = new Class_rk_bf8630d1((int)Class_bd_8faff9cb.Cq("q", (int)19494, (long)(0x4F4F3FC871F89B00L ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
                this.JrgcS = new Class_rk_bf8630d1((int)Class_bd_8faff9cb.Cq("q", (int)44, (long)(0x14DE905BC9EE570FL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
                this.qicmf = new Class_rk_bf8630d1((int)Class_bd_8faff9cb.Cq("q", (int)22822, (long)(0x5FC60E4752560E0FL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
                this.WmfRJ = new Class_ah_02444db4();
                this.gLpse = class_bg_0a91641c;
                this.MCnYt = f;
                this.pNyTQ = f2;
                this.BcpIo = 127.0f;
                this.Wmfur = class_cB_67aec11c;
                Class_bd_8faff9cb class_bd_8faff9cb = this;
                bl = class_cB_67aec11c == null;
            }
            catch (MatchException matchException) {
                throw Class_bd_8faff9cb.Cn(matchException);
            }
            class_bd_8faff9cb.UUEVR = bl;
            int[] nArray = new int[Class_bd_8faff9cb.Cq("q", (int)20856, (long)(0x1191CEE3E47D8653L ^ l))];
            nArray[0] = (int)Class_bd_8faff9cb.Cq("q", (int)8743, (long)(0x579C2E477DD77507L ^ l));
            nArray[1] = (int)Class_bd_8faff9cb.Cq("q", (int)20488, (long)(0x284F158A98D5072AL ^ l));
            nArray[2] = (int)Class_bd_8faff9cb.Cq("q", (int)21434, (long)(0x535D8B8349C9049EL ^ l));
            nArray[3] = (int)Class_bd_8faff9cb.Cq("q", (int)27639, (long)(0x113256CD7244BCD6L ^ l));
            nArray[4] = (int)Class_bd_8faff9cb.Cq("q", (int)31764, (long)(0x6931B1AB201A2B3EL ^ l));
            nArray[5] = (int)Class_bd_8faff9cb.Cq("q", (int)17625, (long)(0x62517A97E75B93F1L ^ l));
            nArray[Class_bd_8faff9cb.Cq("q", (int)29404, (long)(0x7A2199F26C9D25F3L ^ l))] = (int)Class_bd_8faff9cb.Cq("q", (int)31284, (long)(0x6AA9B501AD56AD11L ^ l));
            Class_cJ_2ae1a557 class_cJ_2ae1a557 = new Class_cJ_2ae1a557(Class_mr_7eac5189.clS(nArray)).WE(class_bg_0a91641c.CX().bag());
            class_cJ_2ae1a557.Vd(() -> Class_bd_8faff9cb.Cm(class_bg_0a91641c));
            this.jyYNO = new Class_v_5eec8686(class_cJ_2ae1a557, (Class_az_a4990dcf)this);
            this.iWGks.add(this.jyYNO);
            this.TUcNz = new Class_bk_fda2cc3f(class_bg_0a91641c.CX(), (Class_az_a4990dcf)this);
            this.iWGks.add(this.TUcNz);
            for (Class_cB_67aec11c class_cB_67aec11c2 : class_bg_0a91641c.CX().bwI()) {
                block8: {
                    Class_ak_2ff604c7<? extends Class_cB_67aec11c> class_ak_2ff604c7 = Class_jf_d1c4f950.bAR(class_cB_67aec11c2, this);
                    try {
                        try {
                            if (n2 != 0) break block7;
                            if (class_ak_2ff604c7 == null) break block8;
                        }
                        catch (MatchException matchException) {
                            throw Class_bd_8faff9cb.Cn(matchException);
                        }
                        this.iWGks.add(class_ak_2ff604c7);
                    }
                    catch (MatchException matchException) {
                        throw Class_bd_8faff9cb.Cn(matchException);
                    }
                }
                if (n2 == 0) continue;
            }
            this.MqINl = true;
        }
    }

    static {
        NativeLoader.doInit(Class_bd_8faff9cb.class);
        Class_bd_8faff9cb._720c23323a2914d66ffcad8e094f75ee();
    }

    @Override
    public native float dn();

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean dm(int var1, int var2, int var3);

    private static native MatchException Cn(MatchException var0);

    public native float Cc();

    public native boolean Cf();

    private static native int Co(int var0, long var1);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean fC(double var1, double var3, double var5);

    public native Class_bk_fda2cc3f BY();

    private static native void _720c23323a2914d66ffcad8e094f75ee();

    @Override
    public native boolean dB(double var1, double var3, Class_mA_32d8a5f2 var5, double var6, double var8);

    private native void BO(Class_lC_5322e8cf var1, float var2, float var3, float var4);

    @Override
    public native void fX(Class_lC_5322e8cf var1);

    @Override
    public native boolean eK(char var1);

    @Override
    public native boolean oi();

    @Override
    protected native boolean nZ();

    public native boolean Cb();

    public native Class_bd_8faff9cb Cg(boolean var1);

    public native Class_bg_0a91641c BS();

    public native void BQ(Class_cB_67aec11c var1);

    public native Class_rk_bf8630d1 BU();

    public native boolean Ca();

    public native Class_rk_bf8630d1 BV();

    public native Class_bd_8faff9cb Ci(float var1);

    public native Class_bd_8faff9cb Cj(float var1);

    private static native int Cp(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native void BP(float var1, float var2);

    private native void BR(Class_lC_5322e8cf var1, Class_lf_d247d983 var2, float var3, float var4, float var5, Class_mG_52c8d386 var6);

    public native float Cd();

    public native List<Class_ak_2ff604c7<?>> BT();

    public native Class_v_5eec8686 BX();

    public native Class_ah_02444db4 BZ();

    private static native CallSite Cq(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native Class_bd_8faff9cb Ch(boolean var1);

    public native Class_bd_8faff9cb Ck(Class_cB_67aec11c var1);

    public native Class_rk_bf8630d1 BW();

    public native Class_bd_8faff9cb Cl(boolean var1);

    private static native /* synthetic */ void Cm(Class_bg_0a91641c var0);

    public native Class_cB_67aec11c Ce();
}

