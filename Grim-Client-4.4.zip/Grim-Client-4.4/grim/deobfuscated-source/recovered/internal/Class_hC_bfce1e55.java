/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;

public class Class_hC_bfce1e55
extends Class_hH_ae8f8f77 {
    private final int hbgtX;
    private final int UFhzP;
    private final int kAquG;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hC_bfce1e55(int n, int n2, int n3) {
        this.hbgtX = n;
        this.UFhzP = n2;
        this.kAquG = n3;
    }

    public int bdE() {
        return this.UFhzP;
    }

    public int bdF() {
        return this.kAquG;
    }

    public int bdD() {
        return this.hbgtX;
    }
}

