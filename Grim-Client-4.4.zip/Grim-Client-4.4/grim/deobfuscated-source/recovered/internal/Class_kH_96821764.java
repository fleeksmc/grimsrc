/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.util.math.Box
 */
package recovered.internal;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import recovered.internal.Class_kH_up_e45b7ab9;
import recovered.internal.Class_mG_52c8d386;

public class Class_kH_96821764 {
    private MatrixStack ZNdTt;
    private Box nrbSq;
    private Class_mG_52c8d386 UJMOR;
    private Class_mG_52c8d386 BTmWY;
    private Class_mG_52c8d386 lBaQI;
    private boolean NwNNG;
    private boolean FGWJo;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_kH_96821764(MatrixStack matrixStack, Box box, Class_mG_52c8d386 class_mG_52c8d386, Class_mG_52c8d386 class_mG_52c8d3862, Class_mG_52c8d386 class_mG_52c8d3863, boolean bl, boolean bl2) {
        this.ZNdTt = matrixStack;
        this.nrbSq = box;
        this.UJMOR = class_mG_52c8d386;
        this.BTmWY = class_mG_52c8d3862;
        this.lBaQI = class_mG_52c8d3863;
        this.NwNNG = bl;
        this.FGWJo = bl2;
    }

    public static Class_kH_up_e45b7ab9 bTJ(MatrixStack matrixStack, Box box, boolean bl, boolean bl2) {
        return Class_kH_96821764.bTK().dtL(matrixStack).dtM(box).dtQ(bl).dtR(bl2);
    }

    public static Class_kH_up_e45b7ab9 bTK() {
        return new Class_kH_up_e45b7ab9();
    }

    public Class_mG_52c8d386 bTP() {
        return this.lBaQI;
    }

    public Class_mG_52c8d386 bTO() {
        return this.BTmWY;
    }

    public MatrixStack bTL() {
        return this.ZNdTt;
    }

    public boolean bTR() {
        return this.FGWJo;
    }

    public Box bTM() {
        return this.nrbSq;
    }

    public boolean bTQ() {
        return this.NwNNG;
    }

    public Class_mG_52c8d386 bTN() {
        return this.UJMOR;
    }
}

