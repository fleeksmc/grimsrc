/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.core.ClientMain;
import recovered.internal.Class_bT_3a1e4a37;
import recovered.internal.Class_cv_f4b0140a;
import recovered.internal.Class_cw_dbcad330;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public abstract class Class_bS_979bca5c
extends Class_cw_dbcad330 {
    protected Class_bT_3a1e4a37 fGWTH;
    protected final Class_rk_bf8630d1 dExGi;
    private static int qlHhv;
    private static final long fLLMv;
    private static final long XOMXi;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bS_979bca5c(Class_cv_f4b0140a class_cv_f4b0140a, Class_mr_7eac5189 class_mr_7eac5189) {
        long l = fLLMv ^ 0x39DC722062BAL;
        super(class_cv_f4b0140a, class_mr_7eac5189);
        this.fGWTH = new Class_bT_3a1e4a37(48.0f, 15.0f);
        this.dExGi = new Class_rk_bf8630d1((int)XOMXi).dhs(Class_rj_b691f4f7.NJlxm);
        this.Tz();
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        fLLMv = Class_gb_9d201141.aYR(5886275071503743153L, -451407613624388453L, MethodHandles.lookup().lookupClass()).a(161403895425971L);
        long l = fLLMv ^ 0xBEB53A72125L;
        Class_bS_979bca5c.NQ(104);
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                long l2 = -309442034757594481L;
                byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
                XOMXi = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    public abstract boolean MH();

    public Class_bT_3a1e4a37 NO() {
        return this.fGWTH;
    }

    public Class_rk_bf8630d1 NP() {
        return this.dExGi;
    }

    public static int NR() {
        return qlHhv;
    }

    public void MG(Class_lC_5322e8cf class_lC_5322e8cf, Class_ii_9b427eda class_ii_9b427eda) {
    }

    public Class_mG_52c8d386 MI() {
        return ClientMain.dlM().bjd();
    }

    public static int NS() {
        int n = Class_bS_979bca5c.NR();
        if (n == 0) {
            return 79;
        }
        return 0;
    }

    public void NN(Class_lC_5322e8cf class_lC_5322e8cf, Class_ii_9b427eda class_ii_9b427eda) {
        Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, this.dExGi.dhj());
        this.MG(class_lC_5322e8cf, class_ii_9b427eda);
        Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public static void NQ(int n) {
        qlHhv = n;
    }

    private static MatchException NT(MatchException matchException) {
        return matchException;
    }

    public void Ne(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
    }
}

