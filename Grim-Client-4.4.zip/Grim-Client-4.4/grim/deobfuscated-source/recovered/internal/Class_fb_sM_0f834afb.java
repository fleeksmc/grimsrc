/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import java.util.List;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import recovered.core.NativeLoader;

final class Class_fb_sM_0f834afb
extends Record {
    private final BlockPos railPos;
    private final BlockHitResult cartHitResult;
    private final List<Vec3d> arrowPath;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_fb_sM_0f834afb(BlockPos blockPos, BlockHitResult blockHitResult, List<Vec3d> list) {
        this.railPos = blockPos;
        this.cartHitResult = blockHitResult;
        this.arrowPath = list;
    }

    static {
        NativeLoader.doInit(Class_fb_sM_0f834afb.class);
    }

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    public native List<Vec3d> arrowPath();

    public native BlockPos railPos();

    public native BlockHitResult cartHitResult();
}

