/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;

final class Class_fa_sK_e21557cb
extends Enum<Class_fa_sK_e21557cb> {
    public static /* enum */ Class_fa_sK_e21557cb YbJTa;
    public static /* enum */ Class_fa_sK_e21557cb RWBsV;
    public static /* enum */ Class_fa_sK_e21557cb MAgEy;
    public static /* enum */ Class_fa_sK_e21557cb oBiuY;
    public static /* enum */ Class_fa_sK_e21557cb dzJyB;
    public static /* enum */ Class_fa_sK_e21557cb hECYg;
    public static /* enum */ Class_fa_sK_e21557cb tKIGa;
    public static /* enum */ Class_fa_sK_e21557cb wglWG;
    private static Class_fa_sK_e21557cb[] ZqHfE;
    private static long EfXWt;
    private static long[] QLPlX;
    private static Integer[] EVSCw;
    private static Map GudSQ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_fa_sK_e21557cb.class);
        Class_fa_sK_e21557cb._eea8ed86ca395c650722f611c54003db();
    }

    public static native Class_fa_sK_e21557cb[] values();

    public static native Class_fa_sK_e21557cb valueOf(String var0);

    private static native void _eea8ed86ca395c650722f611c54003db();

    private static native int doT(int var0, long var1);

    private static native CallSite doV(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native Class_fa_sK_e21557cb[] doR();

    private static native String doS(byte[] var0);

    private static native int doU(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);
}

