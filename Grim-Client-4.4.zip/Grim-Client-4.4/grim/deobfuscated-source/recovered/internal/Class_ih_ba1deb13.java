/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import recovered.core.NativeLoader;
import recovered.internal.Class_bb_631496ef;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_ij_d7bf2301;
import recovered.internal.Class_mu_a94f6370;

public class Class_ih_ba1deb13 {
    private final Map<String, Class_ig_ca326427> WUEfC;
    private final Class_mu_a94f6370<Class_bb_631496ef<Class_ig_ca326427>> JopFf;
    private final Class_mu_a94f6370<Class_bb_631496ef<Class_ig_ca326427>> XGrSW;
    private final List<Class_ig_ca326427> RmnBU;
    private static long UZuoX;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ih_ba1deb13() {
        block4: {
            boolean bl;
            block6: {
                block5: {
                    long l = UZuoX ^ 0x46458C204547L;
                    this.WUEfC = new ConcurrentHashMap<String, Class_ig_ca326427>();
                    boolean bl2 = Class_ii_9b427eda.bjT();
                    try {
                        try {
                            this.JopFf = new Class_mu_a94f6370();
                            this.XGrSW = new Class_mu_a94f6370();
                            this.RmnBU = List.of(Class_ig_ca326427.PtFoz, Class_ig_ca326427.gsTXO, Class_ig_ca326427.hzckK, Class_ig_ca326427.eaYCr, Class_ig_ca326427.pHENl, Class_ig_ca326427.WSWRe, Class_ig_ca326427.OetCB);
                            if (Class_iS_888f260e.bwL() != null) break block4;
                            if (!bl2) break block5;
                        }
                        catch (MatchException matchException) {
                            throw Class_ih_ba1deb13.biR(matchException);
                        }
                        bl = false;
                        break block6;
                    }
                    catch (MatchException matchException) {
                        throw Class_ih_ba1deb13.biR(matchException);
                    }
                }
                bl = true;
            }
            Class_ii_9b427eda.bjS(bl);
        }
    }

    static {
        NativeLoader.doInit(Class_ih_ba1deb13.class);
        Class_ih_ba1deb13._40ff4fd37e63ca4e3dd1b28d8fef6d7f();
    }

    public native int biK();

    private static native MatchException biR(MatchException var0);

    public native Map<String, Class_ig_ca326427> biN();

    public native Class_mu_a94f6370<Class_bb_631496ef<Class_ig_ca326427>> biP();

    public native List<Class_ig_ca326427> biQ();

    public native Class_ij_d7bf2301 biL(String var1);

    public native void biM(Class_ig_ca326427 var1);

    public native Class_mu_a94f6370<Class_bb_631496ef<Class_ig_ca326427>> biO();

    private static native void _40ff4fd37e63ca4e3dd1b28d8fef6d7f();
}

