/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.util.math.Box
 */
package recovered.internal;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import recovered.internal.Class_kC_uk_36cdf684;
import recovered.internal.Class_mG_52c8d386;

public class Class_kC_8861e90b {
    private MatrixStack tknaZ;
    private Box LiWCJ;
    private Class_mG_52c8d386 kBIbs;
    private Class_mG_52c8d386 OQuAu;
    private Class_mG_52c8d386 tosoI;
    private boolean efFVS;
    private boolean ZSYRw;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_kC_8861e90b(MatrixStack matrixStack, Box box, Class_mG_52c8d386 class_mG_52c8d386, Class_mG_52c8d386 class_mG_52c8d3862, Class_mG_52c8d386 class_mG_52c8d3863, boolean bl, boolean bl2) {
        this.tknaZ = matrixStack;
        this.LiWCJ = box;
        this.kBIbs = class_mG_52c8d386;
        this.OQuAu = class_mG_52c8d3862;
        this.tosoI = class_mG_52c8d3863;
        this.efFVS = bl;
        this.ZSYRw = bl2;
    }

    public static Class_kC_uk_36cdf684 bSK(MatrixStack matrixStack, Box box, boolean bl, boolean bl2) {
        return Class_kC_8861e90b.bSL().dsE(matrixStack).dsF(box).dsJ(bl).dsK(bl2);
    }

    public static Class_kC_uk_36cdf684 bSL() {
        return new Class_kC_uk_36cdf684();
    }

    public Class_mG_52c8d386 bSO() {
        return this.kBIbs;
    }

    public MatrixStack bSM() {
        return this.tknaZ;
    }

    public boolean bSS() {
        return this.ZSYRw;
    }

    public Class_mG_52c8d386 bSQ() {
        return this.tosoI;
    }

    public Class_mG_52c8d386 bSP() {
        return this.OQuAu;
    }

    public boolean bSR() {
        return this.efFVS;
    }

    public Box bSN() {
        return this.LiWCJ;
    }
}

