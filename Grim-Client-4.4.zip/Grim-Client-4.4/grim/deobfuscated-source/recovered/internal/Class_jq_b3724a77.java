/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.model.PlayerEntityModel
 *  net.minecraft.util.Identifier
 *  org.joml.Matrix3x2f
 *  org.joml.Matrix3x2fc
 */
package recovered.internal;

import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fc;
import recovered.internal.Class_jr_25c15d18;
import recovered.internal.Class_lF_27593463;
import recovered.internal.Class_lJ_e4c3455b;
import recovered.internal.Class_lN_5af116ef;

public final class Class_jq_b3724a77
implements Class_lJ_e4c3455b<Class_jq_b3724a77> {
    private final Matrix3x2fc TxWCH;
    private final PlayerEntityModel WFZJz;
    private final Identifier VuTGU;
    private final float JIkfK;
    private final float PvVIE;
    private final float DWdzr;
    private final float bDAmU;
    private float KjnZj = 1.0f;
    private float bZFHi;
    private float lgJDS;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    @Override
    public Class_lN_5af116ef batchKey() {
        return Class_lN_5af116ef.immediate();
    }

    public Class_jq_b3724a77(Matrix3x2fc matrix3x2fc, PlayerEntityModel playerEntityModel, Identifier identifier, float f, float f2, float f3, float f4) {
        this.TxWCH = new Matrix3x2f(matrix3x2fc);
        this.WFZJz = playerEntityModel;
        this.VuTGU = identifier;
        this.JIkfK = f;
        this.PvVIE = f2;
        this.DWdzr = f3;
        this.bDAmU = f4;
    }

    @Override
    public void execute() {
        Class_jr_25c15d18.bFt(this.TxWCH, this.WFZJz, this.VuTGU, this.KjnZj, this.bZFHi, this.lgJDS, this.JIkfK, this.PvVIE, this.DWdzr, this.bDAmU);
    }

    public Class_jq_b3724a77 bFq(float f) {
        this.bZFHi = f;
        return this;
    }

    public Class_jq_b3724a77 bFr(float f) {
        this.lgJDS = f;
        return this;
    }

    public Class_jq_b3724a77 bFp(float f, float f2) {
        this.bZFHi = f;
        this.lgJDS = f2;
        return this;
    }

    public Class_jq_b3724a77 bFs() {
        Class_lF_27593463.cfA(this);
        return this;
    }

    public Class_jq_b3724a77 bFo(float f) {
        this.KjnZj = f;
        return this;
    }
}

