/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

public final class Class_ac_rM_8a33ea18
extends Enum<Class_ac_rM_8a33ea18> {
    public static /* enum */ Class_ac_rM_8a33ea18 iKApR;
    public static /* enum */ Class_ac_rM_8a33ea18 WpzHJ;
    private static Class_ac_rM_8a33ea18[] pHROC;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_ac_rM_8a33ea18.class);
        Class_ac_rM_8a33ea18._98cd22d8c5e2a65d9859e3c17bcd865c();
    }

    public static native Class_ac_rM_8a33ea18[] values();

    public static native Class_ac_rM_8a33ea18 valueOf(String var0);

    private static native void _98cd22d8c5e2a65d9859e3c17bcd865c();

    private static native Class_ac_rM_8a33ea18[] dmJ();

    private static native String dmK(byte[] var0);
}

