/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_aK_814f8910;
import recovered.internal.Class_aP_5a8d73eb;
import recovered.internal.Class_aR_rY_47ff8b41;
import recovered.internal.Class_aV_88c1c917;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_ap_f3b7a87f;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mu_a94f6370;
import recovered.internal.Class_pF_d0757029;
import recovered.internal.Class_py_edabaa53;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_aR_f155c393
extends Class_az_a4990dcf {
    private static float hzbfp = 4.0f;
    private static float Mmoww = 10.0f;
    private static float SKUcd = 7.5f;
    private final Class_rk_bf8630d1 Dtfzy;
    private final Class_mu_a94f6370<Class_aj_95d0a719> ApoXb;
    private final Class_aP_5a8d73eb xhIWB;
    private final Class_az_a4990dcf znWUp;
    private final Class_aV_88c1c917 LlOkR;
    private final Class_aK_814f8910 IctAz;
    private Class_ap_f3b7a87f BWexP;
    private Class_pF_d0757029 cPSPd;
    private float CHJJM;
    private boolean AnANT;
    private boolean wpCQg;
    private float LqCSm;
    private float XpSnM;
    private boolean GxspQ;
    private static boolean pSyCD;
    private static long qFOrL;
    private static String FssQU;
    private static long[] nJxdY;
    private static Integer[] oOUFn;
    private static Map lLSaC;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aR_f155c393(float f, float f2) {
        long l = qFOrL ^ 0x1BDB60078D1CL;
        this.Dtfzy = new Class_rk_bf8630d1((int)Class_aR_f155c393.yL("a", (int)5865, (long)(0x455B7E03099C9296L ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        this.ApoXb = new Class_mu_a94f6370();
        this.cPSPd = Class_pF_d0757029.JMCCO;
        this.BcpIo = 175.0f;
        this.WjISQ = f2;
        this.CHJJM = f;
        this.xhIWB = new Class_aP_5a8d73eb();
        this.znWUp = new Class_aR_rY_47ff8b41(this).sP((int)Class_aR_f155c393.yL("a", (int)30249, (long)(0x16C4553E6C7DF257L ^ l))).sS(true).sQ(false);
        this.LlOkR = new Class_aV_88c1c917().zc(this::yb);
        this.IctAz = new Class_aK_814f8910(this::yj, this::yn, this::yl, this::yk, this::ym, this::ya);
        this.xhIWB.xt(this.cPSPd);
        this.xhIWB.dY();
        this.AnANT = true;
    }

    static {
        NativeLoader.doInit(Class_aR_f155c393.class);
        Class_aR_f155c393._b932e47186be4624228d4ae33ae42086();
    }

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    private native boolean yl();

    private native void yh();

    @Override
    public native boolean dm(int var1, int var2, int var3);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private native List<Class_py_edabaa53> yi();

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean fC(double var1, double var3, double var5);

    public native Class_aV_88c1c917 ys();

    public native boolean yx();

    public native float yz();

    public native float yy();

    public native boolean yw();

    @Override
    public native boolean dB(double var1, double var3, Class_mA_32d8a5f2 var5, double var6, double var8);

    private native void yb(Class_py_edabaa53 var1, double var2, double var4);

    @Override
    public native boolean eK(char var1);

    @Override
    public native boolean oi();

    @Override
    protected native boolean nZ();

    private static native void _b932e47186be4624228d4ae33ae42086();

    private native void xV(Class_lC_5322e8cf var1, Runnable var2, Runnable var3);

    private native void xZ(double var1, double var3);

    private native void ye(Class_aj_95d0a719 var1);

    public native Class_aR_f155c393 yg(boolean var1);

    public native Class_aP_5a8d73eb yq();

    private native Class_pF_d0757029 yj();

    private native void ya(double var1, double var3);

    private native boolean xY(double var1, double var3);

    private native float xW();

    private native boolean yf();

    private native boolean yk();

    private native float xX();

    private static native void yd(Class_aR_f155c393 var0, Class_lc_b8480f87 var1);

    public native Class_rk_bf8630d1 yo();

    public native Class_mu_a94f6370<Class_aj_95d0a719> yp();

    private native void ym(boolean var1);

    public native Class_az_a4990dcf yr();

    public native Class_aK_814f8910 yt();

    public native Class_ap_f3b7a87f yu();

    private static native CallSite yL(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native float yv();

    public static native void yc();

    private native void yn(Class_pF_d0757029 var1);

    private static native MatchException yH(MatchException var0);

    public native boolean yA();

    public static native boolean yF();

    public static native boolean yG();

    private native /* synthetic */ void yD(Class_lC_5322e8cf var1);

    private static native String yI(byte[] var0);

    private static native int yJ(int var0, long var1);

    private static native int yK(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native /* synthetic */ void yB(Class_ap_f3b7a87f var1);

    public static native void yE(boolean var0);

    private native /* synthetic */ void yC(Class_lC_5322e8cf var1, float var2, float var3);
}

