/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Items
 *  net.minecraft.util.math.Vec2f
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_jI_616cf0dd;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.modules.AmbienceModule;

class Class_dn_sF_dea815f0 {
    private final Vec3d MZUGo;
    private final long SAKLk;
    private boolean uAOSS;
    private final Class_rk_bf8630d1 DUqGa;
    private static final long HGXbz = Class_gb_9d201141.aYR(9072864521275221345L, 5003618611436866665L, MethodHandles.lookup().lookupClass()).a(138821822091752L);
    private static final long jYWIl;
    private static final long ZOVgw;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_dn_sF_dea815f0(Vec3d vec3d) {
        long l = HGXbz ^ 0x341688605BFDL;
        this.uAOSS = false;
        this.DUqGa = new Class_rk_bf8630d1((int)jYWIl);
        this.MZUGo = vec3d;
        this.SAKLk = System.currentTimeMillis();
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = HGXbz ^ 0x49D07AB23E9BL;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        long l2 = -4365810018466571872L;
        byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
        jYWIl = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
        Cipher cipher2 = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory2 = SecretKeyFactory.getInstance("DES");
        byte[] byArray4 = new byte[8];
        byte[] byArray5 = byArray4;
        byArray4[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher2.init(2, (Key)secretKeyFactory2.generateSecret(new DESKeySpec(byArray5)), new IvParameterSpec(new byte[8]));
                long l3 = -8523123680099423305L;
                byte[] byArray6 = cipher2.doFinal(new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3});
                ZOVgw = ((long)byArray6[0] & 0xFFL) << 56 | ((long)byArray6[1] & 0xFFL) << 48 | ((long)byArray6[2] & 0xFFL) << 40 | ((long)byArray6[3] & 0xFFL) << 32 | ((long)byArray6[4] & 0xFFL) << 24 | ((long)byArray6[5] & 0xFFL) << 16 | ((long)byArray6[6] & 0xFFL) << 8 | (long)byArray6[7] & 0xFFL;
                return;
            }
            byArray5 = byArray5;
            byArray5[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    private static MatchException doL(MatchException matchException) {
        return matchException;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean doK() {
        float f;
        block5: {
            Class_iS_888f260e[] class_iS_888f260eArray;
            block4: {
                long l = HGXbz ^ 0x5B07B061B7DCL;
                class_iS_888f260eArray = AmbienceModule.afl();
                float f2 = this.DUqGa.dhj() - 0.0f;
                f = f2 == 0.0f ? 0 : (f2 > 0.0f ? 1 : -1);
                if (class_iS_888f260eArray != null) break block4;
                if (f != false) break block5;
                f = (float)this.uAOSS;
            }
            if (class_iS_888f260eArray != null) return (boolean)f;
            if (f != false) {
                f = 1.0f;
                return (boolean)f;
            }
        }
        f = 0.0f;
        return (boolean)f;
    }

    public void doJ(Class_lC_5322e8cf class_lC_5322e8cf, int n) {
        Vec2f vec2f;
        block6: {
            block5: {
                long l = HGXbz ^ 0x42265D47A192L;
                Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
                boolean bl = this.uAOSS;
                if (class_iS_888f260eArray == null) {
                    bl = !bl;
                }
                this.DUqGa.dhc(bl);
                this.DUqGa.dhs(!this.uAOSS ? Class_rj_b691f4f7.XzDkv : Class_rj_b691f4f7.AYqck);
                long l2 = System.currentTimeMillis() - this.SAKLk;
                if (class_iS_888f260eArray != null) break block5;
                if (l2 <= (long)n * ZOVgw) break block6;
                this.uAOSS = true;
            }
            this.DUqGa.dhd(0.0f);
        }
        if ((vec2f = Class_jI_616cf0dd.bIw(this.MZUGo)) == null) {
            return;
        }
        float f = 25.0f;
        float f2 = vec2f.x - f / 2.0f;
        float f3 = vec2f.y;
        float f4 = f2 + Class_jf_d1c4f950.bAH(16.0f, f);
        float f5 = f3 + Class_jf_d1c4f950.bAH(16.0f, f);
        float f6 = this.DUqGa.dhj();
        Class_jH_c1172273.bId(class_lC_5322e8cf, f2 + f / 2.0f, f3 + f / 2.0f, 0.5f + 0.5f * f6);
        class_lC_5322e8cf.ccW(f2, f3, f, f, f6, 0.0f, Class_ld_bb1690e1.all(f / 2.0f), 3.0f);
        class_lC_5322e8cf.cdZ(Items.FIREWORK_ROCKET, f4, f5, 1.0f).bGv();
        Class_jH_c1172273.bIf();
    }
}

