/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.textures.GpuTexture
 *  net.minecraft.client.gl.Framebuffer
 *  net.minecraft.client.gl.SimpleFramebuffer
 */
package recovered.internal;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import java.lang.invoke.MethodHandles;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jm_b3d8cd6c;
import recovered.internal.Class_lT_411dd062;

public final class Class_jp_fe2807d9
extends SimpleFramebuffer {
    public boolean LHtaR;
    private final boolean mYUfR;
    private static final long OhKWC = Class_gb_9d201141.aYR(1601633786730209997L, 7273737541638152616L, MethodHandles.lookup().lookupClass()).a(133707839667403L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public int bFm() {
        return Class_lT_411dd062.ciQ().nativeTextureId(this.getDepthAttachment());
    }

    public void bFk() {
        block8: {
            GpuTexture gpuTexture;
            block7: {
                Class_jp_fe2807d9 class_jp_fe2807d9;
                Class_iS_888f260e[] class_iS_888f260eArray;
                block6: {
                    block5: {
                        block4: {
                            long l = OhKWC ^ 0x3A056BE72FA9L;
                            gpuTexture = this.getColorAttachment();
                            class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                            if (class_iS_888f260eArray == null) break block4;
                            if (gpuTexture != null) break block5;
                            this.LHtaR = false;
                        }
                        return;
                    }
                    class_jp_fe2807d9 = this;
                    if (class_iS_888f260eArray == null) break block6;
                    if (!class_jp_fe2807d9.mYUfR) break block7;
                    class_jp_fe2807d9 = this;
                }
                if (class_jp_fe2807d9.getDepthAttachment() == null) break block7;
                RenderSystem.getDevice().createCommandEncoder().clearColorAndDepthTextures(gpuTexture, 0, this.getDepthAttachment(), 1.0);
                if (class_iS_888f260eArray != null) break block8;
            }
            RenderSystem.getDevice().createCommandEncoder().clearColorTexture(gpuTexture, 0);
        }
        this.LHtaR = false;
    }

    public void bFj() {
        block11: {
            block10: {
                int n;
                int n2;
                block9: {
                    int n3;
                    int n4;
                    block8: {
                        Class_iS_888f260e[] class_iS_888f260eArray;
                        block6: {
                            block7: {
                                block5: {
                                    block4: {
                                        long l = OhKWC ^ 0x1858EC674B75L;
                                        Framebuffer framebuffer = ClientMain.dlmvG.getFramebuffer();
                                        n2 = framebuffer.textureWidth;
                                        class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                                        n = framebuffer.textureHeight;
                                        n4 = n2;
                                        if (class_iS_888f260eArray == null) break block4;
                                        if (n4 <= 0) break block5;
                                        n4 = n;
                                    }
                                    if (class_iS_888f260eArray == null) break block6;
                                    if (n4 > 0) break block7;
                                }
                                return;
                            }
                            n4 = n2;
                        }
                        n3 = this.textureWidth;
                        if (class_iS_888f260eArray == null) break block8;
                        if (n4 != n3) break block9;
                        n4 = n;
                        n3 = this.textureHeight;
                    }
                    if (n4 == n3) break block10;
                }
                this.resize(n2, n);
                this.bFk();
            }
            if (Class_iS_888f260e.bwL() != null) break block11;
            Class_jm_b3d8cd6c.bDY(new Class_iS_888f260e[1]);
        }
    }

    private static MatchException bFn(MatchException matchException) {
        return matchException;
    }

    public int bFl() {
        return Class_lT_411dd062.ciQ().nativeTextureId(this.getColorAttachment());
    }

    public Class_jp_fe2807d9(String string, boolean bl) {
        block0: {
            long l = OhKWC ^ 0x645CBE577A3L;
            Class_iS_888f260e[] class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
            super(string, ClientMain.dlmvG.getWindow().getFramebufferWidth(), ClientMain.dlmvG.getWindow().getFramebufferHeight(), bl);
            Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
            this.mYUfR = bl;
            this.bFj();
            this.bFk();
            if (class_iS_888f260eArray2 != null) break block0;
            Class_iS_888f260e.bwK("YUp1ac");
        }
    }
}

