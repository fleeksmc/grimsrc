/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_hJ_a20df6c5;
import recovered.internal.Class_hL_db8a30f6;
import recovered.internal.Class_hX_15329af5;
import recovered.internal.Class_hZ_076851ce;

public class Class_hV_8bb67f4f {
    private static long CjUfr;
    private static String[] ItxYX;
    private static String[] tMXNc;
    private static Map LnNrY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_hV_8bb67f4f.class);
        Class_hV_8bb67f4f._9aa1e13785ce9e8c408be64da5d6938f();
    }

    public native Class_hZ_076851ce bfU();

    private static native /* synthetic */ void bfW(Class_hX_15329af5 var0);

    private static native /* synthetic */ void bfX(Class_hL_db8a30f6 var0);

    private static native Object bgc(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native List<String> bfV();

    private static native /* synthetic */ Class_hJ_a20df6c5 bfY(String var0);

    private static native CallSite bgd(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native String bga(byte[] var0);

    private static native String bgb(int var0, long var1);

    private static native MatchException bfZ(MatchException var0);

    private static native void _9aa1e13785ce9e8c408be64da5d6938f();
}

