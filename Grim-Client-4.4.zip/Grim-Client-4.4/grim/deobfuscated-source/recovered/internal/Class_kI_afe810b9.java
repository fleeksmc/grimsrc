/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.VertexFormat$DrawMode
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.util.BufferAllocator
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.util.math.Box
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 */
package recovered.internal;

import com.mojang.blaze3d.vertex.VertexFormat;
import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_kC_8861e90b;
import recovered.internal.Class_kJ_a7cdce3d;
import recovered.internal.Class_kQ_19441787;
import recovered.internal.Class_kR_e9b8cad1;
import recovered.internal.Class_kS_ba7468b5;
import recovered.internal.Class_lF_27593463;
import recovered.internal.Class_lT_411dd062;
import recovered.internal.Class_lh_fe04e581;
import recovered.internal.Class_mG_52c8d386;

public class Class_kI_afe810b9
extends Class_kQ_19441787<Class_kC_8861e90b> {
    private static final Class_kS_ba7468b5 ycoVK;
    private final BufferAllocator lhPSr;
    private BufferBuilder kRoQN;
    private boolean oiwQk;
    private Class_kS_ba7468b5 ndzku;
    private static final long LucMv;
    private static final long cFNAk;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_kI_afe810b9() {
        long l = LucMv ^ 0x6B1AB6BB2FF2L;
        this.lhPSr = new BufferAllocator((int)cFNAk);
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        LucMv = Class_gb_9d201141.aYR(74625261366909609L, -8283339496095112206L, MethodHandles.lookup().lookupClass()).a(7746435210437L);
        long l = LucMv ^ 0x5C6DAA652290L;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                long l2 = -2376035461498767251L;
                byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
                cFNAk = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
                ycoVK = Class_kS_ba7468b5.bVE().duk(Class_lh_fe04e581.aApMr).duo(false).dul(true).dun(false).dup();
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    @Override
    public void flush() {
        this.bVj();
        this.bTT();
        this.bVi(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        this.bTU();
    }

    @Override
    public Class_kS_ba7468b5 defaultState() {
        return ycoVK;
    }

    public void bTS(Class_kC_8861e90b class_kC_8861e90b) {
        block6: {
            int n;
            int n2;
            Box box;
            MatrixStack matrixStack;
            block5: {
                long l = LucMv ^ 0x26A013D6220BL;
                this.bVj();
                matrixStack = class_kC_8861e90b.bSM();
                boolean bl = Class_kJ_a7cdce3d.bUi();
                int n3 = class_kC_8861e90b.bSO().coh();
                box = class_kC_8861e90b.bSN();
                this.bTV(matrixStack, box, n3);
                n2 = class_kC_8861e90b.bSR();
                if (!bl) {
                    if (n2 != 0) {
                        n = class_kC_8861e90b.bSP().coh();
                        this.bTW(matrixStack, box, n);
                    }
                    n2 = class_kC_8861e90b.bSS();
                }
                if (bl) break block5;
                if (n2 == 0) break block6;
                n2 = class_kC_8861e90b.bSQ().coh();
            }
            n = n2;
            this.bTX(matrixStack, box, n);
        }
    }

    @Override
    public void startBatch(Class_kS_ba7468b5 class_kS_ba7468b5) {
        this.ndzku = class_kS_ba7468b5;
        Class_lT_411dd062.ciQ().setLineSmoothing(true);
        this.bVi(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
    }

    @Override
    public void endBatch() {
        this.bVj();
        this.bTT();
        this.bTU();
        Class_lT_411dd062.ciQ().setLineSmoothing(false);
        this.bVl();
    }

    private static Throwable bTZ(Throwable throwable) {
        return throwable;
    }

    private void bTV(MatrixStack matrixStack, Box box, int n) {
        float f = (float)box.minX;
        float f2 = (float)box.minY;
        float f3 = (float)box.minZ;
        float f4 = (float)box.maxX;
        float f5 = (float)box.maxY;
        float f6 = (float)box.maxZ;
        float f7 = (f + f4) * 0.5f;
        float f8 = (f3 + f6) * 0.5f;
        Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
        this.WfBOj.vertex((Matrix4fc)matrix4f, f, f2, f3).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f4, f2, f3).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f4, f2, f3).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f4, f2, f6).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f4, f2, f6).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f, f2, f6).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f, f2, f6).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f, f2, f3).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f, f2, f3).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f7, f5, f8).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f4, f2, f3).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f7, f5, f8).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f4, f2, f6).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f7, f5, f8).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f, f2, f6).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f7, f5, f8).color(n);
    }

    private void bTX(MatrixStack matrixStack, Box box, int n) {
        float f = (float)box.minX;
        float f2 = (float)box.minY;
        float f3 = (float)box.minZ;
        float f4 = (float)box.maxX;
        float f5 = (float)box.maxY;
        float f6 = (float)box.maxZ;
        float f7 = (f + f4) * 0.5f;
        float f8 = (f3 + f6) * 0.5f;
        Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
        this.WfBOj.vertex((Matrix4fc)matrix4f, f, f2, f3).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f4, f2, f6).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f4, f2, f3).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f, f2, f6).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f7, f2, f8).color(n);
        this.WfBOj.vertex((Matrix4fc)matrix4f, f7, f5, f8).color(n);
    }

    /*
     * Unable to fully structure code
     */
    private void bTT() {
        block14: {
            block12: {
                var1_1 = Class_kI_afe810b9.LucMv ^ 9133064678466L;
                var4_2 = this.WfBOj.endNullable();
                var3_3 = Class_kJ_a7cdce3d.bUj();
                try {
                    v0 = var4_2;
                    if (var3_3) {
                        if (v0 != null) {
                            var5_4 = Class_kR_e9b8cad1.MTMwE.bUZ(this.ndzku);
                            Class_lF_27593463.cfW(var5_4, var4_2);
                        }
                        v0 = var4_2;
                    }
                    if (!var3_3) break block12;
                }
                catch (Throwable var5_5) {
                    block13: {
                        v1 = var4_2;
                        if (!var3_3) ** GOTO lbl18
                        if (v1 == null) break block13;
                        try {
                            v1 = var4_2;
lbl18:
                            // 2 sources

                            v1.close();
                        }
                        catch (Throwable var6_6) {
                            var5_5.addSuppressed(var6_6);
                        }
                    }
                    throw var5_5;
                }
                if (v0 == null) break block14;
                v0 = var4_2;
            }
            v0.close();
        }
    }

    /*
     * Unable to fully structure code
     */
    private void bTU() {
        block14: {
            block16: {
                block12: {
                    block13: {
                        var1_1 = Class_kI_afe810b9.LucMv ^ 42963436514698L;
                        var3_2 = Class_kJ_a7cdce3d.bUj();
                        v0 = this;
                        if (!var3_2) break block13;
                        if (!v0.oiwQk) break block14;
                        v0 = this;
                    }
                    var4_3 = v0.kRoQN.endNullable();
                    try {
                        v1 = var4_3;
                        if (var3_2) {
                            if (v1 != null) {
                                var5_4 = Class_kR_e9b8cad1.meLIO.bUZ(this.ndzku);
                                Class_lF_27593463.cfW(var5_4, var4_3);
                            }
                            v1 = var4_3;
                        }
                        if (!var3_2) break block12;
                    }
                    catch (Throwable var5_5) {
                        block15: {
                            v2 = var4_3;
                            if (!var3_2) ** GOTO lbl23
                            if (v2 == null) break block15;
                            try {
                                v2 = var4_3;
lbl23:
                                // 2 sources

                                v2.close();
                            }
                            catch (Throwable var6_6) {
                                var5_5.addSuppressed(var6_6);
                            }
                        }
                        throw var5_5;
                    }
                    if (v1 == null) break block16;
                    v1 = var4_3;
                }
                v1.close();
            }
            this.oiwQk = false;
        }
    }

    private void bTY(Matrix4f matrix4f, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, int n) {
        this.kRoQN.vertex((Matrix4fc)matrix4f, f, f2, f3).color(n);
        this.kRoQN.vertex((Matrix4fc)matrix4f, f4, f5, f6).color(n);
        this.kRoQN.vertex((Matrix4fc)matrix4f, f7, f8, f9).color(n);
    }

    private void bTW(MatrixStack matrixStack, Box box, int n) {
        long l = LucMv ^ 0x68D7E7E37803L;
        boolean bl = Class_kJ_a7cdce3d.bUi();
        int n2 = this.oiwQk;
        if (!bl) {
            if (n2 == 0) {
                this.kRoQN = new BufferBuilder(this.lhPSr, VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
                this.oiwQk = true;
            }
            n2 = Class_mG_52c8d386.cnQ(n).cob(0.5f).coh();
        }
        int n3 = n2;
        float f = (float)box.minX;
        float f2 = (float)box.minY;
        float f3 = (float)box.minZ;
        float f4 = (float)box.maxX;
        float f5 = (float)box.maxY;
        float f6 = (float)box.maxZ;
        float f7 = (f + f4) * 0.5f;
        float f8 = (f3 + f6) * 0.5f;
        Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
        this.bTY(matrix4f, f, f2, f3, f4, f2, f3, f4, f2, f6, n3);
        this.bTY(matrix4f, f, f2, f3, f4, f2, f6, f, f2, f6, n3);
        this.bTY(matrix4f, f, f2, f3, f4, f2, f3, f7, f5, f8, n3);
        this.bTY(matrix4f, f4, f2, f3, f4, f2, f6, f7, f5, f8, n3);
        this.bTY(matrix4f, f4, f2, f6, f, f2, f6, f7, f5, f8, n3);
        this.bTY(matrix4f, f, f2, f6, f, f2, f3, f7, f5, f8, n3);
    }
}

