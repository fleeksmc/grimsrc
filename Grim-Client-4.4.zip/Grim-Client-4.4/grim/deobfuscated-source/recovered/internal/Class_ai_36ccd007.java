/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_aj_95d0a719;

public interface Class_ai_36ccd007 {
    public void run(Class_aj_95d0a719 var1);
}

