/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.core.ClientMain;
import recovered.internal.Class_Z_a19ce218;
import recovered.internal.Class_bS_979bca5c;
import recovered.internal.Class_cv_f4b0140a;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_rj_b691f4f7;

public class Class_bR_961dd2c9
extends Class_bS_979bca5c {
    private String tMmUB = "";
    private String MtpnS = "";
    private int FaxAk = -1;
    private int[] soyDT;
    private boolean sxniw = false;
    private int gCSoD = -1;
    private Class_mG_52c8d386 Bewjf;
    protected Class_Z_a19ce218 QbCNz;
    private static final long WvFup = Class_gb_9d201141.aYR(613445611563642980L, -4291922670228144719L, MethodHandles.lookup().lookupClass()).a(227490622051490L);
    private static final long YyRSM;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bR_961dd2c9(Class_cv_f4b0140a class_cv_f4b0140a, Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_cv_f4b0140a, class_mr_7eac5189);
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = WvFup ^ 0x5799FFE8E40EL;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                long l2 = 1842902776971313975L;
                byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
                YyRSM = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    @Override
    public boolean MH() {
        long l = WvFup ^ 0x1E01C97C4B0EL;
        int n = Class_bS_979bca5c.NS();
        boolean bl = this.FaxAk;
        if (n == 0) {
            bl = !bl;
        }
        return bl;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void MG(Class_lC_5322e8cf var1_1, Class_ii_9b427eda var2_2) {
        block23: {
            block22: {
                block21: {
                    block20: {
                        block19: {
                            block18: {
                                block17: {
                                    block16: {
                                        block15: {
                                            block14: {
                                                var3_3 = Class_bR_961dd2c9.WvFup ^ 18699774226881L;
                                                var5_4 = Class_bS_979bca5c.NR();
                                                v0 = this;
                                                if (var5_4 == 0) break block14;
                                                if (v0.Bewjf == null) break block15;
                                                v0 = this;
                                            }
                                            if (v0.soyDT != null) break block16;
                                        }
                                        return;
                                    }
                                    var6_5 = ClientMain.dlK().RC();
                                    var7_6 = var6_5.RW();
                                    var8_7 = var6_5.RX();
                                    var9_8 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
                                    var10_9 = Class_lE_06fbe260.WTzbi.bYM(6.0f);
                                    v1 = this;
                                    if (var5_4 == 0) break block17;
                                    if (v1.QbCNz != null) break block18;
                                    v1 = this;
                                }
                                v1.QbCNz = new Class_Z_a19ce218(var10_9, 5.0f, (int)Class_bR_961dd2c9.YyRSM, Class_rj_b691f4f7.Zotpp);
                            }
                            var11_10 = 255.0f * this.dExGi.dhj();
                            var12_11 = 20.0f * this.dExGi.dhj();
                            v2 = this;
                            if (var5_4 == 0) break block19;
                            if (!v2.sxniw) break block20;
                            this.QbCNz.kS(false, Class_mG_52c8d386.hoGuU.coa(var11_10));
                            v2 = this;
                        }
                        v2.QbCNz.kO(this.FaxAk);
                    }
                    var13_12 = var9_8.cap(this.soyDT);
                    var14_13 = var10_9.cao(this.tMmUB);
                    var15_14 = var10_9.cao(this.MtpnS);
                    var16_15 = String.valueOf(this.FaxAk);
                    v3 = this;
                    if (var5_4 == 0) ** GOTO lbl43
                    if (v3.sxniw) {
                        v3 = this;
lbl43:
                        // 2 sources

                        v4 = v3.QbCNz.kN();
                    } else {
                        v4 = var10_9.cao(var16_15);
                    }
                    var17_16 = v4;
                    var18_17 = this.gCSoD > 0 ? var10_9.cao("0".repeat(this.gCSoD)) : var17_16;
                    var19_18 = var14_13 + var15_14 + var18_17;
                    var20_19 = 3.5f;
                    var21_20 = var7_6 - 16.0f + var12_11;
                    var22_21 = var8_7 + 3.5f;
                    var23_22 = 2.0f * var20_19 + var19_18;
                    var24_23 = 8.0f;
                    this.fGWTH.NU(var23_22 + 8.0f + var13_12 + 5.0f, 15.0f);
                    var1_1.cdg(var21_20, var22_21, var23_22, var24_23, Class_ld_bb1690e1.all(3.0f), this.Bewjf.coa(var11_10));
                    var25_24 = var8_7 + 5.5f;
                    var26_25 = var14_13 + var17_16 + var15_14;
                    var28_27 = var27_26 = var21_20 + (var23_22 - var26_25) * 0.5f;
                    var1_1.cez(var10_9, this.tMmUB, var28_27, var25_24, Class_mG_52c8d386.hoGuU.coa(var11_10));
                    var29_28 = var28_27 + var14_13;
                    v5 = this;
                    if (var5_4 == 0) break block21;
                    if (!v5.sxniw) break block22;
                    this.QbCNz.sW(var29_28, var25_24);
                    v5 = this;
                }
                v5.QbCNz.su(var1_1);
                if (var5_4 != 0) break block23;
            }
            var1_1.cez(var10_9, var16_15, var29_28, var25_24, Class_mG_52c8d386.hoGuU.coa(var11_10));
        }
        var30_29 = var29_28 + var17_16;
        var1_1.cez(var10_9, this.MtpnS, var30_29, var25_24, Class_mG_52c8d386.hoGuU.coa(var11_10));
        var31_30 = var2_2.bjb().coa(255.0f * this.dExGi.dhj());
        var32_31 = var7_6 + 25.0f - 10.0f * this.dExGi.dhj() + var19_18;
        var1_1.ceA(var9_8, this.soyDT, var32_31, var8_7 + 5.0f, var31_30);
    }

    public void NL(String string, String string2, int n, int[] nArray, Class_mG_52c8d386 class_mG_52c8d386, boolean bl, int n2) {
        this.tMmUB = string;
        this.MtpnS = string2;
        this.FaxAk = n;
        this.soyDT = nArray;
        this.Bewjf = class_mG_52c8d386;
        this.sxniw = bl;
        this.gCSoD = n2;
    }

    public void NK(String string, int n, int[] nArray, Class_mG_52c8d386 class_mG_52c8d386, boolean bl) {
        this.NL("", string, n, nArray, class_mG_52c8d386, bl, this.gCSoD);
    }

    private static MatchException NM(MatchException matchException) {
        return matchException;
    }

    public void NJ(String string, int n, int[] nArray, Class_mG_52c8d386 class_mG_52c8d386, boolean bl, int n2) {
        this.NL("", string, n, nArray, class_mG_52c8d386, bl, n2);
    }
}

