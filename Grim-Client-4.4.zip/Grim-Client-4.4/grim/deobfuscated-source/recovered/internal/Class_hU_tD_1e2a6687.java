/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import recovered.core.NativeLoader;
import recovered.internal.Class_hJ_a20df6c5;
import recovered.internal.Class_hK_37a4c9e8;
import recovered.internal.Class_hU_be18db32;

class Class_hU_tD_1e2a6687
implements Class_hK_37a4c9e8 {
    final List XkoLj;
    private static long Ktmcl;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Ignored method signature, as it can't be verified against descriptor
     */
    Class_hU_tD_1e2a6687(Class_hU_be18db32 class_hU_be18db32, List list) {
        this.XkoLj = list;
    }

    static {
        NativeLoader.doInit(Class_hU_tD_1e2a6687.class);
        Class_hU_tD_1e2a6687._50787977f06a1d9c59bf65fd93e67ec0();
    }

    @Override
    public native Class_hJ_a20df6c5 validate(String var1);

    @Override
    public native List<String> suggestions(String var1);

    private static native MatchException dpH(MatchException var0);

    private static native boolean dpG(String var0, String var1);

    private static native void _50787977f06a1d9c59bf65fd93e67ec0();
}

