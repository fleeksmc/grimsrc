/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_py_edabaa53;

@FunctionalInterface
public interface Class_aU_b708ac4e {
    public void startDrag(Class_py_edabaa53 var1, double var2, double var4);
}

