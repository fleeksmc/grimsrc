/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

public final class Class_gd_2ebaf9bc
extends Enum<Class_gd_2ebaf9bc> {
    public static /* enum */ Class_gd_2ebaf9bc ipLAD;
    public static /* enum */ Class_gd_2ebaf9bc zlSAY;
    private static /* synthetic */ Class_gd_2ebaf9bc[] sGkHu;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_gd_2ebaf9bc.class);
        Class_gd_2ebaf9bc._e41e234a93f47358128ee75c5f1c7220();
    }

    public static native Class_gd_2ebaf9bc[] values();

    public static native Class_gd_2ebaf9bc valueOf(String var0);

    private static native String aZp(byte[] var0);

    private static native /* synthetic */ Class_gd_2ebaf9bc[] aZo();

    private static native void _e41e234a93f47358128ee75c5f1c7220();
}

