/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.listener.PacketListener
 *  net.minecraft.network.packet.Packet
 */
package recovered.internal;

import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import recovered.internal.Class_gL_cf24808b;

public class Class_gL_tk_bd66c550
extends Class_gL_cf24808b {
    private final PacketListener OXWCb;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public <T extends PacketListener> Class_gL_tk_bd66c550(Packet<T> packet, PacketListener packetListener) {
        super(packet);
        this.OXWCb = packetListener;
    }

    public PacketListener dpn() {
        return this.OXWCb;
    }
}

