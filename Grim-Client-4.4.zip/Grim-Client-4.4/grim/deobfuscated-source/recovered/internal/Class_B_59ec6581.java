/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_ak_2ff604c7;
import recovered.internal.Class_ap_f3b7a87f;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_cH_5b9db066;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_B_59ec6581
extends Class_ak_2ff604c7<Class_cH_5b9db066> {
    private boolean ysrqV;
    private Class_ap_f3b7a87f DhMoP;
    private final Class_rk_bf8630d1 gcCYq;
    private static long tjVao;
    private static String[] QiwoD;
    private static String[] gWNPB;
    private static Map kqufA;
    private static long GlDJF;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native String fl(int var0, long var1);

    public Class_B_59ec6581(Class_cH_5b9db066 class_cH_5b9db066, Class_az_a4990dcf class_az_a4990dcf) {
        long l = tjVao ^ 0x4C5063F7C93AL;
        super(class_cH_5b9db066, class_az_a4990dcf);
        this.gcCYq = new Class_rk_bf8630d1((int)GlDJF).dhs(Class_rj_b691f4f7.UPXqT);
    }

    static {
        NativeLoader.doInit(Class_B_59ec6581.class);
        Class_B_59ec6581._584b1d00d1b697f771c40bf5c46eca61();
    }

    @Override
    public native float dn();

    private static native String fk(byte[] var0);

    private static native CallSite fn(MethodHandles.Lookup var0, String var1, MethodType var2);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private native /* synthetic */ void fi();

    private static native Object fm(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    @Override
    public native void dY();

    private static native MatchException fj(MatchException var0);

    private static native void _584b1d00d1b697f771c40bf5c46eca61();
}

