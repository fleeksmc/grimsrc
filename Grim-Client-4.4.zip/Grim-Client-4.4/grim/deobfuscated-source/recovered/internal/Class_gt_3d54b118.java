/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 */
package recovered.internal;

import net.minecraft.client.util.math.MatrixStack;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gt_3d54b118
extends Class_hH_ae8f8f77 {
    private MatrixStack ekSmw;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public MatrixStack bbt() {
        return this.ekSmw;
    }

    public Class_gt_3d54b118(MatrixStack matrixStack) {
        this.ekSmw = matrixStack;
    }
}

