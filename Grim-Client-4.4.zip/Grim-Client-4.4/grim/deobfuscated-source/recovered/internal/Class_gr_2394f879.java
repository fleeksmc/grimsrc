/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockState
 */
package recovered.internal;

import net.minecraft.block.BlockState;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gr_2394f879
extends Class_hH_ae8f8f77 {
    private BlockState AtfkT;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gr_2394f879(BlockState blockState) {
        this.AtfkT = blockState;
    }

    public BlockState bbr() {
        return this.AtfkT;
    }
}

