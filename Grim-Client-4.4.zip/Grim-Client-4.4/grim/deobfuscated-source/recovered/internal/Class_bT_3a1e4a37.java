/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

public class Class_bT_3a1e4a37 {
    public float WbmKd;
    public float Joctj;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bT_3a1e4a37(float f, float f2) {
        this.WbmKd = f;
        this.Joctj = f2;
    }

    public void NU(float f, float f2) {
        this.WbmKd = f;
        this.Joctj = f2;
    }
}

