/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_kW_239383b1;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rk_bf8630d1;

public class Class_aT_ae2e2378
extends Class_az_a4990dcf {
    private static float neTon = 10.0f;
    private static float xNvRr = 8.0f;
    private final Class_rk_bf8630d1 dETbP;
    private final Class_ri_288534d5 hbCCQ;
    private final Class_kW_239383b1 zGBCZ;
    private boolean tzvyR;
    private boolean ecHlG;
    private static long HjqKT;
    private static String kgKhi;
    private static long[] iFifw;
    private static Integer[] qtMBd;
    private static Map ukivL;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aT_ae2e2378() {
        long l = HjqKT ^ 0x33B2770C546BL;
        this.dETbP = new Class_rk_bf8630d1((int)Class_aT_ae2e2378.za("v", (int)4127, (long)(0x1E5B304FE844AB08L ^ l)));
        this.hbCCQ = new Class_ri_288534d5((int)Class_aT_ae2e2378.za("v", (int)24135, (long)(0x60FC7EF5AB586551L ^ l)));
        this.zGBCZ = new Class_kW_239383b1(Class_mG_52c8d386.UhgnI, Class_mG_52c8d386.UhgnI);
    }

    static {
        NativeLoader.doInit(Class_aT_ae2e2378.class);
        Class_aT_ae2e2378._292906081032bf46121a3a79a384cbfd();
    }

    private static native CallSite za(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native void _292906081032bf46121a3a79a384cbfd();

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    public native Class_aT_ae2e2378 yV(boolean var1, boolean var2);

    private static native MatchException yW(MatchException var0);

    private static native int yY(int var0, long var1);

    private static native String yX(byte[] var0);

    private static native int yZ(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);
}

