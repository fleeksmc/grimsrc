/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.ActionResult
 *  net.minecraft.util.Hand
 */
package recovered.internal;

import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import recovered.internal.Class_gO_46ab3598;

public class Class_gO_tl_7094a524
extends Class_gO_46ab3598 {
    private ItemStack ATjwR;
    private Hand cgsEJ;
    private ActionResult OkpCy;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gO_tl_7094a524(ItemStack itemStack, Hand hand, ActionResult actionResult) {
        this.ATjwR = itemStack;
        this.cgsEJ = hand;
        this.OkpCy = actionResult;
    }

    public Hand dpp() {
        return this.cgsEJ;
    }

    public ItemStack dpo() {
        return this.ATjwR;
    }

    public ActionResult dpq() {
        return this.OkpCy;
    }
}

