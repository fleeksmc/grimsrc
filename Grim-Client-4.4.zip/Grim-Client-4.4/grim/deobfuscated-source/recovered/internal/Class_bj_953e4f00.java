/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.texture.AbstractTexture
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.texture.AbstractTexture;
import recovered.core.ClientMain;
import recovered.internal.Class_Q_88b47dba;
import recovered.internal.Class_aA_8076b584;
import recovered.internal.Class_aW_20377974;
import recovered.internal.Class_aX_42eff631;
import recovered.internal.Class_aY_e9eaa44d;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_bg_0a91641c;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_cN_30b69d20;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iM_910cda2e;
import recovered.internal.Class_iO_e7bfa49a;
import recovered.internal.Class_iQ_3442de41;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mT_db06bea0;
import recovered.internal.Class_ob_77a6de24;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bj_953e4f00
extends Class_aA_8076b584 {
    private Class_aX_42eff631 bowKs;
    private Class_iO_e7bfa49a VBBbm;
    private boolean hzXMQ;
    private boolean spRbd;
    private final Class_mT_db06bea0 MjYjp;
    private final Class_ri_288534d5 jCGIU;
    private final Class_rk_bf8630d1 mynHs;
    private final Class_rk_bf8630d1 cciMk;
    private final Class_rk_bf8630d1 zIquG;
    private final List<Class_Q_88b47dba> MNfVN;
    private static final long rxqEL;
    private static final String[] iKrJf;
    private static final String[] usfNW;
    private static final Map PAMXr;
    private static final long[] AJxRJ;
    private static final Integer[] boWdj;
    private static final Map Uzhog;
    private static final long BiNEt;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public boolean DH() {
        return this.spRbd;
    }

    private void DC() {
        ClientMain.dlN().buY(this.VBBbm.bub()).thenAccept(bl -> {
            block2: {
                long l;
                block1: {
                    int n;
                    block0: {
                        l = rxqEL ^ 0x6A2697267F79L;
                        n = Class_bg_0a91641c.Dd();
                        if (n != 0) break block0;
                        if (!bl.booleanValue()) break block1;
                        Class_cN_30b69d20.XG((String)((Object)Class_bj_953e4f00.Eh("h", (int)3289, (long)(0x383DDEE9068364F3L ^ l))));
                    }
                    if (n == 0) break block2;
                }
                Class_cN_30b69d20.XI((String)((Object)Class_bj_953e4f00.Eh("h", (int)17589, (long)(0x2D0991C05353AC9EL ^ l))));
            }
        });
    }

    public Class_bj_953e4f00(Class_iO_e7bfa49a class_iO_e7bfa49a) {
        Class_mG_52c8d386 class_mG_52c8d386;
        long l;
        block6: {
            boolean bl;
            block4: {
                block5: {
                    l = rxqEL ^ 0x7FDB75369CB8L;
                    this.hzXMQ = false;
                    this.spRbd = false;
                    this.MjYjp = Class_mT_db06bea0.cpA();
                    this.mynHs = new Class_rk_bf8630d1((int)Class_bj_953e4f00.Ek("v", (int)23467, (long)(0x239D57DDA4DD82FAL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
                    this.cciMk = new Class_rk_bf8630d1((int)Class_bj_953e4f00.Ek("v", (int)24466, (long)(0x4FDF16AF5CF06C8L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
                    this.zIquG = new Class_rk_bf8630d1((int)Class_bj_953e4f00.Ek("v", (int)23974, (long)(0x799E174D8F7484F4L ^ l)), 0.75f).dhs(Class_rj_b691f4f7.yiIHY);
                    this.MNfVN = new ArrayList<Class_Q_88b47dba>();
                    this.VBBbm = class_iO_e7bfa49a;
                    int n = Class_bg_0a91641c.Dd();
                    this.BcpIo = 115.0f;
                    this.WjISQ = 36.0f;
                    class_mG_52c8d386 = Class_mG_52c8d386.UhgnI;
                    bl = class_iO_e7bfa49a.btW();
                    if (n != 0) break block4;
                    if (!bl) break block5;
                    class_mG_52c8d386 = Class_jk_a0800133.jEkxo;
                    if (n == 0) break block6;
                }
                bl = class_iO_e7bfa49a.btV();
            }
            if (bl) {
                class_mG_52c8d386 = Class_jk_a0800133.tSRYI;
            }
        }
        this.jCGIU = new Class_ri_288534d5((int)Class_bj_953e4f00.Ek("v", (int)24466, (long)(0x4FDF16AF5CF06C8L ^ l)), class_mG_52c8d386);
        this.Dz();
        ClientMain.dlP().bsm(class_iO_e7bfa49a.bug());
    }

    /*
     * Unable to fully structure code
     */
    static {
        block24: {
            block23: {
                block22: {
                    block21: {
                        block20: {
                            Class_bj_953e4f00.rxqEL = Class_gb_9d201141.aYR(3076549665549014300L, 288091292817125813L, MethodHandles.lookup().lookupClass()).a(280097577542423L);
                            Class_bj_953e4f00.PAMXr = new HashMap<K, V>(13);
                            var16 = Class_bj_953e4f00.rxqEL ^ 22047531095032L;
                            var18_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                            v0 = SecretKeyFactory.getInstance("DES");
                            v1 = new byte[8];
                            v2 = v1;
                            v1[0] = (byte)(var16 >>> 56);
                            for (var19_2 = 1; var19_2 < 8; ++var19_2) {
                                v2 = v2;
                                v2[var19_2] = (byte)(var16 << var19_2 * 8 >>> 56);
                            }
                            var18_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                            var25_3 = new String[4];
                            var23_4 = 0;
                            var22_5 = "\u00f36*\u00ab+\u0015\u001f\u00bf\u00b2\u0010\u0017N\u0087\u00cdLxO\u0080B\f\u0002x\u00f2z\u00f5.{6\u001e\u0019S\u00e9\u00db\u00c3\u0087\u00f8\u00f4\u00be\u0093CR\n\u0091\u00deL\u00bd&\u00fb\u00d1\u00cbX\u0018\u00822\u00abJ Y&\u00a1\u00d0\u0019\u00d2\u00d2G\u0013NN\u00c5\u00d0,\u00c4*\u00d0\n\u0088\u00c6+\u008dJ\u00a9\u00fa\u00f8\u0004C\u00ba\u0082\u00ff\u000f";
                            var24_6 = "\u00f36*\u00ab+\u0015\u001f\u00bf\u00b2\u0010\u0017N\u0087\u00cdLxO\u0080B\f\u0002x\u00f2z\u00f5.{6\u001e\u0019S\u00e9\u00db\u00c3\u0087\u00f8\u00f4\u00be\u0093CR\n\u0091\u00deL\u00bd&\u00fb\u00d1\u00cbX\u0018\u00822\u00abJ Y&\u00a1\u00d0\u0019\u00d2\u00d2G\u0013NN\u00c5\u00d0,\u00c4*\u00d0\n\u0088\u00c6+\u008dJ\u00a9\u00fa\u00f8\u0004C\u00ba\u0082\u00ff\u000f".length();
                            var21_7 = 56;
                            var20_8 = -1;
lbl20:
                            // 2 sources

                            while (true) {
                                v3 = ++var20_8;
                                v4 = var22_5.substring(v3, v3 + var21_7);
                                v5 = -1;
                                break block20;
                                break;
                            }
lbl25:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = Class_bj_953e4f00.Ee(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                var22_5 = "s\u0098S\u00dc\u00f0\u0081\u00ac\u00b1\u00f7\u0005\u00fe\u00cd\u00ae\u00c6\u00f6\u00e7\u0097\u001a^\u00c1?\u00ace\u00eaX'\u00aa(\u00f3/\u001d\u00f0U2n@u\u008a\u00c2\u00e58Pb\u00b7\u00df4KJ\u0018<\u00ca\u00b5\u0000{\u0014c\u00e9]\u00c4 \u00c0\u00bc\u00d8VJ)\u001f^%\u0006\u0012\u00b5\u0019";
                                var24_6 = "s\u0098S\u00dc\u00f0\u0081\u00ac\u00b1\u00f7\u0005\u00fe\u00cd\u00ae\u00c6\u00f6\u00e7\u0097\u001a^\u00c1?\u00ace\u00eaX'\u00aa(\u00f3/\u001d\u00f0U2n@u\u008a\u00c2\u00e58Pb\u00b7\u00df4KJ\u0018<\u00ca\u00b5\u0000{\u0014c\u00e9]\u00c4 \u00c0\u00bc\u00d8VJ)\u001f^%\u0006\u0012\u00b5\u0019".length();
                                var21_7 = 48;
                                var20_8 = -1;
lbl34:
                                // 2 sources

                                while (true) {
                                    v6 = ++var20_8;
                                    v4 = var22_5.substring(v6, v6 + var21_7);
                                    v5 = 0;
                                    break block20;
                                    break;
                                }
                                break;
                            }
lbl39:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = Class_bj_953e4f00.Ee(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                break block21;
                                break;
                            }
                        }
                        var26_9 = var18_1.doFinal(v4.getBytes("ISO-8859-1"));
                        switch (v5) {
                            default: {
                                ** continue;
                            }
                            ** case 0:
lbl51:
                            // 1 sources

                            ** continue;
                        }
                    }
                    Class_bj_953e4f00.iKrJf = var25_3;
                    Class_bj_953e4f00.usfNW = new String[4];
                    Class_bj_953e4f00.Uzhog = new HashMap<K, V>(13);
                    var5_10 = Cipher.getInstance("DES/CBC/NoPadding");
                    v7 = SecretKeyFactory.getInstance("DES");
                    v8 = new byte[8];
                    v9 = v8;
                    v8[0] = (byte)(var16 >>> 56);
                    for (var6_11 = 1; var6_11 < 8; ++var6_11) {
                        v9 = v9;
                        v9[var6_11] = (byte)(var16 << var6_11 * 8 >>> 56);
                    }
                    var5_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                    var11_12 = new long[21];
                    var8_13 = 0;
                    var9_14 = "t\u0003C\u00d1\u00a6\u0096\b|F9\u0014\u00ffW\u00c6=G\u001f\u001d\u00bb}j$\u00d9!rq\u00c5\u00ea\u00f3\u000b\u00eb\u00ae\u00dd\u00e0\u00e3\u0003\u00a4>\u00bfs\u00a9P\u00ff\u00cc\u00b5\u001f\f\u00dc[\u00b1\u0002\u0085?\u00ec\u00b6C3F\u00f6\u0006\u00b4\u00e4\u0001=\u00e1\u001a\n\nU\u00a0C\u00edL\u009b\u00bd\u00ed \u00b8r\u0099a\u0010J\u00ee\u000e\u0086K\u00c0y\u00d2\u00acr\u009f\u0087\u0011\u0011\u00c4\u001c\u00deCz\u00b6g\u00e0\u00de\u00db\u009e\\$\u000e\u009b&{\u008f\u00f9\n\u0082\u00d7\u00fb\u008bu\u00031;\b2\u0000\u00c3=nV)\u0093:7\u0096\u00e2VVl\u00e7qK\u00d0\u00e4T\u0090\u0092\u00bf\u00a5~\u00d1";
                    var10_15 = "t\u0003C\u00d1\u00a6\u0096\b|F9\u0014\u00ffW\u00c6=G\u001f\u001d\u00bb}j$\u00d9!rq\u00c5\u00ea\u00f3\u000b\u00eb\u00ae\u00dd\u00e0\u00e3\u0003\u00a4>\u00bfs\u00a9P\u00ff\u00cc\u00b5\u001f\f\u00dc[\u00b1\u0002\u0085?\u00ec\u00b6C3F\u00f6\u0006\u00b4\u00e4\u0001=\u00e1\u001a\n\nU\u00a0C\u00edL\u009b\u00bd\u00ed \u00b8r\u0099a\u0010J\u00ee\u000e\u0086K\u00c0y\u00d2\u00acr\u009f\u0087\u0011\u0011\u00c4\u001c\u00deCz\u00b6g\u00e0\u00de\u00db\u009e\\$\u000e\u009b&{\u008f\u00f9\n\u0082\u00d7\u00fb\u008bu\u00031;\b2\u0000\u00c3=nV)\u0093:7\u0096\u00e2VVl\u00e7qK\u00d0\u00e4T\u0090\u0092\u00bf\u00a5~\u00d1".length();
                    var7_16 = 0;
                    while (true) {
                        var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                        v10 = var11_12;
                        v11 = var8_13++;
                        v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                        v13 = -1;
                        break block22;
                        break;
                    }
lbl78:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        var9_14 = "\u00fc\u00dd\u00cb\u00c8\u00b3\u00ad\u0015\u008f\u00aa\u00abW\u00e4\u00de\u0096Tw";
                        var10_15 = "\u00fc\u00dd\u00cb\u00c8\u00b3\u00ad\u0015\u008f\u00aa\u00abW\u00e4\u00de\u0096Tw".length();
                        var7_16 = 0;
                        while (true) {
                            var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                            v10 = var11_12;
                            v11 = var8_13++;
                            v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                            v13 = 0;
                            break block22;
                            break;
                        }
                        break;
                    }
lbl91:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        break block23;
                        break;
                    }
                }
                var13_18 = v12;
                var15_19 = var5_10.doFinal(new byte[]{(byte)(var13_18 >>> 56), (byte)(var13_18 >>> 48), (byte)(var13_18 >>> 40), (byte)(var13_18 >>> 32), (byte)(var13_18 >>> 24), (byte)(var13_18 >>> 16), (byte)(var13_18 >>> 8), (byte)var13_18});
                v14 = ((long)var15_19[0] & 255L) << 56 | ((long)var15_19[1] & 255L) << 48 | ((long)var15_19[2] & 255L) << 40 | ((long)var15_19[3] & 255L) << 32 | ((long)var15_19[4] & 255L) << 24 | ((long)var15_19[5] & 255L) << 16 | ((long)var15_19[6] & 255L) << 8 | (long)var15_19[7] & 255L;
                switch (v13) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl104:
                    // 1 sources

                    ** continue;
                }
            }
            Class_bj_953e4f00.AJxRJ = var11_12;
            Class_bj_953e4f00.boWdj = new Integer[21];
            var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
            v15 = SecretKeyFactory.getInstance("DES");
            v16 = new byte[8];
            v17 = v16;
            v16[0] = (byte)(var16 >>> 56);
            for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                v17 = v17;
                v17[var1_21] = (byte)(var16 << var1_21 * 8 >>> 56);
            }
            break block24;
lbl118:
            // 1 sources

            while (true) {
                continue;
                break;
            }
        }
        var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
        var2_22 = 6387438058091079061L;
        var4_23 = var0_20.doFinal(new byte[]{(byte)(var2_22 >>> 56), (byte)(var2_22 >>> 48), (byte)(var2_22 >>> 40), (byte)(var2_22 >>> 32), (byte)(var2_22 >>> 24), (byte)(var2_22 >>> 16), (byte)(var2_22 >>> 8), (byte)var2_22});
        ** while (true)
        Class_bj_953e4f00.BiNEt = ((long)var4_23[0] & 255L) << 56 | ((long)var4_23[1] & 255L) << 48 | ((long)var4_23[2] & 255L) << 40 | ((long)var4_23[3] & 255L) << 32 | ((long)var4_23[4] & 255L) << 24 | ((long)var4_23[5] & 255L) << 16 | ((long)var4_23[6] & 255L) << 8 | (long)var4_23[7] & 255L;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean dk(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        long l = rxqEL ^ 0x23FCCB7B731EL;
        int n = Class_bg_0a91641c.De();
        boolean bl = this.tg(d, d2);
        if (n == 0) return bl;
        if (bl) {
            block5: {
                for (Class_Q_88b47dba class_Q_88b47dba : this.MNfVN) {
                    bl = class_Q_88b47dba.dk(d, d2, class_mA_32d8a5f2);
                    if (n != 0) {
                        if (n == 0) boolean bl2;
                        return bl2;
                        if (bl) {
                            return true;
                        }
                        if (n != 0) continue;
                    }
                    break block5;
                }
                bl = this.MjYjp.cpC(BiNEt);
            }
            if (n == 0) return bl;
            if (bl) {
                this.DA();
                this.MjYjp.cpB();
                return true;
            }
        }
        bl = super.dk(d, d2, class_mA_32d8a5f2);
        return bl;
    }

    public Class_aX_42eff631 DE() {
        return this.bowKs;
    }

    @Override
    protected void bV(Class_lC_5322e8cf class_lC_5322e8cf) {
        block22: {
            Class_mG_52c8d386 class_mG_52c8d386;
            float f;
            float f2;
            float f3;
            float f4;
            int n;
            block21: {
                float f5;
                block20: {
                    block19: {
                        Class_bj_953e4f00 class_bj_953e4f00;
                        Object object;
                        block18: {
                            block17: {
                                boolean bl;
                                block15: {
                                    block16: {
                                        float f6;
                                        float f7;
                                        float f8;
                                        block14: {
                                            block13: {
                                                long l = rxqEL ^ 0x7E6903D2A7DAL;
                                                int n2 = Class_bg_0a91641c.De();
                                                this.cciMk.dhc(this.tg(class_lC_5322e8cf.cff(), class_lC_5322e8cf.cfg()));
                                                n = n2;
                                                boolean bl2 = this.hzXMQ;
                                                if (n != 0) {
                                                    bl2 = !bl2;
                                                }
                                                this.mynHs.dhc(bl2);
                                                f5 = this.mynHs.dhj();
                                                Class_mG_52c8d386 class_mG_52c8d3862 = this.CtPwV.bje().cob(0.8f).cob(f5);
                                                class_lC_5322e8cf.cdm(this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ, 5.0f, Class_ld_bb1690e1.M, class_mG_52c8d3862);
                                                f4 = 5.0f;
                                                f8 = this.WjISQ - f4 * 2.0f;
                                                float f9 = this.MCnYt + f4;
                                                f7 = this.pNyTQ + f4;
                                                AbstractTexture abstractTexture = ClientMain.dlP().bso(this.VBBbm.bug(), Class_ob_77a6de24.cBv((String)((Object)Class_bj_953e4f00.Eh("h", (int)1965, (long)(0x36296E6A5EC13726L ^ l)))));
                                                f6 = Class_jF_38b68c76.bHw()[3];
                                                if (n == 0) break block13;
                                                if (abstractTexture == null) break block14;
                                                Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, Math.min(1.0f, f6 * f5));
                                                class_lC_5322e8cf.cee(abstractTexture, f9, f7, f8, f8, Class_ld_bb1690e1.all(4.0f));
                                            }
                                            Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, f6);
                                        }
                                        Class_mG_52c8d386 class_mG_52c8d3863 = this.CtPwV.bjb().cob(f6 * 0.75f + 0.25f * this.cciMk.dhj()).cob(f5);
                                        float f10 = this.MCnYt + f4 + f8 + 7.0f;
                                        float f11 = this.pNyTQ + f4;
                                        Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
                                        class_lC_5322e8cf.ceI(class_lq_87a74641, this.VBBbm.buc(), f10, f11, class_mG_52c8d3863, 0.7f, 0.99f, this.BcpIo - f8 - 7.0f - f4 * 2.0f - 7.0f);
                                        Class_mG_52c8d386 class_mG_52c8d3864 = this.CtPwV.bjb().cob(0.5f).cob(f5);
                                        Class_lq_87a74641 class_lq_87a746412 = Class_lE_06fbe260.joxgd.bYM(6.0f);
                                        float f12 = f11 + class_lq_87a74641.cat() + 3.0f;
                                        class_lC_5322e8cf.ceH(class_lq_87a746412, Class_jf_d1c4f950.bAS(this.VBBbm.bul()), f10, f12, class_mG_52c8d3864, 0.7f, 0.99f, this.BcpIo - f8 - 7.0f - f4 * 2.0f);
                                        float f13 = this.MCnYt + f4 + f8 + 7.0f;
                                        float f14 = f7 + f8 - 8.0f;
                                        for (Class_Q_88b47dba class_Q_88b47dba : this.MNfVN) {
                                            class_Q_88b47dba.jt(f5);
                                            class_Q_88b47dba.sW(f13, f14);
                                            class_Q_88b47dba.su(class_lC_5322e8cf);
                                            f13 += class_Q_88b47dba.kN() + 5.0f;
                                            if (n != 0) continue;
                                        }
                                        object = Class_mG_52c8d386.UhgnI;
                                        bl = this.VBBbm.btW();
                                        if (n == 0) break block15;
                                        if (!bl) break block16;
                                        object = Class_jk_a0800133.jEkxo;
                                        if (n != 0) break block17;
                                    }
                                    class_bj_953e4f00 = this;
                                    if (n == 0) break block18;
                                    bl = class_bj_953e4f00.VBBbm.btV();
                                }
                                if (bl) {
                                    object = Class_jk_a0800133.tSRYI;
                                }
                            }
                            class_bj_953e4f00 = this;
                        }
                        class_bj_953e4f00.jCGIU.dfT((Class_mG_52c8d386)object);
                        f3 = 5.0f;
                        class_lC_5322e8cf.cdg(this.tc() - f4 - f3, this.pNyTQ + f4, f3, f3, Class_ld_bb1690e1.all(f3 / 2.0f), this.jCGIU.dfU().cob(f5));
                        f2 = 10.0f;
                        f = this.zIquG.dhd(f2);
                        class_mG_52c8d386 = this.jCGIU.dfU();
                        if (n == 0) break block19;
                        if (!(f >= 6.0f)) break block20;
                        class_mG_52c8d386 = class_mG_52c8d386.cob((f2 - f) / 4.0f).cob(f5);
                    }
                    if (n != 0) break block21;
                }
                class_mG_52c8d386 = class_mG_52c8d386.cob(f5);
            }
            if (f == f2) {
                this.zIquG.dhe(0.75f);
            }
            class_lC_5322e8cf.ccY(this.tc() - f4 - f3, this.pNyTQ + f4, f3, f3, f, Class_ld_bb1690e1.all(f3 / 2.0f), class_mG_52c8d386);
            if (Class_iS_888f260e.bwL() != null) break block22;
            Class_bg_0a91641c.Dc(++n);
        }
    }

    public void DA() {
        CompletableFuture<Class_iM_910cda2e> completableFuture = ClientMain.dlN().bvb(this.VBBbm.bub());
        CompletableFuture<int[]> completableFuture2 = this.VBBbm.btS();
        completableFuture.thenCombine(completableFuture2, (class_iM_910cda2e, nArray) -> {
            block8: {
                long l;
                block5: {
                    Class_aY_e9eaa44d class_aY_e9eaa44d2;
                    int n;
                    block7: {
                        block6: {
                            boolean bl;
                            l = rxqEL ^ 0x534375BBF04EL;
                            n = Class_bg_0a91641c.Dd();
                            if (class_iM_910cda2e == null || nArray == null) break block5;
                            List<Class_aj_95d0a719> list = Class_bl_a15fbaa5.Ex().manager().aY(Class_aj_95d0a719.class);
                            boolean bl2 = bl = list.stream().filter(class_aj_95d0a719 -> class_aj_95d0a719 instanceof Class_aY_e9eaa44d).map(class_aj_95d0a719 -> (Class_aY_e9eaa44d)class_aj_95d0a719).anyMatch(class_aY_e9eaa44d -> class_aY_e9eaa44d.zU().bub().equals(this.VBBbm.bub()));
                            if (n == 0) {
                                if (bl2) {
                                    return null;
                                }
                                bl2 = class_iM_910cda2e.bua();
                            }
                            if (!bl2) break block6;
                            class_aY_e9eaa44d2 = new Class_aW_20377974(2.0f, (int[])nArray, (Class_iM_910cda2e)class_iM_910cda2e);
                            if (n == 0) break block7;
                        }
                        class_aY_e9eaa44d2 = new Class_aX_42eff631(2.0f, (int[])nArray, (Class_iM_910cda2e)class_iM_910cda2e);
                    }
                    Class_bl_a15fbaa5.Ex().addPopupComponent(class_aY_e9eaa44d2);
                    if (n == 0) break block8;
                }
                Class_cN_30b69d20.XI((String)((Object)Class_bj_953e4f00.Eh("h", (int)23014, (long)(0x24E34F346B9ABEF8L ^ l))));
            }
            return null;
        });
    }

    public Class_bj_953e4f00 DR(boolean bl) {
        this.spRbd = bl;
        return this;
    }

    public boolean DG() {
        return this.hzXMQ;
    }

    public Class_bj_953e4f00 DQ(boolean bl) {
        this.hzXMQ = bl;
        return this;
    }

    public Class_rk_bf8630d1 DK() {
        return this.mynHs;
    }

    public Class_aX_42eff631 Dy() {
        long l = rxqEL ^ 0x628E64612F09L;
        Iterator<Class_aj_95d0a719> iterator = Class_bl_a15fbaa5.Ex().manager().aY(Class_aj_95d0a719.class).iterator();
        int n = Class_bg_0a91641c.De();
        while (iterator.hasNext()) {
            block4: {
                Class_aX_42eff631 class_aX_42eff631;
                block5: {
                    Class_aX_42eff631 class_aX_42eff6312;
                    Class_aj_95d0a719 class_aj_95d0a719;
                    block3: {
                        Class_aj_95d0a719 class_aj_95d0a7192;
                        class_aj_95d0a719 = class_aj_95d0a7192 = iterator.next();
                        if (n == 0) break block3;
                        if (!(class_aj_95d0a719 instanceof Class_aX_42eff631)) break block4;
                        class_aj_95d0a719 = class_aj_95d0a7192;
                    }
                    class_aX_42eff631 = class_aX_42eff6312 = (Class_aX_42eff631)class_aj_95d0a719;
                    if (n == 0) break block5;
                    if (!class_aX_42eff631.zU().bub().equals(this.VBBbm.bub())) break block4;
                    class_aX_42eff631 = class_aX_42eff6312;
                }
                return class_aX_42eff631;
            }
            if (n != 0) continue;
        }
        return null;
    }

    public Class_iO_e7bfa49a DF() {
        return this.VBBbm;
    }

    private void DD() {
        Class_iQ_3442de41 class_iQ_3442de41 = ClientMain.dlN();
        CompletableFuture<Class_iM_910cda2e> completableFuture = class_iQ_3442de41.bvb(this.VBBbm.bub());
        completableFuture.thenAccept(class_iM_910cda2e -> {
            block0: {
                long l = rxqEL ^ 0x789AF18DFA9L;
                if (class_iM_910cda2e == null) break block0;
                class_iQ_3442de41.bvf((Class_iM_910cda2e)class_iM_910cda2e);
            }
        });
    }

    private static String Ee(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static String Ef(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x2B4;
        if (usfNW[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])PAMXr.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    PAMXr.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bj_953e4f00", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = iKrJf[n2].getBytes("ISO-8859-1");
            Class_bj_953e4f00.usfNW[n2] = Class_bj_953e4f00.Ee(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return usfNW[n2];
    }

    private static Object Eg(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_bj_953e4f00.Ef(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static MatchException Ed(MatchException matchException) {
        return matchException;
    }

    private static int Ei(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5001;
        if (boWdj[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = AJxRJ[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])Uzhog.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    Uzhog.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bj_953e4f00", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bj_953e4f00.boWdj[n2] = n3;
        }
        return boWdj[n2];
    }

    private static int Ej(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bj_953e4f00.Ei(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private void DB(Class_Q_88b47dba class_Q_88b47dba) {
        long l = rxqEL ^ 0x608396AE4338L;
        boolean bl = class_Q_88b47dba.jC();
        int n = Class_bg_0a91641c.De();
        boolean bl2 = bl;
        if (n != 0) {
            bl2 = !bl2;
        }
        class_Q_88b47dba.jh(bl2);
        Class_iQ_3442de41 class_iQ_3442de41 = ClientMain.dlN();
        ((CompletableFuture)class_iQ_3442de41.bve(this.VBBbm.bub()).thenAccept(class_iM_910cda2e -> {
            block0: {
                long l = rxqEL ^ 0x625E55DD1D14L;
                if (class_iM_910cda2e == null) break block0;
                class_Q_88b47dba.jh(this.VBBbm.btV());
            }
        })).exceptionally(throwable -> {
            class_Q_88b47dba.jg(bl);
            return null;
        });
    }

    private static CallSite Ek(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bj_953e4f00" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private void Dz() {
        long l = rxqEL ^ 0x20E9A51F1957L;
        Class_Q_88b47dba class_Q_88b47dba2 = (Class_Q_88b47dba)new Class_Q_88b47dba().io(Class_lf_d247d983.dBvvZ).in(Class_lf_d247d983.jfwAa).is(7.0f).jb(this::DB).jm(Class_jk_a0800133.tSRYI).jl(Class_jk_a0800133.tSRYI).jg(true).jh(this.VBBbm.btV()).sX(8.0f, 8.0f);
        this.MNfVN.add(class_Q_88b47dba2);
        int[] nArray = new int[Class_bj_953e4f00.Ek("v", (int)7182, (long)(0x7D65A12B7E9740BCL ^ l))];
        nArray[0] = (int)Class_bj_953e4f00.Ek("v", (int)9956, (long)(0x12A40C725382FA5DL ^ l));
        nArray[1] = (int)Class_bj_953e4f00.Ek("v", (int)4767, (long)(0x1679E1CFE162CE3DL ^ l));
        nArray[2] = (int)Class_bj_953e4f00.Ek("v", (int)24840, (long)(0x1E9425EDAA053DB4L ^ l));
        nArray[3] = (int)Class_bj_953e4f00.Ek("v", (int)28211, (long)(0x104FAAC8EBA0B284L ^ l));
        nArray[4] = (int)Class_bj_953e4f00.Ek("v", (int)21686, (long)(0x5562FECBB188080EL ^ l));
        nArray[5] = (int)Class_bj_953e4f00.Ek("v", (int)15631, (long)(0x6FB12D1B5F0C61ABL ^ l));
        nArray[Class_bj_953e4f00.Ek("v", (int)10221, (long)(0x6F91423B5E897B59L ^ l))] = (int)Class_bj_953e4f00.Ek("v", (int)16993, (long)(0x3AB5D38CE9709EC0L ^ l));
        Class_Q_88b47dba class_Q_88b47dba3 = (Class_Q_88b47dba)((Class_Q_88b47dba)new Class_Q_88b47dba().io(Class_lf_d247d983.JIteU).is(7.0f).jb(class_Q_88b47dba -> this.DA()).jc(nArray)).sX(8.0f, 8.0f);
        this.MNfVN.add(class_Q_88b47dba3);
        Class_Q_88b47dba class_Q_88b47dba4 = (Class_Q_88b47dba)((Class_Q_88b47dba)new Class_Q_88b47dba().io(Class_lf_d247d983.BSuOE).is(7.0f).jb(class_Q_88b47dba -> this.DD()).jc(new int[]{(int)Class_bj_953e4f00.Ek("v", (int)337, (long)(0x707A5D23ED095DEAL ^ l)), (int)Class_bj_953e4f00.Ek("v", (int)31195, (long)(0x203C6C9414B12568L ^ l)), (int)Class_bj_953e4f00.Ek("v", (int)27172, (long)(0x5C55EBA223D0B694L ^ l)), (int)Class_bj_953e4f00.Ek("v", (int)14914, (long)(0x64BF53B0F706E6E2L ^ l))})).sX(11.0f, 8.0f);
        this.MNfVN.add(class_Q_88b47dba4);
        int[] nArray2 = new int[Class_bj_953e4f00.Ek("v", (int)1812, (long)(0x5652235BFB3F5BA5L ^ l))];
        nArray2[0] = (int)Class_bj_953e4f00.Ek("v", (int)18034, (long)(0x22FCEEAA76211AD1L ^ l));
        nArray2[1] = (int)Class_bj_953e4f00.Ek("v", (int)24244, (long)(0x10375D4E439820EL ^ l));
        nArray2[2] = (int)Class_bj_953e4f00.Ek("v", (int)27689, (long)(0x57C473A8E11E309FL ^ l));
        nArray2[3] = (int)Class_bj_953e4f00.Ek("v", (int)24244, (long)(0x10375D4E439820EL ^ l));
        nArray2[4] = (int)Class_bj_953e4f00.Ek("v", (int)13236, (long)(0x53C32965C7416F0BL ^ l));
        nArray2[5] = (int)Class_bj_953e4f00.Ek("v", (int)24244, (long)(0x10375D4E439820EL ^ l));
        Class_Q_88b47dba class_Q_88b47dba5 = (Class_Q_88b47dba)((Class_Q_88b47dba)new Class_Q_88b47dba().io(Class_lf_d247d983.JHGge).is(7.0f).jb(class_Q_88b47dba -> this.DC()).jc(nArray2)).sX(8.0f, 8.0f);
        this.MNfVN.add(class_Q_88b47dba5);
    }

    public Class_mT_db06bea0 DI() {
        return this.MjYjp;
    }

    public Class_ri_288534d5 DJ() {
        return this.jCGIU;
    }

    public Class_rk_bf8630d1 DL() {
        return this.cciMk;
    }

    public Class_rk_bf8630d1 DM() {
        return this.zIquG;
    }

    public List<Class_Q_88b47dba> DN() {
        return this.MNfVN;
    }

    public Class_bj_953e4f00 DO(Class_aX_42eff631 class_aX_42eff631) {
        this.bowKs = class_aX_42eff631;
        return this;
    }

    private static CallSite Eh(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bj_953e4f00" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public Class_bj_953e4f00 DP(Class_iO_e7bfa49a class_iO_e7bfa49a) {
        this.VBBbm = class_iO_e7bfa49a;
        return this;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bj_953e4f00.class, "Ej", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_bj_953e4f00.class, "Eg", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

