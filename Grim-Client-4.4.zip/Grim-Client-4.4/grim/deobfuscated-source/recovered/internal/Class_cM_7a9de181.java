/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_mG_52c8d386;

public final class Class_cM_7a9de181
extends Enum<Class_cM_7a9de181> {
    public static /* enum */ Class_cM_7a9de181 dzTse;
    public static /* enum */ Class_cM_7a9de181 WCwDP;
    public static /* enum */ Class_cM_7a9de181 MENWL;
    private final String xFxGY;
    private final Class_mG_52c8d386 cbCbj;
    private static /* synthetic */ Class_cM_7a9de181[] NAnkv;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_cM_7a9de181(String string2, Class_mG_52c8d386 class_mG_52c8d386) {
        this.xFxGY = string2;
        this.cbCbj = class_mG_52c8d386;
    }

    static {
        NativeLoader.doInit(Class_cM_7a9de181.class);
        Class_cM_7a9de181._4bf5e56081b896906b4db03f7dfadf24();
    }

    public static native Class_cM_7a9de181[] values();

    public static native Class_cM_7a9de181 valueOf(String var0);

    private static native void _4bf5e56081b896906b4db03f7dfadf24();

    private static native /* synthetic */ Class_cM_7a9de181[] XD();

    private static native String XE(byte[] var0);

    public native Class_mG_52c8d386 XC();

    public native String XB();

    public native Class_cM_7a9de181 XA();
}

