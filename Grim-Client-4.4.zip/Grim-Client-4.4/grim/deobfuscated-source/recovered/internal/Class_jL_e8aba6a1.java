/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import recovered.core.NativeLoader;
import recovered.internal.Class_jN_f0c1545a;

public class Class_jL_e8aba6a1 {
    public static Class_jN_f0c1545a SUknV;
    public static Class_jN_f0c1545a qidnW;
    public static Class_jN_f0c1545a VBAOv;
    public static Class_jN_f0c1545a wcOYb;
    public static Class_jN_f0c1545a cazyD;
    public static Class_jN_f0c1545a kiOiT;
    public static Class_jN_f0c1545a ARZDF;
    public static Class_jN_f0c1545a WckAA;
    public static Class_jN_f0c1545a VAxur;
    public static Class_jN_f0c1545a OHwYv;
    public static Class_jN_f0c1545a xOjEv;
    public static Class_jN_f0c1545a TruIk;
    public static Class_jN_f0c1545a rPrcM;
    public static Class_jN_f0c1545a UaPex;
    public static Class_jN_f0c1545a Dract;
    public static Class_jN_f0c1545a aXSot;
    public static Class_jN_f0c1545a LsZdJ;
    public static Class_jN_f0c1545a vcspz;
    public static Class_jN_f0c1545a uHvyh;
    public static Class_jN_f0c1545a PTppR;
    public static Class_jN_f0c1545a wxgUS;
    public static byte[] SjBqH;
    public static byte[] jsWRr;
    private static Map<String, byte[]> nVHGL;
    private static int QlMdw;
    private static long ScRKT;
    private static String[] pVMLy;
    private static String[] gqTIQ;
    private static Map LFILS;
    private static long[] WBZjh;
    private static Integer[] FPeYf;
    private static Map BbWZW;
    private static long MjfKW;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_jL_e8aba6a1.class);
        Class_jL_e8aba6a1._d3a603f3d905b1ddc0b2b8447f909903();
    }

    private native void bIJ();

    private static native void bIM();

    public native CompletableFuture<Void> bIG();

    private native /* synthetic */ Void bIN(Throwable var1);

    private static native String bIT(byte[] var0);

    private static native Object bIV(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native int bIY(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native void bIH();

    private static native CallSite bIZ(MethodHandles.Lookup var0, String var1, MethodType var2);

    public static native int bIQ();

    private native void bII();

    public static native void bIP(int var0);

    private static native Throwable bIS(Throwable var0);

    private native void bIK();

    private static native /* synthetic */ void bIO(String var0, byte[] var1);

    private static native String bIU(int var0, long var1);

    public static native int bIR();

    public native void bIL();

    private static native CallSite bIW(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native int bIX(int var0, long var1);

    private static native void _d3a603f3d905b1ddc0b2b8447f909903();
}

