/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.sun.jna.Structure
 *  com.sun.jna.Structure$ByReference
 */
package recovered.internal;

import com.sun.jna.Structure;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;

public final class Class_jm_tS_c39bf763
extends Structure
implements Structure.ByReference {
    public int aaeEj;
    public int oDYGJ;
    public int ycxcQ;
    public int GOmgg;
    private static final long ykHKx;
    private static final String[] YUCER;
    private static final String[] rIsHL;
    private static final Map fikQq;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_jm_tS_c39bf763.ykHKx = Class_gb_9d201141.aYR(-1927568465887016078L, -3036018275370745488L, MethodHandles.lookup().lookupClass()).a(195138953930490L);
                Class_jm_tS_c39bf763.fikQq = new HashMap<K, V>(13);
                var0 = Class_jm_tS_c39bf763.ykHKx ^ 71571679734540L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[4];
                var7_4 = 0;
                var6_5 = "\u00fa\u00d4CQ\u00c6F\u00fb\u008b\u00dc8\u00d08\u00ffU\u00af\u00d1A\u00cf\u00e7Q\u008cNg<\u0086\u00c2 \u00ed\u00a5\u008c\u0006/ \u00a0\u00a1\u00f0\u00bf\u0012\u00f9\u00b5\u009dz\u000f\u00dc%_*\u008a\u00b6\u00de\u00d2\u00a1\u0090\u0003\u0007\u00a0\u008a\u00fd\u0018R\u0013\u008d1\u009f\u00bb";
                var8_6 = "\u00fa\u00d4CQ\u00c6F\u00fb\u008b\u00dc8\u00d08\u00ffU\u00af\u00d1A\u00cf\u00e7Q\u008cNg<\u0086\u00c2 \u00ed\u00a5\u008c\u0006/ \u00a0\u00a1\u00f0\u00bf\u0012\u00f9\u00b5\u009dz\u000f\u00dc%_*\u008a\u00b6\u00de\u00d2\u00a1\u0090\u0003\u0007\u00a0\u008a\u00fd\u0018R\u0013\u008d1\u009f\u00bb".length();
                var5_7 = 32;
                var4_8 = -1;
lbl20:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl25:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jm_tS_c39bf763.dpS(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "h\u0005\u0091\u0081\u00ba\u00e8\u0014\u00a6\u00fa\u00a6\u009c\u00d3\u000f\u00ac\u00d07(c\u00c1\u0091\u009cHN\u000b,a3yX\u00ca~\u0013 \u00fd\u00f1\u00de7J\u00ab]\n\u0090\u009a\u00f8N\u0098V\u00afY\u00f4\u0092\u0094J\u00ca \u0086\u00ed\u0019\u00b2J\u00bb\u0014\u00c3\u009c\u0000";
                    var8_6 = "h\u0005\u0091\u0081\u00ba\u00e8\u0014\u00a6\u00fa\u00a6\u009c\u00d3\u000f\u00ac\u00d07(c\u00c1\u0091\u009cHN\u000b,a3yX\u00ca~\u0013 \u00fd\u00f1\u00de7J\u00ab]\n\u0090\u009a\u00f8N\u0098V\u00afY\u00f4\u0092\u0094J\u00ca \u0086\u00ed\u0019\u00b2J\u00bb\u0014\u00c3\u009c\u0000".length();
                    var5_7 = 32;
                    var4_8 = -1;
lbl34:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jm_tS_c39bf763.dpS(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl51:
                // 1 sources

                ** continue;
            }
        }
        Class_jm_tS_c39bf763.YUCER = var9_3;
        Class_jm_tS_c39bf763.rIsHL = new String[4];
    }

    protected List<String> getFieldOrder() {
        long l = ykHKx ^ 0x6C8BFD9AC501L;
        return List.of(Class_jm_tS_c39bf763.dpV("a", (int)11927, (long)(0x6B140360317B0840L ^ l)), Class_jm_tS_c39bf763.dpV("a", (int)4473, (long)(0x26392DB0539937ACL ^ l)), Class_jm_tS_c39bf763.dpV("a", (int)28885, (long)(0x1FED8BFFA0A2D601L ^ l)), Class_jm_tS_c39bf763.dpV("a", (int)18514, (long)(0x2AC0CD870B0B6E84L ^ l)));
    }

    private static CallSite dpV(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jm_tS_c39bf763" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static String dpT(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5317;
        if (rIsHL[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])fikQq.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    fikQq.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jm_tS_c39bf763", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = YUCER[n2].getBytes("ISO-8859-1");
            Class_jm_tS_c39bf763.rIsHL[n2] = Class_jm_tS_c39bf763.dpS(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return rIsHL[n2];
    }

    private static String dpS(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static Object dpU(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_jm_tS_c39bf763.dpT(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jm_tS_c39bf763.class, "dpU", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

