/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

class Class_ad_rO_f65cac7a {
    final Class_rk_bf8630d1 zzIIX;
    boolean lfHjU;
    final char UxjLg;
    private static long ZWlAr;
    private static long eAiVx;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ad_rO_f65cac7a(char c) {
        long l = ZWlAr ^ 0x3B7C4C97397BL;
        this.zzIIX = new Class_rk_bf8630d1((int)eAiVx).dhs(Class_rj_b691f4f7.UPXqT);
        this.UxjLg = c;
    }

    static {
        NativeLoader.doInit(Class_ad_rO_f65cac7a.class);
        Class_ad_rO_f65cac7a._8bce1eac70aa2600e7e50c69b155bac5();
    }

    private static native void _8bce1eac70aa2600e7e50c69b155bac5();
}

