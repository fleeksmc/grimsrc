/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;
import recovered.internal.Class_mA_32d8a5f2;

public class Class_hz_5cba7134
extends Class_hH_ae8f8f77 {
    private final double TKNzf;
    private final double IMkJk;
    private final Class_mA_32d8a5f2 pkoWI;
    private final double eOxPO;
    private final double hZNJc;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hz_5cba7134(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2, double d3, double d4) {
        this.TKNzf = d;
        this.IMkJk = d2;
        this.pkoWI = class_mA_32d8a5f2;
        this.eOxPO = d3;
        this.hZNJc = d4;
    }

    public Class_mA_32d8a5f2 bdv() {
        return this.pkoWI;
    }

    public double bdu() {
        return this.IMkJk;
    }

    public double bdx() {
        return this.hZNJc;
    }

    public double bdt() {
        return this.TKNzf;
    }

    public double bdw() {
        return this.eOxPO;
    }
}

