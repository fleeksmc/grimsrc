/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.BufferBuilder
 *  org.joml.Matrix3x2fStack
 *  org.joml.Matrix3x2fc
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import net.minecraft.client.render.BufferBuilder;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix3x2fc;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_kc_d81b206b;
import recovered.internal.Class_la_8f67ae40;
import recovered.internal.Class_mG_52c8d386;

public class Class_kb_995b2295
implements Class_kc_d81b206b {
    private static int[] XoDvl;
    private static final long dzPrA;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    @Override
    public void uv_quad_region_color(BufferBuilder bufferBuilder, Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, Class_mG_52c8d386 class_mG_52c8d386) {
        block0: {
            long l = dzPrA ^ 0x71B715301949L;
            int n = class_mG_52c8d386.coh();
            bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f, f2).texture(f5, f6).color(n);
            bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f, f2 + f4).texture(f5, f8).color(n);
            int[] nArray = Class_kb_995b2295.bOb();
            bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f + f3, f2 + f4).texture(f7, f8).color(n);
            int[] nArray2 = nArray;
            bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f + f3, f2).texture(f7, f6).color(n);
            if (nArray2 == null) break block0;
            Class_iS_888f260e.bwK("LdyUFb");
        }
    }

    static {
        dzPrA = Class_gb_9d201141.aYR(3512256792401566856L, -5836583734373741107L, MethodHandles.lookup().lookupClass()).a(13982792772499L);
        if (Class_kb_995b2295.bOb() != null) {
            Class_kb_995b2295.bOa(new int[5]);
        }
    }

    private static MatchException bOc(MatchException matchException) {
        return matchException;
    }

    public static int[] bOb() {
        return XoDvl;
    }

    @Override
    public void uv_quad(BufferBuilder bufferBuilder, Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3, float f4) {
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f, f2).texture(0.0f, 0.0f);
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f, f2 + f4).texture(0.0f, 1.0f);
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f + f3, f2 + f4).texture(1.0f, 1.0f);
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f + f3, f2).texture(1.0f, 0.0f);
    }

    @Override
    public void quad(BufferBuilder bufferBuilder, Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3, float f4) {
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f, f2);
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f, f2 + f4);
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f + f3, f2 + f4);
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f + f3, f2);
    }

    @Override
    public void quad_color(BufferBuilder bufferBuilder, Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3, float f4, Class_mG_52c8d386 class_mG_52c8d386) {
        int n = class_mG_52c8d386.coh();
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f, f2).color(n);
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f, f2 + f4).color(n);
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f + f3, f2 + f4).color(n);
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f + f3, f2).color(n);
    }

    @Override
    public void quad_color(BufferBuilder bufferBuilder, Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3, float f4, Class_la_8f67ae40 class_la_8f67ae40) {
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f, f2).color(class_la_8f67ae40.bXe().coh());
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f, f2 + f4).color(class_la_8f67ae40.bXg().coh());
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f + f3, f2 + f4).color(class_la_8f67ae40.bXh().coh());
        bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f + f3, f2).color(class_la_8f67ae40.bXf().coh());
    }

    public static void bOa(int[] nArray) {
        XoDvl = nArray;
    }

    @Override
    public void uv_quad_color(BufferBuilder bufferBuilder, Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3, float f4, Class_mG_52c8d386 class_mG_52c8d386) {
        block0: {
            long l = dzPrA ^ 0x3728E4FEAE2CL;
            int n = class_mG_52c8d386.coh();
            int[] nArray = Class_kb_995b2295.bOb();
            bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f, f2).texture(0.0f, 0.0f).color(n);
            int[] nArray2 = nArray;
            bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f, f2 + f4).texture(0.0f, 1.0f).color(n);
            bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f + f3, f2 + f4).texture(1.0f, 1.0f).color(n);
            bufferBuilder.vertex((Matrix3x2fc)matrix3x2fStack, f + f3, f2).texture(1.0f, 0.0f).color(n);
            if (Class_iS_888f260e.bwL() != null) break block0;
            Class_kb_995b2295.bOa(new int[4]);
        }
    }
}

