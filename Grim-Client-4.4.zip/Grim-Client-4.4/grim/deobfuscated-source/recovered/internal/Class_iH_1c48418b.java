/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

public class Class_iH_1c48418b {
    private static long ACJdE;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_iH_1c48418b.class);
        Class_iH_1c48418b._eeef52848074d7bcaebba46f8943fdcd();
    }

    public static native String bsA(int[] var0);

    private static native MatchException bsB(MatchException var0);

    private static native void _eeef52848074d7bcaebba46f8943fdcd();
}

