/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_gC_1f010b94;

public class Class_gC_td_ee32a4c7
extends Class_gC_1f010b94 {
    private final int xcitL;
    private final int fYPLe;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gC_td_ee32a4c7(int n, int n2) {
        this.xcitL = n;
        this.fYPLe = n2;
    }

    public int dpg() {
        return this.xcitL;
    }

    public int dph() {
        return this.fYPLe;
    }
}

