/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_ax_3a65ba66;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public abstract class Class_ak_2ff604c7<T extends Class_cB_67aec11c>
extends Class_az_a4990dcf {
    public static Class_ak_2ff604c7<?> SPSBS;
    protected final Class_az_a4990dcf uVhpi;
    protected final T sCXfR;
    protected final Class_rk_bf8630d1 QmyNF;
    protected final Class_rk_bf8630d1 tDliG;
    private static final long ZyPUF;
    private static final long[] lVcnQ;
    private static final Integer[] aZoru;
    private static final Map nWsJs;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ak_2ff604c7(T t, Class_az_a4990dcf class_az_a4990dcf) {
        long l = ZyPUF ^ 0x31862CD0B3F7L;
        this.QmyNF = new Class_rk_bf8630d1((int)Class_ak_2ff604c7.oP("j", (int)16635, (long)(0x3D397616045A5429L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.tDliG = new Class_rk_bf8630d1((int)Class_ak_2ff604c7.oP("j", (int)15, (long)(0xEEA561015E914DCL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.uVhpi = class_az_a4990dcf;
        this.sCXfR = t;
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        ZyPUF = Class_gb_9d201141.aYR(-1244836903602851909L, -2102368253998822455L, MethodHandles.lookup().lookupClass()).a(83502704156515L);
        nWsJs = new HashMap(13);
        long l = ZyPUF ^ 0x7A5751C2FF37L;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "\u00cc\u00f7\u00f1\u00dcO%\u0088Lq\u007f\u00d7\u0089\u00b1\u0011\u00e4\u00ff";
        int n2 = "\u00cc\u00f7\u00f1\u00dcO%\u0088Lq\u007f\u00d7\u0089\u00b1\u0011\u00e4\u00ff".length();
        int n3 = 0;
        do {
            byte[] byArray3 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
            byte[] byArray4 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray4[0] & 0xFFL) << 56 | ((long)byArray4[1] & 0xFFL) << 48 | ((long)byArray4[2] & 0xFFL) << 40 | ((long)byArray4[3] & 0xFFL) << 32 | ((long)byArray4[4] & 0xFFL) << 24 | ((long)byArray4[5] & 0xFFL) << 16 | ((long)byArray4[6] & 0xFFL) << 8 | (long)byArray4[7] & 0xFFL;
        } while (n3 < n2);
        lVcnQ = lArray;
        aZoru = new Integer[2];
    }

    public boolean oG() {
        long l = ZyPUF ^ 0xB256CC1EED1L;
        String[] stringArray = Class_aj_95d0a719.oA();
        float f = this.QmyNF.dhj() - 0.0f;
        float f2 = f == 0.0f ? 0 : (f > 0.0f ? 1 : -1);
        if (stringArray != null) {
            f2 = f2 != false ? 1.0f : 0.0f;
        }
        return (boolean)f2;
    }

    private static MatchException oM(MatchException matchException) {
        return matchException;
    }

    private static int oN(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x7316;
        if (aZoru[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = lVcnQ[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])nWsJs.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    nWsJs.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_ak_2ff604c7", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_ak_2ff604c7.aZoru[n2] = n3;
        }
        return aZoru[n2];
    }

    public Class_rk_bf8630d1 oK() {
        return this.QmyNF;
    }

    private static int oO(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_ak_2ff604c7.oN(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static CallSite oP(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_ak_2ff604c7" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public void oF(Class_lC_5322e8cf class_lC_5322e8cf, float f) {
        Class_mG_52c8d386 class_mG_52c8d386 = this.CtPwV.bjb().coa(255.0f * (0.75f + 0.25f * this.tDliG.dhj()));
        float f2 = this.MCnYt + 9.0f;
        float f3 = this.pNyTQ + Class_jf_d1c4f950.bAH(Class_ax_3a65ba66.aqGSY.cat(), 18.0f);
        class_lC_5322e8cf.ceI(Class_ax_3a65ba66.aqGSY, ((Class_cB_67aec11c)this.sCXfR).Vm(), f2, f3, class_mG_52c8d386, 0.7f, 0.99f, f);
    }

    public Class_az_a4990dcf oI() {
        return this.uVhpi;
    }

    public Class_rk_bf8630d1 oL() {
        return this.tDliG;
    }

    public float oH() {
        return this.QmyNF.dhj();
    }

    public T oJ() {
        return this.sCXfR;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_ak_2ff604c7.class, "oO", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

