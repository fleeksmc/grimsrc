/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.particle.Particle
 */
package recovered.internal;

import net.minecraft.client.particle.Particle;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gK_e2e886ea
extends Class_hH_ae8f8f77 {
    private Particle eNNyC;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gK_e2e886ea(Particle particle) {
        this.eNNyC = particle;
    }

    public Particle bce() {
        return this.eNNyC;
    }
}

