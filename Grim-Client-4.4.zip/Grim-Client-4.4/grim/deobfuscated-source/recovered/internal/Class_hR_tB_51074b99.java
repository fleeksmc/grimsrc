/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 */
package recovered.internal;

import java.util.List;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import recovered.core.NativeLoader;
import recovered.internal.Class_hJ_a20df6c5;
import recovered.internal.Class_hK_37a4c9e8;
import recovered.internal.Class_hR_81cd6b59;

class Class_hR_tB_51074b99
implements Class_hK_37a4c9e8 {
    private static long jZujz;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_hR_tB_51074b99(Class_hR_81cd6b59 class_hR_81cd6b59) {
    }

    static {
        NativeLoader.doInit(Class_hR_tB_51074b99.class);
        Class_hR_tB_51074b99._b6c6e7fddd0c13db92fdbad23f161b50();
    }

    @Override
    public native Class_hJ_a20df6c5 validate(String var1);

    @Override
    public native List<String> suggestions(String var1);

    private static native void _b6c6e7fddd0c13db92fdbad23f161b50();

    private static native boolean dpz(String var0);

    private static native boolean dpy(String var0, String var1);

    private static native String dpA(AbstractClientPlayerEntity var0);

    private static native MatchException dpB(MatchException var0);
}

