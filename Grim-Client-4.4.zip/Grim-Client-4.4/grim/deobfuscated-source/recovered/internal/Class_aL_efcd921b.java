/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_j_75349621;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mT_db06bea0;
import recovered.internal.Class_n_c440d6e8;
import recovered.internal.Class_pN_84dc4bee;
import recovered.internal.Class_py_edabaa53;

public final class Class_aL_efcd921b {
    private final Map<Class_py_edabaa53, Class_n_c440d6e8> KvEqV = new IdentityHashMap<Class_py_edabaa53, Class_n_c440d6e8>();
    private Class_py_edabaa53 ZmBFy;
    private Class_mT_db06bea0 QpDhe = Class_mT_db06bea0.cpA();
    private boolean uXZpz;
    private static String OQJvI;
    private static long nlySR;
    private static String[] lRcQp;
    private static String[] wkmMg;
    private static Map EKgco;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_aL_efcd921b.class);
        Class_aL_efcd921b._fa2347ff9659be2de33590027733141e();
    }

    private static native CallSite xa(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native void _fa2347ff9659be2de33590027733141e();

    private static native /* synthetic */ Class_n_c440d6e8 wT(Class_py_edabaa53 var0);

    public static native void wU(String var0);

    public static native String wV();

    public native void wQ();

    public native void wP(Class_lC_5322e8cf var1, List<Class_pN_84dc4bee> var2, Class_py_edabaa53 var3, boolean var4, boolean var5, float var6);

    private native Class_j_75349621 wS(Class_py_edabaa53 var1);

    private native Class_n_c440d6e8 wR(Class_py_edabaa53 var1);

    private static native String wX(byte[] var0);

    private static native Object wZ(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native String wY(int var0, long var1);

    private static native MatchException wW(MatchException var0);
}

