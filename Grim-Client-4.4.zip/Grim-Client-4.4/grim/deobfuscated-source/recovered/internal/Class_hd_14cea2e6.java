/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.BlockPos
 */
package recovered.internal;

import net.minecraft.util.math.BlockPos;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_hd_14cea2e6
extends Class_hH_ae8f8f77 {
    private BlockPos kjIxy;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hd_14cea2e6(BlockPos blockPos) {
        this.kjIxy = blockPos;
    }

    public BlockPos bcw() {
        return this.kjIxy;
    }
}

