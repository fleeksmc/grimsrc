/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.MathHelper
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.Key;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.util.math.MathHelper;
import recovered.core.ClientMain;
import recovered.internal.Class_A_dbc69253;
import recovered.internal.Class_B_59ec6581;
import recovered.internal.Class_C_852be712;
import recovered.internal.Class_D_115059b3;
import recovered.internal.Class_ak_2ff604c7;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_cA_4f409280;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_cC_14ef8bb5;
import recovered.internal.Class_cD_84e11ee0;
import recovered.internal.Class_cF_8338f0f7;
import recovered.internal.Class_cG_6e1ba021;
import recovered.internal.Class_cH_5b9db066;
import recovered.internal.Class_cI_ff5df82f;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_cK_54b0e25a;
import recovered.internal.Class_cL_ccb21d14;
import recovered.internal.Class_ct_fa795250;
import recovered.internal.Class_cv_f4b0140a;
import recovered.internal.Class_cx_024b7067;
import recovered.internal.Class_cy_687dcdb6;
import recovered.internal.Class_cz_c738b74f;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_o_cf1b173b;
import recovered.internal.Class_p_35a2c4e0;
import recovered.internal.Class_q_f546fcb9;
import recovered.internal.Class_r_14627bb0;
import recovered.internal.Class_u_1761c4c4;
import recovered.internal.Class_v_5eec8686;
import recovered.internal.Class_w_3ef9c66d;
import recovered.internal.Class_x_c36b9754;
import recovered.internal.Class_y_bc71aa82;

public class Class_jf_d1c4f950 {
    private static final SimpleDateFormat Jlqur;
    private static String[] KVigV;
    private static final long qUVwV;
    private static final String[] OdySV;
    private static final String[] cCYcp;
    private static final Map XKQjR;
    private static final long[] RAjsP;
    private static final Integer[] COJav;
    private static final Map yjAZm;
    private static final long[] yPLqH;
    private static final Long[] LGHNj;
    private static final Map jNPAX;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    public static boolean bAV(float f, float f2, float f3, float f4, Class_az_a4990dcf class_az_a4990dcf) {
        float f5;
        block5: {
            String[] stringArray;
            block7: {
                float f6;
                block6: {
                    block4: {
                        long l = qUVwV ^ 0x45A5DC063F0AL;
                        float f7 = f + f3;
                        stringArray = Class_jf_d1c4f950.bBe();
                        f6 = f2 + f4;
                        float f8 = class_az_a4990dcf.tc() - f;
                        f5 = f8 == 0.0f ? 0 : (f8 > 0.0f ? 1 : -1);
                        if (stringArray == null) break block4;
                        if (f5 <= 0) break block5;
                        float f9 = class_az_a4990dcf.tr() - f7;
                        f5 = f9 == 0.0f ? 0 : (f9 < 0.0f ? -1 : 1);
                    }
                    if (stringArray == null) break block6;
                    if (f5 >= 0) break block5;
                    float f10 = class_az_a4990dcf.tb() - f2;
                    f5 = f10 == 0.0f ? 0 : (f10 > 0.0f ? 1 : -1);
                }
                if (stringArray == null) break block7;
                if (f5 <= 0) break block5;
                float f11 = class_az_a4990dcf.ts() - f6;
                f5 = f11 == 0.0f ? 0 : (f11 < 0.0f ? -1 : 1);
            }
            if (stringArray == null) return (boolean)f5;
            if (f5 < 0) {
                f5 = 1.0f;
                return (boolean)f5;
            }
        }
        f5 = 0.0f;
        return (boolean)f5;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean bAW(Class_lc_b8480f87 class_lc_b8480f87, Class_az_a4990dcf class_az_a4990dcf) {
        float f;
        block5: {
            String[] stringArray;
            block7: {
                block6: {
                    block4: {
                        long l = qUVwV ^ 0x3244DB784F93L;
                        stringArray = Class_jf_d1c4f950.bBe();
                        float f2 = class_az_a4990dcf.tc() - class_lc_b8480f87.bXF();
                        f = f2 == 0.0f ? 0 : (f2 > 0.0f ? 1 : -1);
                        if (stringArray == null) break block4;
                        if (f <= 0) break block5;
                        float f3 = class_az_a4990dcf.tr() - class_lc_b8480f87.bXz();
                        f = f3 == 0.0f ? 0 : (f3 < 0.0f ? -1 : 1);
                    }
                    if (stringArray == null) break block6;
                    if (f >= 0) break block5;
                    float f4 = class_az_a4990dcf.tb() - class_lc_b8480f87.bXG();
                    f = f4 == 0.0f ? 0 : (f4 > 0.0f ? 1 : -1);
                }
                if (stringArray == null) break block7;
                if (f <= 0) break block5;
                float f5 = class_az_a4990dcf.ts() - class_lc_b8480f87.bXA();
                f = f5 == 0.0f ? 0 : (f5 < 0.0f ? -1 : 1);
            }
            if (stringArray == null) return (boolean)f;
            if (f < 0) {
                f = 1.0f;
                return (boolean)f;
            }
        }
        f = 0.0f;
        return (boolean)f;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean bAX(double d, double d2, double d3, double d4, double d5, double d6) {
        double d7;
        block5: {
            String[] stringArray;
            block7: {
                block6: {
                    block4: {
                        long l = qUVwV ^ 0x652217FF95EL;
                        stringArray = Class_jf_d1c4f950.bBe();
                        d7 = d5 == d ? 0 : (d5 > d ? 1 : -1);
                        if (stringArray == null) break block4;
                        if (d7 < 0) break block5;
                        double d8 = d5 - (d + d3);
                        d7 = d8 == 0.0 ? 0 : (d8 < 0.0 ? -1 : 1);
                    }
                    if (stringArray == null) break block6;
                    if (d7 >= 0) break block5;
                    d7 = d6 == d2 ? 0 : (d6 > d2 ? 1 : -1);
                }
                if (stringArray == null) break block7;
                if (d7 < 0) break block5;
                double d9 = d6 - (d2 + d4);
                d7 = d9 == 0.0 ? 0 : (d9 < 0.0 ? -1 : 1);
            }
            if (stringArray == null) return (boolean)d7;
            if (d7 < 0) {
                d7 = 1.0;
                return (boolean)d7;
            }
        }
        d7 = 0.0;
        return (boolean)d7;
    }

    private static String bBh(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x3E3A;
        if (cCYcp[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])XKQjR.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    XKQjR.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jf_d1c4f950", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = OdySV[n2].getBytes("ISO-8859-1");
            Class_jf_d1c4f950.cCYcp[n2] = Class_jf_d1c4f950.bBg(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return cCYcp[n2];
    }

    public static String bAT(Instant instant) {
        long l;
        CallSite callSite;
        long l2;
        long l3;
        block12: {
            long l4;
            long l5;
            block11: {
                l3 = qUVwV ^ 0x5944EC41648BL;
                Instant instant2 = Instant.now();
                Duration duration = Duration.between(instant, instant2);
                l5 = duration.getSeconds();
                String[] stringArray = Class_jf_d1c4f950.bBe();
                long l6 = l5 - Class_jf_d1c4f950.bBp("v", (int)11562, (long)(0x651076705E47398BL ^ l3));
                l4 = l6 == 0L ? 0 : (l6 < 0L ? -1 : 1);
                if (stringArray != null) {
                    if (l4 < 0) {
                        return Class_jf_d1c4f950.bBj("f", (int)6320, (long)(0x55D2E9B2634014D2L ^ l3));
                    }
                    long l7 = l5 - Class_jf_d1c4f950.bBp("v", (int)1631, (long)(0x6350B383F48A12F9L ^ l3));
                    l4 = l7 == 0L ? 0 : (l7 < 0L ? -1 : 1);
                }
                if (stringArray != null) {
                    if (l4 < 0) {
                        long l8;
                        return l8 + (String)((Object)Class_jf_d1c4f950.bBj("f", (int)26885, (long)(0xD78FFF9B464656EL ^ l3))) + ((l8 = l5 / Class_jf_d1c4f950.bBp("v", (int)11562, (long)(0x651076705E47398BL ^ l3))) > 1L ? "s" : "") + (String)((Object)Class_jf_d1c4f950.bBj("f", (int)9483, (long)(0x7DB68F2B031C296AL ^ l3)));
                    }
                    long l9 = l5 - Class_jf_d1c4f950.bBp("v", (int)18330, (long)(0x62F3589E87D2D333L ^ l3));
                    l4 = l9 == 0L ? 0 : (l9 < 0L ? -1 : 1);
                }
                if (stringArray != null) {
                    if (l4 < 0) {
                        long l10;
                        return l10 + (String)((Object)Class_jf_d1c4f950.bBj("f", (int)21168, (long)(0x654661FF7CB7DED3L ^ l3))) + ((l10 = l5 / Class_jf_d1c4f950.bBp("v", (int)11420, (long)(0x137A40B0F4F8B83CL ^ l3))) > 1L ? "s" : "") + (String)((Object)Class_jf_d1c4f950.bBj("f", (int)27460, (long)(0x641C5AC758B0E722L ^ l3)));
                    }
                    long l11 = l5 - Class_jf_d1c4f950.bBp("v", (int)22732, (long)(0x4A1BB2C3D6C9CC64L ^ l3));
                    l4 = l11 == 0L ? 0 : (l11 < 0L ? -1 : 1);
                }
                if (stringArray == null) break block11;
                if (l4 < 0) {
                    long l12;
                    return l12 + (String)((Object)Class_jf_d1c4f950.bBj("f", (int)3511, (long)(0x2801BA91D02101DFL ^ l3))) + ((l12 = l5 / Class_jf_d1c4f950.bBp("v", (int)2511, (long)(0x642DCB5E187D9D6CL ^ l3))) > 1L ? "s" : "") + (String)((Object)Class_jf_d1c4f950.bBj("f", (int)27460, (long)(0x641C5AC758B0E722L ^ l3)));
                }
                l2 = l5;
                callSite = Class_jf_d1c4f950.bBp("v", (int)25267, (long)(0x6AA2A894FD2A7619L ^ l3));
                if (stringArray == null) break block12;
                long l13 = l2 - callSite;
                l4 = l13 == 0L ? 0 : (l13 < 0L ? -1 : 1);
            }
            if (l4 < 0) {
                long l14;
                return l14 + (String)((Object)Class_jf_d1c4f950.bBj("f", (int)16788, (long)(0x1303D0F56D294DFEL ^ l3))) + ((l14 = l5 / Class_jf_d1c4f950.bBp("v", (int)7002, (long)(0x79823089F91E8FF1L ^ l3))) > 1L ? "s" : "") + (String)((Object)Class_jf_d1c4f950.bBj("f", (int)27460, (long)(0x641C5AC758B0E722L ^ l3)));
            }
            l2 = l5;
            callSite = Class_jf_d1c4f950.bBp("v", (int)15713, (long)(0x73069083085DA9C3L ^ l3));
        }
        return l + (String)((Object)Class_jf_d1c4f950.bBj("f", (int)29572, (long)(0x4C3D4AB7CF83FFE4L ^ l3))) + ((l = l2 / callSite) > 1L ? "s" : "") + (String)((Object)Class_jf_d1c4f950.bBj("f", (int)27460, (long)(0x641C5AC758B0E722L ^ l3)));
    }

    private static long bBn(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x26F9;
        if (LGHNj[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = yPLqH[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])jNPAX.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    jNPAX.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jf_d1c4f950", exception);
            }
            long l4 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            Class_jf_d1c4f950.LGHNj[n2] = l4;
        }
        return LGHNj[n2];
    }

    private static int bBl(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_jf_d1c4f950.bBk(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public static void bAZ(String string) {
        ClientMain.dlmvG.keyboard.setClipboard(string);
    }

    private static long bBo(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        long l2 = Class_jf_d1c4f950.bBn(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l2;
    }

    private static Object bBi(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_jf_d1c4f950.bBh(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static String bBg(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static int bBk(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x2AA2;
        if (COJav[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = RAjsP[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])yjAZm.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    yjAZm.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jf_d1c4f950", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_jf_d1c4f950.COJav[n2] = n3;
        }
        return COJav[n2];
    }

    public static String bBa() {
        return Jlqur.format(new Date());
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean bAU(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
        float f9;
        block5: {
            String[] stringArray;
            block7: {
                float f10;
                block6: {
                    block4: {
                        long l = qUVwV ^ 0x4F577A9CC17DL;
                        float f11 = f + f3;
                        stringArray = Class_jf_d1c4f950.bBe();
                        f10 = f2 + f4;
                        float f12 = f5 + f7 - f;
                        f9 = f12 == 0.0f ? 0 : (f12 > 0.0f ? 1 : -1);
                        if (stringArray == null) break block4;
                        if (f9 <= 0) break block5;
                        f9 = f5 == f11 ? 0 : (f5 < f11 ? -1 : 1);
                    }
                    if (stringArray == null) break block6;
                    if (f9 >= 0) break block5;
                    float f13 = f6 + f8 - f2;
                    f9 = f13 == 0.0f ? 0 : (f13 > 0.0f ? 1 : -1);
                }
                if (stringArray == null) break block7;
                if (f9 <= 0) break block5;
                f9 = f6 == f10 ? 0 : (f6 < f10 ? -1 : 1);
            }
            if (stringArray == null) return (boolean)f9;
            if (f9 < 0) {
                f9 = 1.0f;
                return (boolean)f9;
            }
        }
        f9 = 0.0f;
        return (boolean)f9;
    }

    public static int bBb(double d) {
        return String.valueOf(Math.abs((long)d)).length();
    }

    public static String bAS(Instant instant) {
        long l = qUVwV ^ 0x197CD6A542DEL;
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern((String)((Object)Class_jf_d1c4f950.bBj("f", (int)5667, (long)(0x7221F14DDB81BC12L ^ l)))).withZone(ZoneId.systemDefault());
        return dateTimeFormatter.format(instant);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean bAY(Class_lc_b8480f87 class_lc_b8480f87, double d, double d2) {
        double d3;
        block5: {
            String[] stringArray;
            block7: {
                block6: {
                    block4: {
                        long l = qUVwV ^ 0x42BD7D7D829L;
                        stringArray = Class_jf_d1c4f950.bBe();
                        double d4 = d - (double)class_lc_b8480f87.bXF();
                        d3 = d4 == 0.0 ? 0 : (d4 > 0.0 ? 1 : -1);
                        if (stringArray == null) break block4;
                        if (d3 < 0) break block5;
                        double d5 = d - (double)class_lc_b8480f87.bXz();
                        d3 = d5 == 0.0 ? 0 : (d5 < 0.0 ? -1 : 1);
                    }
                    if (stringArray == null) break block6;
                    if (d3 >= 0) break block5;
                    double d6 = d2 - (double)class_lc_b8480f87.bXG();
                    d3 = d6 == 0.0 ? 0 : (d6 > 0.0 ? 1 : -1);
                }
                if (stringArray == null) break block7;
                if (d3 < 0) break block5;
                double d7 = d2 - (double)class_lc_b8480f87.bXA();
                d3 = d7 == 0.0 ? 0 : (d7 < 0.0 ? -1 : 1);
            }
            if (stringArray == null) return (boolean)d3;
            if (d3 < 0) {
                d3 = 1.0;
                return (boolean)d3;
            }
        }
        d3 = 0.0;
        return (boolean)d3;
    }

    public static float bAH(float f, float f2) {
        return (f2 - f) * 0.5f;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean bAE(double d, double d2, double d3, double d4, double d5, double d6) {
        double d7;
        block5: {
            String[] stringArray;
            block7: {
                block6: {
                    block4: {
                        long l = qUVwV ^ 0x5B74EAD4BCB1L;
                        stringArray = Class_jf_d1c4f950.bBe();
                        d7 = d == d3 ? 0 : (d > d3 ? 1 : -1);
                        if (stringArray == null) break block4;
                        if (d7 < 0) break block5;
                        double d8 = d - (d3 + d5);
                        d7 = d8 == 0.0 ? 0 : (d8 < 0.0 ? -1 : 1);
                    }
                    if (stringArray == null) break block6;
                    if (d7 > 0) break block5;
                    d7 = d2 == d4 ? 0 : (d2 > d4 ? 1 : -1);
                }
                if (stringArray == null) break block7;
                if (d7 < 0) break block5;
                double d9 = d2 - (d4 + d6);
                d7 = d9 == 0.0 ? 0 : (d9 < 0.0 ? -1 : 1);
            }
            if (stringArray == null) return (boolean)d7;
            if (d7 <= 0) {
                d7 = 1.0;
                return (boolean)d7;
            }
        }
        d7 = 0.0;
        return (boolean)d7;
    }

    private static MatchException bBf(MatchException matchException) {
        return matchException;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean bAG(Class_lC_5322e8cf class_lC_5322e8cf, double d, double d2, double d3, double d4) {
        double d5;
        block5: {
            String[] stringArray;
            block7: {
                double d6;
                block6: {
                    block4: {
                        long l = qUVwV ^ 0x345E65FA1E5EL;
                        double d7 = class_lC_5322e8cf.cff();
                        stringArray = Class_jf_d1c4f950.bBe();
                        d6 = class_lC_5322e8cf.cfg();
                        d5 = d7 == d ? 0 : (d7 > d ? 1 : -1);
                        if (stringArray == null) break block4;
                        if (d5 < 0) break block5;
                        double d8 = d7 - (d + d3);
                        d5 = d8 == 0.0 ? 0 : (d8 < 0.0 ? -1 : 1);
                    }
                    if (stringArray == null) break block6;
                    if (d5 > 0) break block5;
                    d5 = d6 == d2 ? 0 : (d6 > d2 ? 1 : -1);
                }
                if (stringArray == null) break block7;
                if (d5 < 0) break block5;
                double d9 = d6 - (d2 + d4);
                d5 = d9 == 0.0 ? 0 : (d9 < 0.0 ? -1 : 1);
            }
            if (stringArray == null) return (boolean)d5;
            if (d5 <= 0) {
                d5 = 1.0;
                return (boolean)d5;
            }
        }
        d5 = 0.0;
        return (boolean)d5;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean bAF(Class_lC_5322e8cf class_lC_5322e8cf, Class_az_a4990dcf class_az_a4990dcf) {
        double d;
        block5: {
            String[] stringArray;
            block7: {
                double d2;
                block6: {
                    block4: {
                        long l = qUVwV ^ 0x71077AE43393L;
                        double d3 = class_lC_5322e8cf.cff();
                        stringArray = Class_jf_d1c4f950.bBe();
                        d2 = class_lC_5322e8cf.cfg();
                        double d4 = d3 - (double)class_az_a4990dcf.tr();
                        d = d4 == 0.0 ? 0 : (d4 > 0.0 ? 1 : -1);
                        if (stringArray == null) break block4;
                        if (d < 0) break block5;
                        double d5 = d3 - (double)class_az_a4990dcf.tc();
                        d = d5 == 0.0 ? 0 : (d5 < 0.0 ? -1 : 1);
                    }
                    if (stringArray == null) break block6;
                    if (d > 0) break block5;
                    double d6 = d2 - (double)class_az_a4990dcf.ts();
                    d = d6 == 0.0 ? 0 : (d6 > 0.0 ? 1 : -1);
                }
                if (stringArray == null) break block7;
                if (d < 0) break block5;
                double d7 = d2 - (double)class_az_a4990dcf.tb();
                d = d7 == 0.0 ? 0 : (d7 < 0.0 ? -1 : 1);
            }
            if (stringArray == null) return (boolean)d;
            if (d <= 0) {
                d = 1.0;
                return (boolean)d;
            }
        }
        d = 0.0;
        return (boolean)d;
    }

    public static String bAN(long l) {
        long l2 = qUVwV ^ 0x4697C9B6304FL;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        long l3 = l - 0L;
        long l4 = l3 == 0L ? 0 : (l3 < 0L ? -1 : 1);
        if (stringArray != null) {
            l4 = l4 < 0 ? (long)1 : (long)0;
        }
        long l5 = l4;
        long l6 = Math.abs(l);
        long l7 = l6 / Class_jf_d1c4f950.bBp("v", (int)9252, (long)(0x401BDC8B3FA6445L ^ l2));
        long l8 = l6 % Class_jf_d1c4f950.bBp("v", (int)11562, (long)(0x651069A37BB06D4FL ^ l2));
        String string = l7 + ":" + (l8 < Class_jf_d1c4f950.bBp("v", (int)270, (long)(0x2CBCFEFCA1EE416DL ^ l2)) ? "0" : "") + l8;
        return l5 != false ? "-" + string : string;
    }

    private static CallSite bBm(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jf_d1c4f950" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public static String bAP(double d) {
        String string;
        BigDecimal bigDecimal;
        long l = qUVwV ^ 0x748FE21CD3C1L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        double d2 = d;
        if (stringArray != null) {
            if (!Double.isFinite(d2)) {
                return Double.toString(d);
            }
            d2 = d;
        }
        BigDecimal bigDecimal2 = bigDecimal = BigDecimal.valueOf(d2).setScale(2, RoundingMode.HALF_UP);
        if (stringArray != null) {
            if (bigDecimal2.compareTo(BigDecimal.valueOf(d)) == 0) {
                return Class_jf_d1c4f950.bAO(d);
            }
            bigDecimal2 = BigDecimal.valueOf(d).setScale(5, RoundingMode.HALF_UP).stripTrailingZeros();
        }
        BigDecimal bigDecimal3 = bigDecimal2;
        String string2 = string = bigDecimal3.toPlainString();
        if (stringArray != null) {
            string2 = string2.equals(Class_jf_d1c4f950.bBj("f", (int)15730, (long)(0x214C4FCF2DF50651L ^ l))) ? "0" : string;
        }
        return string2;
    }

    public static String bAL(String string) {
        Object object;
        block4: {
            block5: {
                String string2;
                block2: {
                    block3: {
                        long l = qUVwV ^ 0x45CB671C41E2L;
                        String[] stringArray = Class_jf_d1c4f950.bBe();
                        string2 = string;
                        if (stringArray == null) break block2;
                        if (string2 == null) break block3;
                        object = string;
                        if (stringArray == null) break block4;
                        if (!((String)object).isBlank()) break block5;
                    }
                    string2 = string;
                }
                return string2;
            }
            object = string.substring(0, 1).toUpperCase() + string.substring(1).toLowerCase();
        }
        return object;
    }

    public static float bAJ(float f, float f2, float f3, float f4, double d) {
        return (float)(Math.min(1.0, Math.max(0.0, (d - (double)f3) / (double)f4)) * (double)(f2 - f) + (double)f);
    }

    public static float bAI(float f, float f2, float f3) {
        return (f - f2) / (f3 - f2);
    }

    public static String bAM(double d) {
        long l = qUVwV ^ 0x20B152C38B0L;
        long l2 = Math.round(d * 10.0);
        long l3 = l2 / Class_jf_d1c4f950.bBp("v", (int)26697, (long)(0x166BAFBE4FE8A0D6L ^ l));
        long l4 = Math.abs(l2 % Class_jf_d1c4f950.bBp("v", (int)270, (long)(0x2CBCBA607D744992L ^ l)));
        return l3 + "." + l4;
    }

    private static CallSite bBp(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jf_d1c4f950" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static CallSite bBj(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jf_d1c4f950" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public static List<int[]> bAQ(int[] nArray, float f, Class_lq_87a74641 class_lq_87a74641) {
        ArrayList<Object> arrayList;
        block52: {
            ArrayList<int[]> arrayList2;
            block41: {
                int n;
                int n2;
                String[] stringArray;
                ArrayList<Integer> arrayList3;
                block36: {
                    long l = qUVwV ^ 0x7E81442FC8DFL;
                    arrayList2 = new ArrayList<int[]>();
                    arrayList3 = new ArrayList<Integer>();
                    float f2 = 0.0f;
                    float f3 = class_lq_87a74641.cap(new int[]{(int)Class_jf_d1c4f950.bBm("k", (int)25490, (long)(0x2182CEAF6E24573DL ^ l))});
                    stringArray = Class_jf_d1c4f950.bBe();
                    int n3 = 0;
                    int n4 = nArray.length;
                    Runnable runnable = () -> {
                        block5: {
                            block3: {
                                int n;
                                String[] stringArray;
                                block4: {
                                    long l = qUVwV ^ 0x25EBC3E1B4D4L;
                                    stringArray = Class_jf_d1c4f950.bBe();
                                    n = arrayList3.isEmpty();
                                    if (stringArray == null) break block4;
                                    if (n != 0) break block5;
                                    n = arrayList3.size();
                                }
                                int[] nArray = new int[n];
                                for (int i = 0; i < arrayList3.size(); ++i) {
                                    nArray[i] = (Integer)arrayList3.get(i);
                                    if (stringArray != null) {
                                        if (stringArray != null) continue;
                                    }
                                    break block3;
                                }
                                arrayList2.add(nArray);
                            }
                            arrayList3.clear();
                        }
                    };
                    while (n3 < n4) {
                        block51: {
                            Object object;
                            int n5;
                            block50: {
                                int n6;
                                block46: {
                                    float f4;
                                    block39: {
                                        boolean bl;
                                        ArrayList<Integer> arrayList4;
                                        int[] nArray2;
                                        block47: {
                                            float f5;
                                            block42: {
                                                block43: {
                                                    block38: {
                                                        float f6;
                                                        block45: {
                                                            block44: {
                                                                Object object2;
                                                                int n7;
                                                                block37: {
                                                                    n2 = n3;
                                                                    if (stringArray == null) break block36;
                                                                    for (n6 = v68121; n6 < n4; ++n6) {
                                                                        n7 = nArray[n6];
                                                                        object2 = Class_jf_d1c4f950.bBm("k", (int)18398, (long)(0x372C5809206A7370L ^ l));
                                                                        if (stringArray != null && stringArray != null) {
                                                                            if (n7 == object2) break;
                                                                            if (stringArray != null) continue;
                                                                        }
                                                                        break block37;
                                                                    }
                                                                    n7 = n6;
                                                                    object2 = n3;
                                                                }
                                                                n = n7 - object2;
                                                                nArray2 = new int[n];
                                                                System.arraycopy(nArray, n3, nArray2, 0, n);
                                                                f6 = class_lq_87a74641.cap(nArray2);
                                                                f5 = f6 == f ? 0 : (f6 < f ? -1 : 1);
                                                                if (stringArray == null) break block42;
                                                                if (f5 > 0) break block43;
                                                                boolean bl2 = arrayList3.isEmpty();
                                                                if (stringArray != null) {
                                                                    bl2 = !bl2;
                                                                }
                                                                boolean bl3 = bl2;
                                                                f4 = f2 + (bl3 ? f3 : 0.0f) + f6;
                                                                float f7 = f4 == f ? 0 : (f4 > f ? 1 : -1);
                                                                if (stringArray != null) {
                                                                    if (f7 > 0) {
                                                                        runnable.run();
                                                                        f2 = 0.0f;
                                                                        bl3 = false;
                                                                    }
                                                                    f7 = (float)bl3;
                                                                }
                                                                if (stringArray == null) break block44;
                                                                if (f7 == false) break block45;
                                                                f7 = (float)arrayList3.add((int)Class_jf_d1c4f950.bBm("k", (int)18398, (long)(0x372C5809206A7370L ^ l)));
                                                            }
                                                            f2 += f3;
                                                        }
                                                        for (int n8 : nArray2) {
                                                            arrayList3.add(n8);
                                                            if (stringArray != null) {
                                                                if (stringArray != null) continue;
                                                            }
                                                            break block38;
                                                        }
                                                        f2 += f6;
                                                    }
                                                    if (stringArray != null) break block46;
                                                }
                                                arrayList4 = arrayList3;
                                                if (stringArray == null) break block47;
                                                f5 = (float)arrayList4.isEmpty();
                                            }
                                            if (f5 == false) {
                                                runnable.run();
                                            }
                                            arrayList4 = new ArrayList<Integer>();
                                        }
                                        ArrayList<Integer> arrayList5 = arrayList4;
                                        f4 = 0.0f;
                                        for (int i = 0; i < n; ++i) {
                                            float f8;
                                            block48: {
                                                int n9;
                                                int n10;
                                                block49: {
                                                    n10 = nArray2[i];
                                                    f8 = class_lq_87a74641.cap(new int[]{n10});
                                                    bl = arrayList5.isEmpty();
                                                    if (stringArray == null) break block39;
                                                    if (stringArray == null) break block48;
                                                    if (bl) break block49;
                                                    float f9 = f4 + f8 - f;
                                                    n9 = f9 == 0.0f ? 0 : (f9 > 0.0f ? 1 : -1);
                                                    if (stringArray == null) break block48;
                                                    if (n9 > 0) {
                                                        block40: {
                                                            int[] nArray3 = new int[arrayList5.size()];
                                                            for (int j = 0; j < arrayList5.size(); ++j) {
                                                                nArray3[j] = (Integer)arrayList5.get(j);
                                                                if (stringArray != null) {
                                                                    if (stringArray != null) continue;
                                                                }
                                                                break block40;
                                                            }
                                                            arrayList2.add(nArray3);
                                                            arrayList5.clear();
                                                        }
                                                        f4 = 0.0f;
                                                    }
                                                }
                                                n9 = arrayList5.add(n10);
                                            }
                                            f4 += f8;
                                            if (stringArray != null) continue;
                                        }
                                        arrayList3.clear();
                                        bl = arrayList3.addAll(arrayList5);
                                    }
                                    f2 = f4;
                                }
                                n5 = n3 = n6;
                                object = n4;
                                if (stringArray == null) break block50;
                                if (n5 >= object) break block51;
                                n5 = nArray[n3];
                                object = Class_jf_d1c4f950.bBm("k", (int)18398, (long)(0x372C5809206A7370L ^ l));
                            }
                            if (n5 == object) {
                                ++n3;
                            }
                        }
                        if (stringArray != null) continue;
                    }
                    arrayList = arrayList3;
                    if (stringArray == null) break block52;
                    n2 = arrayList.isEmpty() ? 1 : 0;
                }
                if (n2 == 0) {
                    int[] nArray4 = new int[arrayList3.size()];
                    for (n = 0; n < arrayList3.size(); ++n) {
                        nArray4[n] = (Integer)arrayList3.get(n);
                        if (stringArray != null) {
                            if (stringArray != null) continue;
                        }
                        break block41;
                    }
                    arrayList2.add(nArray4);
                }
            }
            arrayList = arrayList2;
        }
        return arrayList;
    }

    public static String bAO(double d) {
        String string;
        long l = qUVwV ^ 0x5D5F424DAC8AL;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        double d2 = d;
        if (stringArray != null) {
            if (!Double.isFinite(d2)) {
                return Double.toString(d);
            }
            d2 = d;
        }
        BigDecimal bigDecimal = BigDecimal.valueOf(d2).setScale(2, RoundingMode.HALF_UP).stripTrailingZeros();
        String string2 = string = bigDecimal.toPlainString();
        if (stringArray != null) {
            string2 = string2.equals(Class_jf_d1c4f950.bBj("f", (int)22129, (long)(0x44FB70DDD4669217L ^ l))) ? "0" : string;
        }
        return string2;
    }

    public static float bAK(float f, float f2, float f3, double d) {
        block3: {
            double d2;
            double d3;
            block2: {
                long l = qUVwV ^ 0x414DED9613E6L;
                String[] stringArray = Class_jf_d1c4f950.bBe();
                d3 = d;
                d2 = 0.0;
                if (stringArray == null) break block2;
                if (!(d3 > d2)) break block3;
                d3 = (double)Math.round((double)(f - f2) / d) * d;
                d2 = f2;
            }
            f = (float)(d3 + d2);
        }
        return MathHelper.clamp((float)f, (float)f2, (float)f3);
    }

    public static Class_ak_2ff604c7<? extends Class_cB_67aec11c> bAR(Class_cB_67aec11c class_cB_67aec11c, Class_az_a4990dcf class_az_a4990dcf) {
        String[] stringArray;
        Class_ak_2ff604c7 class_ak_2ff604c7;
        block7: {
            Class_cB_67aec11c class_cB_67aec11c2;
            block34: {
                boolean bl;
                block32: {
                    block33: {
                        block30: {
                            block31: {
                                block28: {
                                    block29: {
                                        block26: {
                                            block27: {
                                                block24: {
                                                    block25: {
                                                        block22: {
                                                            block23: {
                                                                block20: {
                                                                    block21: {
                                                                        block18: {
                                                                            block19: {
                                                                                block16: {
                                                                                    block17: {
                                                                                        block14: {
                                                                                            block15: {
                                                                                                block12: {
                                                                                                    block13: {
                                                                                                        block10: {
                                                                                                            block11: {
                                                                                                                block8: {
                                                                                                                    block9: {
                                                                                                                        block5: {
                                                                                                                            block6: {
                                                                                                                                long l = qUVwV ^ 0x2D3D8A74E017L;
                                                                                                                                class_ak_2ff604c7 = null;
                                                                                                                                stringArray = Class_jf_d1c4f950.bBe();
                                                                                                                                bl = class_cB_67aec11c instanceof Class_cJ_2ae1a557;
                                                                                                                                if (stringArray == null) break block5;
                                                                                                                                if (!bl) break block6;
                                                                                                                                Class_cJ_2ae1a557 class_cJ_2ae1a557 = (Class_cJ_2ae1a557)class_cB_67aec11c;
                                                                                                                                class_ak_2ff604c7 = new Class_v_5eec8686(class_cJ_2ae1a557, class_az_a4990dcf);
                                                                                                                                break block7;
                                                                                                                            }
                                                                                                                            bl = class_cB_67aec11c instanceof Class_cz_c738b74f;
                                                                                                                        }
                                                                                                                        if (stringArray == null) break block8;
                                                                                                                        if (!bl) break block9;
                                                                                                                        Class_cz_c738b74f class_cz_c738b74f = (Class_cz_c738b74f)class_cB_67aec11c;
                                                                                                                        class_ak_2ff604c7 = new Class_x_c36b9754<Class_cz_c738b74f>(class_cz_c738b74f, class_az_a4990dcf);
                                                                                                                        break block7;
                                                                                                                    }
                                                                                                                    bl = class_cB_67aec11c instanceof Class_cF_8338f0f7;
                                                                                                                }
                                                                                                                if (stringArray == null) break block10;
                                                                                                                if (!bl) break block11;
                                                                                                                Class_cF_8338f0f7 class_cF_8338f0f7 = (Class_cF_8338f0f7)class_cB_67aec11c;
                                                                                                                class_ak_2ff604c7 = new Class_x_c36b9754<Class_cF_8338f0f7>(class_cF_8338f0f7, class_az_a4990dcf);
                                                                                                                break block7;
                                                                                                            }
                                                                                                            bl = class_cB_67aec11c instanceof Class_cK_54b0e25a;
                                                                                                        }
                                                                                                        if (stringArray == null) break block12;
                                                                                                        if (!bl) break block13;
                                                                                                        Class_cK_54b0e25a class_cK_54b0e25a = (Class_cK_54b0e25a)class_cB_67aec11c;
                                                                                                        class_ak_2ff604c7 = new Class_x_c36b9754<Class_cK_54b0e25a>(class_cK_54b0e25a, class_az_a4990dcf);
                                                                                                        break block7;
                                                                                                    }
                                                                                                    bl = class_cB_67aec11c instanceof Class_cD_84e11ee0;
                                                                                                }
                                                                                                if (stringArray == null) break block14;
                                                                                                if (!bl) break block15;
                                                                                                Class_cD_84e11ee0 class_cD_84e11ee0 = (Class_cD_84e11ee0)class_cB_67aec11c;
                                                                                                class_ak_2ff604c7 = new Class_y_bc71aa82(class_cD_84e11ee0, class_az_a4990dcf);
                                                                                                break block7;
                                                                                            }
                                                                                            bl = class_cB_67aec11c instanceof Class_cx_024b7067;
                                                                                        }
                                                                                        if (stringArray == null) break block16;
                                                                                        if (!bl) break block17;
                                                                                        Class_cx_024b7067 class_cx_024b7067 = (Class_cx_024b7067)class_cB_67aec11c;
                                                                                        class_ak_2ff604c7 = new Class_u_1761c4c4(class_cx_024b7067, class_az_a4990dcf);
                                                                                        break block7;
                                                                                    }
                                                                                    bl = class_cB_67aec11c instanceof Class_cG_6e1ba021;
                                                                                }
                                                                                if (stringArray == null) break block18;
                                                                                if (!bl) break block19;
                                                                                Class_cG_6e1ba021 class_cG_6e1ba021 = (Class_cG_6e1ba021)class_cB_67aec11c;
                                                                                class_ak_2ff604c7 = new Class_A_dbc69253(class_cG_6e1ba021, class_az_a4990dcf);
                                                                                break block7;
                                                                            }
                                                                            bl = class_cB_67aec11c instanceof Class_ct_fa795250;
                                                                        }
                                                                        if (stringArray == null) break block20;
                                                                        if (!bl) break block21;
                                                                        Class_ct_fa795250 class_ct_fa795250 = (Class_ct_fa795250)class_cB_67aec11c;
                                                                        class_ak_2ff604c7 = new Class_q_f546fcb9(class_ct_fa795250, class_az_a4990dcf);
                                                                        break block7;
                                                                    }
                                                                    bl = class_cB_67aec11c instanceof Class_cv_f4b0140a;
                                                                }
                                                                if (stringArray == null) break block22;
                                                                if (!bl) break block23;
                                                                Class_cv_f4b0140a class_cv_f4b0140a = (Class_cv_f4b0140a)class_cB_67aec11c;
                                                                class_ak_2ff604c7 = new Class_r_14627bb0(class_cv_f4b0140a, class_az_a4990dcf);
                                                                break block7;
                                                            }
                                                            bl = class_cB_67aec11c instanceof Class_cA_4f409280;
                                                        }
                                                        if (stringArray == null) break block24;
                                                        if (!bl) break block25;
                                                        Class_cA_4f409280 class_cA_4f409280 = (Class_cA_4f409280)class_cB_67aec11c;
                                                        class_ak_2ff604c7 = new Class_p_35a2c4e0(class_cA_4f409280, class_az_a4990dcf);
                                                        break block7;
                                                    }
                                                    bl = class_cB_67aec11c instanceof Class_cL_ccb21d14;
                                                }
                                                if (stringArray == null) break block26;
                                                if (!bl) break block27;
                                                Class_cL_ccb21d14 class_cL_ccb21d14 = (Class_cL_ccb21d14)class_cB_67aec11c;
                                                class_ak_2ff604c7 = new Class_D_115059b3(class_cL_ccb21d14, class_az_a4990dcf);
                                                break block7;
                                            }
                                            bl = class_cB_67aec11c instanceof Class_cC_14ef8bb5;
                                        }
                                        if (stringArray == null) break block28;
                                        if (!bl) break block29;
                                        Class_cC_14ef8bb5 class_cC_14ef8bb5 = (Class_cC_14ef8bb5)class_cB_67aec11c;
                                        class_ak_2ff604c7 = new Class_o_cf1b173b(class_cC_14ef8bb5, class_az_a4990dcf);
                                        break block7;
                                    }
                                    bl = class_cB_67aec11c instanceof Class_cy_687dcdb6;
                                }
                                if (stringArray == null) break block30;
                                if (!bl) break block31;
                                Class_cy_687dcdb6 class_cy_687dcdb6 = (Class_cy_687dcdb6)class_cB_67aec11c;
                                class_ak_2ff604c7 = new Class_w_3ef9c66d(class_cy_687dcdb6, class_az_a4990dcf);
                                break block7;
                            }
                            bl = class_cB_67aec11c instanceof Class_cI_ff5df82f;
                        }
                        if (stringArray == null) break block32;
                        if (!bl) break block33;
                        Class_cI_ff5df82f class_cI_ff5df82f = (Class_cI_ff5df82f)class_cB_67aec11c;
                        class_ak_2ff604c7 = new Class_C_852be712(class_cI_ff5df82f, class_az_a4990dcf);
                        break block7;
                    }
                    class_cB_67aec11c2 = class_cB_67aec11c;
                    if (stringArray == null) break block34;
                    bl = class_cB_67aec11c2 instanceof Class_cH_5b9db066;
                }
                if (!bl) break block7;
                class_cB_67aec11c2 = class_cB_67aec11c;
            }
            Class_cH_5b9db066 class_cH_5b9db066 = (Class_cH_5b9db066)class_cB_67aec11c2;
            class_ak_2ff604c7 = new Class_B_59ec6581(class_cH_5b9db066, class_az_a4990dcf);
        }
        Class_v_5eec8686 class_v_5eec8686 = class_ak_2ff604c7;
        if (stringArray != null) {
            if (class_v_5eec8686 != null) {
                class_ak_2ff604c7.dY();
            }
            class_v_5eec8686 = class_ak_2ff604c7;
        }
        return class_v_5eec8686;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block26: {
            block25: {
                block24: {
                    block23: {
                        block22: {
                            block21: {
                                Class_jf_d1c4f950.qUVwV = Class_gb_9d201141.aYR(1721898729720351064L, 4639039868156347492L, MethodHandles.lookup().lookupClass()).a(226751541499181L);
                                var31 = Class_jf_d1c4f950.qUVwV ^ 121133083164871L;
                                Class_jf_d1c4f950.XKQjR = new HashMap<K, V>(13);
                                Class_jf_d1c4f950.bBd(new String[2]);
                                var22_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                                v0 = SecretKeyFactory.getInstance("DES");
                                v1 = new byte[8];
                                v2 = v1;
                                v1[0] = (byte)(var31 >>> 56);
                                for (var23_2 = 1; var23_2 < 8; ++var23_2) {
                                    v2 = v2;
                                    v2[var23_2] = (byte)(var31 << var23_2 * 8 >>> 56);
                                }
                                var22_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                                var29_3 = new String[12];
                                var27_4 = 0;
                                var26_5 = "\u009c#\u00d5\u0095n\u001d\u00deH\u00c4\u00a3*\"\u00d0T=J\u00e8\u0082E_\u00b2\u00a7I+\u0010&=\u00e2W\u00968\u00900*(G%\u009bW[0\u0010\u00c8\u00b1E\u00ad\u00c0\u00f1\u00be\u00c3\u0095\u00db\u00c0\u00c9\u009c\u0085<t\u0010\u00c3\u008d\u0017r\u00a3\u00c4\u00fc|\u00e9&\t\u0007u(S\u007f\u0010\u0017Q\u00a8\u00c5\u00dc\u00cb\u00d2Ee\u00c8\u009c\u00faU\u0089t\u0091\u0010\u00d7:\u0003T\u00c6\u001d\u00f3\r&\u00bb\u008d\u00bd\u00da\u00ae_\u00f1 \u00a5\u001e\u0080f\u00b51\u00a4v\u0082\u0017\u00a1j\n\u001eRB\u0098\t\u00f7\u0000\u00d2\u00dd\u00f6\u00e4>\u0015\u008a\u00e3\u00a5\u0088r\u00f8\u0010\u00e2\u00e6\u00d4\u0019)\u00b1\u00c0\u0001A>\u00d1\u0091}\u00c2\u00bb\u0002\u0010uq\u00f8\u00b9f3\u00ce\u0096R\u0084V\u00c0\u00c6\u00a9\u00184\u0010\r@\u00a2\u00bf\u00166\u0002\u0097\u0015\u00a4\u0080\u008eU\u00de\u00e1\u0097";
                                var28_6 = "\u009c#\u00d5\u0095n\u001d\u00deH\u00c4\u00a3*\"\u00d0T=J\u00e8\u0082E_\u00b2\u00a7I+\u0010&=\u00e2W\u00968\u00900*(G%\u009bW[0\u0010\u00c8\u00b1E\u00ad\u00c0\u00f1\u00be\u00c3\u0095\u00db\u00c0\u00c9\u009c\u0085<t\u0010\u00c3\u008d\u0017r\u00a3\u00c4\u00fc|\u00e9&\t\u0007u(S\u007f\u0010\u0017Q\u00a8\u00c5\u00dc\u00cb\u00d2Ee\u00c8\u009c\u00faU\u0089t\u0091\u0010\u00d7:\u0003T\u00c6\u001d\u00f3\r&\u00bb\u008d\u00bd\u00da\u00ae_\u00f1 \u00a5\u001e\u0080f\u00b51\u00a4v\u0082\u0017\u00a1j\n\u001eRB\u0098\t\u00f7\u0000\u00d2\u00dd\u00f6\u00e4>\u0015\u008a\u00e3\u00a5\u0088r\u00f8\u0010\u00e2\u00e6\u00d4\u0019)\u00b1\u00c0\u0001A>\u00d1\u0091}\u00c2\u00bb\u0002\u0010uq\u00f8\u00b9f3\u00ce\u0096R\u0084V\u00c0\u00c6\u00a9\u00184\u0010\r@\u00a2\u00bf\u00166\u0002\u0097\u0015\u00a4\u0080\u008eU\u00de\u00e1\u0097".length();
                                var25_7 = 24;
                                var24_8 = -1;
lbl21:
                                // 2 sources

                                while (true) {
                                    v3 = ++var24_8;
                                    v4 = var26_5.substring(v3, v3 + var25_7);
                                    v5 = -1;
                                    break block21;
                                    break;
                                }
lbl26:
                                // 1 sources

                                while (true) {
                                    var29_3[var27_4++] = Class_jf_d1c4f950.bBg(var30_9).intern();
                                    if ((var24_8 += var25_7) < var28_6) {
                                        var25_7 = var26_5.charAt(var24_8);
                                        ** continue;
                                    }
                                    var26_5 = "\u00d9\u0005\u00f8J)\tB\u00b7\u00e1z!\u00978<\u001d[\u00107\u0092\u00bfr\u00cdj\u00ba\u009c\u00c0;\f|(]\u00af\u0019";
                                    var28_6 = "\u00d9\u0005\u00f8J)\tB\u00b7\u00e1z!\u00978<\u001d[\u00107\u0092\u00bfr\u00cdj\u00ba\u009c\u00c0;\f|(]\u00af\u0019".length();
                                    var25_7 = 16;
                                    var24_8 = -1;
lbl35:
                                    // 2 sources

                                    while (true) {
                                        v6 = ++var24_8;
                                        v4 = var26_5.substring(v6, v6 + var25_7);
                                        v5 = 0;
                                        break block21;
                                        break;
                                    }
                                    break;
                                }
lbl40:
                                // 1 sources

                                while (true) {
                                    var29_3[var27_4++] = Class_jf_d1c4f950.bBg(var30_9).intern();
                                    if ((var24_8 += var25_7) < var28_6) {
                                        var25_7 = var26_5.charAt(var24_8);
                                        ** continue;
                                    }
                                    break block22;
                                    break;
                                }
                            }
                            var30_9 = var22_1.doFinal(v4.getBytes("ISO-8859-1"));
                            switch (v5) {
                                default: {
                                    ** continue;
                                }
                                ** case 0:
lbl52:
                                // 1 sources

                                ** continue;
                            }
                        }
                        Class_jf_d1c4f950.OdySV = var29_3;
                        Class_jf_d1c4f950.cCYcp = new String[12];
                        Class_jf_d1c4f950.yjAZm = new HashMap<K, V>(13);
                        var11_10 = Cipher.getInstance("DES/CBC/NoPadding");
                        v7 = SecretKeyFactory.getInstance("DES");
                        v8 = new byte[8];
                        v9 = v8;
                        v8[0] = (byte)(var31 >>> 56);
                        for (var12_11 = 1; var12_11 < 8; ++var12_11) {
                            v9 = v9;
                            v9[var12_11] = (byte)(var31 << var12_11 * 8 >>> 56);
                        }
                        var11_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                        var17_12 = new long[2];
                        var14_13 = 0;
                        var15_14 = "P\u009d\u00b9\u00dd/\u0082\u0089\u0003\u00fc0:\u009a\t\f\u00fc\u00bb";
                        var16_15 = "P\u009d\u00b9\u00dd/\u0082\u0089\u0003\u00fc0:\u009a\t\f\u00fc\u00bb".length();
                        var13_16 = 0;
                        while (true) {
                            break block23;
                            break;
                        }
lbl74:
                        // 1 sources

                        while (true) {
                            var17_12[v10] = ((long)var21_19[0] & 255L) << 56 | ((long)var21_19[1] & 255L) << 48 | ((long)var21_19[2] & 255L) << 40 | ((long)var21_19[3] & 255L) << 32 | ((long)var21_19[4] & 255L) << 24 | ((long)var21_19[5] & 255L) << 16 | ((long)var21_19[6] & 255L) << 8 | (long)var21_19[7] & 255L;
                            if (var13_16 < var16_15) ** continue;
                            break block24;
                            break;
                        }
                    }
                    var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                    v10 = var14_13++;
                    var19_18 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                    var21_19 = var11_10.doFinal(new byte[]{(byte)(var19_18 >>> 56), (byte)(var19_18 >>> 48), (byte)(var19_18 >>> 40), (byte)(var19_18 >>> 32), (byte)(var19_18 >>> 24), (byte)(var19_18 >>> 16), (byte)(var19_18 >>> 8), (byte)var19_18});
                    ** while (true)
                }
                Class_jf_d1c4f950.RAjsP = var17_12;
                Class_jf_d1c4f950.COJav = new Integer[2];
                Class_jf_d1c4f950.jNPAX = new HashMap<K, V>(13);
                var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
                v11 = SecretKeyFactory.getInstance("DES");
                v12 = new byte[8];
                v13 = v12;
                v12[0] = (byte)(var31 >>> 56);
                for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                    v13 = v13;
                    v13[var1_21] = (byte)(var31 << var1_21 * 8 >>> 56);
                }
                var0_20.init(2, (Key)v11.generateSecret(new DESKeySpec(v13)), new IvParameterSpec(new byte[8]));
                var6_22 = new long[12];
                var3_23 = 0;
                var4_24 = "\u00d0\u00cc\u00f9v\u00a6s\u00d2\u0081\u001eljy\u00e7\u0002\u0098\u0007\u0007\u00ac\ncF4hOrfa\u00d16!N\u0090\u00f6\u00a5\u00ae\u00a0\u0084\u00fbw\u00c4\u00af\u00de\u0081N\u00eb\u00c2\u00f41Di/^\u00af.\u001a[KY\u00f2\u00c9;\u008eF^&^?\u000e\u0097\u0098\u00c4\t d/\u00ee\u00a4\u0006\u00e7\u00fd";
                var5_25 = "\u00d0\u00cc\u00f9v\u00a6s\u00d2\u0081\u001eljy\u00e7\u0002\u0098\u0007\u0007\u00ac\ncF4hOrfa\u00d16!N\u0090\u00f6\u00a5\u00ae\u00a0\u0084\u00fbw\u00c4\u00af\u00de\u0081N\u00eb\u00c2\u00f41Di/^\u00af.\u001a[KY\u00f2\u00c9;\u008eF^&^?\u000e\u0097\u0098\u00c4\t d/\u00ee\u00a4\u0006\u00e7\u00fd".length();
                var2_26 = 0;
                while (true) {
                    var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                    v14 = var6_22;
                    v15 = var3_23++;
                    v16 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                    v17 = -1;
                    break block25;
                    break;
                }
lbl113:
                // 1 sources

                while (true) {
                    v14[v15] = v18;
                    if (var2_26 < var5_25) ** continue;
                    var4_24 = "\u00df\u0098uW\u008dp\u00a5{\u00a6|\u00fcd\u00a1L\u00a5@";
                    var5_25 = "\u00df\u0098uW\u008dp\u00a5{\u00a6|\u00fcd\u00a1L\u00a5@".length();
                    var2_26 = 0;
                    while (true) {
                        var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                        v14 = var6_22;
                        v15 = var3_23++;
                        v16 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                        v17 = 0;
                        break block25;
                        break;
                    }
                    break;
                }
lbl126:
                // 1 sources

                while (true) {
                    v14[v15] = v18;
                    if (var2_26 < var5_25) ** continue;
                    break block26;
                    break;
                }
            }
            var8_28 = v16;
            var10_29 = var0_20.doFinal(new byte[]{(byte)(var8_28 >>> 56), (byte)(var8_28 >>> 48), (byte)(var8_28 >>> 40), (byte)(var8_28 >>> 32), (byte)(var8_28 >>> 24), (byte)(var8_28 >>> 16), (byte)(var8_28 >>> 8), (byte)var8_28});
            v18 = ((long)var10_29[0] & 255L) << 56 | ((long)var10_29[1] & 255L) << 48 | ((long)var10_29[2] & 255L) << 40 | ((long)var10_29[3] & 255L) << 32 | ((long)var10_29[4] & 255L) << 24 | ((long)var10_29[5] & 255L) << 16 | ((long)var10_29[6] & 255L) << 8 | (long)var10_29[7] & 255L;
            switch (v17) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl139:
                // 1 sources

                ** continue;
            }
        }
        Class_jf_d1c4f950.yPLqH = var6_22;
        Class_jf_d1c4f950.LGHNj = new Long[12];
        Class_jf_d1c4f950.Jlqur = new SimpleDateFormat((String)Class_jf_d1c4f950.bBj("f", (int)24478, (long)(762683943723284407L ^ var31)), Locale.getDefault());
    }

    public static String[] bBe() {
        return KVigV;
    }

    public static void bBd(String[] stringArray) {
        KVigV = stringArray;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jf_d1c4f950.class, "bBl", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_jf_d1c4f950.class, "bBo", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(Class_jf_d1c4f950.class, "bBi", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

