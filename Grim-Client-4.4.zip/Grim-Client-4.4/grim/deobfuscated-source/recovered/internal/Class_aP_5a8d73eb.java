/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.ArrayList;
import java.util.List;
import recovered.core.ClientMain;
import recovered.core.NativeLoader;
import recovered.internal.Class_aL_efcd921b;
import recovered.internal.Class_aT_ae2e2378;
import recovered.internal.Class_ag_8130246f;
import recovered.internal.Class_ag_rR_5deaebc6;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_pF_d0757029;
import recovered.internal.Class_pM_b8c9d65e;
import recovered.internal.Class_pN_84dc4bee;
import recovered.internal.Class_pi_3708be5b;
import recovered.internal.Class_py_edabaa53;

public class Class_aP_5a8d73eb
extends Class_az_a4990dcf {
    private static float Ytddt = 50.0f;
    private static float EOrgK = 20.0f;
    private final Class_ag_8130246f bEgXx;
    private final Class_aT_ae2e2378 fbWFG;
    private final Class_aL_efcd921b OOHfm = new Class_aL_efcd921b();
    private final Class_lc_b8480f87 NVkGu = new Class_lc_b8480f87(0.0f, 0.0f, 0.0f, 0.0f);
    private final Class_lc_b8480f87 OcfDY = new Class_lc_b8480f87(0.0f, 0.0f, 0.0f, 0.0f);
    private final List<Class_pN_84dc4bee> gUcHl = new ArrayList<Class_pN_84dc4bee>();
    private Class_pF_d0757029 bliCO = Class_pF_d0757029.JMCCO;
    private boolean DyAoO;
    private float uKwAx;
    private Class_py_edabaa53 pNlKr;
    private Class_pN_84dc4bee OiKGb;
    private Class_pM_b8c9d65e llMcT;
    private Class_py_edabaa53 bWBCm;
    private boolean EBWOa;
    private boolean tjQNE;
    private static long TCrzP;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aP_5a8d73eb() {
        this.bEgXx = new Class_ag_8130246f(ClientMain.dlmvG.player.getGameProfile().name(), Class_ag_rR_5deaebc6.cyZLf).nk(0.0f, 0.0f);
        this.bEgXx.sX(45.0f, 135.0f);
        this.fbWFG = new Class_aT_ae2e2378();
    }

    static {
        NativeLoader.doInit(Class_aP_5a8d73eb.class);
        Class_aP_5a8d73eb._fd1d2f9425d675076556ea60ae371a18();
    }

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    public native Class_aP_5a8d73eb xs(boolean var1, float var2);

    private native Class_pN_84dc4bee xx(Class_lC_5322e8cf var1, Class_pi_3708be5b var2);

    public native void xz(Class_lC_5322e8cf var1);

    private native void xy(Class_py_edabaa53 var1);

    private native Class_pi_3708be5b xw(Class_lC_5322e8cf var1, Class_lc_b8480f87 var2);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean dB(double var1, double var3, Class_mA_32d8a5f2 var5, double var6, double var8);

    @Override
    public native void dY();

    @Override
    public native boolean fC(double var1, double var3, double var5);

    public native Class_aP_5a8d73eb xt(Class_pF_d0757029 var1);

    private static native void _fd1d2f9425d675076556ea60ae371a18();

    public native void xB(Class_py_edabaa53 var1, double var2, double var4);

    public native void xA(Class_pF_d0757029 var1);

    private native void xI();

    public native Class_aP_5a8d73eb xL(boolean var1);

    private native void xH();

    private native void xD(double var1, double var3);

    private native void xv(Class_lC_5322e8cf var1, float var2);

    public native Class_aT_ae2e2378 xM();

    private native void xG(double var1, double var3, Class_lc_b8480f87 var5);

    private static native MatchException xN(MatchException var0);

    private native void xK(Class_py_edabaa53 var1, double var2, double var4);

    private native void xF(double var1, double var3);

    private native void xJ(Class_py_edabaa53 var1);

    private native void xC(Class_py_edabaa53 var1, double var2);

    private native Class_lc_b8480f87 xu(Class_lC_5322e8cf var1);

    private native void xE(boolean var1);
}

