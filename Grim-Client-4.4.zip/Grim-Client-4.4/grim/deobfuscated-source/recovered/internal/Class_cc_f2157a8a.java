/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  media.IMediaSession
 *  media.MediaInfo
 *  media.impl.win.WindowsMediaSession
 *  net.minecraft.client.gui.screen.ChatScreen
 *  net.minecraft.util.math.MathHelper
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import media.IMediaSession;
import media.MediaInfo;
import media.impl.win.WindowsMediaSession;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.util.math.MathHelper;
import recovered.core.ClientMain;
import recovered.internal.Class_ca_75c833b3;
import recovered.internal.Class_cr_3ba4ae18;
import recovered.internal.Class_ct_fa795250;
import recovered.internal.Class_cu_7306ec45;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_kW_239383b1;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mT_db06bea0;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_ob_77a6de24;
import recovered.internal.Class_qO_d37ef529;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.internal.Class_rm_d861be3b;

public class Class_cc_f2157a8a
extends Class_cr_3ba4ae18 {
    private final Class_ct_fa795250 poEJg;
    private final Class_cu_7306ec45 cdPcl;
    private final Class_cu_7306ec45 DnfPC;
    private final Class_rk_bf8630d1[] nKTkB;
    private final float[] ywaEw;
    private final Class_mT_db06bea0 Uslxa;
    private final Class_ri_288534d5 tYJbR;
    private final Class_ri_288534d5 wNrIZ;
    private final Class_rk_bf8630d1 LzQrF;
    private final Class_rk_bf8630d1 QpQRV;
    private final Class_rk_bf8630d1 debmQ;
    private final Class_rk_bf8630d1 IbiJA;
    private final Class_rk_bf8630d1 zzuzN;
    private static final long axaUP;
    private static final String[] wtTpp;
    private static final String[] vRGNc;
    private static final Map nvHhc;
    private static final long[] dunGn;
    private static final Integer[] NQYLH;
    private static final Map rhxtg;
    private static final long QlUSv;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static Object PD(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_cc_f2157a8a.PC(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    public Class_cc_f2157a8a() {
        long l = axaUP ^ 0x482FA3832EE7L;
        super(new int[]{(int)Class_cc_f2157a8a.PH("l", (int)7657, (long)(0x74364B9612E6E35L ^ l)), (int)Class_cc_f2157a8a.PH("l", (int)19555, (long)(0x7846DBF4EA433FA9L ^ l)), (int)Class_cc_f2157a8a.PH("l", (int)10145, (long)(0x23552468933BD468L ^ l)), (int)Class_cc_f2157a8a.PH("l", (int)26710, (long)(0x1C8D464F4A6D9BB3L ^ l)), (int)Class_cc_f2157a8a.PH("l", (int)18870, (long)(0xA2DAEB111C3A63L ^ l))}, Class_lf_d247d983.MZXpZ);
        int[] nArray = new int[Class_cc_f2157a8a.PH("l", (int)12172, (long)(0x99C86710E15C63L ^ l))];
        nArray[0] = (int)Class_cc_f2157a8a.PH("l", (int)1992, (long)(0x4B92F4C16677F42AL ^ l));
        nArray[1] = (int)Class_cc_f2157a8a.PH("l", (int)17592, (long)(0x2F2C546BD2F63755L ^ l));
        nArray[2] = (int)Class_cc_f2157a8a.PH("l", (int)13380, (long)(0x1FA1E7E78042C781L ^ l));
        nArray[3] = (int)Class_cc_f2157a8a.PH("l", (int)18365, (long)(0x968C72AAEE9B46BL ^ l));
        nArray[4] = (int)Class_cc_f2157a8a.PH("l", (int)26133, (long)(0x28F7CED857BD95D6L ^ l));
        nArray[5] = (int)Class_cc_f2157a8a.PH("l", (int)8647, (long)(0x7E018394989A5210L ^ l));
        nArray[Class_cc_f2157a8a.PH("l", (int)13599, (long)(0x58796B82F35BC6C0L ^ l))] = (int)Class_cc_f2157a8a.PH("l", (int)31573, (long)(0x155EF2C6E0C9889EL ^ l));
        nArray[Class_cc_f2157a8a.PH("l", (int)26194, (long)(0x4998720FEF551580L ^ l))] = (int)Class_cc_f2157a8a.PH("l", (int)16470, (long)(0x3315C4774C8FB391L ^ l));
        nArray[Class_cc_f2157a8a.PH("l", (int)14469, (long)(0x645B9B8A720ACB6BL ^ l))] = (int)Class_cc_f2157a8a.PH("l", (int)2901, (long)(0x51854AFBF17BF895L ^ l));
        nArray[Class_cc_f2157a8a.PH("l", (int)29670, (long)(0x303323D2838E8007L ^ l))] = (int)Class_cc_f2157a8a.PH("l", (int)678, (long)(0x4D993E056D8AF17FL ^ l));
        nArray[Class_cc_f2157a8a.PH("l", (int)29721, (long)(0x4250A9EF8CE507DBL ^ l))] = (int)Class_cc_f2157a8a.PH("l", (int)30040, (long)(0x7AAE5CE874506B4L ^ l));
        nArray[Class_cc_f2157a8a.PH("l", (int)13901, (long)(0x38AB11ADC0F545ADL ^ l))] = (int)Class_cc_f2157a8a.PH("l", (int)14655, (long)(0x10D58622F2674AEBL ^ l));
        nArray[Class_cc_f2157a8a.PH("l", (int)15394, (long)(0x4DFB99FDC5E8CFFAL ^ l))] = (int)Class_cc_f2157a8a.PH("l", (int)2901, (long)(0x51854AFBF17BF895L ^ l));
        nArray[Class_cc_f2157a8a.PH("l", (int)31788, (long)(0x13FD252F24990FFCL ^ l))] = (int)Class_cc_f2157a8a.PH("l", (int)29898, (long)(0x2D57F50D47B8711L ^ l));
        nArray[Class_cc_f2157a8a.PH("l", (int)14582, (long)(0x6ADDD8135CF7CB1EL ^ l))] = (int)Class_cc_f2157a8a.PH("l", (int)10598, (long)(0x17256900C93E5AB5L ^ l));
        this.poEJg = new Class_ct_fa795250(this, Class_mr_7eac5189.clS(nArray));
        int[] nArray2 = new int[Class_cc_f2157a8a.PH("l", (int)18904, (long)(0x5CB083C2FC753A3CL ^ l))];
        nArray2[0] = (int)Class_cc_f2157a8a.PH("l", (int)5237, (long)(0x4EB9B1DFFFFDE7B8L ^ l));
        nArray2[1] = (int)Class_cc_f2157a8a.PH("l", (int)22068, (long)(0x31C83AC1855325EEL ^ l));
        nArray2[2] = (int)Class_cc_f2157a8a.PH("l", (int)18992, (long)(0x45D1C42E962639FCL ^ l));
        nArray2[3] = (int)Class_cc_f2157a8a.PH("l", (int)12827, (long)(0x419B21AA9284C1D5L ^ l));
        nArray2[4] = (int)Class_cc_f2157a8a.PH("l", (int)14371, (long)(0x57E314EBA20F4BE5L ^ l));
        nArray2[5] = (int)Class_cc_f2157a8a.PH("l", (int)23535, (long)(0x228C630214A4A82EL ^ l));
        this.cdPcl = new Class_cu_7306ec45(this.poEJg, Class_mr_7eac5189.clS(nArray2));
        int[] nArray3 = new int[Class_cc_f2157a8a.PH("l", (int)18904, (long)(0x5CB083C2FC753A3CL ^ l))];
        nArray3[0] = (int)Class_cc_f2157a8a.PH("l", (int)18210, (long)(0x3316EDB2461634C1L ^ l));
        nArray3[1] = (int)Class_cc_f2157a8a.PH("l", (int)10312, (long)(0xF71F1C60FDB5B8CL ^ l));
        nArray3[2] = (int)Class_cc_f2157a8a.PH("l", (int)16438, (long)(0x4FA9724E719AB3F9L ^ l));
        nArray3[3] = (int)Class_cc_f2157a8a.PH("l", (int)14609, (long)(0x6A688C0C45934AFAL ^ l));
        nArray3[4] = (int)Class_cc_f2157a8a.PH("l", (int)27836, (long)(0x7B4A57361C3D9F55L ^ l));
        nArray3[5] = (int)Class_cc_f2157a8a.PH("l", (int)12827, (long)(0x419B21AA9284C1D5L ^ l));
        this.DnfPC = new Class_cu_7306ec45(this.poEJg, Class_mr_7eac5189.clS(nArray3)).SY();
        this.nKTkB = new Class_rk_bf8630d1[Class_cc_f2157a8a.PH("l", (int)18904, (long)(0x5CB083C2FC753A3CL ^ l))];
        this.ywaEw = new float[Class_cc_f2157a8a.PH("l", (int)18904, (long)(0x5CB083C2FC753A3CL ^ l))];
        this.Uslxa = Class_mT_db06bea0.cpz();
        boolean bl = Class_ca_75c833b3.OX();
        this.tYJbR = new Class_ri_288534d5((int)Class_cc_f2157a8a.PH("l", (int)15293, (long)(0x1DC14A1942D74863L ^ l)));
        this.wNrIZ = new Class_ri_288534d5((int)Class_cc_f2157a8a.PH("l", (int)9998, (long)(0xE5425EE485E54C6L ^ l)));
        this.LzQrF = new Class_rk_bf8630d1((int)Class_cc_f2157a8a.PH("l", (int)3475, (long)(0x282B88B91D7E79L ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        this.QpQRV = new Class_rk_bf8630d1((int)Class_cc_f2157a8a.PH("l", (int)23819, (long)(0x449AD816D47DAEDAL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.debmQ = new Class_rk_bf8630d1((int)Class_cc_f2157a8a.PH("l", (int)23819, (long)(0x449AD816D47DAEDAL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.IbiJA = new Class_rk_bf8630d1((int)Class_cc_f2157a8a.PH("l", (int)23819, (long)(0x449AD816D47DAEDAL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.zzuzN = new Class_rk_bf8630d1((int)Class_cc_f2157a8a.PH("l", (int)21582, (long)(0x3C5E234D48D0A793L ^ l))).dhs(Class_rj_b691f4f7.Xmkbr);
        for (int i = 0; i < this.nKTkB.length; ++i) {
            this.nKTkB[i] = new Class_rk_bf8630d1((int)Class_cc_f2157a8a.PH("l", (int)9998, (long)(0xE5425EE485E54C6L ^ l))).dhs(Class_rj_b691f4f7.Xmkbr);
            this.nKTkB[i].dhf(0.35f);
            this.ywaEw[i] = 0.35f;
            if (!bl) continue;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block17: {
            block16: {
                block15: {
                    block14: {
                        Class_cc_f2157a8a.axaUP = Class_gb_9d201141.aYR(5575654254560810711L, 2251488754095607058L, MethodHandles.lookup().lookupClass()).a(201337464245299L);
                        Class_cc_f2157a8a.nvHhc = new HashMap<K, V>(13);
                        var16 = Class_cc_f2157a8a.axaUP ^ 59834845167809L;
                        var18_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var16 >>> 56);
                        for (var19_2 = 1; var19_2 < 8; ++var19_2) {
                            v2 = v2;
                            v2[var19_2] = (byte)(var16 << var19_2 * 8 >>> 56);
                        }
                        var18_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var25_3 = new String[2];
                        var23_4 = 0;
                        var22_5 = "6\u00bc=\u00c4\u00a5\u00de\u00aa\u00cb\u0088\u00f159C\u00a6\u00fb\u00b9\u00be\u001cD\u0098\u00e7\u00f8k-\u008c+\u0005\u00881\u0086\u00ac\u00f3\u00b1$\u00ea{\u0017Qy\u00bd \u00dfv\u0089*}\u00e2VnL\u00f3\u0016\u00a9\u0016,\u00a9\u00fd,9OH\u0093\u0006\u00ef\u008c#\u00d5\u0082\u00c6\u00c7Li7";
                        var24_6 = "6\u00bc=\u00c4\u00a5\u00de\u00aa\u00cb\u0088\u00f159C\u00a6\u00fb\u00b9\u00be\u001cD\u0098\u00e7\u00f8k-\u008c+\u0005\u00881\u0086\u00ac\u00f3\u00b1$\u00ea{\u0017Qy\u00bd \u00dfv\u0089*}\u00e2VnL\u00f3\u0016\u00a9\u0016,\u00a9\u00fd,9OH\u0093\u0006\u00ef\u008c#\u00d5\u0082\u00c6\u00c7Li7".length();
                        var21_7 = 40;
                        var20_8 = -1;
lbl20:
                        // 2 sources

                        while (true) {
                            continue;
                            break;
                        }
lbl22:
                        // 1 sources

                        while (true) {
                            var25_3[var23_4++] = Class_cc_f2157a8a.PB(var26_9).intern();
                            if ((var20_8 += var21_7) < var24_6) {
                                var21_7 = var22_5.charAt(var20_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                        v3 = ++var20_8;
                        var26_9 = var18_1.doFinal(var22_5.substring(v3, v3 + var21_7).getBytes("ISO-8859-1"));
                        ** while (true)
                    }
                    Class_cc_f2157a8a.wtTpp = var25_3;
                    Class_cc_f2157a8a.vRGNc = new String[2];
                    Class_cc_f2157a8a.rhxtg = new HashMap<K, V>(13);
                    var5_10 = Cipher.getInstance("DES/CBC/NoPadding");
                    v4 = SecretKeyFactory.getInstance("DES");
                    v5 = new byte[8];
                    v6 = v5;
                    v5[0] = (byte)(var16 >>> 56);
                    for (var6_11 = 1; var6_11 < 8; ++var6_11) {
                        v6 = v6;
                        v6[var6_11] = (byte)(var16 << var6_11 * 8 >>> 56);
                    }
                    var5_10.init(2, (Key)v4.generateSecret(new DESKeySpec(v6)), new IvParameterSpec(new byte[8]));
                    var11_12 = new long[46];
                    var8_13 = 0;
                    var9_14 = "rFK\u001d\u00e2\u00bf\u009b\u009b\u00b8\u00c8\u00f1\u00a4\u0015!\t\u007fq08b\u0016\u008b\u00e3\u00d6\u00d8\u001aQ\u00cbb\u00be?W\u008c\u00c9\u00fe\u00e4{\u008d0\u00c6.Um\u00c5x\u00b8\u00cdE\u00f6\u0005V+\u00a6\u001a\u00a7@g\u00e9\u0007,\u00b94\u00ec\u00fa\u00fe\u00b1\u00fb\u00b3Gd\u001e9*D\u00a8p\u00feqV\u00b7\u00eb_{v0\u00043:\u0093\u00b7<\u0081\u0093_\u00a9c\u00e3#\u00d7^7_ZQ\u0086\u009923 I\u00fdf\u0083?\u0005\u001c^\u0003t\u0006\u00db}&0X\u00a4l\u0010\u00be\u00d6l\u00ab\u0080\u00f2\u0014x_\u00f5\u00ab\u0092J\u00ce\u0081gPO8\u0007j'n\u00b9\u00ecr\u0012\u0007\u00e0\u0004\u0096~Y\u00a19\u000e\u00fc@\u001aP\u00b3\u00c5<<\u001b\u00bcq\u00d0<\u00e04\u001e\u00d6\u0005\u00a3\u00c4\u008c\u00a1e\u009c5\u00b7\u00fc2\u000ev\u00e3\"\u0086x0\u00f4\u00fch\u00b1l\u00c4\u0087\u00cf\u00ef\u0011\u00e5\u00ce\u00a2\u00d2c\u00b9\u001d\u00b6\u00ce\t3&$\u001f\u00a8\u00a7\u00b4Z|\u00a2_\u00dd\u0083\u0003\u00ae\u001a\u00c0\u000f\u008bQ\u00b7\u00baG\u00f9\u009d\u00ffE#\u008f\u00d6\u0005\u00fb\u00d6\u00ae\r\u00f3\u001b\u00bd\u00a5\u00d4\u00a5:*L+\u00ca%\u00eb\u00f1\u007f\u00eb\u00d1\u00d4@{\u00ce,\u00de\u00d0^\u00c6\u00ec\u0003\u0089\u00c3\u008b/\u00d3\u00f0) \u00d0\u000es\u0011)\u00e4'\u008bsw\u00f0\u000bi\rPP(\u00c2\u00ab\u00a3\u0081\u0084\u0015\u00ed\u00f7\u0001\u00a7\u009dN\u00fcU ;]2^_\u009c\u00fd\u00dc\u00fc\u00e3\u009e\u0018\u0019\u00c3[\u001c\u0006\u001d\u00b9\u009e\u00eb\u00c7k5\u00f9\u008d\u009c\u00fe:t";
                    var10_15 = "rFK\u001d\u00e2\u00bf\u009b\u009b\u00b8\u00c8\u00f1\u00a4\u0015!\t\u007fq08b\u0016\u008b\u00e3\u00d6\u00d8\u001aQ\u00cbb\u00be?W\u008c\u00c9\u00fe\u00e4{\u008d0\u00c6.Um\u00c5x\u00b8\u00cdE\u00f6\u0005V+\u00a6\u001a\u00a7@g\u00e9\u0007,\u00b94\u00ec\u00fa\u00fe\u00b1\u00fb\u00b3Gd\u001e9*D\u00a8p\u00feqV\u00b7\u00eb_{v0\u00043:\u0093\u00b7<\u0081\u0093_\u00a9c\u00e3#\u00d7^7_ZQ\u0086\u009923 I\u00fdf\u0083?\u0005\u001c^\u0003t\u0006\u00db}&0X\u00a4l\u0010\u00be\u00d6l\u00ab\u0080\u00f2\u0014x_\u00f5\u00ab\u0092J\u00ce\u0081gPO8\u0007j'n\u00b9\u00ecr\u0012\u0007\u00e0\u0004\u0096~Y\u00a19\u000e\u00fc@\u001aP\u00b3\u00c5<<\u001b\u00bcq\u00d0<\u00e04\u001e\u00d6\u0005\u00a3\u00c4\u008c\u00a1e\u009c5\u00b7\u00fc2\u000ev\u00e3\"\u0086x0\u00f4\u00fch\u00b1l\u00c4\u0087\u00cf\u00ef\u0011\u00e5\u00ce\u00a2\u00d2c\u00b9\u001d\u00b6\u00ce\t3&$\u001f\u00a8\u00a7\u00b4Z|\u00a2_\u00dd\u0083\u0003\u00ae\u001a\u00c0\u000f\u008bQ\u00b7\u00baG\u00f9\u009d\u00ffE#\u008f\u00d6\u0005\u00fb\u00d6\u00ae\r\u00f3\u001b\u00bd\u00a5\u00d4\u00a5:*L+\u00ca%\u00eb\u00f1\u007f\u00eb\u00d1\u00d4@{\u00ce,\u00de\u00d0^\u00c6\u00ec\u0003\u0089\u00c3\u008b/\u00d3\u00f0) \u00d0\u000es\u0011)\u00e4'\u008bsw\u00f0\u000bi\rPP(\u00c2\u00ab\u00a3\u0081\u0084\u0015\u00ed\u00f7\u0001\u00a7\u009dN\u00fcU ;]2^_\u009c\u00fd\u00dc\u00fc\u00e3\u009e\u0018\u0019\u00c3[\u001c\u0006\u001d\u00b9\u009e\u00eb\u00c7k5\u00f9\u008d\u009c\u00fe:t".length();
                    var7_16 = 0;
                    while (true) {
                        var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                        v7 = var11_12;
                        v8 = var8_13++;
                        v9 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                        v10 = -1;
                        break block15;
                        break;
                    }
lbl58:
                    // 1 sources

                    while (true) {
                        v7[v8] = v11;
                        if (var7_16 < var10_15) ** continue;
                        var9_14 = "\u00fc\u00bf\u008a\u0090x\u0012\u008e\u00d5\u00c0.\u00af`\u0088\u009c\u00bd\u0091";
                        var10_15 = "\u00fc\u00bf\u008a\u0090x\u0012\u008e\u00d5\u00c0.\u00af`\u0088\u009c\u00bd\u0091".length();
                        var7_16 = 0;
                        while (true) {
                            var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                            v7 = var11_12;
                            v8 = var8_13++;
                            v9 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                            v10 = 0;
                            break block15;
                            break;
                        }
                        break;
                    }
lbl71:
                    // 1 sources

                    while (true) {
                        v7[v8] = v11;
                        if (var7_16 < var10_15) ** continue;
                        break block16;
                        break;
                    }
                }
                var13_18 = v9;
                var15_19 = var5_10.doFinal(new byte[]{(byte)(var13_18 >>> 56), (byte)(var13_18 >>> 48), (byte)(var13_18 >>> 40), (byte)(var13_18 >>> 32), (byte)(var13_18 >>> 24), (byte)(var13_18 >>> 16), (byte)(var13_18 >>> 8), (byte)var13_18});
                v11 = ((long)var15_19[0] & 255L) << 56 | ((long)var15_19[1] & 255L) << 48 | ((long)var15_19[2] & 255L) << 40 | ((long)var15_19[3] & 255L) << 32 | ((long)var15_19[4] & 255L) << 24 | ((long)var15_19[5] & 255L) << 16 | ((long)var15_19[6] & 255L) << 8 | (long)var15_19[7] & 255L;
                switch (v10) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl84:
                    // 1 sources

                    ** continue;
                }
            }
            Class_cc_f2157a8a.dunGn = var11_12;
            Class_cc_f2157a8a.NQYLH = new Integer[46];
            var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
            v12 = SecretKeyFactory.getInstance("DES");
            v13 = new byte[8];
            v14 = v13;
            v13[0] = (byte)(var16 >>> 56);
            for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                v14 = v14;
                v14[var1_21] = (byte)(var16 << var1_21 * 8 >>> 56);
            }
            break block17;
lbl98:
            // 1 sources

            while (true) {
                continue;
                break;
            }
        }
        var0_20.init(2, (Key)v12.generateSecret(new DESKeySpec(v14)), new IvParameterSpec(new byte[8]));
        var2_22 = 6537864497686658242L;
        var4_23 = var0_20.doFinal(new byte[]{(byte)(var2_22 >>> 56), (byte)(var2_22 >>> 48), (byte)(var2_22 >>> 40), (byte)(var2_22 >>> 32), (byte)(var2_22 >>> 24), (byte)(var2_22 >>> 16), (byte)(var2_22 >>> 8), (byte)var2_22});
        ** while (true)
        Class_cc_f2157a8a.QlUSv = ((long)var4_23[0] & 255L) << 56 | ((long)var4_23[1] & 255L) << 48 | ((long)var4_23[2] & 255L) << 40 | ((long)var4_23[3] & 255L) << 32 | ((long)var4_23[4] & 255L) << 24 | ((long)var4_23[5] & 255L) << 16 | ((long)var4_23[6] & 255L) << 8 | (long)var4_23[7] & 255L;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    protected void NV(Class_lC_5322e8cf var1_1) {
        block7: {
            block6: {
                var2_2 = Class_cc_f2157a8a.axaUP ^ 13073517335315L;
                var5_3 = ClientMain.dlM();
                var4_4 = Class_ca_75c833b3.OY();
                var6_5 = this.ormBS.dhj();
                var7_6 = this.gILqY.dhj();
                var8_7 = Class_mG_52c8d386.QHTxQ.cob(0.3f * var7_6);
                var1_1.ccY(this.toIeR - 5.0f, this.QWaAn - 5.0f, this.jTsqG + 10.0f, this.Xtjvx + 10.0f, 15.0f, Class_ld_bb1690e1.all(6.0f), var8_7);
                var1_1.ccU(this.toIeR, this.QWaAn, this.jTsqG, this.Xtjvx, var6_5, var7_6);
                var9_8 = ClientMain.dmg();
                v0 = var9_8.dcK();
                if (var4_4) {
                    v0 = v0 != null ? var9_8.dcK() : Class_ob_77a6de24.cBv((String)Class_cc_f2157a8a.PE("g", (int)25611, (long)(3310658822238917880L ^ var2_2)));
                }
                var10_9 = v0;
                var11_10 = 26.0f;
                var1_1.cef(var10_9, this.toIeR + 7.0f, this.QWaAn + 7.0f, var11_10, var11_10, Class_ld_bb1690e1.all(3.0f), Class_mG_52c8d386.hoGuU);
                var12_11 = Class_lE_06fbe260.SVnNc.bYM(8.0f);
                var13_12 = Class_lE_06fbe260.SVnNc.bYM(7.0f);
                var14_13 = var5_3.bjb().coa(255.0f * var6_5);
                var15_14 = this.toIeR + 7.0f + var11_10 + 7.0f;
                var16_15 = this.QWaAn + 10.0f;
                v1 = var9_8;
                if (!var4_4) ** GOTO lbl27
                if (v1.dcX().isBlank()) {
                    v2 = Class_cc_f2157a8a.PE("g", (int)24446, (long)(1809442907373563788L ^ var2_2));
                } else {
                    v1 = var9_8;
lbl27:
                    // 2 sources

                    v2 = v1.dcX();
                }
                var17_16 = v2;
                var1_1.ceH(var12_11, var17_16, var15_14, var16_15, var14_13, 0.3f, 0.7f, 140.0f);
                v3 = var9_8;
                if (!var4_4) break block6;
                if (!v3.dcQ()) break block7;
                v3 = var9_8;
            }
            this.LzQrF.dhd((var19_18 = (var18_17 = v3.dcS()).media()).playing() != false ? 1.0f : 0.0f);
            var20_19 = var19_18.artist();
            var1_1.ceH(var13_12, var20_19, var15_14, var16_15 + var12_11.cat() + 4.0f, var14_13.cob(0.5f), 0.3f, 0.7f, 140.0f);
            this.Pw(var1_1, var14_13, var19_18);
            this.Px(var1_1, var9_8.dcU(), var14_13, var19_18);
            this.Pz(var1_1, var14_13, var18_17);
        }
    }

    @Override
    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        this.jTsqG = 160.0f;
        this.Xtjvx = 75.0f;
        super.LX(class_lC_5322e8cf);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean Om() {
        long l = axaUP ^ 0x86E7CDB1639L;
        boolean bl = Class_ca_75c833b3.OY();
        boolean bl2 = ClientMain.dmg().dcQ();
        if (!bl) return bl2;
        if (bl2) return true;
        bl2 = ClientMain.dlmvG.currentScreen instanceof ChatScreen;
        if (!bl) return bl2;
        if (!bl2) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean onMouseClicked(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        boolean bl;
        long l = axaUP ^ 0x901A8DE13BL;
        Class_qO_d37ef529 class_qO_d37ef529 = ClientMain.dmg();
        boolean bl2 = Class_ca_75c833b3.OY();
        IMediaSession iMediaSession = class_qO_d37ef529.dcS();
        if (iMediaSession != null) {
            float f = this.toIeR + this.jTsqG / 2.0f;
            float f2 = this.QWaAn + 50.0f;
            Class_lc_b8480f87 class_lc_b8480f87 = new Class_lc_b8480f87(f - 40.0f, f2, 16.0f, 16.0f);
            Class_lc_b8480f87 class_lc_b8480f872 = new Class_lc_b8480f87(f - 8.0f, f2, 16.0f, 16.0f);
            Class_lc_b8480f87 class_lc_b8480f873 = new Class_lc_b8480f87(f + 24.0f, f2, 16.0f, 16.0f);
            Class_lc_b8480f87 class_lc_b8480f874 = new Class_lc_b8480f87(this.toIeR + this.jTsqG - 24.0f, f2 + 4.0f, 8.0f, 8.0f);
            bl = class_lc_b8480f87.bXD(d, d2);
            if (bl2) {
                if (bl) {
                    iMediaSession.previous();
                    return true;
                }
                bl = class_lc_b8480f872.bXD(d, d2);
            }
            if (bl2) {
                if (bl) {
                    iMediaSession.playPause();
                    return true;
                }
                bl = class_lc_b8480f873.bXD(d, d2);
            }
            if (bl2) {
                if (bl) {
                    iMediaSession.next();
                    return true;
                }
                bl = class_lc_b8480f874.bXD(d, d2);
            }
            if (!bl2) return bl;
            if (bl) {
                iMediaSession.swapCycle();
                WindowsMediaSession.setCycle((int)iMediaSession.getCycleType());
                return true;
            }
        }
        bl = super.onMouseClicked(d, d2, class_mA_32d8a5f2);
        return bl;
    }

    private static MatchException PA(MatchException matchException) {
        return matchException;
    }

    private void Pw(Class_lC_5322e8cf class_lC_5322e8cf, Class_mG_52c8d386 class_mG_52c8d386, MediaInfo mediaInfo) {
        Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.SVnNc.bYM(6.0f);
        String string = Class_jf_d1c4f950.bAN(mediaInfo.position());
        long l = Math.max(0L, mediaInfo.duration() - mediaInfo.position());
        String string2 = Class_jf_d1c4f950.bAN(l);
        float f = 110.0f;
        float f2 = 3.0f;
        float f3 = this.toIeR + this.jTsqG / 2.0f - f / 2.0f;
        float f4 = this.QWaAn + 40.0f;
        class_lC_5322e8cf.cdg(f3, f4, f, f2, Class_ld_bb1690e1.all(0.5f), class_mG_52c8d386.coa(63.75f));
        this.zzuzN.dhd(Math.min(1.0f, (float)mediaInfo.position() / (float)mediaInfo.duration()));
        float f5 = f * this.zzuzN.dhj();
        class_lC_5322e8cf.cdg(f3, f4, f5, f2, Class_ld_bb1690e1.all(0.5f), class_mG_52c8d386.coa(150.0f));
        class_lC_5322e8cf.cez(class_lq_87a74641, string, f3 - class_lq_87a74641.cao(string) - 3.0f, f4 - 0.75f, class_mG_52c8d386.cob(0.5f));
        class_lC_5322e8cf.cez(class_lq_87a74641, string2, f3 + f + 3.0f, f4 - 0.75f, class_mG_52c8d386.cob(0.5f));
    }

    private static CallSite PE(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cc_f2157a8a" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private void Py(boolean n) {
        int n2;
        long l = axaUP ^ 0x5E5C282A2EB4L;
        boolean bl = Class_ca_75c833b3.OX();
        int n3 = n;
        if (!bl) {
            if (n3 == 0) {
                Arrays.fill(this.ywaEw, 0.35f);
                return;
            }
            n3 = this.Uslxa.cpE(QlUSv) ? 1 : 0;
        }
        if (!bl) {
            if (n3 == 0) {
                return;
            }
            n3 = n2 = 0;
        }
        while (n2 < this.ywaEw.length) {
            this.ywaEw[n2] = MathHelper.lerp((float)((float)Math.random()), (float)0.35f, (float)1.0f);
            ++n2;
            if (!bl) continue;
        }
    }

    private static String PC(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5927;
        if (vRGNc[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])nvHhc.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    nvHhc.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cc_f2157a8a", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = wtTpp[n2].getBytes("ISO-8859-1");
            Class_cc_f2157a8a.vRGNc[n2] = Class_cc_f2157a8a.PB(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return vRGNc[n2];
    }

    private static String PB(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    /*
     * Unable to fully structure code
     */
    private void Pz(Class_lC_5322e8cf var1_1, Class_mG_52c8d386 var2_2, IMediaSession var3_3) {
        var4_4 = Class_cc_f2157a8a.axaUP ^ 80694777663515L;
        var7_5 = this.toIeR + this.jTsqG / 2.0f;
        var8_6 = this.QWaAn + 50.0f;
        var9_7 = new Class_lc_b8480f87(var7_5 - 40.0f, var8_6, 16.0f, 16.0f);
        var10_8 = new Class_lc_b8480f87(var7_5 - 8.0f, var8_6, 16.0f, 16.0f);
        var11_9 = new Class_lc_b8480f87(var7_5 + 24.0f, var8_6, 16.0f, 16.0f);
        var12_10 = new Class_lc_b8480f87(this.toIeR + this.jTsqG - 24.0f, var8_6 + 4.0f, 8.0f, 8.0f);
        var13_11 = Class_rm_d861be3b.dis();
        var14_12 = this.RR(var13_11.x);
        var16_13 = this.RS(var13_11.y);
        this.QpQRV.dhc(var9_7.bXD(var14_12, var16_13));
        this.debmQ.dhc(var10_8.bXD(var14_12, var16_13));
        this.IbiJA.dhc(var11_9.bXD(var14_12, var16_13));
        v0 = Class_ca_75c833b3.OY();
        var1_1.ceq(Class_lf_d247d983.RJfxY, var9_7, var2_2.coa(255.0f - 100.0f * this.QpQRV.dhj()));
        var18_14 = this.LzQrF.dhj();
        var19_15 = var10_8.bXF() + var10_8.bXH() / 2.0f;
        var20_16 = var10_8.bXG() + var10_8.bXI() / 2.0f;
        var1_1.ceV();
        var1_1.cfb(var19_15, var20_16, 90.0f * var18_14);
        Class_jH_c1172273.bId(var1_1, var19_15, var20_16, 1.0f - var18_14);
        var1_1.ceq(Class_lf_d247d983.bLlHc, var10_8, var2_2.coa(255.0f * (1.0f - var18_14) - 100.0f * this.debmQ.dhj()));
        Class_jH_c1172273.bIf();
        var1_1.ceW();
        var1_1.ceV();
        var1_1.cfb(var19_15, var20_16, -90.0f + 90.0f * var18_14);
        Class_jH_c1172273.bId(var1_1, var19_15, var20_16, var18_14);
        var1_1.ceq(Class_lf_d247d983.wJqgL, var10_8, var2_2.coa(255.0f * var18_14 - 100.0f * this.debmQ.dhj()));
        Class_jH_c1172273.bIf();
        var1_1.ceW();
        var6_17 = v0;
        var1_1.ceq(Class_lf_d247d983.xesLS, var11_9, var2_2.coa(255.0f - 100.0f * this.IbiJA.dhj()));
        if (!var6_17) ** GOTO lbl37
        switch (var3_3.getCycleType()) {
            case 0: {
                var1_1.ceq(Class_lf_d247d983.PzeJx, var12_10, this.wNrIZ.dfT(var2_2.cob(0.5f)));
lbl37:
                // 2 sources

                if (var6_17) break;
            }
            case 1: {
                var1_1.ceq(Class_lf_d247d983.PzeJx, var12_10, this.wNrIZ.dfT(var2_2));
                if (var6_17) break;
            }
            case 2: {
                var1_1.ceq(Class_lf_d247d983.QZzTA, var12_10, this.wNrIZ.dfT(var2_2));
                break;
            }
        }
    }

    private static int PF(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x67E9;
        if (NQYLH[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = dunGn[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])rhxtg.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    rhxtg.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cc_f2157a8a", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_cc_f2157a8a.NQYLH[n2] = n3;
        }
        return NQYLH[n2];
    }

    private void Px(Class_lC_5322e8cf class_lC_5322e8cf, Class_mG_52c8d386 class_mG_52c8d386, Class_mG_52c8d386 class_mG_52c8d3862, MediaInfo mediaInfo) {
        long l = axaUP ^ 0x4B00523EA6BFL;
        boolean bl = Class_ca_75c833b3.OX();
        this.Py(mediaInfo.playing());
        boolean bl2 = bl;
        Class_mG_52c8d386 class_mG_52c8d3863 = this.cdPcl.SZ() ? class_mG_52c8d386.coc(Class_mG_52c8d386.hoGuU, 0.2f) : class_mG_52c8d3862;
        Class_mG_52c8d386 class_mG_52c8d3864 = this.tYJbR.dfT(class_mG_52c8d3863.cob(this.ormBS.dhj()));
        Class_kW_239383b1 class_kW_239383b1 = new Class_kW_239383b1(class_mG_52c8d3864.cof(), class_mG_52c8d3864);
        float f = 1.2f;
        float f2 = 7.0f;
        float f3 = 1.0f;
        int n = this.nKTkB.length;
        float f4 = f * (float)n + (float)(n - 1) * f3;
        float f5 = this.toIeR + this.jTsqG - 7.0f - f4 * this.ormBS.dhj();
        float f6 = this.QWaAn + 10.0f + 3.5f;
        for (int i = 0; i < n; ++i) {
            this.nKTkB[i].dhq((int)Class_cc_f2157a8a.PH("l", (int)23819, (long)(0x449ADB3925C02682L ^ l)));
            float f7 = this.nKTkB[i].dhd(this.ywaEw[i]);
            float f8 = f2 * f7;
            float f9 = f5 + (float)i * (f + f3);
            float f10 = f6 - f8 / 2.0f;
            class_lC_5322e8cf.cdP(f9, f10, f, f8, Class_ld_bb1690e1.all(0.5f), class_kW_239383b1, 0.5f);
            if (!bl2) continue;
        }
    }

    private static int PG(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_cc_f2157a8a.PF(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static CallSite PH(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cc_f2157a8a" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cc_f2157a8a.class, "PD", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_cc_f2157a8a.class, "PG", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

