/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;

public class Class_hh_0d24bd9b
extends Class_hH_ae8f8f77 {
    private float cLQBU;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hh_0d24bd9b(float f) {
        this.cLQBU = f;
    }

    public float bcA() {
        return this.cLQBU;
    }
}

