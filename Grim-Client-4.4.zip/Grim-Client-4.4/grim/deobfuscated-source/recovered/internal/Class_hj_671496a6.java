/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.LivingEntity
 */
package recovered.internal;

import net.minecraft.entity.LivingEntity;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_hj_671496a6
extends Class_hH_ae8f8f77 {
    private double GTWMp;
    private double iBdYe;
    private double VgCDR;
    private LivingEntity dMOjl;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hj_671496a6(double d, double d2, double d3, LivingEntity livingEntity) {
        this.GTWMp = d;
        this.iBdYe = d2;
        this.VgCDR = d3;
        this.dMOjl = livingEntity;
    }

    public double bcI() {
        return this.GTWMp;
    }

    public double bcK() {
        return this.VgCDR;
    }

    public LivingEntity bcL() {
        return this.dMOjl;
    }

    public double bcJ() {
        return this.iBdYe;
    }
}

