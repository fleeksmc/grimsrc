/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

public final class Class_ag_rR_5deaebc6
extends Enum<Class_ag_rR_5deaebc6> {
    public static /* enum */ Class_ag_rR_5deaebc6 cyZLf;
    public static /* enum */ Class_ag_rR_5deaebc6 VdGoA;
    public static /* enum */ Class_ag_rR_5deaebc6 DMyaI;
    private static Class_ag_rR_5deaebc6[] OSceP;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_ag_rR_5deaebc6.class);
        Class_ag_rR_5deaebc6._6022c76405527bab38dd67708bcb9e6b();
    }

    public static native Class_ag_rR_5deaebc6[] values();

    public static native Class_ag_rR_5deaebc6 valueOf(String var0);

    private static native void _6022c76405527bab38dd67708bcb9e6b();

    private static native Class_ag_rR_5deaebc6[] dmQ();

    private static native String dmR(byte[] var0);
}

