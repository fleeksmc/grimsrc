/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.ArrayList;
import java.util.Vector;
import recovered.core.NativeLoader;
import recovered.internal.Class_fZ_f7ad3492;
import recovered.internal.Class_ga_05c8213e;

public class Class_gb_9d201141
implements Class_ga_05c8213e {
    private long fypFy;
    private int[] kClfx;
    private Class_ga_05c8213e NpnYD;
    private long srzmL;
    private long[] DNYiY;
    private static long[] EYSuF;
    static int[] idqOu;
    private static ArrayList YRQDX;
    private static Vector aMmNt;
    private static int saIRC;
    private static Object anmuy;
    private static int Oefhm;
    private static int GyBiN;
    private static int qfDRg;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_gb_9d201141(long l) {
        this.fypFy = l;
        this.kClfx = idqOu;
        this.DNYiY = EYSuF;
    }

    static {
        NativeLoader.doInit(Class_gb_9d201141.class);
        Class_gb_9d201141._bab653dcf48cf5170082af05b37ffda0();
    }

    public native boolean equals(Object var1);

    public native int hashCode();

    @Override
    public native void b(long var1);

    @Override
    public native int[] b();

    @Override
    public native boolean b(Class_ga_05c8213e var1);

    @Override
    public native void a(Class_ga_05c8213e var1);

    @Override
    public native long a(long var1);

    public static native Class_ga_05c8213e aYR(long var0, long var2, Object var4);

    public static native Object aYQ();

    private native long aYX(int var1, int var2);

    static native void aYV(Class_fZ_f7ad3492 var0);

    private static native long aYY(long var0, int var2, int var3, int[] var4, long[] var5);

    private static native void aYZ();

    private static native void aZa(int var0, int var1, ArrayList var2, ArrayList var3, int var4);

    private static native void aZb(int var0, int var1, int var2, ArrayList var3, ArrayList var4);

    static native Class_ga_05c8213e aYS(long var0);

    private static native Class_ga_05c8213e aYT(long var0);

    static native void aYU(Class_fZ_f7ad3492 var0);

    private native long aYW(int var1);

    private static native void aZc();

    private static native void _bab653dcf48cf5170082af05b37ffda0();
}

