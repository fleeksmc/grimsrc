/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mG_52c8d386;

public class Class_af_98bd07d0
extends Class_az_a4990dcf {
    private int[] aZkxe;
    private int[] VuamI;
    private float AUSed = 4.0f;
    private Class_mG_52c8d386 QaaNI = Class_mG_52c8d386.hoGuU;
    private Class_mG_52c8d386 RZOxF = Class_mG_52c8d386.hoGuU.cob(0.5f);
    private Class_mG_52c8d386 Pitns;
    private Class_ld_bb1690e1 kkUiM;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_af_98bd07d0.class);
    }

    public native Class_af_98bd07d0 nb(String var1);

    public native Class_af_98bd07d0 nf(float var1);

    public native Class_af_98bd07d0 ni(Class_mG_52c8d386 var1);

    public native Class_af_98bd07d0 ne(int[] var1);

    public native Class_af_98bd07d0 nh(Class_mG_52c8d386 var1);

    public native Class_af_98bd07d0 nc(int[] var1);

    public native Class_af_98bd07d0 nd(String var1);

    public native Class_af_98bd07d0 ng(Class_mG_52c8d386 var1);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    public native Class_af_98bd07d0 nj(Class_ld_bb1690e1 var1);
}

