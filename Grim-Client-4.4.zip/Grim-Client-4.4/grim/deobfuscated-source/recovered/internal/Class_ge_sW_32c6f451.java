/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.reflect.TypeToken
 */
package recovered.internal;

import com.google.common.reflect.TypeToken;
import java.util.Map;
import recovered.internal.Class_ge_83bda88c;
import recovered.internal.Class_mz_7ef7b67c;

class Class_ge_sW_32c6f451
extends TypeToken<Map<Integer, Class_mz_7ef7b67c<int[], int[]>>> {
    final Class_ge_83bda88c JJwtd;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_ge_sW_32c6f451(Class_ge_83bda88c class_ge_83bda88c) {
        this.JJwtd = class_ge_83bda88c;
    }
}

