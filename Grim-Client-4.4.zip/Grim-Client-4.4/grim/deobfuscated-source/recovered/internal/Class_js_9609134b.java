/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import recovered.internal.Class_gb_9d201141;

public class Class_js_9609134b {
    private static final ThreadLocal<Integer> TOuAs;
    private static String[] lfwai;
    private static final long JIoBD;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        JIoBD = Class_gb_9d201141.aYR(255756148750922649L, -1897272244287991293L, MethodHandles.lookup().lookupClass()).a(50545706369725L);
        TOuAs = ThreadLocal.withInitial(() -> 0);
        Class_js_9609134b.bFE(null);
    }

    public static void bFB() {
        block2: {
            int n;
            block1: {
                String[] stringArray;
                block0: {
                    long l = JIoBD ^ 0x63948DB819E0L;
                    n = TOuAs.get() - 1;
                    stringArray = Class_js_9609134b.bFF();
                    if (stringArray != null) break block0;
                    if (n > 0) break block1;
                    TOuAs.remove();
                }
                if (stringArray == null) break block2;
            }
            TOuAs.set(n);
        }
    }

    public static void bFA() {
        TOuAs.set(TOuAs.get() + 1);
    }

    private static MatchException bFG(MatchException matchException) {
        return matchException;
    }

    public static void bFE(String[] stringArray) {
        lfwai = stringArray;
    }

    public static String[] bFF() {
        return lfwai;
    }

    public static boolean bFC() {
        long l = JIoBD ^ 0x42392A7897BFL;
        String[] stringArray = Class_js_9609134b.bFF();
        boolean bl = TOuAs.get().intValue();
        if (stringArray == null) {
            bl = bl > false;
        }
        return bl;
    }
}

