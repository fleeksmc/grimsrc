/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.PlayerEntity
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import net.minecraft.entity.player.PlayerEntity;
import recovered.core.NativeLoader;
import recovered.internal.Class_hL_db8a30f6;
import recovered.internal.Class_hX_15329af5;
import recovered.internal.Class_hZ_076851ce;

public class Class_hR_81cd6b59 {
    private static long zKJZR;
    private static String[] VRROQ;
    private static String[] pefzz;
    private static Map HPyEP;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_hR_81cd6b59.class);
        Class_hR_81cd6b59._cb450bd1a56b1f3ac2916942b09679fa();
    }

    private static native void _cb450bd1a56b1f3ac2916942b09679fa();

    public native Class_hZ_076851ce beN();

    private native /* synthetic */ void beQ(Class_hX_15329af5 var1);

    private static native String beU(int var0, long var1);

    private static native Object beV(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native void beP(PlayerEntity var1);

    private native PlayerEntity beO(String var1);

    private static native MatchException beS(MatchException var0);

    private static native String beT(byte[] var0);

    private static native CallSite beW(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native /* synthetic */ void beR(Class_hL_db8a30f6 var1);
}

