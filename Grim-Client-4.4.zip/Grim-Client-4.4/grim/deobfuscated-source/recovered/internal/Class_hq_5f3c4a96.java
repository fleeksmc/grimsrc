/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 */
package recovered.internal;

import net.minecraft.entity.Entity;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_hq_5f3c4a96
extends Class_hH_ae8f8f77 {
    private Entity vUbKz;
    private Entity utwPn;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hq_5f3c4a96(Entity entity, Entity entity2) {
        this.vUbKz = entity;
        this.utwPn = entity2;
    }

    public Entity bcZ() {
        return this.vUbKz;
    }

    public Entity bda() {
        return this.utwPn;
    }
}

