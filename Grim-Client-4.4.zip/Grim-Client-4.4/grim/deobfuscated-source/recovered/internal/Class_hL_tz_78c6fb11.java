/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import recovered.core.NativeLoader;
import recovered.internal.Class_hJ_a20df6c5;
import recovered.internal.Class_hK_37a4c9e8;
import recovered.internal.Class_hL_db8a30f6;

class Class_hL_tz_78c6fb11
implements Class_hK_37a4c9e8 {
    final Class_hK_37a4c9e8 ussFH;
    final List CLLeY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Ignored method signature, as it can't be verified against descriptor
     */
    Class_hL_tz_78c6fb11(Class_hL_db8a30f6 class_hL_db8a30f6, Class_hK_37a4c9e8 class_hK_37a4c9e8, List list) {
        this.ussFH = class_hK_37a4c9e8;
        this.CLLeY = list;
    }

    static {
        NativeLoader.doInit(Class_hL_tz_78c6fb11.class);
    }

    @Override
    public native Class_hJ_a20df6c5 validate(String var1);

    @Override
    public native List<String> suggestions(String var1);

    private static native boolean dpu(String var0, String var1);
}

