/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.scoreboard.AbstractTeam
 *  net.minecraft.scoreboard.Scoreboard
 *  net.minecraft.scoreboard.ScoreboardDisplaySlot
 *  net.minecraft.scoreboard.ScoreboardEntry
 *  net.minecraft.scoreboard.ScoreboardObjective
 *  net.minecraft.scoreboard.Team
 *  net.minecraft.scoreboard.number.NumberFormat
 *  net.minecraft.scoreboard.number.StyledNumberFormat
 *  net.minecraft.text.MutableText
 *  net.minecraft.text.StringVisitable
 *  net.minecraft.text.Text
 *  net.minecraft.util.Formatting
 *  net.minecraft.util.math.Vec2f
 *  org.joml.Matrix3x2fc
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.scoreboard.AbstractTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.number.NumberFormat;
import net.minecraft.scoreboard.number.StyledNumberFormat;
import net.minecraft.text.MutableText;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec2f;
import org.joml.Matrix3x2fc;
import recovered.core.ClientMain;
import recovered.internal.Class_bX_sj_c4120501;
import recovered.internal.Class_bX_sk_72c9b1cb;
import recovered.internal.Class_cp_ba0fd449;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jz_f6b25671;
import recovered.internal.Class_jz_tU_b0c4bef4;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_rm_d861be3b;

public class Class_bX_66e572fb
extends Class_cp_ba0fd449 {
    private static final int Rtycl;
    private static final int wRANw;
    private static final int hDLMV;
    private static final int VhZzF;
    private static final Comparator<ScoreboardEntry> PmBSa;
    private static boolean ckbaU;
    private static final long ueCGs;
    private static final String LoMwA;
    private static final long[] sJLTV;
    private static final Integer[] LWJTM;
    private static final Map HBGny;
    private static final long KkDAQ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bX_66e572fb() {
        block0: {
            long l = ueCGs ^ 0x36E6039BB7ABL;
            boolean bl = Class_bX_66e572fb.Ou();
            int[] nArray = new int[Class_bX_66e572fb.OA("a", (int)8551, (long)(0x728CF540E2CF3588L ^ l))];
            nArray[0] = (int)Class_bX_66e572fb.OA("a", (int)14440, (long)(0x1DB9B2121E55AC80L ^ l));
            nArray[1] = (int)Class_bX_66e572fb.OA("a", (int)3833, (long)(0x3A5B5C53B2E79A0AL ^ l));
            nArray[2] = (int)Class_bX_66e572fb.OA("a", (int)3024, (long)(0x2E46D654838B1F35L ^ l));
            nArray[3] = (int)Class_bX_66e572fb.OA("a", (int)6135, (long)(0x163F87484116031AL ^ l));
            nArray[4] = (int)Class_bX_66e572fb.OA("a", (int)26714, (long)(0x35F0143501197CAAL ^ l));
            nArray[5] = (int)Class_bX_66e572fb.OA("a", (int)4603, (long)(0x6A637BD410830512L ^ l));
            nArray[Class_bX_66e572fb.OA("a", (int)29550, (long)(0x29DDA1E685C1678AL ^ l))] = (int)Class_bX_66e572fb.OA("a", (int)15154, (long)(0x2D9E5141AFB7AFD8L ^ l));
            nArray[Class_bX_66e572fb.OA("a", (int)8338, (long)(0x59E3ED75A4E93472L ^ l))] = (int)Class_bX_66e572fb.OA("a", (int)15546, (long)(0x47A02E3DF4AD284FL ^ l));
            nArray[Class_bX_66e572fb.OA("a", (int)13683, (long)(0x121837EE7432192L ^ l))] = (int)Class_bX_66e572fb.OA("a", (int)30923, (long)(0x1D8E6C78D5C4EC2DL ^ l));
            nArray[Class_bX_66e572fb.OA("a", (int)29975, (long)(0x4D3585F812E1E5L ^ l))] = (int)Class_bX_66e572fb.OA("a", (int)11012, (long)(0x50418BAE3BE93FE3L ^ l));
            super(nArray, Class_lf_d247d983.TMFYi);
            boolean bl2 = bl;
            if (bl2) break block0;
            Class_iS_888f260e.bwK("knyA2b");
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block15: {
            block13: {
                block12: {
                    block14: {
                        Class_bX_66e572fb.ueCGs = Class_gb_9d201141.aYR(-6352574835933114182L, -7086090206663917643L, MethodHandles.lookup().lookupClass()).a(125013036524319L);
                        var16 = Class_bX_66e572fb.ueCGs ^ 89947509825978L;
                        Class_bX_66e572fb.Ot(true);
                        var18_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var16 >>> 56);
                        for (var19_2 = 1; var19_2 < 8; ++var19_2) {
                            v2 = v2;
                            v2[var19_2] = (byte)(var16 << var19_2 * 8 >>> 56);
                        }
                        break block14;
lbl14:
                        // 1 sources

                        while (true) {
                            continue;
                            break;
                        }
                    }
                    var18_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                    var20_3 = var18_1.doFinal("\u00dac`\u0019\u00b6\u00cd\u00c0\u009f".getBytes("ISO-8859-1"));
                    ** while (true)
                    Class_bX_66e572fb.LoMwA = Class_bX_66e572fb.Ox(var20_3).intern();
                    Class_bX_66e572fb.HBGny = new HashMap<K, V>(13);
                    var5_4 = Cipher.getInstance("DES/CBC/NoPadding");
                    v3 = SecretKeyFactory.getInstance("DES");
                    v4 = new byte[8];
                    v5 = v4;
                    v4[0] = (byte)(var16 >>> 56);
                    for (var6_5 = 1; var6_5 < 8; ++var6_5) {
                        v5 = v5;
                        v5[var6_5] = (byte)(var16 << var6_5 * 8 >>> 56);
                    }
                    var5_4.init(2, (Key)v3.generateSecret(new DESKeySpec(v5)), new IvParameterSpec(new byte[8]));
                    var11_6 = new long[23];
                    var8_7 = 0;
                    var9_8 = "\u0015C\u00fa\u00cca1Dg\u0000\u00acH\u00b0[\u00aa\u00d7\u0080Tl\u00ac\u00cf\u0012\u0002h\u00fd\u0096y\u00bb\u00cb\u0084\u0011\u001fe\u008e\u008d\u001c\\\u00b8\u0013r\b@\u00b6\u0011\u0097S\u008e,\u0016\\<jz\u0001@\u00e37\u00dc\u00b7\u001c\u00afx\u00f6\u00c2\u0005\u0089X\u00a7>\u00ebu\u009d\u00a8a\u00e0 +\u0097\u00e1G\u00d3\u0093;;\u0017\u00ed\u009eb\u00e0\u0012\u008c\u00cc\u00ea\u007f\u00ac5\u0007\t0\u00ff\u008dWyP,m\u007f\u0017\u00f4D\u008e\u001e\u000f\u00a85Q&\u00b4\u00a7y|n\u0017;\u00fd\u0086\u00a3\u00c4\u00e3\u0019*~S.\u00e4sU\u00ec\u00d3\u008f\u00c6\u00fc\u00ef{\u0088\u0091ck\u00df)T\u00f3c\u00cb^v\u00dc\u0094\u00e45\u00a1X\u00c6\u0082&~\u00ce\u0014\u00ed";
                    var10_9 = "\u0015C\u00fa\u00cca1Dg\u0000\u00acH\u00b0[\u00aa\u00d7\u0080Tl\u00ac\u00cf\u0012\u0002h\u00fd\u0096y\u00bb\u00cb\u0084\u0011\u001fe\u008e\u008d\u001c\\\u00b8\u0013r\b@\u00b6\u0011\u0097S\u008e,\u0016\\<jz\u0001@\u00e37\u00dc\u00b7\u001c\u00afx\u00f6\u00c2\u0005\u0089X\u00a7>\u00ebu\u009d\u00a8a\u00e0 +\u0097\u00e1G\u00d3\u0093;;\u0017\u00ed\u009eb\u00e0\u0012\u008c\u00cc\u00ea\u007f\u00ac5\u0007\t0\u00ff\u008dWyP,m\u007f\u0017\u00f4D\u008e\u001e\u000f\u00a85Q&\u00b4\u00a7y|n\u0017;\u00fd\u0086\u00a3\u00c4\u00e3\u0019*~S.\u00e4sU\u00ec\u00d3\u008f\u00c6\u00fc\u00ef{\u0088\u0091ck\u00df)T\u00f3c\u00cb^v\u00dc\u0094\u00e45\u00a1X\u00c6\u0082&~\u00ce\u0014\u00ed".length();
                    var7_10 = 0;
                    while (true) {
                        var12_11 = var9_8.substring(var7_10, var7_10 += 8).getBytes("ISO-8859-1");
                        v6 = var11_6;
                        v7 = var8_7++;
                        v8 = ((long)var12_11[0] & 255L) << 56 | ((long)var12_11[1] & 255L) << 48 | ((long)var12_11[2] & 255L) << 40 | ((long)var12_11[3] & 255L) << 32 | ((long)var12_11[4] & 255L) << 24 | ((long)var12_11[5] & 255L) << 16 | ((long)var12_11[6] & 255L) << 8 | (long)var12_11[7] & 255L;
                        v9 = -1;
                        break block12;
                        break;
                    }
lbl45:
                    // 1 sources

                    while (true) {
                        v6[v7] = v10;
                        if (var7_10 < var10_9) ** continue;
                        var9_8 = "\u00c9\u00a0\u00edQ\u0097\u009f\u00ff\u000e!\u0011!\u00f5Y \u00d6w";
                        var10_9 = "\u00c9\u00a0\u00edQ\u0097\u009f\u00ff\u000e!\u0011!\u00f5Y \u00d6w".length();
                        var7_10 = 0;
                        while (true) {
                            var12_11 = var9_8.substring(var7_10, var7_10 += 8).getBytes("ISO-8859-1");
                            v6 = var11_6;
                            v7 = var8_7++;
                            v8 = ((long)var12_11[0] & 255L) << 56 | ((long)var12_11[1] & 255L) << 48 | ((long)var12_11[2] & 255L) << 40 | ((long)var12_11[3] & 255L) << 32 | ((long)var12_11[4] & 255L) << 24 | ((long)var12_11[5] & 255L) << 16 | ((long)var12_11[6] & 255L) << 8 | (long)var12_11[7] & 255L;
                            v9 = 0;
                            break block12;
                            break;
                        }
                        break;
                    }
lbl58:
                    // 1 sources

                    while (true) {
                        v6[v7] = v10;
                        if (var7_10 < var10_9) ** continue;
                        break block13;
                        break;
                    }
                }
                var13_12 = v8;
                var15_13 = var5_4.doFinal(new byte[]{(byte)(var13_12 >>> 56), (byte)(var13_12 >>> 48), (byte)(var13_12 >>> 40), (byte)(var13_12 >>> 32), (byte)(var13_12 >>> 24), (byte)(var13_12 >>> 16), (byte)(var13_12 >>> 8), (byte)var13_12});
                v10 = ((long)var15_13[0] & 255L) << 56 | ((long)var15_13[1] & 255L) << 48 | ((long)var15_13[2] & 255L) << 40 | ((long)var15_13[3] & 255L) << 32 | ((long)var15_13[4] & 255L) << 24 | ((long)var15_13[5] & 255L) << 16 | ((long)var15_13[6] & 255L) << 8 | (long)var15_13[7] & 255L;
                switch (v9) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl71:
                    // 1 sources

                    ** continue;
                }
            }
            Class_bX_66e572fb.sJLTV = var11_6;
            Class_bX_66e572fb.LWJTM = new Integer[23];
            Class_bX_66e572fb.hDLMV = (int)Class_bX_66e572fb.OA("a", (int)13182, (long)(var16 ^ 5157849299394769293L));
            Class_bX_66e572fb.Rtycl = (int)Class_bX_66e572fb.OA("a", (int)14090, (long)(var16 ^ 2671455856374953452L));
            Class_bX_66e572fb.VhZzF = (int)Class_bX_66e572fb.OA("a", (int)21854, (long)(var16 ^ 8209158299869206436L));
            Class_bX_66e572fb.wRANw = (int)Class_bX_66e572fb.OA("a", (int)20600, (long)(var16 ^ 3750981237575635591L));
            var0_14 = Cipher.getInstance("DES/CBC/NoPadding");
            v11 = SecretKeyFactory.getInstance("DES");
            v12 = new byte[8];
            v13 = v12;
            v12[0] = (byte)(var16 >>> 56);
            for (var1_15 = 1; var1_15 < 8; ++var1_15) {
                v13 = v13;
                v13[var1_15] = (byte)(var16 << var1_15 * 8 >>> 56);
            }
            break block15;
lbl89:
            // 1 sources

            while (true) {
                continue;
                break;
            }
        }
        var0_14.init(2, (Key)v11.generateSecret(new DESKeySpec(v13)), new IvParameterSpec(new byte[8]));
        var2_16 = -7413647882450658063L;
        var4_17 = var0_14.doFinal(new byte[]{(byte)(var2_16 >>> 56), (byte)(var2_16 >>> 48), (byte)(var2_16 >>> 40), (byte)(var2_16 >>> 32), (byte)(var2_16 >>> 24), (byte)(var2_16 >>> 16), (byte)(var2_16 >>> 8), (byte)var2_16});
        ** while (true)
        Class_bX_66e572fb.KkDAQ = ((long)var4_17[0] & 255L) << 56 | ((long)var4_17[1] & 255L) << 48 | ((long)var4_17[2] & 255L) << 40 | ((long)var4_17[3] & 255L) << 32 | ((long)var4_17[4] & 255L) << 24 | ((long)var4_17[5] & 255L) << 16 | ((long)var4_17[6] & 255L) << 8 | (long)var4_17[7] & 255L;
        Class_bX_66e572fb.PmBSa = Comparator.comparing((Function<ScoreboardEntry, Integer>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, comp_2128(), (Lnet/minecraft/scoreboard/ScoreboardEntry;)Ljava/lang/Integer;)()).reversed().thenComparing((Function<ScoreboardEntry, String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, comp_2127(), (Lnet/minecraft/scoreboard/ScoreboardEntry;)Ljava/lang/String;)(), String.CASE_INSENSITIVE_ORDER);
    }

    private void Op(Class_lC_5322e8cf class_lC_5322e8cf, Class_bX_sj_c4120501 class_bX_sj_c4120501) {
        block2: {
            long l = ueCGs ^ 0x43564746109DL;
            float f = this.toIeR + 7.0f;
            int n = Math.round(this.toIeR + (float)class_bX_sj_c4120501.backgroundWidth());
            boolean bl = Class_bX_66e572fb.Ou();
            class_lC_5322e8cf.ccU(this.toIeR, this.QWaAn, class_bX_sj_c4120501.backgroundWidth(), class_bX_sj_c4120501.backgroundHeight(), this.ormBS.dhj(), this.gILqY.dhj());
            boolean bl2 = bl;
            int n2 = Math.round(f + (float)(class_bX_sj_c4120501.contentWidth() - class_bX_sj_c4120501.titleWidth()) / 2.0f);
            int n3 = Math.round(this.QWaAn + 5.0f);
            Class_jz_f6b25671.bGI((Matrix3x2fc)class_lC_5322e8cf.cfc(), ClientMain.dlmvG.textRenderer, class_bX_sj_c4120501.title(), n2, n3, -1, false, Class_jz_tU_b0c4bef4.iSvaF);
            for (int i = 0; i < class_bX_sj_c4120501.entries().length; ++i) {
                Class_bX_sk_72c9b1cb class_bX_sk_72c9b1cb = class_bX_sj_c4120501.entries()[i];
                int n4 = Math.round(this.QWaAn + 5.0f + 10.0f + (float)(i * Class_bX_66e572fb.OA("a", (int)29975, (long)(0x4D4035BCCF46D3L ^ l))));
                Class_jz_f6b25671.bGI((Matrix3x2fc)class_lC_5322e8cf.cfc(), ClientMain.dlmvG.textRenderer, class_bX_sk_72c9b1cb.name, Math.round(f), n4, -1, false, Class_jz_tU_b0c4bef4.iSvaF);
                Class_jz_f6b25671.bGI((Matrix3x2fc)class_lC_5322e8cf.cfc(), ClientMain.dlmvG.textRenderer, class_bX_sk_72c9b1cb.score, n - Class_bX_66e572fb.OA("a", (int)3309, (long)(0x1C7151F58331BF2AL ^ l)) - class_bX_sk_72c9b1cb.scoreWidth, n4, -1, false, Class_jz_tU_b0c4bef4.iSvaF);
                if (bl2) {
                    if (bl2) continue;
                }
                break block2;
            }
            Class_jz_f6b25671.bGJ();
        }
    }

    @Override
    protected void NV(Class_lC_5322e8cf class_lC_5322e8cf) {
        block0: {
            long l = ueCGs ^ 0x54B848F0E2B1L;
            Class_bX_sj_c4120501 class_bX_sj_c4120501 = this.Oo(this.On());
            if (class_bX_sj_c4120501 == null) break block0;
            this.Op(class_lC_5322e8cf, class_bX_sj_c4120501);
        }
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void LX(Class_lC_5322e8cf var1_1) {
        var2_2 = Class_bX_66e572fb.ueCGs ^ 70384363048305L;
        var5_3 = this.Oo(this.On());
        var4_4 = Class_bX_66e572fb.Ou();
        v0 = var5_3;
        if (!var4_4) ** GOTO lbl8
        if (v0 != null) {
            v0 = var5_3;
lbl8:
            // 2 sources

            v1 = v0.backgroundWidth();
        } else {
            v1 = 0.0f;
        }
        this.jTsqG = v1;
        v2 = var5_3;
        if (!var4_4) ** GOTO lbl16
        if (v2 != null) {
            v2 = var5_3;
lbl16:
            // 2 sources

            v3 = v2.backgroundHeight();
        } else {
            v3 = 0.0f;
        }
        this.Xtjvx = v3;
        super.LX(var1_1);
    }

    public static void Ot(boolean bl) {
        ckbaU = bl;
    }

    private static CallSite OA(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bX_66e572fb" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static MatchException Ow(MatchException matchException) {
        return matchException;
    }

    private Class_bX_sj_c4120501 Oo(ScoreboardObjective scoreboardObjective) {
        int n;
        int n2;
        int n3;
        Text text;
        Class_bX_sk_72c9b1cb[] class_bX_sk_72c9b1cbArray;
        long l;
        block5: {
            l = ueCGs ^ 0x4BA48AE500F7L;
            boolean bl = Class_bX_66e572fb.Ov();
            ScoreboardObjective scoreboardObjective2 = scoreboardObjective;
            if (!bl) {
                if (scoreboardObjective2 == null) {
                    return null;
                }
                scoreboardObjective2 = scoreboardObjective;
            }
            Scoreboard scoreboard = scoreboardObjective2.getScoreboard();
            NumberFormat numberFormat = scoreboardObjective.getNumberFormatOr((NumberFormat)StyledNumberFormat.RED);
            class_bX_sk_72c9b1cbArray = (Class_bX_sk_72c9b1cb[])scoreboard.getScoreboardEntries(scoreboardObjective).stream().filter(scoreboardEntry -> {
                long l = ueCGs ^ 0x56769E1D5F48L;
                boolean bl = Class_bX_66e572fb.Ou();
                boolean bl2 = scoreboardEntry.hidden();
                if (bl) {
                    bl2 = !bl2;
                }
                return bl2;
            }).sorted(PmBSa).limit(KkDAQ).map(scoreboardEntry -> {
                Team team = scoreboard.getScoreHolderTeam(scoreboardEntry.comp_2127());
                Text text = scoreboardEntry.name();
                MutableText mutableText = Team.decorateName((AbstractTeam)team, (Text)text);
                MutableText mutableText2 = scoreboardEntry.formatted(numberFormat);
                int n = ClientMain.dlmvG.textRenderer.getWidth((StringVisitable)mutableText2);
                return new Class_bX_sk_72c9b1cb((Text)mutableText, (Text)mutableText2, n);
            }).toArray(Class_bX_sk_72c9b1cb[]::new);
            text = scoreboardObjective.getDisplayName();
            n2 = n3 = ClientMain.dlmvG.textRenderer.getWidth((StringVisitable)text);
            int n4 = ClientMain.dlmvG.textRenderer.getWidth(LoMwA);
            for (Class_bX_sk_72c9b1cb class_bX_sk_72c9b1cb : class_bX_sk_72c9b1cbArray) {
                n = n2;
                if (!bl) {
                    int n5 = ClientMain.dlmvG.textRenderer.getWidth((StringVisitable)class_bX_sk_72c9b1cb.name);
                    int n6 = class_bX_sk_72c9b1cb.scoreWidth;
                    if (!bl) {
                        n6 = n6 > 0 ? n4 + class_bX_sk_72c9b1cb.scoreWidth : 0;
                    }
                    n2 = Math.max(n, n5 + n6);
                    if (!bl) continue;
                }
                break block5;
            }
            n = class_bX_sk_72c9b1cbArray.length;
        }
        int n7 = n;
        int n8 = n2 + Class_bX_66e572fb.OA("a", (int)24047, (long)(0x14F53E5894B3FE50L ^ l));
        Object object = Class_bX_66e572fb.OA("a", (int)2723, (long)(0x57EAC5DC741A913L ^ l)) + n7 * Class_bX_66e572fb.OA("a", (int)29975, (long)(0x4D48C7716C56B9L ^ l)) + Class_bX_66e572fb.OA("a", (int)2723, (long)(0x57EAC5DC741A913L ^ l));
        return new Class_bX_sj_c4120501(text, n3, n2, n8, (int)object, class_bX_sk_72c9b1cbArray);
    }

    private ScoreboardObjective On() {
        ScoreboardObjective scoreboardObjective;
        Scoreboard scoreboard;
        boolean bl;
        block13: {
            ScoreboardDisplaySlot scoreboardDisplaySlot;
            Team team;
            block12: {
                Team team2;
                MinecraftClient minecraftClient;
                block10: {
                    block11: {
                        block9: {
                            block8: {
                                long l = ueCGs ^ 0x32DD6E52B445L;
                                bl = Class_bX_66e572fb.Ou();
                                minecraftClient = ClientMain.dlmvG;
                                if (!bl) break block8;
                                if (minecraftClient.world == null) break block9;
                                minecraftClient = ClientMain.dlmvG;
                            }
                            if (!bl) break block10;
                            if (minecraftClient.player != null) break block11;
                        }
                        return null;
                    }
                    minecraftClient = ClientMain.dlmvG;
                }
                scoreboard = minecraftClient.world.getScoreboard();
                scoreboardObjective = null;
                team = team2 = scoreboard.getScoreHolderTeam(ClientMain.dlmvG.player.getNameForScoreboard());
                if (!bl) break block12;
                if (team == null) break block13;
                team = team2;
            }
            if ((scoreboardDisplaySlot = ScoreboardDisplaySlot.fromFormatting((Formatting)team.getColor())) != null) {
                scoreboardObjective = scoreboard.getObjectiveForSlot(scoreboardDisplaySlot);
            }
        }
        ScoreboardObjective scoreboardObjective2 = scoreboardObjective;
        if (bl) {
            scoreboardObjective2 = scoreboardObjective2 != null ? scoreboardObjective : scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        }
        return scoreboardObjective2;
    }

    private static int Oz(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bX_66e572fb.Oy(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public static boolean Ou() {
        return ckbaU;
    }

    private static String Ox(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public static boolean Ov() {
        boolean bl = Class_bX_66e572fb.Ou();
        return !bl;
    }

    @Override
    protected void Ol() {
        Class_bX_sj_c4120501 class_bX_sj_c4120501;
        long l = ueCGs ^ 0x7A702A514192L;
        boolean bl = Class_bX_66e572fb.Ov();
        Class_bX_66e572fb class_bX_66e572fb = this;
        if (!bl) {
            if (!class_bX_66e572fb.mZZzJ.WF()) {
                return;
            }
            class_bX_66e572fb = this;
        }
        if ((class_bX_sj_c4120501 = class_bX_66e572fb.Oo(this.On())) == null) {
            return;
        }
        Vec2f vec2f = Class_rm_d861be3b.dip();
        float f = this.RT();
        int n = class_bX_sj_c4120501.entries().length * Class_bX_66e572fb.OA("a", (int)20943, (long)(0x1FF6C1472DE43300L ^ l));
        float f2 = (float)n * f;
        float f3 = 10.0f * f;
        this.toIeR = vec2f.x - this.RU();
        this.QWaAn = vec2f.y / 2.0f + f2 / 3.0f - f2 - f3;
    }

    private static int Oy(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x282D;
        if (LWJTM[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = sJLTV[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])HBGny.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    HBGny.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bX_66e572fb", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bX_66e572fb.LWJTM[n2] = n3;
        }
        return LWJTM[n2];
    }

    @Override
    public boolean Om() {
        long l = ueCGs ^ 0x5735DE70A79BL;
        return this.On() != null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bX_66e572fb.class, "Oz", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

