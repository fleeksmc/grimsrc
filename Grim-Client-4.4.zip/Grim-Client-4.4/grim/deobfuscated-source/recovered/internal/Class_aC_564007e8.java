/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.core.ClientMain;
import recovered.core.ModuleBase;
import recovered.internal.Class_Y_0432e62a;
import recovered.internal.Class_aF_88ec985e;
import recovered.internal.Class_al_68896891;
import recovered.internal.Class_bd_8faff9cb;
import recovered.internal.Class_bg_0a91641c;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_gh_ecfd0cde;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_rj_b691f4f7;

public class Class_aC_564007e8
extends Class_aF_88ec985e {
    private final List<Class_bg_0a91641c> yfSFR;
    private Class_gh_ecfd0cde mvWDQ;
    private Class_bg_0a91641c nEhCf;
    private final Class_Y_0432e62a YZFGi;
    private static final long jNpun;
    private static final long[] QSCCk;
    private static final Integer[] jbUMH;
    private static final Map AHrLJ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aC_564007e8() {
        Object object;
        Object object2;
        long l;
        block2: {
            l = jNpun ^ 0x51B7C367FEB9L;
            Class_iS_888f260e[] class_iS_888f260eArray = Class_lc_b8480f87.bXK();
            super(new int[]{(int)Class_aC_564007e8.uq("r", (int)18453, (long)(0x549A515C77DF9ACEL ^ l)), (int)Class_aC_564007e8.uq("r", (int)17575, (long)(0x7127F1780EE71678L ^ l)), (int)Class_aC_564007e8.uq("r", (int)5631, (long)(0x26044D3C4DE24721L ^ l)), (int)Class_aC_564007e8.uq("r", (int)19949, (long)(0x6D02069390BA9F31L ^ l))});
            Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
            this.yfSFR = new ArrayList<Class_bg_0a91641c>();
            this.mvWDQ = null;
            object2 = ClientMain.dlJ().aZz().values().iterator();
            while (object2.hasNext()) {
                ModuleBase moduleBase = object2.next();
                Class_bg_0a91641c class_bg_0a91641c = new Class_bg_0a91641c(moduleBase);
                object = this.yfSFR;
                if (class_iS_888f260eArray2 != null) {
                    object.add(class_bg_0a91641c);
                    if (class_iS_888f260eArray2 != null) continue;
                }
                break block2;
            }
            object = this.yfSFR.get(0);
        }
        this.nEhCf = object2 = object;
        this.YZFGi = new Class_Y_0432e62a().kf(Class_lE_06fbe260.joxgd.bYM(7.0f)).ko(Class_mG_52c8d386.hoGuU.cob(0.5f)).kg(((Class_bg_0a91641c)object2).CX().bae()).ki(5.0f).kj((int)Class_aC_564007e8.uq("r", (int)23903, (long)(0xE1AC9DCA9A48F82L ^ l))).kk(Class_rj_b691f4f7.UPXqT);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_aC_564007e8.jNpun = Class_gb_9d201141.aYR(-8194529757589197398L, 694691784488164671L, MethodHandles.lookup().lookupClass()).a(208218874951726L);
                Class_aC_564007e8.AHrLJ = new HashMap<K, V>(13);
                var0 = Class_aC_564007e8.jNpun ^ 121802149965389L;
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[5];
                var5_4 = 0;
                var6_5 = "\u009ee\u0080\u0081V\u0082\u000e\u0086\u0000\u00a6\u0091\u0081\u00f5V\u00be\u00c5\u0005\u0089\u00e0\f\u008cb\u00dfE";
                var7_6 = "\u009ee\u0080\u0081V\u0082\u000e\u0086\u0000\u00a6\u0091\u0081\u00f5V\u00be\u00c5\u0005\u0089\u00e0\f\u008cb\u00dfE".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl26:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = "\u009e\u00d2\u008eTU\u00d8\u008eN\u00e4\u00bf\u0005\u0017\u0092\f\u000b\u0090";
                    var7_6 = "\u009e\u00d2\u008eTU\u00d8\u008eN\u00e4\u00bf\u0005\u0017\u0092\f\u000b\u0090".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl52:
                // 1 sources

                ** continue;
            }
        }
        Class_aC_564007e8.QSCCk = var8_3;
        Class_aC_564007e8.jbUMH = new Integer[5];
    }

    private static int up(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_aC_564007e8.uo(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public Class_bg_0a91641c ui() {
        return this.nEhCf;
    }

    @Override
    public void dY() {
        long l = jNpun ^ 0x69848956A398L;
        super.dY();
        Class_iS_888f260e[] class_iS_888f260eArray = Class_lc_b8480f87.bXK();
        this.LGwHI.clear();
        this.YYZes = this.mvWDQ.baG().clT();
        Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
        List<ModuleBase> list = ClientMain.dlJ().aZw(moduleBase -> {
            long l = jNpun ^ 0x6798E4A6422EL;
            return moduleBase.bak() == this.mvWDQ;
        });
        for (Class_bg_0a91641c class_bg_0a91641c : this.yfSFR) {
            boolean bl = list.contains(class_bg_0a91641c.CX());
            if (class_iS_888f260eArray2 != null && bl) {
                class_bg_0a91641c.CR().dhg();
                bl = this.LGwHI.add(class_bg_0a91641c);
            }
            if (class_iS_888f260eArray2 != null) continue;
        }
    }

    public Class_gh_ecfd0cde uh() {
        return this.mvWDQ;
    }

    @Override
    public void tP(Class_lC_5322e8cf class_lC_5322e8cf, float f, Class_al_68896891 class_al_68896891) {
        Class_lq_87a74641 class_lq_87a74641;
        block4: {
            List<Class_bd_8faff9cb> list;
            block3: {
                Class_iS_888f260e[] class_iS_888f260eArray;
                block2: {
                    long l = jNpun ^ 0x62B72DC087E0L;
                    class_lq_87a74641 = Class_lE_06fbe260.joxgd.bYM(7.0f);
                    class_iS_888f260eArray = Class_lc_b8480f87.bXK();
                    list = Class_bl_a15fbaa5.Ex().manager().aY(Class_bd_8faff9cb.class);
                    if (class_iS_888f260eArray == null) break block2;
                    if (!list.isEmpty()) break block3;
                    this.YZFGi.ku(this.nEhCf.CX().bae());
                }
                if (class_iS_888f260eArray != null) break block4;
            }
            this.YZFGi.ku(list.getLast().BS().CX().bae());
        }
        this.YZFGi.sW(f, class_al_68896891.ts() + Class_jf_d1c4f950.bAH(class_lq_87a74641.cat(), class_al_68896891.dn()));
        this.YZFGi.su(class_lC_5322e8cf);
    }

    @Override
    protected int tR() {
        return 2;
    }

    public Class_aC_564007e8 ul(Class_bg_0a91641c class_bg_0a91641c) {
        this.nEhCf = class_bg_0a91641c;
        return this;
    }

    public Class_aC_564007e8 uk(Class_gh_ecfd0cde class_gh_ecfd0cde) {
        this.mvWDQ = class_gh_ecfd0cde;
        return this;
    }

    private static MatchException un(MatchException matchException) {
        return matchException;
    }

    public List<Class_bg_0a91641c> ug() {
        return this.yfSFR;
    }

    private static int uo(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x14E3;
        if (jbUMH[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = QSCCk[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])AHrLJ.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    AHrLJ.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_aC_564007e8", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_aC_564007e8.jbUMH[n2] = n3;
        }
        return jbUMH[n2];
    }

    private static CallSite uq(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_aC_564007e8" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public Class_Y_0432e62a uj() {
        return this.YZFGi;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_aC_564007e8.class, "up", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

