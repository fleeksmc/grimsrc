/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;

public abstract class Class_gX_511309ce
extends Class_hH_ae8f8f77 {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

