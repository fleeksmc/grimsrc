/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.entity.BlockEntity
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Direction
 *  net.minecraft.world.chunk.WorldChunk
 */
package recovered.internal;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.chunk.WorldChunk;
import recovered.core.NativeLoader;
import recovered.internal.Class_jf_d1c4f950;

public class Class_ja_f9b15645 {
    public static Direction[] srUqw;
    public static Direction[] toQLU;
    private static long PbEQK;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native void _b322c0acb18f2f07ac99b71e048df7be();

    static {
        NativeLoader.doInit(Class_ja_f9b15645.class);
        Class_ja_f9b15645._b322c0acb18f2f07ac99b71e048df7be();
    }

    private static native MatchException byK(MatchException var0);

    public static native boolean byF(Box var0, BlockPos var1);

    public static List<BlockEntity> byD(WorldChunk worldChunk) {
        return new ArrayList<BlockEntity>(worldChunk.getBlockEntities().values());
    }

    public static native List<WorldChunk> byG();

    public static native void byJ();

    public static List<BlockPos> byE(BlockPos blockPos) {
        long l = PbEQK ^ 0x3BAEABDA4E6DL;
        ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
        String[] stringArray = Class_jf_d1c4f950.bBe();
        int n = blockPos.getX() - 2;
        block2: while (true) {
            int n2 = n;
            block3: while (n2 <= blockPos.getX() + 2) {
                int n3 = blockPos.getY() - 1;
                while (n3 <= blockPos.getY() + 4) {
                    block7: {
                        n2 = blockPos.getZ() - 2;
                        if (stringArray == null) continue block3;
                        for (int i = v33695; i <= blockPos.getZ() + 2; ++i) {
                            try {
                                arrayList.add(new BlockPos(n, n3, i));
                                if (stringArray != null) {
                                    if (stringArray != null) continue;
                                    break;
                                }
                                break block7;
                            }
                            catch (MatchException matchException) {
                                throw Class_ja_f9b15645.byK(matchException);
                            }
                        }
                        ++n3;
                    }
                    if (stringArray != null) continue;
                }
                ++n;
                if (stringArray != null) continue block2;
            }
            break;
        }
        return arrayList;
    }

    public static native boolean byH(Block var0);

    public static native boolean byI(BlockPos var0);
}

