/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package recovered.internal;

import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_nf_8f40fc48;
import recovered.internal.Class_rp_2e61368f;

public class Class_iD_f0bb28c7
implements Class_rp_2e61368f {
    private int[] japwe;
    private String gpYuG;
    private String vBoEf;
    private int fBMuG;
    private int YGxtI;
    private String zgHNS;
    private String DbaKZ;
    private boolean MSbmD;
    private boolean LcKMK;
    private boolean ddiza;
    private int HkXKf;
    private boolean uDdOx;
    private boolean dPYcy;
    private String NgGnX;
    private int MpPjj;
    private int CaczB;
    private int rNgKW;
    private int BFxdQ;
    private List<Class_nf_8f40fc48> AXaev;
    private static Class_iS_888f260e[] ViqaA;
    private static long LJRfo;
    private static String[] ldwyP;
    private static String[] qOOqx;
    private static Map CQicq;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public native Class_iD_f0bb28c7 brp(int var1);

    static {
        NativeLoader.doInit(Class_iD_f0bb28c7.class);
        Class_iD_f0bb28c7._87147bff5b5405e44675d2f8a5104f03();
    }

    public native int bri();

    @Override
    public native void fromJson(JsonObject var1);

    @Override
    public native JsonObject toJson();

    public native int brc();

    public native String brf();

    public native boolean bre();

    public native boolean brd();

    public native List<Class_nf_8f40fc48> brk();

    public static native void brE(Class_iS_888f260e[] var0);

    public native int brj();

    public native int brg();

    private static native MatchException brG(MatchException var0);

    private static native Object brJ(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite brK(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native boolean brb();

    public native int brh();

    public static native Class_iS_888f260e[] brF();

    private static native String brH(byte[] var0);

    private static native String brI(int var0, long var1);

    public native int[] bqS();

    public native String bqU();

    public native int bqV();

    public native String bqX();

    public native String bqY();

    public native boolean bqZ();

    public native String bqT();

    public native int bqW();

    public native boolean bra();

    public native Class_iD_f0bb28c7 brt(boolean var1);

    public native Class_iD_f0bb28c7 brr(String var1);

    public native Class_iD_f0bb28c7 brC(int var1);

    public native Class_iD_f0bb28c7 brm(String var1);

    public native Class_iD_f0bb28c7 brn(String var1);

    public native Class_iD_f0bb28c7 brq(String var1);

    public native Class_iD_f0bb28c7 brs(boolean var1);

    public native Class_iD_f0bb28c7 bry(String var1);

    public native Class_iD_f0bb28c7 brv(int var1);

    public native Class_iD_f0bb28c7 brA(int var1);

    public native Class_iD_f0bb28c7 brw(boolean var1);

    public native Class_iD_f0bb28c7 brz(int var1);

    public native Class_iD_f0bb28c7 brB(int var1);

    public native Class_iD_f0bb28c7 brD(List<Class_nf_8f40fc48> var1);

    public native Class_iD_f0bb28c7 bru(boolean var1);

    public native Class_iD_f0bb28c7 brx(boolean var1);

    public native Class_iD_f0bb28c7 bro(int var1);

    public native Class_iD_f0bb28c7 brl(int[] var1);

    private static native void _87147bff5b5405e44675d2f8a5104f03();
}

