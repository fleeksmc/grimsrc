/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.World
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import net.minecraft.world.World;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.modules.AmbienceModule;

class Class_dh_sy_30347b33 {
    private float cmcMI = 0.0f;
    private float eIsxf = 0.0f;
    private static final long cdlKh = Class_gb_9d201141.aYR(-8094499602601458092L, 6363211938442674905L, MethodHandles.lookup().lookupClass()).a(85071454242371L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_dh_sy_30347b33() {
    }

    public void doy(World world) {
        block2: {
            long l = cdlKh ^ 0x32278D612A4FL;
            Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
            float f = this.cmcMI - 0.0f;
            float f2 = f == 0.0f ? 0 : (f > 0.0f ? 1 : -1);
            if (class_iS_888f260eArray == null) {
                float f3;
                if (f2 >= 0) {
                    world.setRainGradient(this.cmcMI);
                }
                f2 = (f3 = this.eIsxf - 0.0f) == 0.0f ? 0 : (f3 > 0.0f ? 1 : -1);
            }
            if (f2 < 0) break block2;
            world.setThunderGradient(this.eIsxf);
        }
    }

    public void dow(float f) {
        this.eIsxf = f;
    }

    public void dov(float f) {
        this.cmcMI = f;
    }

    public void dox() {
        this.cmcMI = 0.0f;
        this.eIsxf = 0.0f;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean doz() {
        long l = cdlKh ^ 0x1AF7BEBC7FA8L;
        Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
        float f = this.cmcMI - 0.0f;
        float f2 = f == 0.0f ? 0 : (f > 0.0f ? 1 : -1);
        if (class_iS_888f260eArray != null) return (boolean)f2;
        if (f2 < 0) {
            float f3 = this.eIsxf - 1.0f;
            f2 = f3 == 0.0f ? 0 : (f3 > 0.0f ? 1 : -1);
            if (class_iS_888f260eArray != null) return (boolean)f2;
            if (f2 < 0) {
                f2 = 0.0f;
                return (boolean)f2;
            }
        }
        f2 = 1.0f;
        return (boolean)f2;
    }

    private static MatchException doA(MatchException matchException) {
        return matchException;
    }
}

