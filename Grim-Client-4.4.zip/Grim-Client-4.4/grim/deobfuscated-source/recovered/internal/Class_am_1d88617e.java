/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  sixtwo.am$rS
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_ah_02444db4;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_lC_5322e8cf;
import sixtwo.am;

public class Class_am_1d88617e
extends Class_az_a4990dcf {
    private final List<am.rS> dKgZe = new ArrayList<am.rS>();
    private final Class_ah_02444db4 PZcRW = new Class_ah_02444db4();
    private static long TXFPf;
    private static String[] YbYUL;
    private static String[] zRGKj;
    private static Map ImqWj;
    private static long GqCCj;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_am_1d88617e(String string) {
        this.oX(string);
    }

    static {
        NativeLoader.doInit(Class_am_1d88617e.class);
        Class_am_1d88617e._084bbcaff7b3cc723e303c46feb338d2();
    }

    private static native String pc(int var0, long var1);

    private static native MatchException pa(MatchException var0);

    private static native Object pd(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite pe(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native String pb(byte[] var0);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean fC(double var1, double var3, double var5);

    private static native void _084bbcaff7b3cc723e303c46feb338d2();

    public native Class_ah_02444db4 oZ();

    public native void oX(String var1);

    public native List<am.rS> oY();
}

