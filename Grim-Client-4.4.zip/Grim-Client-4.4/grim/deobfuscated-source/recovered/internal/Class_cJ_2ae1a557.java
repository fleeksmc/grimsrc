/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 */
package recovered.internal;

import com.google.gson.JsonElement;
import java.lang.invoke.MethodHandles;
import java.util.Arrays;
import java.util.Map;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mr_7eac5189;

public class Class_cJ_2ae1a557
extends Class_cB_67aec11c {
    private boolean LIkdP = false;
    private static boolean bLjCM;
    private static final long hpdui;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cJ_2ae1a557(Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_mr_7eac5189);
    }

    public Class_cJ_2ae1a557(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    static {
        hpdui = Class_gb_9d201141.aYR(-6547464087807471634L, 1371317141899777693L, MethodHandles.lookup().lookupClass()).a(166795554959631L);
        if (!Class_cJ_2ae1a557.WI()) {
            Class_cJ_2ae1a557.WG(true);
        }
    }

    private static MatchException WJ(MatchException matchException) {
        return matchException;
    }

    @Override
    public void SS(JsonElement jsonElement) {
        this.WE(jsonElement.getAsBoolean());
    }

    @Override
    public void SR(Map<String, Object> map) {
        map.put(Arrays.toString(this.NwlSF), this.LIkdP);
    }

    public boolean WF() {
        return this.LIkdP;
    }

    public static boolean WH() {
        return bLjCM;
    }

    public Class_cJ_2ae1a557 WD() {
        long l = hpdui ^ 0x3C1F0C23707DL;
        boolean bl = Class_cB_67aec11c.Vt();
        boolean bl2 = this.LIkdP;
        if (bl) {
            bl2 = !bl2;
        }
        this.LIkdP = bl2;
        this.Vk();
        return this;
    }

    public static void WG(boolean bl) {
        bLjCM = bl;
    }

    public static boolean WI() {
        boolean bl = Class_cJ_2ae1a557.WH();
        return !bl;
    }

    public Class_cJ_2ae1a557 WE(boolean bl) {
        long l = hpdui ^ 0x4EE06A0D22D9L;
        boolean bl2 = Class_cB_67aec11c.Vu();
        Class_cJ_2ae1a557 class_cJ_2ae1a557 = this;
        if (!bl2) {
            if (class_cJ_2ae1a557.LIkdP == bl) {
                return this;
            }
            this.LIkdP = bl;
            this.Vk();
            class_cJ_2ae1a557 = this;
        }
        return class_cJ_2ae1a557;
    }
}

