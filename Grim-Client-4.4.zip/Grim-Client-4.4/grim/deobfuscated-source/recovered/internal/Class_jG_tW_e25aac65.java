/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

record Class_jG_tW_e25aac65(int x, int y, int width, int height) {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

