/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.network.ClientPlayerEntity
 *  net.minecraft.client.render.entity.model.EntityModelLayers
 *  net.minecraft.client.render.entity.model.LoadedEntityModels
 *  net.minecraft.client.render.entity.model.PlayerEntityModel
 *  net.minecraft.client.util.DefaultSkinHelper
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.Util
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.RotationAxis
 *  org.joml.Matrix3x2fc
 *  org.joml.Matrix4f
 *  org.joml.Quaternionfc
 *  org.joml.Vector3f
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import java.util.function.Function;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.LoadedEntityModels;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix3x2fc;
import org.joml.Matrix4f;
import org.joml.Quaternionfc;
import org.joml.Vector3f;
import recovered.core.ClientMain;
import recovered.internal.Class_ag_rQ_eeb048ad;
import recovered.internal.Class_ag_rR_5deaebc6;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jI_616cf0dd;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_mA_32d8a5f2;

public class Class_ag_8130246f
extends Class_az_a4990dcf {
    private static final float sbZWT = 2.125f;
    private static final float qccLr = -0.53125f;
    private static final float RjGUj = 1.515625f;
    private static final float YhWDg = 0.28125f;
    private static final float Uofge = 0.515625f;
    private static final float vlFnX = 0.453125f;
    private String cKAzP;
    private PlayerEntityModel varoa;
    private PlayerEntityModel QSyUZ;
    private final Class_ag_rR_5deaebc6 VSKnI;
    private boolean FiFgY;
    Function<String, Class_ag_rQ_eeb048ad> ZYZql = string -> {
        Identifier identifier;
        block8: {
            Identifier identifier2;
            block7: {
                String[] stringArray;
                block4: {
                    block5: {
                        ClientPlayerEntity clientPlayerEntity;
                        block6: {
                            long l = WkMeU ^ 0x72883CB37841L;
                            identifier = Class_ag_rQ_eeb048ad.cachedSkins.get(string);
                            stringArray = Class_aj_95d0a719.oA();
                            identifier2 = identifier;
                            if (stringArray == null) break block4;
                            if (identifier2 != null) break block5;
                            clientPlayerEntity = ClientMain.dlmvG.player;
                            if (stringArray == null) break block6;
                            if (clientPlayerEntity == null) break block5;
                            clientPlayerEntity = ClientMain.dlmvG.player;
                        }
                        identifier = clientPlayerEntity.getSkin().comp_1626().comp_3627();
                    }
                    identifier2 = identifier;
                }
                if (stringArray == null) break block7;
                if (identifier2 != null) break block8;
                identifier2 = DefaultSkinHelper.getSteve().comp_1626().comp_3627();
            }
            identifier = identifier2;
        }
        return new Class_ag_rQ_eeb048ad(identifier, true);
    };
    float EnbkJ = -5.0f;
    float Vinex = 30.0f;
    private static final long WkMeU = Class_gb_9d201141.aYR(-2652524297955319212L, -8454400431850127096L, MethodHandles.lookup().lookupClass()).a(258803647282649L);
    private static final long wxrIA;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ag_8130246f(String string2, Class_ag_rR_5deaebc6 class_ag_rR_5deaebc6) {
        this.cKAzP = string2;
        this.VSKnI = class_ag_rR_5deaebc6;
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = WkMeU ^ 0x6034D328BF48L;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                long l2 = 8043091998414103728L;
                byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
                wxrIA = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    public Class_lc_b8480f87 nl(Class_lC_5322e8cf class_lC_5322e8cf, boolean bl) {
        float f;
        float f2;
        float f3;
        float f4;
        block25: {
            block22: {
                int n;
                block24: {
                    String[] stringArray;
                    block23: {
                        block21: {
                            block16: {
                                Class_ag_rQ_eeb048ad class_ag_rQ_eeb048ad;
                                Object object;
                                block19: {
                                    block20: {
                                        block18: {
                                            long l = WkMeU ^ 0x6F1029A0A61EL;
                                            stringArray = Class_aj_95d0a719.oA();
                                            if (class_lC_5322e8cf == null) break block18;
                                            object = this;
                                            if (stringArray == null) break block19;
                                            if (((Class_az_a4990dcf)object).tf()) break block20;
                                        }
                                        return this.td();
                                    }
                                    object = this.ZYZql.apply(this.cKAzP);
                                }
                                if ((class_ag_rQ_eeb048ad = (Class_ag_rQ_eeb048ad)object) == null) {
                                    return this.td();
                                }
                                float f5 = this.WjISQ / 2.125f;
                                float f6 = class_ag_rQ_eeb048ad.slim() ? 0.453125f : 0.515625f;
                                Matrix4f matrix4f = Class_jI_616cf0dd.bIl((Matrix3x2fc)class_lC_5322e8cf.cfc());
                                matrix4f.translate(this.MCnYt + this.BcpIo / 2.0f, this.pNyTQ + this.WjISQ, 0.0f);
                                matrix4f.scale(f5, f5, f5);
                                matrix4f.translate(0.0f, -0.0625f, 0.0f);
                                if (stringArray != null) {
                                    if (!bl) {
                                        matrix4f.rotateAround((Quaternionfc)RotationAxis.POSITIVE_X.rotationDegrees(this.EnbkJ), 0.0f, -1.0625f, 0.0f);
                                        matrix4f.rotate((Quaternionfc)RotationAxis.POSITIVE_Y.rotationDegrees(this.Vinex));
                                    }
                                    matrix4f.scale(1.0f, 1.0f, -1.0f);
                                    matrix4f.translate(0.0f, -1.5f, 0.0f);
                                }
                                f4 = Float.POSITIVE_INFINITY;
                                f3 = Float.POSITIVE_INFINITY;
                                f2 = Float.NEGATIVE_INFINITY;
                                f = Float.NEGATIVE_INFINITY;
                                float[] fArray = new float[]{-f6, f6};
                                int n2 = fArray.length;
                                int n3 = 0;
                                block0: while (true) {
                                    int n4 = n3;
                                    block1: while (n4 < n2) {
                                        float f7 = fArray[n3];
                                        float[] fArray2 = new float[]{-0.53125f, 1.515625f};
                                        int n5 = fArray2.length;
                                        n = 0;
                                        if (stringArray == null) break block16;
                                        int n6 = n;
                                        while (n6 < n5) {
                                            block17: {
                                                float f8 = fArray2[n6];
                                                float[] fArray3 = new float[]{-0.28125f, 0.28125f};
                                                int n7 = fArray3.length;
                                                n4 = 0;
                                                if (stringArray == null) continue block1;
                                                for (int i = v104518; i < n7; ++i) {
                                                    float f9 = fArray3[i];
                                                    Vector3f vector3f = matrix4f.transformPosition(f7, f8, f9, new Vector3f());
                                                    f4 = Math.min(f4, vector3f.x);
                                                    f3 = Math.min(f3, vector3f.y);
                                                    f2 = Math.max(f2, vector3f.x);
                                                    f = Math.max(f, vector3f.y);
                                                    if (stringArray != null) {
                                                        if (stringArray != null) continue;
                                                    }
                                                    break block17;
                                                }
                                                ++n6;
                                            }
                                            if (stringArray != null) continue;
                                        }
                                        ++n3;
                                        if (stringArray != null) continue block0;
                                    }
                                    break;
                                }
                                n = Float.isFinite(f4);
                            }
                            if (stringArray == null) break block21;
                            if (n == 0) break block22;
                            n = Float.isFinite(f3);
                        }
                        if (stringArray == null) break block23;
                        if (n == 0) break block22;
                        n = Float.isFinite(f2);
                    }
                    if (stringArray == null) break block24;
                    if (n == 0) break block22;
                    n = Float.isFinite(f);
                }
                if (n != 0) break block25;
            }
            return this.td();
        }
        return new Class_lc_b8480f87(f4 - 1.0f, f3 - 1.0f, f2 - f4 + 2.0f, f - f3 + 2.0f);
    }

    public PlayerEntityModel nr() {
        return this.QSyUZ;
    }

    public Class_ag_rR_5deaebc6 ns() {
        return this.VSKnI;
    }

    public boolean nt() {
        return this.FiFgY;
    }

    private void nm(PlayerEntityModel playerEntityModel) {
        long l = WkMeU ^ 0x11EF879EB1C9L;
        if (this.VSKnI == Class_ag_rR_5deaebc6.VdGoA) {
            float f = (float)(Util.getMeasuringTimeMs() % wxrIA) / 1000.0f;
            float f2 = 0.8f;
            float f3 = f * f2 * (float)Math.PI;
            float f4 = 0.8f;
            float f5 = MathHelper.cos((double)f3) * f4;
            float f6 = MathHelper.cos((double)(f3 + (float)Math.PI)) * f4;
            float f7 = MathHelper.cos((double)(f3 + (float)Math.PI)) * f4;
            float f8 = MathHelper.cos((double)f3) * f4;
            playerEntityModel.rightArm.pitch = f5;
            playerEntityModel.rightLeg.pitch = f7;
            playerEntityModel.leftArm.pitch = f6;
            playerEntityModel.leftLeg.pitch = f8;
        }
    }

    @Override
    public void dl(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        long l = WkMeU ^ 0x4DF2EA07BB13L;
        String[] stringArray = Class_aj_95d0a719.oA();
        if (stringArray != null) {
            if (class_mA_32d8a5f2 == Class_mA_32d8a5f2.sCBUa) {
                this.FiFgY = false;
            }
            super.dl(d, d2, class_mA_32d8a5f2);
        }
    }

    public String np() {
        return this.cKAzP;
    }

    public Function<String, Class_ag_rQ_eeb048ad> nu() {
        return this.ZYZql;
    }

    private void no() {
        block5: {
            PlayerEntityModel playerEntityModel;
            block4: {
                long l = WkMeU ^ 0x1BF6F4AD0C5FL;
                String[] stringArray = Class_aj_95d0a719.oA();
                playerEntityModel = this.varoa;
                if (stringArray == null) break block4;
                if (playerEntityModel == null) break block5;
                playerEntityModel = this.QSyUZ;
            }
            if (playerEntityModel != null) {
                return;
            }
        }
        LoadedEntityModels loadedEntityModels = ClientMain.dlmvG.getLoadedEntityModels();
        this.varoa = new PlayerEntityModel(loadedEntityModels.getModelPart(EntityModelLayers.PLAYER), false);
        this.QSyUZ = new PlayerEntityModel(loadedEntityModels.getModelPart(EntityModelLayers.PLAYER_SLIM), true);
    }

    private boolean nn() {
        long l = WkMeU ^ 0x7520C011A6CFL;
        return this.VSKnI == Class_ag_rR_5deaebc6.cyZLf;
    }

    public Class_ag_8130246f nk(float f, float f2) {
        this.EnbkJ = f;
        this.Vinex = f2;
        return this;
    }

    @Override
    public boolean dk(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        boolean bl;
        block4: {
            block5: {
                boolean bl2;
                block2: {
                    block3: {
                        long l = WkMeU ^ 0x3F41F7B25E6AL;
                        String[] stringArray = Class_aj_95d0a719.oA();
                        bl2 = this.nn();
                        if (stringArray == null) break block2;
                        if (!bl2 || class_mA_32d8a5f2 != Class_mA_32d8a5f2.sCBUa) break block3;
                        bl = this.tg(d, d2);
                        if (stringArray == null) break block4;
                        if (bl) break block5;
                    }
                    bl2 = super.dk(d, d2, class_mA_32d8a5f2);
                }
                return bl2;
            }
            this.FiFgY = true;
            bl = true;
        }
        return bl;
    }

    public float nv() {
        return this.EnbkJ;
    }

    public float nw() {
        return this.Vinex;
    }

    public Class_ag_8130246f nx(String string) {
        this.cKAzP = string;
        return this;
    }

    public Class_ag_8130246f ny(PlayerEntityModel playerEntityModel) {
        this.varoa = playerEntityModel;
        return this;
    }

    public Class_ag_8130246f nz(PlayerEntityModel playerEntityModel) {
        this.QSyUZ = playerEntityModel;
        return this;
    }

    @Override
    protected void bV(Class_lC_5322e8cf class_lC_5322e8cf) {
        Class_ag_rQ_eeb048ad class_ag_rQ_eeb048ad;
        Class_ag_rQ_eeb048ad class_ag_rQ_eeb048ad2;
        block4: {
            block5: {
                block3: {
                    String[] stringArray;
                    block2: {
                        long l = WkMeU ^ 0x62D43F1B8AAEL;
                        String[] stringArray2 = Class_aj_95d0a719.oA();
                        this.no();
                        class_ag_rQ_eeb048ad2 = this.ZYZql.apply(this.cKAzP);
                        stringArray = stringArray2;
                        class_ag_rQ_eeb048ad = class_ag_rQ_eeb048ad2;
                        if (stringArray == null) break block2;
                        if (class_ag_rQ_eeb048ad == null) break block3;
                        class_ag_rQ_eeb048ad = class_ag_rQ_eeb048ad2;
                    }
                    if (stringArray == null) break block4;
                    if (class_ag_rQ_eeb048ad.skin() != null) break block5;
                }
                return;
            }
            class_ag_rQ_eeb048ad = class_ag_rQ_eeb048ad2;
        }
        PlayerEntityModel playerEntityModel = class_ag_rQ_eeb048ad.slim() ? this.QSyUZ : this.varoa;
        this.nm(playerEntityModel);
        float f = this.WjISQ / 2.125f;
        class_lC_5322e8cf.cec(playerEntityModel, class_ag_rQ_eeb048ad2.skin(), this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ).bFo(f).bFp(this.EnbkJ, this.Vinex).bFs();
    }

    @Override
    public boolean dB(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2, double d3, double d4) {
        block4: {
            boolean bl;
            block2: {
                block3: {
                    long l = WkMeU ^ 0x179154326EA7L;
                    String[] stringArray = Class_aj_95d0a719.oA();
                    bl = this.nn();
                    if (stringArray == null) break block2;
                    if (!bl) break block3;
                    bl = this.FiFgY;
                    if (stringArray == null) break block2;
                    if (bl && class_mA_32d8a5f2 == Class_mA_32d8a5f2.sCBUa) break block4;
                }
                bl = super.dB(d, d2, class_mA_32d8a5f2, d3, d4);
            }
            return bl;
        }
        this.Vinex = MathHelper.wrapDegrees((float)(this.Vinex + (float)d3 * 1.5f));
        this.EnbkJ = MathHelper.clamp((float)(this.EnbkJ + (float)d4 * 1.2f), (float)-60.0f, (float)60.0f);
        return true;
    }

    public PlayerEntityModel nq() {
        return this.varoa;
    }

    private static MatchException nF(MatchException matchException) {
        return matchException;
    }

    public Class_ag_8130246f nD(float f) {
        this.Vinex = f;
        return this;
    }

    public Class_ag_8130246f nA(boolean bl) {
        this.FiFgY = bl;
        return this;
    }

    public Class_ag_8130246f nC(float f) {
        this.EnbkJ = f;
        return this;
    }

    public Class_ag_8130246f nB(Function<String, Class_ag_rQ_eeb048ad> function) {
        this.ZYZql = function;
        return this;
    }
}

