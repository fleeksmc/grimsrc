/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Objects;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_gb_9d201141;

public final class Class_ay_c070a086 {
    public static final Object eGcjO;
    private static final Deque<Object> SeYIH;
    private static Object fuxGD;
    private static boolean ZmJyP;
    private static final long VfsuD;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        VfsuD = Class_gb_9d201141.aYR(-9049166262062814204L, -529335740970060287L, MethodHandles.lookup().lookupClass()).a(5773309340471L);
        eGcjO = new Object();
        SeYIH = new ArrayDeque<Object>();
    }

    public static void sp() {
        fuxGD = null;
        ZmJyP = false;
        SeYIH.clear();
    }

    public static Object ss() {
        block3: {
            Object object;
            block2: {
                long l = VfsuD ^ 0x414621E21B2EL;
                Object object2 = SeYIH.peek();
                String string = Class_az_a4990dcf.tE();
                object = object2;
                if (string == null) break block2;
                if (object == null) break block3;
                object = object2;
            }
            return object;
        }
        return ZmJyP ? fuxGD : eGcjO;
    }

    private static MatchException st(MatchException matchException) {
        return matchException;
    }

    public static boolean sr() {
        Object object;
        String string;
        block6: {
            boolean bl;
            block5: {
                long l = VfsuD ^ 0x583FFDC48074L;
                string = Class_az_a4990dcf.tE();
                bl = ZmJyP;
                if (string == null) break block5;
                if (bl) break block6;
                bl = true;
            }
            return bl;
        }
        Object object2 = object = SeYIH.peek();
        if (string != null) {
            if (object2 == null) {
                return fuxGD == eGcjO;
            }
            object2 = object;
        }
        return Objects.equals(object2, fuxGD);
    }

    public static void sq(Object object, Runnable runnable) {
        SeYIH.push(object);
        try {
            runnable.run();
        }
        finally {
            SeYIH.pop();
        }
    }

    public static void so(Object object) {
        long l = VfsuD ^ 0xC1F5453D8A2L;
        fuxGD = object;
        ZmJyP = object != null;
        SeYIH.clear();
    }
}

