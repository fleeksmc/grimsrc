/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.Click
 *  net.minecraft.client.gui.DrawContext
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.client.input.CharInput
 *  net.minecraft.client.input.KeyInput
 *  net.minecraft.client.option.KeyBinding
 *  net.minecraft.text.Text
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec2f
 *  org.jspecify.annotations.NonNull
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import org.jspecify.annotations.NonNull;
import recovered.core.ClientMain;
import recovered.internal.Class_ad_d4e95a2c;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_cs_f7c4d6b1;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iX_8d826c07;
import recovered.internal.Class_kk_ea401760;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_rk_bf8630d1;
import recovered.internal.Class_rm_d861be3b;
import recovered.internal.Class_rr_be159084;

public abstract class Class_av_ffcf74a1
extends Screen
implements Class_cs_f7c4d6b1 {
    protected final Class_rk_bf8630d1 Weytw;
    protected boolean VWsmm;
    private static boolean LSCIa;
    private static final long oVYdO;
    private static final long myUnc;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    protected Class_av_ffcf74a1() {
        long l = oVYdO ^ 0x1B5D73AB471DL;
        super((Text)Text.empty());
        this.Weytw = new Class_rk_bf8630d1((int)myUnc);
        this.VWsmm = true;
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        oVYdO = Class_gb_9d201141.aYR(5327485615965762991L, -6615214864910727710L, MethodHandles.lookup().lookupClass()).a(37594205416973L);
        long l = oVYdO ^ 0x7B5CA3A0E4D4L;
        Class_av_ffcf74a1.sk(false);
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                long l2 = -3729010028508391083L;
                byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
                myUnc = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    public static boolean sl() {
        return LSCIa;
    }

    protected abstract Vec2f n();

    public static boolean sm() {
        boolean bl = Class_av_ffcf74a1.sl();
        return !bl;
    }

    public abstract void m(Class_lC_5322e8cf var1);

    protected void si() {
        long l = oVYdO ^ 0x6ABD0C35883L;
        String string = Class_az_a4990dcf.tE();
        if (Class_ad_d4e95a2c.rmmkh != null || ClientMain.dme().ddY()) {
            return;
        }
        for (KeyBinding keyBinding : Class_iX_8d826c07.HpSlL) {
            keyBinding.setPressed(Class_rr_be159084.diW(keyBinding.getDefaultKey().getCode()));
            if (string != null) continue;
        }
    }

    public Class_rk_bf8630d1 sj() {
        return this.Weytw;
    }

    protected double sh() {
        double d;
        Vec2f vec2f;
        Vec2f vec2f2;
        String string;
        double d2;
        block8: {
            block9: {
                block6: {
                    float f;
                    block7: {
                        float f2;
                        Vec2f vec2f3;
                        block5: {
                            long l = oVYdO ^ 0x538F088B9D98L;
                            d2 = 2.0;
                            string = Class_az_a4990dcf.tE();
                            vec2f3 = vec2f2 = this.n();
                            if (string == null) break block5;
                            if (vec2f3 == null) break block6;
                            vec2f3 = vec2f2;
                        }
                        f = (f2 = vec2f3.x - 0.0f) == 0.0f ? 0 : (f2 < 0.0f ? -1 : 1);
                        if (string == null) break block7;
                        if (f <= 0) break block6;
                        vec2f = vec2f2;
                        if (string == null) break block8;
                        float f3 = vec2f.y - 0.0f;
                        f = f3 == 0.0f ? 0 : (f3 < 0.0f ? -1 : 1);
                    }
                    if (f > 0) break block9;
                }
                return d2;
            }
            vec2f = Class_rm_d861be3b.dip();
        }
        Vec2f vec2f4 = vec2f;
        double d3 = vec2f4.x / vec2f2.x;
        double d4 = vec2f4.y / vec2f2.y;
        double d5 = d = Math.min(d3, d4);
        if (string != null) {
            if (!Double.isFinite(d5)) {
                return d2;
            }
            d5 = MathHelper.clamp((double)d, (double)0.5, (double)d2);
        }
        return d5;
    }

    public boolean closing() {
        return this.VWsmm;
    }

    private static MatchException sn(MatchException matchException) {
        return matchException;
    }

    public float sf() {
        return 0.5f + 0.5f * this.Weytw.dhj();
    }

    public static void sk(boolean bl) {
        LSCIa = bl;
    }

    protected void sg() {
        Class_kk_ea401760.bPH();
    }

    public final boolean mouseScrolled(double d, double d2, double d3, double d4) {
        long l = oVYdO ^ 0x18471DD50F81L;
        Vec2f vec2f = Class_rm_d861be3b.dis();
        String string = Class_az_a4990dcf.tE();
        boolean bl = this.onMouseScrolled(vec2f.x, vec2f.y, d4);
        if (string != null) {
            if (bl) {
                return true;
            }
            bl = super.mouseScrolled(d, d2, d3, d4);
        }
        return bl;
    }

    public final boolean mouseReleased(Click click) {
        long l = oVYdO ^ 0x2BD621F900FBL;
        Class_mA_32d8a5f2 class_mA_32d8a5f2 = Class_mA_32d8a5f2.cmN(click.button());
        String string = Class_az_a4990dcf.tE();
        Vec2f vec2f = Class_rm_d861be3b.dis();
        boolean bl = this.onMouseReleased(vec2f.x, vec2f.y, class_mA_32d8a5f2);
        if (string != null) {
            if (bl) {
                return true;
            }
            bl = super.mouseReleased(click);
        }
        return bl;
    }

    public final boolean mouseDragged(Click click, double d, double d2) {
        long l = oVYdO ^ 0x38DC6776A938L;
        Class_mA_32d8a5f2 class_mA_32d8a5f2 = Class_mA_32d8a5f2.cmN(click.button());
        String string = Class_az_a4990dcf.tE();
        Vec2f vec2f = Class_rm_d861be3b.dis();
        boolean bl = this.onMouseDragged(vec2f.x, vec2f.y, class_mA_32d8a5f2, d, d2);
        if (string != null) {
            if (bl) {
                return true;
            }
            bl = super.mouseDragged(click, d, d2);
        }
        return bl;
    }

    public final boolean charTyped(CharInput charInput) {
        long l = oVYdO ^ 0x1D128A4B1161L;
        String string = Class_az_a4990dcf.tE();
        boolean bl = this.onCharTyped((char)charInput.comp_4793());
        if (string != null) {
            if (bl) {
                return true;
            }
            bl = super.charTyped(charInput);
        }
        return bl;
    }

    public final boolean mouseClicked(Click click, boolean bl) {
        long l = oVYdO ^ 0x1B16028A05F3L;
        Class_mA_32d8a5f2 class_mA_32d8a5f2 = Class_mA_32d8a5f2.cmN(click.button());
        Vec2f vec2f = Class_rm_d861be3b.dis();
        String string = Class_az_a4990dcf.tE();
        boolean bl2 = this.onMouseClicked(vec2f.x, vec2f.y, class_mA_32d8a5f2);
        if (string != null) {
            if (bl2) {
                return true;
            }
            bl2 = super.mouseClicked(click, bl);
        }
        return bl2;
    }

    public void renderBackground(DrawContext drawContext, int n, int n2, float f) {
        block3: {
            Class_av_ffcf74a1 class_av_ffcf74a1;
            block2: {
                long l = oVYdO ^ 0x362932BE2BA3L;
                String string = Class_az_a4990dcf.tE();
                class_av_ffcf74a1 = this;
                if (string == null) break block2;
                if (class_av_ffcf74a1.client.world != null) break block3;
                class_av_ffcf74a1 = this;
            }
            class_av_ffcf74a1.renderPanoramaBackground(drawContext, f);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public final void render(@NonNull DrawContext drawContext, int n, int n2, float f) {
        Class_rm_d861be3b.dil(this.sh());
        Vec2f vec2f = Class_rm_d861be3b.dis();
        Class_lC_5322e8cf class_lC_5322e8cf = Class_lC_5322e8cf.ccP(drawContext, vec2f.x, vec2f.y, f);
        try {
            this.m(class_lC_5322e8cf);
        }
        finally {
            class_lC_5322e8cf.ccR();
            Class_rm_d861be3b.dim();
        }
    }

    public final boolean keyPressed(KeyInput keyInput) {
        long l = oVYdO ^ 0x3B9AE85EEC96L;
        String string = Class_az_a4990dcf.tE();
        boolean bl = this.onKeyPressed(keyInput.comp_4795(), keyInput.comp_4796(), keyInput.comp_4797());
        if (string != null) {
            if (bl) {
                return true;
            }
            bl = super.keyPressed(keyInput);
        }
        return bl;
    }

    public boolean shouldPause() {
        return false;
    }
}

