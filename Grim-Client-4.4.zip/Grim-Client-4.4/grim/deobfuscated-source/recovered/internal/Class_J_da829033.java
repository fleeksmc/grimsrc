/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.ClientMain;
import recovered.core.ModuleBase;
import recovered.core.NativeLoader;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_gd_2ebaf9bc;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_J_da829033
extends Class_aj_95d0a719 {
    private final Class_ri_288534d5 WfQYT;
    private final Class_ri_288534d5 BVWWc;
    private final Class_ri_288534d5 wLrDR;
    private final Class_rk_bf8630d1 DJXfP;
    private final Class_rk_bf8630d1 ynopW;
    private final Class_rk_bf8630d1 ePBBz;
    private final ModuleBase GLrDe;
    private int nbZRc;
    private static int[] ijbRx;
    private static long oGMgf;
    private static String[] FlSmk;
    private static String[] FalZQ;
    private static Map NLFhJ;
    private static long[] sNGZe;
    private static Integer[] XsKuU;
    private static Map IgGRb;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_J_da829033(float f, float f2, float f3, ModuleBase moduleBase) {
        float f4;
        CallSite callSite;
        Class_rk_bf8630d1 class_rk_bf8630d1;
        Class_rk_bf8630d1 class_rk_bf8630d12;
        boolean bl;
        long l = oGMgf ^ 0x63F0FC237390L;
        super(f, f2, 130.0f, 75.0f);
        this.IzFhM = f3;
        this.GLrDe = moduleBase;
        int[] nArray = Class_J_da829033.gu();
        Class_ig_ca326427 class_ig_ca326427 = ClientMain.dlM().bjG();
        try {
            bl = moduleBase.baf().aZg() == Class_gd_2ebaf9bc.zlSAY;
        }
        catch (MatchException matchException) {
            throw Class_J_da829033.gv(matchException);
        }
        boolean bl2 = bl;
        Class_mG_52c8d386 class_mG_52c8d386 = class_ig_ca326427.bio().cob(0.9f);
        Class_mG_52c8d386 class_mG_52c8d3862 = class_ig_ca326427.bio().cob(0.7f);
        try {
            Class_rk_bf8630d1 class_rk_bf8630d13;
            Class_J_da829033 class_J_da829033 = this;
            class_rk_bf8630d12 = class_rk_bf8630d13;
            class_rk_bf8630d1 = class_rk_bf8630d13;
            callSite = Class_J_da829033.gC("s", (int)24601, (long)(0x68D9CCAFD93CA07DL ^ l));
            f4 = bl2 ? 1.0f : 0.0f;
        }
        catch (MatchException matchException) {
            throw Class_J_da829033.gv(matchException);
        }
        class_rk_bf8630d12((int)callSite, f4);
        class_J_da829033.ePBBz = class_rk_bf8630d1.dhs(Class_rj_b691f4f7.UPXqT);
        this.DJXfP = new Class_rk_bf8630d1((int)Class_J_da829033.gC("s", (int)14281, (long)(0x4696037C4DE477AEL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.ynopW = new Class_rk_bf8630d1((int)Class_J_da829033.gC("s", (int)26935, (long)(0x171345BA6814A951L ^ l)), 1.0f).dhs(Class_rj_b691f4f7.UPXqT);
        this.WfQYT = new Class_ri_288534d5((int)Class_J_da829033.gC("s", (int)26935, (long)(0x171345BA6814A951L ^ l)), class_ig_ca326427.bio().cob(0.5f)).dfW(Class_rj_b691f4f7.UPXqT);
        this.BVWWc = new Class_ri_288534d5((int)Class_J_da829033.gC("s", (int)26935, (long)(0x171345BA6814A951L ^ l)), bl2 ? class_mG_52c8d3862 : class_mG_52c8d386).dfW(Class_rj_b691f4f7.UPXqT);
        this.wLrDR = new Class_ri_288534d5((int)Class_J_da829033.gC("s", (int)26935, (long)(0x171345BA6814A951L ^ l)), bl2 ? class_mG_52c8d386 : class_mG_52c8d3862).dfW(Class_rj_b691f4f7.UPXqT);
        this.FHbTC = true;
        if (nArray != null) {
            Class_iS_888f260e.bwK("DeBmPb");
        }
    }

    static {
        NativeLoader.doInit(Class_J_da829033.class);
        Class_J_da829033._1a6f26e3e4126fbd19826f02aaf7c123();
    }

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    public native Class_ri_288534d5 gk();

    public native ModuleBase gp();

    public native Class_rk_bf8630d1 gm();

    public native Class_rk_bf8630d1 gn();

    public static native void gt(int[] var0);

    public native Class_rk_bf8630d1 go();

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    public static native int[] gu();

    public native Class_ri_288534d5 gl();

    private native /* synthetic */ void gs(Class_lC_5322e8cf var1);

    private static native void _1a6f26e3e4126fbd19826f02aaf7c123();

    private static native CallSite gC(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native MatchException gv(MatchException var0);

    public native Class_ri_288534d5 gj();

    public native Class_J_da829033 gr(int var1);

    public native int gq();

    private static native String gx(int var0, long var1);

    private static native Object gy(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native int gB(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite gz(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native String gw(byte[] var0);

    private static native int gA(int var0, long var1);
}

