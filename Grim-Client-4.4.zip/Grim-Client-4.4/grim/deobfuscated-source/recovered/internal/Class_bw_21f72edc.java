/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_P_2c9819bb;
import recovered.internal.Class_ah_02444db4;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bu_edcf85ea;
import recovered.internal.Class_bx_b2c78987;
import recovered.internal.Class_cy_687dcdb6;
import recovered.internal.Class_iy_c88c0f4f;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;

public class Class_bw_21f72edc
extends Class_az_a4990dcf {
    private static float aFUAn = 6.0f;
    private static float Dpaff = 8.0f;
    private final Class_ah_02444db4 tzVyn = new Class_ah_02444db4();
    private final List<Class_bu_edcf85ea> cQweT = new ArrayList<Class_bu_edcf85ea>();
    private final List<Class_bu_edcf85ea> OcAmG = new ArrayList<Class_bu_edcf85ea>();
    private final Class_bx_b2c78987 oafWa = new Class_bx_b2c78987();
    private static int[] eUuos;
    private static long lnHem;
    private static String[] LVKwu;
    private static String[] PssjK;
    private static Map NDFGv;
    private static long[] rcGrP;
    private static Integer[] boUwc;
    private static Map qNkli;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native void _15a8b9f15c75f28d339e1fbf3b5dddb1();

    private static native int IP(int var0, long var1);

    static {
        NativeLoader.doInit(Class_bw_21f72edc.class);
        Class_bw_21f72edc._15a8b9f15c75f28d339e1fbf3b5dddb1();
    }

    private native Class_P_2c9819bb ID(Class_aj_95d0a719 var1);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean fC(double var1, double var3, double var5);

    public static native void II(int[] var0);

    private native /* synthetic */ void IE(Class_P_2c9819bb var1);

    private static native Object IN(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native float Iu(float var1, float var2);

    private native void IA(Class_aj_95d0a719 var1);

    private native Class_bu_edcf85ea Iz(String var1);

    private native /* synthetic */ void IF(Class_P_2c9819bb var1);

    private static native /* synthetic */ void IH(Class_aj_95d0a719 var0, Boolean var1);

    private native void Iw(List<Class_iy_c88c0f4f> var1);

    private static native /* synthetic */ void IG(Class_cy_687dcdb6 var0, Class_aj_95d0a719 var1);

    private static native String IL(byte[] var0);

    private native void Ix(float var1, float var2);

    private static native MatchException IK(MatchException var0);

    private static native int IQ(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite IR(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native String Iy(Class_iy_c88c0f4f var1);

    private native Class_P_2c9819bb IC(Class_aj_95d0a719 var1);

    public static native int[] IJ();

    private static native String IM(int var0, long var1);

    private static native CallSite IO(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native void IB(Class_aj_95d0a719 var1);

    private native float Iv(int var1);

    private native float It(float var1);
}

