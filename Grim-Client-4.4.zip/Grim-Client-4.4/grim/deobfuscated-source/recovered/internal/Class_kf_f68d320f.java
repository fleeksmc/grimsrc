/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;

public final class Class_kf_f68d320f
extends Enum<Class_kf_f68d320f> {
    public static final /* enum */ Class_kf_f68d320f viqyh;
    public static final /* enum */ Class_kf_f68d320f nvgmg;
    private final int vsKnl;
    private static final /* synthetic */ Class_kf_f68d320f[] jjfJk;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_kf_f68d320f(int n2) {
        this.vsKnl = n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = Class_gb_9d201141.aYR(-8085889407779633277L, -8427837932458597743L, MethodHandles.lookup().lookupClass()).a(79293739322069L) ^ 0x25C298E76827L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[2];
        int n = 0;
        String string = "\u0096\u00ffHbx~\u008d\u0010\b\u0088\u00f5\u00f1\u00e6\u00af\u00d4\u0089,";
        int n2 = "\u0096\u00ffHbx~\u008d\u0010\b\u0088\u00f5\u00f1\u00e6\u00af\u00d4\u0089,".length();
        int n3 = 8;
        int n4 = -1;
        while (true) {
            int n5 = ++n4;
            byte[] byArray3 = cipher.doFinal(string.substring(n5, n5 + n3).getBytes("ISO-8859-1"));
            stringArray[n++] = Class_kf_f68d320f.bOt(byArray3).intern();
            if ((n4 += n3) >= n2) {
                viqyh = new Class_kf_f68d320f(0);
                nvgmg = new Class_kf_f68d320f(1);
                jjfJk = Class_kf_f68d320f.bOs();
                return;
            }
            n3 = string.charAt(n4);
        }
    }

    public static Class_kf_f68d320f[] values() {
        return (Class_kf_f68d320f[])jjfJk.clone();
    }

    public static Class_kf_f68d320f valueOf(String string) {
        return Enum.valueOf(Class_kf_f68d320f.class, string);
    }

    private static String bOt(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static /* synthetic */ Class_kf_f68d320f[] bOs() {
        return new Class_kf_f68d320f[]{viqyh, nvgmg};
    }

    public int bOr() {
        return this.vsKnl;
    }
}

