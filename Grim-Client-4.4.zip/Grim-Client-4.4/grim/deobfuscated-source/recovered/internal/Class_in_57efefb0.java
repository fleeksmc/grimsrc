/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package recovered.internal;

import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_im_0fce3469;
import recovered.internal.Class_io_666f07e0;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.internal.Class_rp_2e61368f;

public class Class_in_57efefb0
implements Class_rp_2e61368f {
    public static Class_in_57efefb0 FBjZE;
    public static Class_in_57efefb0 mYAkW;
    public static Class_in_57efefb0 eiOnG;
    public static Class_in_57efefb0 lTmAi;
    private int[] yxFSl;
    private Class_io_666f07e0 wPkDg;
    private Class_io_666f07e0 WJgNc;
    private boolean IaqFE;
    private float opmrX;
    private Class_im_0fce3469 mIkOu;
    private Class_im_0fce3469 BnBip;
    private boolean hAyen;
    private boolean IoFoI;
    private boolean UDYLZ;
    private transient Class_rk_bf8630d1 Tfucw;
    private transient Class_rk_bf8630d1 kcGmI;
    private static long NPqyE;
    private static String[] VSQwQ;
    private static String[] QYWHV;
    private static Map hrszQ;
    private static long[] XfKFD;
    private static Integer[] gILVB;
    private static Map dvIBQ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_in_57efefb0() {
        long l = NPqyE ^ 0x23121100217L;
        this.Tfucw = new Class_rk_bf8630d1((int)Class_in_57efefb0.blv("b", (int)15138, (long)(0x386B241884D361E3L ^ l))).dhs(Class_rj_b691f4f7.ceYgU);
        this.kcGmI = new Class_rk_bf8630d1((int)Class_in_57efefb0.blv("b", (int)13138, (long)(0x2371717F4E1BE995L ^ l))).dhs(Class_rj_b691f4f7.ceYgU);
    }

    public Class_in_57efefb0(int[] nArray, Class_io_666f07e0 class_io_666f07e0, Class_io_666f07e0 class_io_666f07e02, boolean bl, float f, boolean bl2, boolean bl3, boolean bl4, Class_im_0fce3469 class_im_0fce3469, Class_im_0fce3469 class_im_0fce34692) {
        long l = NPqyE ^ 0x25640CB2CD75L;
        this.Tfucw = new Class_rk_bf8630d1((int)Class_in_57efefb0.blv("b", (int)13138, (long)(0x2371562A63B926F7L ^ l))).dhs(Class_rj_b691f4f7.ceYgU);
        this.kcGmI = new Class_rk_bf8630d1((int)Class_in_57efefb0.blv("b", (int)13138, (long)(0x2371562A63B926F7L ^ l))).dhs(Class_rj_b691f4f7.ceYgU);
        this.yxFSl = nArray;
        this.wPkDg = class_io_666f07e0;
        this.WJgNc = class_io_666f07e02;
        this.IaqFE = bl;
        this.opmrX = f;
        this.hAyen = bl2;
        this.IoFoI = bl3;
        this.UDYLZ = bl4;
        this.mIkOu = class_im_0fce3469;
        this.BnBip = class_im_0fce34692;
    }

    static {
        NativeLoader.doInit(Class_in_57efefb0.class);
        Class_in_57efefb0._5a7af36d39efe4659f5189a76e605002();
    }

    public native Class_in_57efefb0 blk(boolean var1);

    public native Class_in_57efefb0 blg(float var1);

    @Override
    public native void fromJson(JsonObject var1);

    @Override
    public native JsonObject toJson();

    public native Class_in_57efefb0 ble(Class_io_666f07e0 var1);

    private static native CallSite blv(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native Class_in_57efefb0 blc(int[] var1);

    public native Class_in_57efefb0 blf(boolean var1);

    public native Class_in_57efefb0 blh(Class_im_0fce3469 var1);

    public native Class_in_57efefb0 blj(boolean var1);

    public native Class_im_0fce3469 bkV();

    public native Class_io_666f07e0 bkR();

    public native Class_rk_bf8630d1 bla();

    public native Class_rk_bf8630d1 blb();

    public native Class_in_57efefb0 bld(Class_io_666f07e0 var1);

    public native boolean bkP();

    public native Class_in_57efefb0 bll(boolean var1);

    public native Class_in_57efefb0 bli(Class_im_0fce3469 var1);

    public native Class_in_57efefb0 blm(Class_rk_bf8630d1 var1);

    public native Class_in_57efefb0 bln(Class_rk_bf8630d1 var1);

    private static native String blp(byte[] var0);

    public native boolean bkT();

    public native float bkU();

    public native Class_im_0fce3469 bkW();

    private static native MatchException blo(MatchException var0);

    public native int[] bkQ();

    public native String bkO();

    public native Class_io_666f07e0 bkS();

    private static native Object blr(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite bls(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native String blq(int var0, long var1);

    private static native int blt(int var0, long var1);

    private static native int blu(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native void _5a7af36d39efe4659f5189a76e605002();

    public native boolean bkZ();

    public native boolean bkX();

    public native boolean bkY();
}

