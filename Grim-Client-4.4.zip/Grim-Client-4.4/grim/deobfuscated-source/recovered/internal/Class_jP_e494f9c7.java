/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.joml.Matrix3x2fStack
 */
package recovered.internal;

import org.joml.Matrix3x2fStack;
import recovered.internal.Class_jP_ua_1336673e;
import recovered.internal.Class_kd_dfbdd90e;
import recovered.internal.Class_kf_f68d320f;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mG_52c8d386;

public class Class_jP_e494f9c7 {
    private Matrix3x2fStack XqlAR;
    private float FPYAo;
    private float anlpu;
    private float GMmvL;
    private float iBvaP;
    private Class_kd_dfbdd90e gnhtH;
    private Class_kf_f68d320f AImrl;
    private Class_ld_bb1690e1 oiyqt;
    private Class_mG_52c8d386 EPsyp;
    private float qnbRC;
    private float vCTLg;
    private float qRWYm;
    private float acdta;
    private float kjnua;
    private float akiaT;
    private float SHDZT;
    private boolean GVlRD;
    private float FQvSn;
    private float YKIxI;
    private float XHRTH;
    private float ywQIU;
    private float Bsobg;
    private float DqfKy;
    private float YJWRY;
    private float QSfKx;
    private Class_mG_52c8d386 bGoWz;
    private Class_mG_52c8d386 XjXfC;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_jP_e494f9c7(Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3, float f4, Class_kd_dfbdd90e class_kd_dfbdd90e, Class_kf_f68d320f class_kf_f68d320f, Class_ld_bb1690e1 class_ld_bb1690e1, Class_mG_52c8d386 class_mG_52c8d386, float f5, float f6, float f7, float f8, float f9, float f10, float f11, boolean bl, float f12, float f13, float f14, float f15, float f16, float f17, float f18, float f19, Class_mG_52c8d386 class_mG_52c8d3862, Class_mG_52c8d386 class_mG_52c8d3863) {
        this.XqlAR = matrix3x2fStack;
        this.FPYAo = f;
        this.anlpu = f2;
        this.GMmvL = f3;
        this.iBvaP = f4;
        this.gnhtH = class_kd_dfbdd90e;
        this.AImrl = class_kf_f68d320f;
        this.oiyqt = class_ld_bb1690e1;
        this.EPsyp = class_mG_52c8d386;
        this.qnbRC = f5;
        this.vCTLg = f6;
        this.qRWYm = f7;
        this.acdta = f8;
        this.kjnua = f9;
        this.akiaT = f10;
        this.SHDZT = f11;
        this.GVlRD = bl;
        this.FQvSn = f12;
        this.YKIxI = f13;
        this.XHRTH = f14;
        this.ywQIU = f15;
        this.Bsobg = f16;
        this.DqfKy = f17;
        this.YJWRY = f18;
        this.QSfKx = f19;
        this.bGoWz = class_mG_52c8d3862;
        this.XjXfC = class_mG_52c8d3863;
    }

    public float bLr() {
        return this.XHRTH;
    }

    public float bLu() {
        return this.DqfKy;
    }

    public float bLv() {
        return this.YJWRY;
    }

    public Class_mG_52c8d386 bLy() {
        return this.XjXfC;
    }

    public float bLs() {
        return this.ywQIU;
    }

    public Class_mG_52c8d386 bLx() {
        return this.bGoWz;
    }

    public Class_ld_bb1690e1 bLf() {
        return this.oiyqt;
    }

    public float bLj() {
        return this.qRWYm;
    }

    public float bLt() {
        return this.Bsobg;
    }

    public float bKZ() {
        return this.FPYAo;
    }

    public float bLc() {
        return this.iBvaP;
    }

    public float bLw() {
        return this.QSfKx;
    }

    public Class_kd_dfbdd90e bLd() {
        return this.gnhtH;
    }

    public Matrix3x2fStack bKY() {
        return this.XqlAR;
    }

    public Class_mG_52c8d386 bLg() {
        return this.EPsyp;
    }

    public float bLa() {
        return this.anlpu;
    }

    public float bLb() {
        return this.GMmvL;
    }

    public float bLq() {
        return this.YKIxI;
    }

    public float bLk() {
        return this.acdta;
    }

    public float bLn() {
        return this.SHDZT;
    }

    public float bLh() {
        return this.qnbRC;
    }

    public float bLi() {
        return this.vCTLg;
    }

    public Class_kf_f68d320f bLe() {
        return this.AImrl;
    }

    public boolean bLo() {
        return this.GVlRD;
    }

    public float bLl() {
        return this.kjnua;
    }

    public float bLm() {
        return this.akiaT;
    }

    private static Class_kd_dfbdd90e bKB() {
        return Class_kd_dfbdd90e.AhlXN;
    }

    private static float bKN() {
        return 0.0f;
    }

    private static float bKO() {
        return 100.0f;
    }

    private static Class_kf_f68d320f bKC() {
        return Class_kf_f68d320f.viqyh;
    }

    public static Class_jP_ua_1336673e bKX() {
        return new Class_jP_ua_1336673e();
    }

    private static Class_mG_52c8d386 bKE() {
        return Class_mG_52c8d386.hoGuU;
    }

    private static float bKI() {
        return 0.0f;
    }

    private static float bKJ() {
        return 0.0f;
    }

    private static float bKK() {
        return 0.0f;
    }

    private static float bKF() {
        return 0.75f;
    }

    private static Class_ld_bb1690e1 bKD() {
        return Class_ld_bb1690e1.NONE;
    }

    private static float bKG() {
        return 1.0f;
    }

    private static float bKH() {
        return 7.0f;
    }

    private static float bKL() {
        return (float)Math.PI * 2;
    }

    private static boolean bKM() {
        return false;
    }

    private static float bKP() {
        return 100.0f;
    }

    private static float bKR() {
        return 0.0f;
    }

    private static float bKT() {
        return -45.0f;
    }

    private static float bKU() {
        return 1.5f;
    }

    public float bLp() {
        return this.FQvSn;
    }

    private static Class_mG_52c8d386 bKV() {
        return Class_mG_52c8d386.hoGuU;
    }

    private static float bKS() {
        return 80.0f;
    }

    private static float bKQ() {
        return 100.0f;
    }

    private static Class_mG_52c8d386 bKW() {
        return Class_mG_52c8d386.UhgnI;
    }

    public static Class_jP_ua_1336673e bKA(Matrix3x2fStack matrix3x2fStack, double d, double d2, double d3, double d4) {
        return Class_jP_e494f9c7.bKX().dqF(matrix3x2fStack).dqG((float)d).dqH((float)d2).dqI((float)d3).dqJ((float)d4);
    }
}

