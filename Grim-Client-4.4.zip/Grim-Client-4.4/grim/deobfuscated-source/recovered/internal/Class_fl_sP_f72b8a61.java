/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.Hand
 */
package recovered.internal;

import net.minecraft.util.Hand;
import recovered.core.NativeLoader;

final class Class_fl_sP_f72b8a61
extends Record {
    private final int hotbarSlot;
    private final Hand hand;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_fl_sP_f72b8a61(int n, Hand hand) {
        this.hotbarSlot = n;
        this.hand = hand;
    }

    static {
        NativeLoader.doInit(Class_fl_sP_f72b8a61.class);
    }

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    public native int hotbarSlot();

    public native Hand hand();
}

