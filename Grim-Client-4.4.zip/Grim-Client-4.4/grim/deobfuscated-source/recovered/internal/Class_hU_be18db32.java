/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item
 *  net.minecraft.util.Hand
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import net.minecraft.item.Item;
import net.minecraft.util.Hand;
import recovered.core.NativeLoader;
import recovered.internal.Class_hK_37a4c9e8;
import recovered.internal.Class_hL_db8a30f6;
import recovered.internal.Class_hX_15329af5;
import recovered.internal.Class_hZ_076851ce;
import recovered.internal.Class_iS_888f260e;
import recovered.modules.FakePlayerModule;

public class Class_hU_be18db32 {
    private static Class_iS_888f260e[] NriVM;
    private static long GTcDz;
    private static String[] uFMkg;
    private static String[] NKWRI;
    private static Map jCjYb;
    private static long[] UtYAl;
    private static Integer[] lVWdM;
    private static Map nIIHT;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_hU_be18db32.class);
        Class_hU_be18db32._86a15a3fd310d322b9a693370e419569();
    }

    private native Class_hK_37a4c9e8 bfy();

    private native Class_hZ_076851ce bft();

    private native boolean bfu();

    private native Item bfw(String var1);

    private native Class_hZ_076851ce bfq();

    private native Class_hZ_076851ce bfr();

    private native Class_hZ_076851ce bfs();

    private native /* synthetic */ void bfB(Class_hX_15329af5 var1);

    private static native /* synthetic */ void bfC(Class_hL_db8a30f6 var0);

    private native /* synthetic */ void bfE(Class_hX_15329af5 var1);

    private native String bfx(Hand var1);

    public native Class_hZ_076851ce bfo();

    private native FakePlayerModule bfv();

    private native Class_hK_37a4c9e8 bfz();

    private native /* synthetic */ void bfA(Class_hX_15329af5 var1);

    private static native /* synthetic */ void bfD(Class_hL_db8a30f6 var0);

    private native /* synthetic */ void bfG(Class_hL_db8a30f6 var1);

    private native Class_hZ_076851ce bfp();

    private native /* synthetic */ void bfH(Class_hL_db8a30f6 var1);

    private native /* synthetic */ void bfI(Class_hX_15329af5 var1);

    private native /* synthetic */ void bfJ(Class_hX_15329af5 var1);

    public static native void bfK(Class_iS_888f260e[] var0);

    public static native Class_iS_888f260e[] bfL();

    private static native MatchException bfM(MatchException var0);

    private static native String bfN(byte[] var0);

    private static native /* synthetic */ void bfF(Class_hL_db8a30f6 var0);

    private static native String bfO(int var0, long var1);

    private static native int bfS(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native int bfR(int var0, long var1);

    private static native CallSite bfT(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native CallSite bfQ(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native Object bfP(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native void _86a15a3fd310d322b9a693370e419569();
}

