/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screen.ChatScreen
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.screen.ChatScreen;
import recovered.core.ClientMain;
import recovered.core.ModuleBase;
import recovered.internal.Class_cG_6e1ba021;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_ca_75c833b3;
import recovered.internal.Class_co_c10d0572;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_gc_4c0dfe20;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jb_fa6e084e;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_ce_48116553
extends Class_co_c10d0572 {
    private final Class_cJ_2ae1a557 cHqOw;
    private final Class_cJ_2ae1a557 UIgzX;
    private final Class_cG_6e1ba021 QyAzy;
    private final Class_cG_6e1ba021 sFKNs;
    private int WViuF;
    private static final long AjBQU;
    private static final long[] DHEMI;
    private static final Integer[] sMfLg;
    private static final Map QuPpy;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ce_48116553() {
        long l = AjBQU ^ 0xACFAB920C52L;
        int[] nArray = new int[Class_ce_48116553.PW("m", (int)11243, (long)(0x1DEB022E05DF385FL ^ l))];
        nArray[0] = (int)Class_ce_48116553.PW("m", (int)17516, (long)(0x21327B8EA95157F4L ^ l));
        nArray[1] = (int)Class_ce_48116553.PW("m", (int)7431, (long)(0x58DD44FC8BEC0EB0L ^ l));
        nArray[2] = (int)Class_ce_48116553.PW("m", (int)4271, (long)(0xCAD3CD3A864032FL ^ l));
        nArray[3] = (int)Class_ce_48116553.PW("m", (int)25851, (long)(0x71D9FA01EE687765L ^ l));
        nArray[4] = (int)Class_ce_48116553.PW("m", (int)627, (long)(0x2EF47998245C11FEL ^ l));
        nArray[5] = (int)Class_ce_48116553.PW("m", (int)30720, (long)(0x2818A5947C546B95L ^ l));
        nArray[Class_ce_48116553.PW("m", (int)18567, (long)(0x5C3D9CFDD7F45B16L ^ l))] = (int)Class_ce_48116553.PW("m", (int)18918, (long)(0x1FEE4218D838DA4BL ^ l));
        nArray[Class_ce_48116553.PW("m", (int)17214, (long)(0x1C4423E0D6FF5086L ^ l))] = (int)Class_ce_48116553.PW("m", (int)8328, (long)(0x7D7DFAD362483303L ^ l));
        super(nArray, Class_lf_d247d983.wmWhC);
        int[] nArray2 = new int[Class_ce_48116553.PW("m", (int)9694, (long)(0x41E607123E0B65CL ^ l))];
        nArray2[0] = (int)Class_ce_48116553.PW("m", (int)9043, (long)(0x18F4B354C6C7B0FFL ^ l));
        nArray2[1] = (int)Class_ce_48116553.PW("m", (int)23728, (long)(0x762E9E53CF914F0EL ^ l));
        nArray2[2] = (int)Class_ce_48116553.PW("m", (int)6958, (long)(0x3D2B12608ECF88B2L ^ l));
        nArray2[3] = (int)Class_ce_48116553.PW("m", (int)7393, (long)(0x5A6425DC2FF08F7EL ^ l));
        nArray2[4] = (int)Class_ce_48116553.PW("m", (int)20252, (long)(0x61EEFF1322B9DCB7L ^ l));
        nArray2[5] = (int)Class_ce_48116553.PW("m", (int)2944, (long)(0x2D534F32DFAB9814L ^ l));
        nArray2[Class_ce_48116553.PW("m", (int)175, (long)(0x789EAD272C1931EL ^ l))] = (int)Class_ce_48116553.PW("m", (int)5349, (long)(0x5FD15C96D0408756L ^ l));
        nArray2[Class_ce_48116553.PW("m", (int)28382, (long)(0x1D73F7434BB6FD4EL ^ l))] = (int)Class_ce_48116553.PW("m", (int)19660, (long)(0x2914CF785CBBDF71L ^ l));
        nArray2[Class_ce_48116553.PW("m", (int)20303, (long)(0x3EC512EBA3225CF0L ^ l))] = (int)Class_ce_48116553.PW("m", (int)4786, (long)(0x212C94ED6E5F013BL ^ l));
        nArray2[Class_ce_48116553.PW("m", (int)19074, (long)(0x727C6F84F2A2D914L ^ l))] = (int)Class_ce_48116553.PW("m", (int)24823, (long)(0x2870C3DC93E8F345L ^ l));
        nArray2[Class_ce_48116553.PW("m", (int)5175, (long)(0x7DC71E26DA3807BFL ^ l))] = (int)Class_ce_48116553.PW("m", (int)24193, (long)(0x2C55B0A92B13CD0BL ^ l));
        this.cHqOw = new Class_cJ_2ae1a557(this, Class_mr_7eac5189.clS(nArray2)).WE(true);
        int[] nArray3 = new int[Class_ce_48116553.PW("m", (int)16782, (long)(0x524778B14D9B520DL ^ l))];
        nArray3[0] = (int)Class_ce_48116553.PW("m", (int)9865, (long)(0x3F1E0C96B70E3533L ^ l));
        nArray3[1] = (int)Class_ce_48116553.PW("m", (int)7393, (long)(0x5A6425DC2FF08F7EL ^ l));
        nArray3[2] = (int)Class_ce_48116553.PW("m", (int)23728, (long)(0x762E9E53CF914F0EL ^ l));
        nArray3[3] = (int)Class_ce_48116553.PW("m", (int)24783, (long)(0x28A7C77E02E8F35DL ^ l));
        nArray3[4] = (int)Class_ce_48116553.PW("m", (int)30245, (long)(0x4DE460B96E4CE5AAL ^ l));
        nArray3[5] = (int)Class_ce_48116553.PW("m", (int)4786, (long)(0x212C94ED6E5F013BL ^ l));
        nArray3[Class_ce_48116553.PW("m", (int)175, (long)(0x789EAD272C1931EL ^ l))] = (int)Class_ce_48116553.PW("m", (int)25977, (long)(0x1022F01DABF576EEL ^ l));
        nArray3[Class_ce_48116553.PW("m", (int)28382, (long)(0x1D73F7434BB6FD4EL ^ l))] = (int)Class_ce_48116553.PW("m", (int)2149, (long)(0x5BA8F5C35F179BD0L ^ l));
        nArray3[Class_ce_48116553.PW("m", (int)20303, (long)(0x3EC512EBA3225CF0L ^ l))] = (int)Class_ce_48116553.PW("m", (int)13598, (long)(0x67ECA88A2B9BA6AEL ^ l));
        nArray3[Class_ce_48116553.PW("m", (int)27485, (long)(0x5158CC61E18B78C7L ^ l))] = (int)Class_ce_48116553.PW("m", (int)3163, (long)(0x13A2C214E0771FEDL ^ l));
        nArray3[Class_ce_48116553.PW("m", (int)16216, (long)(0x716480A89ECB2CE1L ^ l))] = (int)Class_ce_48116553.PW("m", (int)14470, (long)(0x408A0F78DDC62B00L ^ l));
        nArray3[Class_ce_48116553.PW("m", (int)12233, (long)(0x7294A956F0983C75L ^ l))] = (int)Class_ce_48116553.PW("m", (int)13848, (long)(0x1D46E8D4C87CA58BL ^ l));
        nArray3[Class_ce_48116553.PW("m", (int)10325, (long)(0x6C4511681154BBD2L ^ l))] = (int)Class_ce_48116553.PW("m", (int)25787, (long)(0x768E2D8C9D91F720L ^ l));
        this.UIgzX = new Class_cJ_2ae1a557(this, Class_mr_7eac5189.clS(nArray3)).WE(true);
        int[] nArray4 = new int[Class_ce_48116553.PW("m", (int)14981, (long)(0x2B273042A87DA901L ^ l))];
        nArray4[0] = (int)Class_ce_48116553.PW("m", (int)5100, (long)(0x422F43D52599806DL ^ l));
        nArray4[1] = (int)Class_ce_48116553.PW("m", (int)23728, (long)(0x762E9E53CF914F0EL ^ l));
        nArray4[2] = (int)Class_ce_48116553.PW("m", (int)17196, (long)(0x4E40E7F7AD625083L ^ l));
        nArray4[3] = (int)Class_ce_48116553.PW("m", (int)25690, (long)(0x27B1070788EB77C3L ^ l));
        nArray4[4] = (int)Class_ce_48116553.PW("m", (int)14470, (long)(0x408A0F78DDC62B00L ^ l));
        nArray4[5] = (int)Class_ce_48116553.PW("m", (int)24193, (long)(0x2C55B0A92B13CD0BL ^ l));
        nArray4[Class_ce_48116553.PW("m", (int)175, (long)(0x789EAD272C1931EL ^ l))] = (int)Class_ce_48116553.PW("m", (int)16247, (long)(0x67EC6D87632ACDDL ^ l));
        nArray4[Class_ce_48116553.PW("m", (int)28382, (long)(0x1D73F7434BB6FD4EL ^ l))] = (int)Class_ce_48116553.PW("m", (int)2149, (long)(0x5BA8F5C35F179BD0L ^ l));
        nArray4[Class_ce_48116553.PW("m", (int)20303, (long)(0x3EC512EBA3225CF0L ^ l))] = (int)Class_ce_48116553.PW("m", (int)7309, (long)(0x5F7EB36614470F08L ^ l));
        nArray4[Class_ce_48116553.PW("m", (int)27485, (long)(0x5158CC61E18B78C7L ^ l))] = (int)Class_ce_48116553.PW("m", (int)13848, (long)(0x1D46E8D4C87CA58BL ^ l));
        nArray4[Class_ce_48116553.PW("m", (int)16216, (long)(0x716480A89ECB2CE1L ^ l))] = (int)Class_ce_48116553.PW("m", (int)14470, (long)(0x408A0F78DDC62B00L ^ l));
        nArray4[Class_ce_48116553.PW("m", (int)12233, (long)(0x7294A956F0983C75L ^ l))] = (int)Class_ce_48116553.PW("m", (int)13848, (long)(0x1D46E8D4C87CA58BL ^ l));
        nArray4[Class_ce_48116553.PW("m", (int)31349, (long)(0xA0F431740EB69F9L ^ l))] = (int)Class_ce_48116553.PW("m", (int)18033, (long)(0x3CEC5E994945D5ECL ^ l));
        this.QyAzy = new Class_cG_6e1ba021(this, Class_mr_7eac5189.clS(nArray4)).Uf(Class_jk_a0800133.jEkxo);
        int[] nArray5 = new int[Class_ce_48116553.PW("m", (int)17579, (long)(0x1975C6967D105725L ^ l))];
        nArray5[0] = (int)Class_ce_48116553.PW("m", (int)8256, (long)(0x630CA0DF3ABBB3FBL ^ l));
        nArray5[1] = (int)Class_ce_48116553.PW("m", (int)4786, (long)(0x212C94ED6E5F013BL ^ l));
        nArray5[2] = (int)Class_ce_48116553.PW("m", (int)26523, (long)(0x6D32C452D48FF435L ^ l));
        nArray5[3] = (int)Class_ce_48116553.PW("m", (int)17196, (long)(0x4E40E7F7AD625083L ^ l));
        nArray5[4] = (int)Class_ce_48116553.PW("m", (int)25690, (long)(0x27B1070788EB77C3L ^ l));
        nArray5[5] = (int)Class_ce_48116553.PW("m", (int)14470, (long)(0x408A0F78DDC62B00L ^ l));
        nArray5[Class_ce_48116553.PW("m", (int)175, (long)(0x789EAD272C1931EL ^ l))] = (int)Class_ce_48116553.PW("m", (int)24193, (long)(0x2C55B0A92B13CD0BL ^ l));
        nArray5[Class_ce_48116553.PW("m", (int)28382, (long)(0x1D73F7434BB6FD4EL ^ l))] = (int)Class_ce_48116553.PW("m", (int)16247, (long)(0x67EC6D87632ACDDL ^ l));
        nArray5[Class_ce_48116553.PW("m", (int)20303, (long)(0x3EC512EBA3225CF0L ^ l))] = (int)Class_ce_48116553.PW("m", (int)2149, (long)(0x5BA8F5C35F179BD0L ^ l));
        nArray5[Class_ce_48116553.PW("m", (int)27485, (long)(0x5158CC61E18B78C7L ^ l))] = (int)Class_ce_48116553.PW("m", (int)7309, (long)(0x5F7EB36614470F08L ^ l));
        nArray5[Class_ce_48116553.PW("m", (int)16216, (long)(0x716480A89ECB2CE1L ^ l))] = (int)Class_ce_48116553.PW("m", (int)13848, (long)(0x1D46E8D4C87CA58BL ^ l));
        nArray5[Class_ce_48116553.PW("m", (int)12233, (long)(0x7294A956F0983C75L ^ l))] = (int)Class_ce_48116553.PW("m", (int)14470, (long)(0x408A0F78DDC62B00L ^ l));
        nArray5[Class_ce_48116553.PW("m", (int)31349, (long)(0xA0F431740EB69F9L ^ l))] = (int)Class_ce_48116553.PW("m", (int)13848, (long)(0x1D46E8D4C87CA58BL ^ l));
        nArray5[Class_ce_48116553.PW("m", (int)14981, (long)(0x2B273042A87DA901L ^ l))] = (int)Class_ce_48116553.PW("m", (int)18033, (long)(0x3CEC5E994945D5ECL ^ l));
        this.sFKNs = new Class_cG_6e1ba021(this, Class_mr_7eac5189.clS(nArray5)).Uf(Class_jk_a0800133.mPXGi);
        this.UIgzX.Vf(() -> {
            long l = AjBQU ^ 0x2562D0DF5C42L;
            boolean bl = Class_ca_75c833b3.OY();
            boolean bl2 = this.cHqOw.WF();
            if (bl) {
                bl2 = !bl2;
            }
            return bl2;
        });
        this.QyAzy.Vf(() -> {
            boolean bl;
            block5: {
                boolean bl2;
                block4: {
                    long l = AjBQU ^ 0x67458BBB3CB9L;
                    bl2 = Class_ca_75c833b3.OY();
                    bl = this.UIgzX.WF();
                    if (!bl2) break block4;
                    if (!bl) break block5;
                    bl = this.cHqOw.WF();
                }
                if (!bl2) return bl;
                if (!bl) {
                    bl = true;
                    return bl;
                }
            }
            bl = false;
            return bl;
        });
        this.sFKNs.Vf(() -> {
            boolean bl;
            block5: {
                boolean bl2;
                block4: {
                    long l = AjBQU ^ 0x24D1FF285177L;
                    bl2 = Class_ca_75c833b3.OY();
                    bl = this.UIgzX.WF();
                    if (!bl2) break block4;
                    if (!bl) break block5;
                    bl = this.cHqOw.WF();
                }
                if (!bl2) return bl;
                if (!bl) {
                    bl = true;
                    return bl;
                }
            }
            bl = false;
            return bl;
        });
    }

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_ce_48116553.AjBQU = Class_gb_9d201141.aYR(7143941292212095405L, 356946915132009460L, MethodHandles.lookup().lookupClass()).a(198176423092325L);
                Class_ce_48116553.QuPpy = new HashMap<K, V>(13);
                var0 = Class_ce_48116553.AjBQU ^ 111885727475900L;
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[54];
                var5_4 = 0;
                var6_5 = ">\u00ee\u00d2\u00f9R\u00fd\u00c8\f\u001f\u00f5+\bR\u00e0\u00fc\u00f5A\u00a3\u00c4\u001f\u00a4-\u00b2:\u00f3!\u00c7sH\u0097\u00c9m\u00e2\u000e\u00d3\u00b1E$\u00b1|Z\u008coy\u00ad\u00b7})\u00bdp\u0097ha@D\u00cb_'\u00ac\u00c57\u00eb\u00a2\u008bx\u001c%l\u009c\u00c4\u00df\u0011/r\u00f3c}\u00c6?Y\u00ed\u00b5h\u00e3\u00cd\u00af<\u0011?]\u0081_\u00db\u00dbJ\u0018\u009b\u00e9,RW3\u0003\u00f8\u00e9X\r\u00c9\u00d4\u008em\u00fa~h?/\u00a2\u00a2\u00db\u00a3$ D\u00b4\u00e1\u00b4<\u00b9e\u00c1\f\u00eb(\u00d5\u00a0\u00fbGq\u009f\u00e6!~j\u009ekkm&K\u00c8L\u00959\u00ea\u0001\u00f3\u00de9\u001e\u00cbK\u00eb\u00b7\u00fe.\u007f\u0081\u00be\u0014Os\u0090\u00ab!\u00b5)\u00aa1\u0084F\u0095\u0096\u00f8=\u0087\u0096\u00fer\u00a8{\u00a1X\u0097K\u0088\u00db\u00b6h \u0089yoI\u00fa\u0017\u00c4(\u00ba\u00e1dWv\r'hE\u00abP^:\u009b\u00e3\u0088\"]X\u0098\u0085N\u00e2\u008a'\u00f0\u00c0\u009e[\u000e\u00f3\u00c7\u00a2F\u00bcc\u008b\u0003\u00c0\u00e6\u0012\u0083\u00f9\u0000\u00b7X\u00df\u00b2\u00ad{i\u00c82\u00e0G\u00f5\u00d9k\u00bb\u0015*\u0003\u00d9\u00db\u00d8\u00e9/\u00fdJ\u00c5\u00cf/\u00e0\u00e3\u00e5\u00aa1\u00e6\u00fe\u00f7\u0087\b\u00bc\u0080\u00fb\u0007Y\u00b1\u001e_\u00aezx\u00c5E\u001d1a\u00cc\u00ee\u000b\u00c7M\u0018\u00b7E\u0010)E\u00d8\u00cd\u00a9\u00cc\u00d4\u00ef\u00de\u00b77$\u00ed\u00a8iM\u00b3\u00b7\u0098\"\u00b1k\u00b6\u0086\u000e\u00d6\u0094\u00a9\bCidl9\u0018\u00d2\u00af?\u00c1\u001f\u00be\u0006\u0006Lo.i8hfk\u00b4\u00dd\u00b5\u00d26\u00f7\u00e7\u00bd|\u00ea\u00e41\u0012\u0084+\u00c8\u00f6\u00c7\u00a5\u00d88\u00f7\u00da\u00ae#\u00f1\u0098\u0087x\u00e3z0\n\u0091\u00bcUG\u00d5\u00cfP\u008a\u00d6(\u008c\u000e\u000e\u00ca[\u0092\\\u00c6";
                var7_6 = ">\u00ee\u00d2\u00f9R\u00fd\u00c8\f\u001f\u00f5+\bR\u00e0\u00fc\u00f5A\u00a3\u00c4\u001f\u00a4-\u00b2:\u00f3!\u00c7sH\u0097\u00c9m\u00e2\u000e\u00d3\u00b1E$\u00b1|Z\u008coy\u00ad\u00b7})\u00bdp\u0097ha@D\u00cb_'\u00ac\u00c57\u00eb\u00a2\u008bx\u001c%l\u009c\u00c4\u00df\u0011/r\u00f3c}\u00c6?Y\u00ed\u00b5h\u00e3\u00cd\u00af<\u0011?]\u0081_\u00db\u00dbJ\u0018\u009b\u00e9,RW3\u0003\u00f8\u00e9X\r\u00c9\u00d4\u008em\u00fa~h?/\u00a2\u00a2\u00db\u00a3$ D\u00b4\u00e1\u00b4<\u00b9e\u00c1\f\u00eb(\u00d5\u00a0\u00fbGq\u009f\u00e6!~j\u009ekkm&K\u00c8L\u00959\u00ea\u0001\u00f3\u00de9\u001e\u00cbK\u00eb\u00b7\u00fe.\u007f\u0081\u00be\u0014Os\u0090\u00ab!\u00b5)\u00aa1\u0084F\u0095\u0096\u00f8=\u0087\u0096\u00fer\u00a8{\u00a1X\u0097K\u0088\u00db\u00b6h \u0089yoI\u00fa\u0017\u00c4(\u00ba\u00e1dWv\r'hE\u00abP^:\u009b\u00e3\u0088\"]X\u0098\u0085N\u00e2\u008a'\u00f0\u00c0\u009e[\u000e\u00f3\u00c7\u00a2F\u00bcc\u008b\u0003\u00c0\u00e6\u0012\u0083\u00f9\u0000\u00b7X\u00df\u00b2\u00ad{i\u00c82\u00e0G\u00f5\u00d9k\u00bb\u0015*\u0003\u00d9\u00db\u00d8\u00e9/\u00fdJ\u00c5\u00cf/\u00e0\u00e3\u00e5\u00aa1\u00e6\u00fe\u00f7\u0087\b\u00bc\u0080\u00fb\u0007Y\u00b1\u001e_\u00aezx\u00c5E\u001d1a\u00cc\u00ee\u000b\u00c7M\u0018\u00b7E\u0010)E\u00d8\u00cd\u00a9\u00cc\u00d4\u00ef\u00de\u00b77$\u00ed\u00a8iM\u00b3\u00b7\u0098\"\u00b1k\u00b6\u0086\u000e\u00d6\u0094\u00a9\bCidl9\u0018\u00d2\u00af?\u00c1\u001f\u00be\u0006\u0006Lo.i8hfk\u00b4\u00dd\u00b5\u00d26\u00f7\u00e7\u00bd|\u00ea\u00e41\u0012\u0084+\u00c8\u00f6\u00c7\u00a5\u00d88\u00f7\u00da\u00ae#\u00f1\u0098\u0087x\u00e3z0\n\u0091\u00bcUG\u00d5\u00cfP\u008a\u00d6(\u008c\u000e\u000e\u00ca[\u0092\\\u00c6".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl26:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = "\u0006\u009a\u0006@\u00a9m\u00df\u0093)\u00aa\u00f3Y\u00ca\u000bP\r";
                    var7_6 = "\u0006\u009a\u0006@\u00a9m\u00df\u0093)\u00aa\u00f3Y\u00ca\u000bP\r".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl52:
                // 1 sources

                ** continue;
            }
        }
        Class_ce_48116553.DHEMI = var8_3;
        Class_ce_48116553.sMfLg = new Integer[54];
    }

    private static MatchException PT(MatchException matchException) {
        return matchException;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean PO(ModuleBase moduleBase, boolean bl) {
        long l = AjBQU ^ 0x741909C74288L;
        boolean bl2 = Class_ca_75c833b3.OX();
        ModuleBase moduleBase2 = moduleBase;
        if (!bl2) {
            if (moduleBase2.baj()) {
                return false;
            }
            moduleBase2 = moduleBase;
        }
        Class_gc_4c0dfe20 class_gc_4c0dfe20 = moduleBase2.baf();
        boolean bl3 = class_gc_4c0dfe20.aZf();
        if (!bl2) {
            if (bl3) return false;
            bl3 = bl;
        }
        if (bl2) return bl3;
        if (!bl3) return true;
        bl3 = moduleBase.bag();
        if (bl2) return bl3;
        if (!bl3) return false;
        return true;
    }

    private static CallSite PW(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_ce_48116553" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int PU(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x1059;
        if (sMfLg[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = DHEMI[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])QuPpy.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    QuPpy.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_ce_48116553", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_ce_48116553.sMfLg[n2] = n3;
        }
        return sMfLg[n2];
    }

    private static int PV(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_ce_48116553.PU(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    @Override
    protected void NV(Class_lC_5322e8cf class_lC_5322e8cf) {
        block10: {
            ArrayList<ModuleBase> arrayList;
            float f;
            float f2;
            float f3;
            Class_ii_9b427eda class_ii_9b427eda;
            Class_lq_87a74641 class_lq_87a74641;
            boolean bl;
            block12: {
                block11: {
                    long l = AjBQU ^ 0x2A446EA26640L;
                    Class_lq_87a74641 class_lq_87a746412 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
                    bl = Class_ca_75c833b3.OY();
                    class_lq_87a74641 = Class_lE_06fbe260.joxgd.bYM(7.0f);
                    class_ii_9b427eda = ClientMain.dlM();
                    f3 = this.ormBS.dhj();
                    f2 = this.gILqY.dhj();
                    Class_mG_52c8d386 class_mG_52c8d386 = class_ii_9b427eda.bjb().coa(255.0f * f3);
                    Class_mG_52c8d386 class_mG_52c8d3862 = class_ii_9b427eda.bjc().coa(255.0f * f3);
                    float f4 = 20.0f;
                    f = 2.0f;
                    class_lC_5322e8cf.ccU(this.toIeR, this.QWaAn, this.jTsqG, f4, f3, f2);
                    class_lC_5322e8cf.ceA(class_lq_87a746412, this.eqWHC, this.toIeR + 7.0f, this.QWaAn + Class_jf_d1c4f950.bAH(class_lq_87a746412.cat(), f4), class_mG_52c8d386);
                    float f5 = 8.0f;
                    class_lC_5322e8cf.cem(this.jAncU, this.toIeR + this.jTsqG - f5 - 7.0f, this.QWaAn + Class_jf_d1c4f950.bAH(f5, f4), f5, class_mG_52c8d3862);
                    arrayList = new ArrayList<ModuleBase>(ClientMain.dlJ().aZz().values());
                    Class_ce_48116553 class_ce_48116553 = this;
                    if (!bl) break block11;
                    if (class_ce_48116553.WViuF == arrayList.size()) break block12;
                    arrayList.sort(Comparator.comparingDouble(moduleBase -> class_lq_87a746412.cap(moduleBase.bad()) + class_lq_87a746412.cao(Class_jb_fa6e084e.byM(moduleBase.baf().aZh()))));
                    class_ce_48116553 = this;
                }
                class_ce_48116553.WViuF = arrayList.size();
            }
            float f6 = 13.0f;
            zXCXX.bUa(class_lq_87a74641);
            float f7 = 22.0f;
            for (ModuleBase moduleBase2 : arrayList) {
                Class_mG_52c8d386 class_mG_52c8d386;
                float f8;
                float f9;
                block15: {
                    block14: {
                        boolean bl2;
                        block13: {
                            Class_rk_bf8630d1 class_rk_bf8630d1 = moduleBase2.bal();
                            if (!bl) break block10;
                            float f10 = class_rk_bf8630d1.dhj();
                            if (bl) {
                                if (f10 == 0.0f && bl) continue;
                                f10 = class_rk_bf8630d1.dhj();
                            }
                            f9 = f10;
                            float f11 = -4.5f + 4.5f * f9;
                            f8 = this.QWaAn + f7 + f11;
                            bl2 = this.UIgzX.WF();
                            if (!bl) break block13;
                            if (!bl2) break block14;
                            bl2 = this.cHqOw.WF();
                        }
                        if (bl2) break block14;
                        moduleBase2.ban().dfT(moduleBase2.bag() ? this.QyAzy.Wf() : this.sFKNs.Wf());
                        class_mG_52c8d386 = moduleBase2.ban().dfU();
                        if (bl) break block15;
                    }
                    class_mG_52c8d386 = class_ii_9b427eda.bjb();
                }
                class_mG_52c8d386 = class_mG_52c8d386.coa(255.0f * f9);
                String string = Class_jb_fa6e084e.byM(moduleBase2.baf().aZh());
                float f12 = class_lq_87a74641.cap(moduleBase2.bad());
                float f13 = class_lq_87a74641.cao(string);
                float f14 = 7.0f;
                float f15 = this.toIeR + f13 + f14 * 2.0f + 3.0f;
                float f16 = f13 + f14 * 2.0f;
                float f17 = f9;
                float f18 = 0.1f;
                if (bl) {
                    if (f17 >= f18) {
                        class_lC_5322e8cf.ccW(this.toIeR, f8, f16, 13.0f, f3, f2, Class_ld_bb1690e1.all(5.0f), 7.0f);
                        class_lC_5322e8cf.ccW(f15, f8, f12 + f14 * 2.0f, 13.0f, f3, f2, Class_ld_bb1690e1.all(5.0f), 7.0f);
                    }
                    f17 = this.toIeR;
                    f18 = f14 * f9;
                }
                float f19 = f17 + f18;
                float f20 = f8 + Class_jf_d1c4f950.bAH(class_lq_87a74641.cat(), 13.0f);
                class_lC_5322e8cf.cer(class_lq_87a74641, string, f19, f20, class_mG_52c8d386);
                float f21 = f15 + f12 + f14 * 2.0f - f14 * f9;
                class_lC_5322e8cf.cew(class_lq_87a74641, moduleBase2.bad(), f21, f20, class_mG_52c8d386);
                f7 += (13.0f + f) * f9;
                if (bl) continue;
            }
            zXCXX.endBatch();
        }
    }

    @Override
    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        block4: {
            long l = AjBQU ^ 0x3EFF84A78980L;
            this.jTsqG = 67.0f;
            this.Xtjvx = 20.0f;
            boolean bl = this.cHqOw.WF();
            Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.joxgd.bYM(7.0f);
            boolean bl2 = Class_ca_75c833b3.OX();
            for (ModuleBase moduleBase : ClientMain.dlJ().aZz().values()) {
                boolean bl3 = Class_ce_48116553.PO(moduleBase, bl);
                Class_rk_bf8630d1 class_rk_bf8630d1 = moduleBase.bal();
                class_rk_bf8630d1.dhc(bl3);
                class_rk_bf8630d1.dhs(Class_rj_b691f4f7.XzDkv);
                if (!bl2) {
                    if (!bl2) {
                        if (class_rk_bf8630d1.dhj() != 0.0f) {
                            this.jTsqG = Math.max(class_lq_87a74641.cap(moduleBase.bad()) + class_lq_87a74641.cao(Class_jb_fa6e084e.byM(moduleBase.baf().aZh())) + 31.0f, this.jTsqG);
                        }
                        this.Xtjvx += 15.0f * class_rk_bf8630d1.dhj();
                    }
                    if (!bl2) continue;
                }
                break block4;
            }
            super.LX(class_lC_5322e8cf);
        }
    }

    @Override
    public boolean Om() {
        boolean bl;
        block6: {
            long l = AjBQU ^ 0x29C9F822236AL;
            boolean bl2 = Class_ca_75c833b3.OY();
            boolean bl3 = ClientMain.dlmvG.currentScreen instanceof ChatScreen;
            if (bl2) {
                if (bl3) {
                    return true;
                }
                bl3 = this.cHqOw.WF();
            }
            boolean bl4 = bl3;
            for (ModuleBase moduleBase : ClientMain.dlJ().aZz().values()) {
                block8: {
                    boolean bl5;
                    block7: {
                        bl = Class_ce_48116553.PO(moduleBase, bl4);
                        if (!bl2) break block6;
                        if (!bl2) break block7;
                        if (!bl) break block8;
                        bl5 = true;
                    }
                    return bl5;
                }
                if (bl2) continue;
            }
            bl = false;
        }
        return bl;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_ce_48116553.class, "PV", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

