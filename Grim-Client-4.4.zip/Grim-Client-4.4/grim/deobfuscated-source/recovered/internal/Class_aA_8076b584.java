/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.core.ClientMain;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_bz_8cac7329;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public abstract class Class_aA_8076b584
extends Class_az_a4990dcf {
    private final Class_rk_bf8630d1 pLXUh;
    private final Class_rk_bf8630d1 sWdzd;
    private float UNVTC;
    private float kLgGw;
    private boolean hxRxH;
    private float yNfcJ;
    private float TMZHo;
    private float uoFGr;
    private boolean hkFfr;
    private boolean DCCbb;
    private boolean WBAUx;
    private boolean QdNTF;
    private boolean fHvqn;
    private static final long GTpjx = Class_gb_9d201141.aYR(-4850908496947294916L, -5906113067756810804L, MethodHandles.lookup().lookupClass()).a(234998979476403L);
    private static final long[] INkfH;
    private static final Integer[] bhgzy;
    private static final Map BrWZl;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aA_8076b584() {
        long l = GTpjx ^ 0x73FD2086EF21L;
        this.pLXUh = new Class_rk_bf8630d1((int)Class_aA_8076b584.tO("d", (int)5197, (long)(0x22BFD686FC81DE32L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.sWdzd = new Class_rk_bf8630d1((int)Class_aA_8076b584.tO("d", (int)1864, (long)(0x4040E1296204D36L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.WBAUx = true;
        this.QdNTF = true;
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        BrWZl = new HashMap(13);
        long l = GTpjx ^ 0x3F814D173D46L;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "@\u00f5\u0014\u00ddk\u0093\u00d7\u00af\u00d6\u00aa\u00ce~\u00e2)\u009b\u00d4";
        int n2 = "@\u00f5\u0014\u00ddk\u0093\u00d7\u00af\u00d6\u00aa\u00ce~\u00e2)\u009b\u00d4".length();
        int n3 = 0;
        do {
            byte[] byArray3 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
            byte[] byArray4 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray4[0] & 0xFFL) << 56 | ((long)byArray4[1] & 0xFFL) << 48 | ((long)byArray4[2] & 0xFFL) << 40 | ((long)byArray4[3] & 0xFFL) << 32 | ((long)byArray4[4] & 0xFFL) << 24 | ((long)byArray4[5] & 0xFFL) << 16 | ((long)byArray4[6] & 0xFFL) << 8 | (long)byArray4[7] & 0xFFL;
        } while (n3 < n2);
        INkfH = lArray;
        bhgzy = new Integer[2];
    }

    @Override
    public void dY() {
        super.dY();
        this.tK();
    }

    protected void tK() {
        this.hxRxH = false;
        this.hkFfr = false;
        this.DCCbb = false;
        this.UNVTC = this.MCnYt;
        this.kLgGw = this.pNyTQ;
        this.pLXUh.dhg();
        this.sWdzd.dhg();
    }

    private static MatchException tL(MatchException matchException) {
        return matchException;
    }

    public Class_aA_8076b584 tI(boolean bl) {
        long l = GTpjx ^ 0x63D20AB3C0ADL;
        String string = Class_az_a4990dcf.tE();
        Class_aA_8076b584 class_aA_8076b584 = this;
        if (string != null) {
            class_aA_8076b584.QdNTF = bl;
            if (!bl) {
                this.sWdzd.dhg();
            }
            class_aA_8076b584 = this;
        }
        return class_aA_8076b584;
    }

    private static int tM(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x4952;
        if (bhgzy[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = INkfH[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])BrWZl.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    BrWZl.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_aA_8076b584", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_aA_8076b584.bhgzy[n2] = n3;
        }
        return bhgzy[n2];
    }

    public Class_aA_8076b584 tH(boolean bl) {
        long l = GTpjx ^ 0x732793E1B182L;
        String string = Class_az_a4990dcf.tE();
        Class_aA_8076b584 class_aA_8076b584 = this;
        if (string != null) {
            class_aA_8076b584.WBAUx = bl;
            if (!bl) {
                this.pLXUh.dhg();
            }
            class_aA_8076b584 = this;
        }
        return class_aA_8076b584;
    }

    public Class_aA_8076b584 tJ(boolean bl) {
        this.fHvqn = bl;
        return this;
    }

    private static CallSite tO(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_aA_8076b584" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int tN(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_aA_8076b584.tM(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    /*
     * Unable to fully structure code
     */
    public Class_aA_8076b584 tG(float var1_1, float var2_2) {
        block52: {
            block53: {
                block54: {
                    block47: {
                        block51: {
                            block50: {
                                block48: {
                                    block49: {
                                        block45: {
                                            block46: {
                                                block44: {
                                                    block43: {
                                                        block42: {
                                                            block39: {
                                                                block40: {
                                                                    block41: {
                                                                        block38: {
                                                                            block37: {
                                                                                block34: {
                                                                                    block35: {
                                                                                        block36: {
                                                                                            block33: {
                                                                                                block32: {
                                                                                                    block31: {
                                                                                                        block29: {
                                                                                                            block30: {
                                                                                                                var3_3 = Class_aA_8076b584.GTpjx ^ 122213593604793L;
                                                                                                                var6_4 = 0.0f;
                                                                                                                var7_5 = 0.0f;
                                                                                                                var8_6 = 0.0f;
                                                                                                                var9_7 = false;
                                                                                                                var10_8 = 0.0f;
                                                                                                                var11_9 = 0.0f;
                                                                                                                var12_10 = false;
                                                                                                                var13_11 = 0.0f;
                                                                                                                var16_12 = ClientMain.dlmvG.currentScreen;
                                                                                                                var5_15 = Class_az_a4990dcf.tE();
                                                                                                                v0 = var16_12 instanceof Class_bl_a15fbaa5;
                                                                                                                if (var5_15 == null) break block29;
                                                                                                                if (!v0) break block30;
                                                                                                                var14_16 = (Class_bl_a15fbaa5)var16_12;
                                                                                                                v1 = var14_16.EF();
                                                                                                                if (var5_15 != null) {
                                                                                                                    if (v1) {
                                                                                                                        var9_7 = true;
                                                                                                                        var10_8 = var14_16.Ey().bXF();
                                                                                                                        var11_9 = var14_16.Ey().bXG();
                                                                                                                    }
                                                                                                                    v1 = true;
                                                                                                                }
                                                                                                                var12_10 = v1;
                                                                                                                var13_11 = (float)(-var14_16.Ez().nH());
                                                                                                                if (var5_15 != null) break block31;
                                                                                                                Class_iS_888f260e.bwK("YClhyb");
                                                                                                            }
                                                                                                            var16_12 = ClientMain.dlmvG.currentScreen;
                                                                                                            v0 = var16_12 instanceof Class_bz_8cac7329;
                                                                                                        }
                                                                                                        if (var5_15 == null) break block32;
                                                                                                        if (v0) {
                                                                                                            var15_18 = (Class_bz_8cac7329)var16_12;
                                                                                                            var9_7 = true;
                                                                                                            var10_8 = var15_18.KI().bXF();
                                                                                                            var11_9 = var15_18.KI().bXG();
                                                                                                            var12_10 = true;
                                                                                                            var13_11 = (float)(-var15_18.KO().nH());
                                                                                                        }
                                                                                                    }
                                                                                                    v0 = var9_7;
                                                                                                }
                                                                                                if (var5_15 == null) break block33;
                                                                                                if (!v0) break block34;
                                                                                                v2 = this;
                                                                                                if (var5_15 == null) break block35;
                                                                                                v0 = v2.hkFfr;
                                                                                            }
                                                                                            if (v0) break block36;
                                                                                            this.yNfcJ = var10_8;
                                                                                            this.TMZHo = var11_9;
                                                                                            this.hkFfr = true;
                                                                                            if (var5_15 != null) break block37;
                                                                                        }
                                                                                        var6_4 = var10_8 - this.yNfcJ;
                                                                                        var7_5 = var11_9 - this.TMZHo;
                                                                                        this.yNfcJ = var10_8;
                                                                                        v2 = this;
                                                                                    }
                                                                                    v2.TMZHo = var11_9;
                                                                                    if (var5_15 != null) break block37;
                                                                                }
                                                                                this.hkFfr = false;
                                                                            }
                                                                            v3 = var12_10;
                                                                            if (var5_15 == null) break block38;
                                                                            if (!v3) break block39;
                                                                            v4 = this;
                                                                            if (var5_15 == null) break block40;
                                                                            v3 = v4.DCCbb;
                                                                        }
                                                                        if (v3) break block41;
                                                                        this.uoFGr = var13_11;
                                                                        this.DCCbb = true;
                                                                        if (var5_15 != null) break block42;
                                                                    }
                                                                    var8_6 = var13_11 - this.uoFGr;
                                                                    v4 = this;
                                                                }
                                                                v4.uoFGr = var13_11;
                                                                if (var5_15 != null) break block42;
                                                            }
                                                            this.DCCbb = false;
                                                        }
                                                        v5 = this;
                                                        if (var5_15 == null) break block43;
                                                        if (v5.hxRxH) break block44;
                                                        this.UNVTC = var1_1;
                                                        this.kLgGw = var2_2;
                                                        this.pLXUh.dhg();
                                                        this.sWdzd.dhg();
                                                        v5 = this;
                                                    }
                                                    v5.hxRxH = true;
                                                }
                                                var14_17 = var1_1 - this.UNVTC;
                                                var15_19 = var2_2 - this.kLgGw;
                                                this.UNVTC = var1_1;
                                                this.kLgGw = var2_2;
                                                cfr_temp_0 = var14_17 - 0.0f;
                                                v6 = cfr_temp_0 == 0.0f ? 0 : (cfr_temp_0 > 0.0f ? 1 : -1);
                                                if (var5_15 == null) break block45;
                                                if (v6 != false) break block46;
                                                cfr_temp_1 = var15_19 - 0.0f;
                                                v6 = cfr_temp_1 == 0.0f ? 0 : (cfr_temp_1 > 0.0f ? 1 : -1);
                                                if (var5_15 == null) break block45;
                                                if (v6 == false) break block47;
                                            }
                                            v6 = (float)this.WBAUx;
                                        }
                                        var16_13 = v6 != false ? var14_17 - var6_4 : 0.0f;
                                        var17_20 = this.QdNTF != false ? var15_19 - var7_5 : 0.0f;
                                        v7 = this.QdNTF;
                                        if (var5_15 == null) break block48;
                                        if (v7 == 0) break block49;
                                        cfr_temp_2 = var8_6 - 0.0f;
                                        v7 = cfr_temp_2 == 0.0f ? 0 : (cfr_temp_2 > 0.0f ? 1 : -1);
                                        if (var5_15 == null) break block48;
                                        if (v7 == 0) break block49;
                                        var18_21 = var17_20 - var8_6;
                                        cfr_temp_3 = Math.abs(var18_21) - 0.001f;
                                        v7 = cfr_temp_3 == 0.0f ? 0 : (cfr_temp_3 < 0.0f ? -1 : 1);
                                        if (var5_15 == null) break block48;
                                        if (v7 <= 0) {
                                            var17_20 = 0.0f;
                                        }
                                    }
                                    v7 = (cfr_temp_4 = var16_13 - 0.0f) == 0.0f ? 0 : (cfr_temp_4 > 0.0f ? 1 : -1);
                                }
                                if (var5_15 == null) break block50;
                                if (v7 != 0) break block51;
                                cfr_temp_5 = var17_20 - 0.0f;
                                v7 = cfr_temp_5 == 0.0f ? 0 : (cfr_temp_5 > 0.0f ? 1 : -1);
                            }
                            if (v7 == 0) break block47;
                        }
                        this.pLXUh.dhe(this.pLXUh.dhj() - var16_13);
                        this.sWdzd.dhe(this.sWdzd.dhj() - var17_20);
                    }
                    v8 = this;
                    if (var5_15 == null) ** GOTO lbl142
                    if (v8.WBAUx) {
                        v8 = this;
lbl142:
                        // 2 sources

                        v9 = v8.pLXUh.dhd(0.0f);
                    } else {
                        v9 = 0.0f;
                    }
                    this.MCnYt = this.UNVTC + v9;
                    v10 = this;
                    if (var5_15 == null) ** GOTO lbl150
                    if (v10.QdNTF) {
                        v10 = this;
lbl150:
                        // 2 sources

                        v11 = v10.sWdzd.dhd(0.0f);
                    } else {
                        v11 = 0.0f;
                    }
                    var16_14 = this.kLgGw + v11;
                    v12 = this;
                    if (var5_15 == null) break block52;
                    if (!v12.fHvqn) break block53;
                    v12 = this;
                    if (var5_15 == null) break block52;
                    if (!v12.QdNTF) break block53;
                    v13 = var7_5;
                    if (var5_15 == null) break block54;
                    if (v13 != 0.0f) break block53;
                    v13 = this.kLgGw;
                }
                var16_14 = v13;
            }
            this.pNyTQ = var16_14;
            v12 = this;
        }
        return v12;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_aA_8076b584.class, "tN", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

