/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 */
package recovered.internal;

import net.minecraft.client.util.math.MatrixStack;
import recovered.internal.Class_kE_um_1dbd26be;
import recovered.internal.Class_mG_52c8d386;

public class Class_kE_3fe65a3d {
    private MatrixStack kccAM;
    private float tJewO;
    private float MDRnX;
    private float QfJwz;
    private float dWDvH;
    private Class_mG_52c8d386 lLAZi;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_kE_3fe65a3d(MatrixStack matrixStack, float f, float f2, float f3, float f4, Class_mG_52c8d386 class_mG_52c8d386) {
        this.kccAM = matrixStack;
        this.tJewO = f;
        this.MDRnX = f2;
        this.QfJwz = f3;
        this.dWDvH = f4;
        this.lLAZi = class_mG_52c8d386;
    }

    public static Class_kE_um_1dbd26be bTg() {
        return new Class_kE_um_1dbd26be();
    }

    public static Class_kE_um_1dbd26be bTf(MatrixStack matrixStack, double d, double d2, double d3, float f) {
        return Class_kE_3fe65a3d.bTg().dtd(matrixStack).dte((float)d).dtf((float)d2).dtg((float)d3).dth(f);
    }

    public float bTk() {
        return this.QfJwz;
    }

    public MatrixStack bTh() {
        return this.kccAM;
    }

    public float bTl() {
        return this.dWDvH;
    }

    public float bTj() {
        return this.MDRnX;
    }

    public Class_mG_52c8d386 bTm() {
        return this.lLAZi;
    }

    public float bTi() {
        return this.tJewO;
    }
}

