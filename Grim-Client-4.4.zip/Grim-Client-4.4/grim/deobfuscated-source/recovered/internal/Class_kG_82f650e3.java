/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 *  org.joml.Matrix3x2fStack
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix3x2fStack;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_kG_uo_864a18a0;
import recovered.internal.Class_mG_52c8d386;

public class Class_kG_82f650e3 {
    private MatrixStack HMKVC;
    private Matrix3x2fStack RyMUH;
    private float CKUpI;
    private float VHjcQ;
    private float zLaiu;
    private float THJBt;
    private float yoCan;
    private Class_mG_52c8d386 rjrxM;
    private static Class_iS_888f260e[] ajnUy;
    private static final long AwfGk;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public static Class_iS_888f260e[] bTH() {
        return ajnUy;
    }

    public static void bTG(Class_iS_888f260e[] class_iS_888f260eArray) {
        ajnUy = class_iS_888f260eArray;
    }

    public static Class_kG_uo_864a18a0 bTx() {
        return new Class_kG_uo_864a18a0();
    }

    private static MatchException bTI(MatchException matchException) {
        return matchException;
    }

    public static Class_kG_uo_864a18a0 bTw(Matrix3x2fStack matrix3x2fStack, double d, double d2, double d3, double d4, double d5) {
        return Class_kG_82f650e3.bTx().dtz(matrix3x2fStack).dtA((float)d).dtB((float)d2).dtC((float)d3).dtD((float)d4).dtE((float)d5);
    }

    Class_kG_82f650e3(MatrixStack matrixStack, Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3, float f4, float f5, Class_mG_52c8d386 class_mG_52c8d386) {
        block0: {
            long l = AwfGk ^ 0x72128EA2A5E3L;
            this.HMKVC = matrixStack;
            this.RyMUH = matrix3x2fStack;
            this.CKUpI = f;
            this.VHjcQ = f2;
            this.zLaiu = f3;
            Class_iS_888f260e[] class_iS_888f260eArray = Class_kG_82f650e3.bTH();
            this.THJBt = f4;
            this.yoCan = f5;
            this.rjrxM = class_mG_52c8d386;
            if (Class_iS_888f260e.bwL() != null) break block0;
            Class_kG_82f650e3.bTG(new Class_iS_888f260e[4]);
        }
    }

    static {
        AwfGk = Class_gb_9d201141.aYR(2091655255853178601L, 5796732930774797645L, MethodHandles.lookup().lookupClass()).a(280769937773786L);
        if (Class_kG_82f650e3.bTH() != null) {
            Class_kG_82f650e3.bTG(new Class_iS_888f260e[1]);
        }
    }

    public static Class_kG_uo_864a18a0 bTv(MatrixStack matrixStack, double d, double d2, double d3, double d4, double d5) {
        return Class_kG_82f650e3.bTx().dty(matrixStack).dtA((float)d).dtB((float)d2).dtC((float)d3).dtD((float)d4).dtE((float)d5);
    }

    public float bTE() {
        return this.yoCan;
    }

    public float bTA() {
        return this.CKUpI;
    }

    public float bTB() {
        return this.VHjcQ;
    }

    public Matrix3x2fStack bTz() {
        return this.RyMUH;
    }

    public float bTC() {
        return this.zLaiu;
    }

    public float bTD() {
        return this.THJBt;
    }

    public MatrixStack bTy() {
        return this.HMKVC;
    }

    public Class_mG_52c8d386 bTF() {
        return this.rjrxM;
    }
}

