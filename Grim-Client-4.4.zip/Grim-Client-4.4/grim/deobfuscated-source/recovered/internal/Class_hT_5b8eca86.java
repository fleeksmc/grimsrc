/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_hL_db8a30f6;
import recovered.internal.Class_hX_15329af5;
import recovered.internal.Class_hZ_076851ce;

public class Class_hT_5b8eca86 {
    private static long MgoIE;
    private static String[] tAJxG;
    private static String[] SREhy;
    private static Map KThVk;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_hT_5b8eca86.class);
        Class_hT_5b8eca86._b3f0ce18369101911bee73aa880aaa6f();
    }

    private static native /* synthetic */ void bfi(Class_hL_db8a30f6 var0);

    private static native void _b3f0ce18369101911bee73aa880aaa6f();

    private static native CallSite bfn(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native String bfl(int var0, long var1);

    public native Class_hZ_076851ce bff();

    private static native MatchException bfj(MatchException var0);

    private static native Object bfm(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native String bfk(byte[] var0);

    private static native /* synthetic */ void bfh(Class_hL_db8a30f6 var0);

    private static native /* synthetic */ void bfg(Class_hX_15329af5 var0);
}

