/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  media.IMediaSession
 *  media.MediaInfo
 *  media.impl.macos.MacOSMediaSession
 *  media.impl.win.WindowsMediaSession
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import media.IMediaSession;
import media.MediaInfo;
import media.impl.macos.MacOSMediaSession;
import media.impl.win.WindowsMediaSession;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import recovered.core.ClientMain;
import recovered.internal.Class_bJ_24f874fc;
import recovered.internal.Class_bU_714b1dad;
import recovered.internal.Class_bV_61960ba1;
import recovered.internal.Class_cv_f4b0140a;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_kW_239383b1;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mT_db06bea0;
import recovered.internal.Class_mZ_07f59a29;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_qO_d37ef529;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.internal.Class_rm_d861be3b;

public class Class_bL_258db0cf
extends Class_bV_61960ba1 {
    private final Class_rk_bf8630d1[] pBlmF;
    private final float[] CkuYo;
    private final Class_mT_db06bea0 VSvxM;
    private final Class_ri_288534d5 jGMUW;
    private final Class_rk_bf8630d1 PgRze;
    private final Class_rk_bf8630d1 IACKo;
    private final Class_rk_bf8630d1 GBFJq;
    private final Class_rk_bf8630d1 CAJMs;
    private final Class_rk_bf8630d1 UzjcR;
    private static final long PysbJ;
    private static final long[] njGgj;
    private static final Integer[] KhHGj;
    private static final Map jOYJZ;
    private static final long rsXSP;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bL_258db0cf(Class_cv_f4b0140a class_cv_f4b0140a) {
        long l = PysbJ ^ 0x2A804AE246E8L;
        int[] nArray = new int[Class_bL_258db0cf.Nm("b", (int)10220, (long)(0x543C0BE1022F96D5L ^ l))];
        nArray[0] = (int)Class_bL_258db0cf.Nm("b", (int)5192, (long)(0x524A74B616DEA579L ^ l));
        nArray[1] = (int)Class_bL_258db0cf.Nm("b", (int)8269, (long)(0x6380B9BCDB3D917BL ^ l));
        nArray[2] = (int)Class_bL_258db0cf.Nm("b", (int)6374, (long)(0x4E8C0C3DA3F129C8L ^ l));
        nArray[3] = (int)Class_bL_258db0cf.Nm("b", (int)20668, (long)(0x29E1427278B2E18BL ^ l));
        nArray[4] = (int)Class_bL_258db0cf.Nm("b", (int)1217, (long)(0x6160FC9473A735E9L ^ l));
        nArray[5] = (int)Class_bL_258db0cf.Nm("b", (int)27774, (long)(0x3975FF8FD00ADD51L ^ l));
        nArray[Class_bL_258db0cf.Nm("b", (int)3057, (long)(0x570EB73F35F4BADAL ^ l))] = (int)Class_bL_258db0cf.Nm("b", (int)3408, (long)(0x4484D87D60ECBC6FL ^ l));
        nArray[Class_bL_258db0cf.Nm("b", (int)24800, (long)(0x70BDD4EDC6F651CCL ^ l))] = (int)Class_bL_258db0cf.Nm("b", (int)12355, (long)(0xD8C351B92BA017FL ^ l));
        nArray[Class_bL_258db0cf.Nm("b", (int)3817, (long)(0x2DDCFDFE8B52BFDBL ^ l))] = (int)Class_bL_258db0cf.Nm("b", (int)32735, (long)(0x33E2CAB66E77CEEAL ^ l));
        nArray[Class_bL_258db0cf.Nm("b", (int)20904, (long)(0x33427A6E21426096L ^ l))] = (int)Class_bL_258db0cf.Nm("b", (int)13770, (long)(0x4E2189E37C0904F9L ^ l));
        nArray[Class_bL_258db0cf.Nm("b", (int)27797, (long)(0x54E2EC67304E5DAEL ^ l))] = (int)Class_bL_258db0cf.Nm("b", (int)18379, (long)(0x444B7BC30A07F6F6L ^ l));
        nArray[Class_bL_258db0cf.Nm("b", (int)25276, (long)(0x10DAB88848E2D388L ^ l))] = (int)Class_bL_258db0cf.Nm("b", (int)5080, (long)(0x629842470FD8A2E0L ^ l));
        super(class_cv_f4b0140a, Class_mr_7eac5189.clS(nArray));
        this.pBlmF = new Class_rk_bf8630d1[Class_bL_258db0cf.Nm("b", (int)19958, (long)(0x1792549DD530FCDCL ^ l))];
        this.CkuYo = new float[Class_bL_258db0cf.Nm("b", (int)19958, (long)(0x1792549DD530FCDCL ^ l))];
        this.VSvxM = Class_mT_db06bea0.cpz();
        this.jGMUW = new Class_ri_288534d5((int)Class_bL_258db0cf.Nm("b", (int)16257, (long)(0x666069F586350EACL ^ l)));
        this.PgRze = new Class_rk_bf8630d1((int)Class_bL_258db0cf.Nm("b", (int)32728, (long)(0x46A9D09F8044EF9L ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        this.IACKo = new Class_rk_bf8630d1((int)Class_bL_258db0cf.Nm("b", (int)27304, (long)(0x268117B67652DB98L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.GBFJq = new Class_rk_bf8630d1((int)Class_bL_258db0cf.Nm("b", (int)27304, (long)(0x268117B67652DB98L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.CAJMs = new Class_rk_bf8630d1((int)Class_bL_258db0cf.Nm("b", (int)27304, (long)(0x268117B67652DB98L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.UzjcR = new Class_rk_bf8630d1((int)Class_bL_258db0cf.Nm("b", (int)10829, (long)(0x14EFE76AFA929B77L ^ l))).dhs(Class_rj_b691f4f7.Xmkbr);
        boolean bl = Class_bJ_24f874fc.MN();
        for (int i = 0; i < this.pBlmF.length; ++i) {
            this.pBlmF[i] = new Class_rk_bf8630d1((int)Class_bL_258db0cf.Nm("b", (int)4038, (long)(0x2AC2B7D2761C3EEFL ^ l))).dhs(Class_rj_b691f4f7.Xmkbr);
            this.pBlmF[i].dhf(0.35f);
            this.CkuYo[i] = 0.35f;
            if (!bl) continue;
        }
        if (Class_iS_888f260e.bwL() == null) {
            Class_bJ_24f874fc.ML(!bl);
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block12: {
            block11: {
                block10: {
                    Class_bL_258db0cf.PysbJ = Class_gb_9d201141.aYR(3522061553632044626L, -8172081121300398233L, MethodHandles.lookup().lookupClass()).a(33674603162358L);
                    Class_bL_258db0cf.jOYJZ = new HashMap<K, V>(13);
                    var5 = Class_bL_258db0cf.PysbJ ^ 120042774779715L;
                    var7_1 = Cipher.getInstance("DES/CBC/NoPadding");
                    v0 = SecretKeyFactory.getInstance("DES");
                    v1 = new byte[8];
                    v2 = v1;
                    v1[0] = (byte)(var5 >>> 56);
                    for (var8_2 = 1; var8_2 < 8; ++var8_2) {
                        v2 = v2;
                        v2[var8_2] = (byte)(var5 << var8_2 * 8 >>> 56);
                    }
                    var7_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                    var13_3 = new long[25];
                    var10_4 = 0;
                    var11_5 = "v\u0019\u00c2&\u00a0\u00b3\u00e1\u00ea\u0087%c\u00aa\u00d6\u00af\u0097\u001f?S\u00c4\u00f7\u00b93\u00ea@s\u00e3\u00b8\u00f8\u0097g\u0091P\u00f6\u00ddm\u007fm\u00e5E)u\u00a8\u0017\u0081 \u0007\u00cd\u00b94\u0000\u00f3 Dx\u00fe\u00fc3\u00e8\u0013\u001e\u00adb\u0091\u0010\u00fbm\u0003,%i\u00c6\u00e0\u0080\u00bc\u000fX\u0000u\u00b2\u00b9\u0014FV\u0014\u00e4\u001a\u00aaF&\u0019ya\u00d1dONDbqW\u0084\u0089\u000b\u00b8\u00da\u00fbD)\u001d\u000bb'rF\u00d4\u0085U\u0098\u00ba\u00d9Z\u00d4\u0002\u00a46\u0088\u00bd\u00ba\u00a4\u00f1\u00fa\u008f\u00ef\u00b3\u00c2\u00c9\u00e0\u00a6\u00ce\u008d\u0019H8W\"\u00a9\u00af\u00d8\u007f\u00e6\u00a9{\u00c6\u00b0\n\u00c4}\u008a%7l8\u0092I8\u00a0N\u00fe 2\u00b6GQOt\u00e0\u0000\u008d\u00c3\u00e2\u0001\u00e9\u00d9x";
                    var12_6 = "v\u0019\u00c2&\u00a0\u00b3\u00e1\u00ea\u0087%c\u00aa\u00d6\u00af\u0097\u001f?S\u00c4\u00f7\u00b93\u00ea@s\u00e3\u00b8\u00f8\u0097g\u0091P\u00f6\u00ddm\u007fm\u00e5E)u\u00a8\u0017\u0081 \u0007\u00cd\u00b94\u0000\u00f3 Dx\u00fe\u00fc3\u00e8\u0013\u001e\u00adb\u0091\u0010\u00fbm\u0003,%i\u00c6\u00e0\u0080\u00bc\u000fX\u0000u\u00b2\u00b9\u0014FV\u0014\u00e4\u001a\u00aaF&\u0019ya\u00d1dONDbqW\u0084\u0089\u000b\u00b8\u00da\u00fbD)\u001d\u000bb'rF\u00d4\u0085U\u0098\u00ba\u00d9Z\u00d4\u0002\u00a46\u0088\u00bd\u00ba\u00a4\u00f1\u00fa\u008f\u00ef\u00b3\u00c2\u00c9\u00e0\u00a6\u00ce\u008d\u0019H8W\"\u00a9\u00af\u00d8\u007f\u00e6\u00a9{\u00c6\u00b0\n\u00c4}\u008a%7l8\u0092I8\u00a0N\u00fe 2\u00b6GQOt\u00e0\u0000\u008d\u00c3\u00e2\u0001\u00e9\u00d9x".length();
                    var9_7 = 0;
                    while (true) {
                        var14_9 = var11_5.substring(var9_7, var9_7 += 8).getBytes("ISO-8859-1");
                        v3 = var13_3;
                        v4 = var10_4++;
                        v5 = ((long)var14_9[0] & 255L) << 56 | ((long)var14_9[1] & 255L) << 48 | ((long)var14_9[2] & 255L) << 40 | ((long)var14_9[3] & 255L) << 32 | ((long)var14_9[4] & 255L) << 24 | ((long)var14_9[5] & 255L) << 16 | ((long)var14_9[6] & 255L) << 8 | (long)var14_9[7] & 255L;
                        v6 = -1;
                        break block10;
                        break;
                    }
lbl26:
                    // 1 sources

                    while (true) {
                        v3[v4] = v7;
                        if (var9_7 < var12_6) ** continue;
                        var11_5 = "\u00b49\u0088\u0094\\\u00bb\u00ab\u00f8\u009f\u00ecb|\u0094~\u00af\u00ba";
                        var12_6 = "\u00b49\u0088\u0094\\\u00bb\u00ab\u00f8\u009f\u00ecb|\u0094~\u00af\u00ba".length();
                        var9_7 = 0;
                        while (true) {
                            var14_9 = var11_5.substring(var9_7, var9_7 += 8).getBytes("ISO-8859-1");
                            v3 = var13_3;
                            v4 = var10_4++;
                            v5 = ((long)var14_9[0] & 255L) << 56 | ((long)var14_9[1] & 255L) << 48 | ((long)var14_9[2] & 255L) << 40 | ((long)var14_9[3] & 255L) << 32 | ((long)var14_9[4] & 255L) << 24 | ((long)var14_9[5] & 255L) << 16 | ((long)var14_9[6] & 255L) << 8 | (long)var14_9[7] & 255L;
                            v6 = 0;
                            break block10;
                            break;
                        }
                        break;
                    }
lbl39:
                    // 1 sources

                    while (true) {
                        v3[v4] = v7;
                        if (var9_7 < var12_6) ** continue;
                        break block11;
                        break;
                    }
                }
                var15_10 = v5;
                var17_8 = var7_1.doFinal(new byte[]{(byte)(var15_10 >>> 56), (byte)(var15_10 >>> 48), (byte)(var15_10 >>> 40), (byte)(var15_10 >>> 32), (byte)(var15_10 >>> 24), (byte)(var15_10 >>> 16), (byte)(var15_10 >>> 8), (byte)var15_10});
                v7 = ((long)var17_8[0] & 255L) << 56 | ((long)var17_8[1] & 255L) << 48 | ((long)var17_8[2] & 255L) << 40 | ((long)var17_8[3] & 255L) << 32 | ((long)var17_8[4] & 255L) << 24 | ((long)var17_8[5] & 255L) << 16 | ((long)var17_8[6] & 255L) << 8 | (long)var17_8[7] & 255L;
                switch (v6) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl52:
                    // 1 sources

                    ** continue;
                }
            }
            Class_bL_258db0cf.njGgj = var13_3;
            Class_bL_258db0cf.KhHGj = new Integer[25];
            var0_11 = Cipher.getInstance("DES/CBC/NoPadding");
            v8 = SecretKeyFactory.getInstance("DES");
            v9 = new byte[8];
            v10 = v9;
            v9[0] = (byte)(var5 >>> 56);
            for (var1_12 = 1; var1_12 < 8; ++var1_12) {
                v10 = v10;
                v10[var1_12] = (byte)(var5 << var1_12 * 8 >>> 56);
            }
            break block12;
lbl66:
            // 1 sources

            while (true) {
                continue;
                break;
            }
        }
        var0_11.init(2, (Key)v8.generateSecret(new DESKeySpec(v10)), new IvParameterSpec(new byte[8]));
        var2_13 = 6068978616664588365L;
        var4_14 = var0_11.doFinal(new byte[]{(byte)(var2_13 >>> 56), (byte)(var2_13 >>> 48), (byte)(var2_13 >>> 40), (byte)(var2_13 >>> 32), (byte)(var2_13 >>> 24), (byte)(var2_13 >>> 16), (byte)(var2_13 >>> 8), (byte)var2_13});
        ** while (true)
        Class_bL_258db0cf.rsXSP = ((long)var4_14[0] & 255L) << 56 | ((long)var4_14[1] & 255L) << 48 | ((long)var4_14[2] & 255L) << 40 | ((long)var4_14[3] & 255L) << 32 | ((long)var4_14[4] & 255L) << 24 | ((long)var4_14[5] & 255L) << 16 | ((long)var4_14[6] & 255L) << 8 | (long)var4_14[7] & 255L;
    }

    @Override
    public boolean MH() {
        return ClientMain.dmg().dcQ();
    }

    private void Nd(Class_lC_5322e8cf class_lC_5322e8cf, Class_mG_52c8d386 class_mG_52c8d386, IMediaSession iMediaSession, float f, float f2, float f3) {
        Class_lc_b8480f87 class_lc_b8480f87 = this.Nf(f, f2);
        Class_lc_b8480f87 class_lc_b8480f872 = this.Ng(f, f2);
        Class_lc_b8480f87 class_lc_b8480f873 = this.Nh(f, f2);
        Vec2f vec2f = Class_rm_d861be3b.dis();
        this.IACKo.dhc(class_lc_b8480f87.bXD(vec2f.x, vec2f.y));
        this.GBFJq.dhc(class_lc_b8480f872.bXD(vec2f.x, vec2f.y));
        this.CAJMs.dhc(class_lc_b8480f873.bXD(vec2f.x, vec2f.y));
        class_lC_5322e8cf.ceq(Class_lf_d247d983.RJfxY, class_lc_b8480f87, class_mG_52c8d386.coa((255.0f - 100.0f * this.IACKo.dhj()) * f3));
        float f4 = this.PgRze.dhj();
        float f5 = class_lc_b8480f872.bXF() + class_lc_b8480f872.bXH() / 2.0f;
        float f6 = class_lc_b8480f872.bXG() + class_lc_b8480f872.bXI() / 2.0f;
        class_lC_5322e8cf.ceV();
        class_lC_5322e8cf.cfb(f5, f6, 90.0f * f4);
        Class_jH_c1172273.bId(class_lC_5322e8cf, f5, f6, 1.0f - f4);
        class_lC_5322e8cf.ceq(Class_lf_d247d983.bLlHc, class_lc_b8480f872, class_mG_52c8d386.coa((255.0f * (1.0f - f4) - 100.0f * this.GBFJq.dhj()) * f3));
        Class_jH_c1172273.bIf();
        class_lC_5322e8cf.ceW();
        class_lC_5322e8cf.ceV();
        class_lC_5322e8cf.cfb(f5, f6, -90.0f + 90.0f * f4);
        Class_jH_c1172273.bId(class_lC_5322e8cf, f5, f6, f4);
        class_lC_5322e8cf.ceq(Class_lf_d247d983.wJqgL, class_lc_b8480f872, class_mG_52c8d386.coa((255.0f * f4 - 100.0f * this.GBFJq.dhj()) * f3));
        Class_jH_c1172273.bIf();
        class_lC_5322e8cf.ceW();
        class_lC_5322e8cf.ceq(Class_lf_d247d983.xesLS, class_lc_b8480f873, class_mG_52c8d386.coa((255.0f - 100.0f * this.CAJMs.dhj()) * f3));
    }

    private static int Nl(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bL_258db0cf.Nk(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    @Override
    public void MG(Class_lC_5322e8cf class_lC_5322e8cf, Class_ii_9b427eda class_ii_9b427eda) {
        block5: {
            Class_lC_5322e8cf class_lC_5322e8cf2;
            Class_bL_258db0cf class_bL_258db0cf;
            float f;
            float f2;
            MediaInfo mediaInfo;
            Class_mG_52c8d386 class_mG_52c8d386;
            IMediaSession iMediaSession;
            float f3;
            float f4;
            block4: {
                long l = PysbJ ^ 0x35513F7C09BCL;
                Class_bU_714b1dad class_bU_714b1dad = ClientMain.dlK().RC();
                f4 = class_bU_714b1dad.RW();
                f3 = class_bU_714b1dad.RX();
                Class_qO_d37ef529 class_qO_d37ef529 = ClientMain.dmg();
                boolean bl = Class_bJ_24f874fc.MN();
                iMediaSession = class_qO_d37ef529.dcS();
                if (!class_qO_d37ef529.dcQ()) {
                    return;
                }
                class_mG_52c8d386 = class_ii_9b427eda.bjb();
                mediaInfo = iMediaSession.media();
                Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
                f2 = 164.0f;
                float f5 = 80.0f;
                float f6 = 100.0f;
                float f7 = 32.0f + class_lq_87a74641.cao(mediaInfo.title());
                this.fGWTH.NU(class_bU_714b1dad.Oa() ? f2 : Math.min(f7, f6), class_bU_714b1dad.Oa() ? f5 : 15.0f);
                f = class_bU_714b1dad.Ob().dhj();
                float f8 = 4.0f + 6.0f * f;
                float f9 = 7.0f + 19.0f * f;
                float f10 = f3 + (class_bU_714b1dad.Oa() ? f8 : Class_jf_d1c4f950.bAH(f9, class_bU_714b1dad.NZ().Joctj));
                class_lC_5322e8cf.cee(class_qO_d37ef529.dcK(), f4 + f8 - 10.0f + 10.0f * this.dExGi.dhj(), f10, f9, f9, Class_ld_bb1690e1.all(1.0f + 4.0f * f));
                class_lC_5322e8cf.ceH(class_lq_87a74641, mediaInfo.title(), f4 - 5.0f + 10.0f * this.dExGi.dhj() + 10.0f * this.dExGi.dhj() + 29.0f * f, f3 + 5.0f + 11.0f * f, class_mG_52c8d386, 0.3f, 0.7f, class_bU_714b1dad.Oa() ? f2 - 30.0f : f6 + 5.0f);
                Class_mG_52c8d386 class_mG_52c8d3862 = ClientMain.dmg().dcU().coc(Class_mG_52c8d386.hoGuU, 0.2f);
                class_bL_258db0cf = this;
                class_lC_5322e8cf2 = class_lC_5322e8cf;
                if (bl) break block4;
                class_bL_258db0cf.Nb(class_lC_5322e8cf2, class_mG_52c8d3862, mediaInfo, f4, f3, f, f7, f2, f6);
                if (!(f > 0.0f)) break block5;
                class_bL_258db0cf = this;
                class_lC_5322e8cf2 = class_lC_5322e8cf;
            }
            class_bL_258db0cf.MZ(class_lC_5322e8cf2, iMediaSession, mediaInfo, class_mG_52c8d386, f4, f3, f2, f);
        }
    }

    @Override
    public Class_mG_52c8d386 MI() {
        return ClientMain.dmg().dcU();
    }

    private Class_lc_b8480f87 Nf(float f, float f2) {
        return new Class_lc_b8480f87(f + 40.0f, f2 + 55.0f, 16.0f, 16.0f);
    }

    private static int Nk(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5CA5;
        if (KhHGj[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = njGgj[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])jOYJZ.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    jOYJZ.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bL_258db0cf", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bL_258db0cf.KhHGj[n2] = n3;
        }
        return KhHGj[n2];
    }

    private Class_lc_b8480f87 Nh(float f, float f2) {
        return new Class_lc_b8480f87(f + 104.0f, f2 + 55.0f, 16.0f, 16.0f);
    }

    private Class_lc_b8480f87 Ng(float f, float f2) {
        return new Class_lc_b8480f87(f + 72.0f, f2 + 55.0f, 16.0f, 16.0f);
    }

    private void Nc(boolean n) {
        int n2;
        long l = PysbJ ^ 0x7D6D9A1DBED4L;
        boolean bl = Class_bJ_24f874fc.MN();
        int n3 = n;
        if (!bl) {
            if (n3 == 0) {
                Arrays.fill(this.CkuYo, 0.35f);
                return;
            }
            n3 = this.VSvxM.cpE(rsXSP) ? 1 : 0;
        }
        if (!bl) {
            if (n3 == 0) {
                return;
            }
            n3 = n2 = 0;
        }
        while (n2 < this.CkuYo.length) {
            this.CkuYo[n2] = MathHelper.lerp((float)((float)Math.random()), (float)0.35f, (float)1.0f);
            ++n2;
            if (!bl) continue;
        }
    }

    private void Na(Class_lC_5322e8cf class_lC_5322e8cf, Class_mG_52c8d386 class_mG_52c8d386, MediaInfo mediaInfo, float f, float f2, float f3, float f4) {
        Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.SVnNc.bYM(6.0f);
        String string = Class_jf_d1c4f950.bAN(mediaInfo.position());
        long l = Math.max(0L, mediaInfo.duration() - mediaInfo.position());
        String string2 = "-" + Class_jf_d1c4f950.bAN(l);
        float f5 = 110.0f;
        float f6 = 3.0f;
        float f7 = f + Class_jf_d1c4f950.bAH(f5, f3);
        float f8 = f2 + 45.0f;
        Class_mG_52c8d386 class_mG_52c8d3862 = class_mG_52c8d386.coa(63.75f * f4);
        class_lC_5322e8cf.cdg(f7, f8, f5, f6, Class_ld_bb1690e1.all(0.5f), class_mG_52c8d3862);
        this.UzjcR.dhd(Math.min(1.0f, (float)mediaInfo.position() / (float)mediaInfo.duration()));
        float f9 = f5 * this.UzjcR.dhj();
        Class_mG_52c8d386 class_mG_52c8d3863 = class_mG_52c8d386.coa(150.0f * f4);
        class_lC_5322e8cf.cdg(f7, f8, f9, f6, Class_ld_bb1690e1.all(0.5f), class_mG_52c8d3863);
        Class_mG_52c8d386 class_mG_52c8d3864 = class_mG_52c8d386.cob(0.5f * f4);
        class_lC_5322e8cf.cez(class_lq_87a74641, string, f7 - class_lq_87a74641.cao(string) - 3.0f, f8 - 0.75f, class_mG_52c8d3864);
        class_lC_5322e8cf.cez(class_lq_87a74641, string2, f7 + f5 + 3.0f, f8 - 0.75f, class_mG_52c8d3864);
    }

    private void Nb(Class_lC_5322e8cf class_lC_5322e8cf, Class_mG_52c8d386 class_mG_52c8d386, MediaInfo mediaInfo, float f, float f2, float f3, float f4, float f5, float f6) {
        long l = PysbJ ^ 0x382AEF32264DL;
        boolean bl = Class_bJ_24f874fc.MN();
        this.Nc(mediaInfo.playing());
        Class_kW_239383b1 class_kW_239383b1 = new Class_kW_239383b1(class_mG_52c8d386.cof(), class_mG_52c8d386);
        float f7 = 1.2f;
        boolean bl2 = bl;
        float f8 = 7.0f;
        float f9 = 1.0f;
        float f10 = f3 - 0.7f;
        Object object = f10 == 0.0f ? 0 : (f10 > 0.0f ? 1 : -1);
        if (!bl2) {
            object = object > 0 ? (Object)Class_bL_258db0cf.Nm("b", (int)19958, (long)(0x1792463770E09C79L ^ l)) : (Object)4;
        }
        float f11 = object;
        float f12 = f7 * (float)f11 + (float)(f11 - true) * f9;
        float f13 = 5.0f - 5.0f * f3;
        float f14 = f + Class_mZ_07f59a29.csl(Math.min(f4, f6), f5 - f12, f3) - f12 * this.dExGi.dhj() - f13;
        for (int i = 0; i < f11; ++i) {
            this.pBlmF[i].dhq((int)Class_bL_258db0cf.Nm("b", (int)27304, (long)(0x2681051CD382BB3DL ^ l)));
            float f15 = this.pBlmF[i].dhd(this.CkuYo[i]);
            float f16 = f8 * f15;
            float f17 = f2 + 5.0f + 11.0f * f3;
            float f18 = f17 + 3.0f;
            float f19 = f14 + (float)i * (f7 + f9);
            float f20 = f18 - f16 / 2.0f;
            class_lC_5322e8cf.cdP(f19, f20, f7, f16, Class_ld_bb1690e1.all(0.25f), class_kW_239383b1, 0.5f);
            if (!bl2) continue;
        }
    }

    private static MatchException Nj(MatchException matchException) {
        return matchException;
    }

    private Class_lc_b8480f87 Ni(float f, float f2) {
        return new Class_lc_b8480f87(f + 136.0f, f2 + 59.0f, 8.0f, 8.0f);
    }

    /*
     * Unable to fully structure code
     */
    private void MZ(Class_lC_5322e8cf var1_1, IMediaSession var2_2, MediaInfo var3_3, Class_mG_52c8d386 var4_4, float var5_5, float var6_6, float var7_7, float var8_8) {
        var9_9 = Class_bL_258db0cf.PysbJ ^ 31995452235836L;
        var11_10 = Class_bJ_24f874fc.MM();
        this.PgRze.dhd(var3_3.playing() != false ? 1.0f : 0.0f);
        var12_11 = var5_5 + 20.0f + 24.0f * var8_8;
        var13_12 = var6_6 + 5.0f + 19.0f * var8_8;
        var1_1.ceH(Class_lE_06fbe260.joxgd.bYM(7.0f), var3_3.artist(), var12_11, var13_12, var4_4.cob(0.7f * var8_8), 0.3f, 0.7f, var7_7 - 34.0f);
        this.Na(var1_1, var4_4, var3_3, var5_5, var6_6, var7_7, var8_8);
        this.Nd(var1_1, var4_4, var2_2, var5_5, var6_6, var8_8);
        var14_13 = this.Ni(var5_5, var6_6);
        if (!var11_10) ** GOTO lbl15
        switch (var2_2.getCycleType()) {
            case 1: {
                var1_1.ceq(Class_lf_d247d983.PzeJx, var14_13, this.jGMUW.dfT(var4_4.cob(var8_8)));
lbl15:
                // 2 sources

                if (var11_10) break;
            }
            case 2: {
                var1_1.ceq(Class_lf_d247d983.QZzTA, var14_13, this.jGMUW.dfT(var4_4.cob(var8_8)));
                if (var11_10) break;
            }
            default: {
                var1_1.ceq(Class_lf_d247d983.PzeJx, var14_13, this.jGMUW.dfT(var4_4.cob(0.5f * var8_8)));
                break;
            }
        }
    }

    private static CallSite Nm(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bL_258db0cf" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    @Override
    public void Ne(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        block11: {
            int n;
            block14: {
                boolean bl;
                IMediaSession iMediaSession;
                block12: {
                    block13: {
                        block10: {
                            long l = PysbJ ^ 0x3BE0A2F4EB94L;
                            iMediaSession = ClientMain.dmg().dcS();
                            bl = Class_bJ_24f874fc.MM();
                            if (iMediaSession == null) {
                                return;
                            }
                            Class_bU_714b1dad class_bU_714b1dad = ClientMain.dlK().RC();
                            float f = class_bU_714b1dad.RW();
                            float f2 = class_bU_714b1dad.RX();
                            n = this.Nf(f, f2).bXD(d, d2);
                            if (bl) {
                                if (n != 0) {
                                    iMediaSession.previous();
                                    return;
                                }
                                n = this.Ng(f, f2).bXD(d, d2);
                            }
                            if (bl) {
                                if (n != 0) {
                                    iMediaSession.playPause();
                                    return;
                                }
                                n = this.Nh(f, f2).bXD(d, d2);
                            }
                            if (bl) {
                                if (n != 0) {
                                    iMediaSession.next();
                                    return;
                                }
                                n = this.Ni(f, f2).bXD(d, d2) ? 1 : 0;
                            }
                            if (!bl) break block10;
                            if (n == 0) break block11;
                            iMediaSession.swapCycle();
                            n = iMediaSession instanceof WindowsMediaSession;
                        }
                        if (!bl) break block12;
                        if (n == 0) break block13;
                        WindowsMediaSession.setCycle((int)iMediaSession.getCycleType());
                        if (bl) break block11;
                    }
                    n = iMediaSession instanceof MacOSMediaSession;
                }
                if (!bl) break block14;
                if (n == 0) break block11;
                n = iMediaSession.getCycleType();
            }
            MacOSMediaSession.setCycle((int)n);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bL_258db0cf.class, "Nl", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

