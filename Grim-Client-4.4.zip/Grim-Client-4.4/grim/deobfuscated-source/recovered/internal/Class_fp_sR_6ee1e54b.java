/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.packet.Packet
 */
package recovered.internal;

import net.minecraft.network.packet.Packet;
import recovered.core.NativeLoader;

final class Class_fp_sR_6ee1e54b
extends Record {
    private final Packet<?> packet;
    private final long time;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_fp_sR_6ee1e54b(Packet<?> packet) {
        this(packet, System.currentTimeMillis());
    }

    private Class_fp_sR_6ee1e54b(Packet<?> packet, long l) {
        this.packet = packet;
        this.time = l;
    }

    static {
        NativeLoader.doInit(Class_fp_sR_6ee1e54b.class);
    }

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    public native long time();

    public native Packet<?> packet();
}

