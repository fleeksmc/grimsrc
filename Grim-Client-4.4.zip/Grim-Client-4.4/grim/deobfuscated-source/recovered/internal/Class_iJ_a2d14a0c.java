/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import recovered.core.NativeLoader;
import recovered.internal.Class_iE_00f71a81;
import recovered.internal.Class_iK_af06a2a2;
import recovered.internal.Class_iL_fafa72df;
import recovered.internal.Class_iM_910cda2e;
import recovered.internal.Class_iO_e7bfa49a;
import recovered.internal.Class_iu_bf2db566;

public class Class_iJ_a2d14a0c
extends Class_iE_00f71a81
implements Class_iK_af06a2a2 {
    private static String dBTIE;
    private static long tpAxI;
    private static String[] GwRhC;
    private static String[] ciYOV;
    private static Map JHeJg;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native MatchException btp(MatchException var0);

    @Override
    public native CompletableFuture<Class_iM_910cda2e> likeConfig(String var1);

    private native /* synthetic */ Class_iM_910cda2e btg(Throwable var1);

    private native /* synthetic */ Class_iM_910cda2e bti(Throwable var1);

    private native /* synthetic */ Class_iu_bf2db566 btl(Throwable var1);

    private native /* synthetic */ Class_iM_910cda2e btm(Throwable var1);

    private static native String btr(int var0, long var1);

    public static native String bto();

    private static native String btq(byte[] var0);

    private static native CallSite btt(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native /* synthetic */ Class_iM_910cda2e btk(Throwable var1);

    private native /* synthetic */ Class_iu_bf2db566 btd(Throwable var1);

    private native /* synthetic */ Class_iu_bf2db566 btf(Throwable var1);

    private native /* synthetic */ Class_iM_910cda2e bth(Throwable var1);

    private native /* synthetic */ Class_iu_bf2db566 btj(Throwable var1);

    public static native void btn(String var0);

    static {
        NativeLoader.doInit(Class_iJ_a2d14a0c.class);
        Class_iJ_a2d14a0c._b1b4166abfe67205bc51989fb8318952();
    }

    @Override
    public native CompletableFuture<Class_iu_bf2db566> loadConfig(Class_iM_910cda2e var1);

    private static native Object bts(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    @Override
    public native CompletableFuture<Class_iu_bf2db566> importConfig(String var1);

    @Override
    public native CompletableFuture<Class_iu_bf2db566> deleteConfig(String var1);

    @Override
    public native CompletableFuture<Class_iM_910cda2e> dislikeConfig(String var1);

    @Override
    public native CompletableFuture<Class_iM_910cda2e> createConfig(int[] var1, int[] var2, Class_iL_fafa72df var3);

    @Override
    public native CompletableFuture<Class_iM_910cda2e> downloadConfig(String var1);

    @Override
    public native CompletableFuture<Class_iu_bf2db566> resetLoadedConfig();

    @Override
    public native CompletableFuture<List<Class_iO_e7bfa49a>> fetchMetadata();

    @Override
    public native CompletableFuture<Class_iM_910cda2e> updateConfig(String var1, int[] var2, int[] var3, Class_iL_fafa72df var4, boolean var5);

    @Override
    public native CompletableFuture<Class_iu_bf2db566> favouriteConfig(String var1);

    private native /* synthetic */ Class_iu_bf2db566 bte(Throwable var1);

    private static native void _b1b4166abfe67205bc51989fb8318952();
}

