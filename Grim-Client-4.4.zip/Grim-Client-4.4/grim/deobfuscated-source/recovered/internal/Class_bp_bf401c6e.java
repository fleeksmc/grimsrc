/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import recovered.core.ClientMain;
import recovered.core.NativeLoader;
import recovered.internal.Class_P_2c9819bb;
import recovered.internal.Class_S_f3cb3437;
import recovered.internal.Class_ah_02444db4;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_cy_687dcdb6;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_nd_e33facc7;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bp_bf401c6e
extends Class_az_a4990dcf {
    private static float AMFXd = 12.0f;
    private static float WJzgl = 0.5f;
    private static float vNQUo = 4.0f;
    private static float lSqcN = 12.5f;
    private final List<Class_nd_e33facc7> sKQDB;
    private final Class_az_a4990dcf IYJTL;
    private final Class_rk_bf8630d1 LTCPm;
    private final Class_rk_bf8630d1 kSenW;
    private final Class_rk_bf8630d1 NMQry;
    private final Class_P_2c9819bb sIfhE;
    private final Class_P_2c9819bb hgCRo;
    private final Class_ah_02444db4 keiTB;
    private final Map<Class_nd_e33facc7, Class_rk_bf8630d1> DZPiP;
    private static long fGoeO;
    private static String[] FQbHd;
    private static String[] jzZEi;
    private static Map qDzlt;
    private static long[] eNOwA;
    private static Integer[] QiEfT;
    private static Map TrcZL;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private native /* synthetic */ void FL(double var1, double var3, Class_nd_e33facc7 var5, Class_P_2c9819bb var6);

    private native void FF(double var1, double var3, Class_nd_e33facc7 var5);

    public Class_bp_bf401c6e(List<Class_nd_e33facc7> list, Class_az_a4990dcf class_az_a4990dcf) {
        long l = fGoeO ^ 0x638512B828CEL;
        this.LTCPm = new Class_rk_bf8630d1((int)Class_bp_bf401c6e.FU("n", (int)190, (long)(0x1575444A8CDC3BACL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.kSenW = new Class_rk_bf8630d1((int)Class_bp_bf401c6e.FU("n", (int)190, (long)(0x1575444A8CDC3BACL ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        this.NMQry = new Class_rk_bf8630d1((int)Class_bp_bf401c6e.FU("n", (int)190, (long)(0x1575444A8CDC3BACL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.keiTB = new Class_ah_02444db4();
        this.DZPiP = new IdentityHashMap<Class_nd_e33facc7, Class_rk_bf8630d1>();
        this.sKQDB = list;
        this.IYJTL = class_az_a4990dcf;
        Class_ig_ca326427 class_ig_ca326427 = ClientMain.dlM().bjG();
        this.sIfhE = ((Class_P_2c9819bb)new Class_P_2c9819bb(null, (String)((Object)Class_bp_bf401c6e.FR("d", (int)29479, (long)(0x245B84E2EFE53169L ^ l))), Class_lf_d247d983.cuxpa).ja(class_ig_ca326427.biw().bhF())).hO(Class_S_f3cb3437.CLgKH);
        this.hgCRo = ((Class_P_2c9819bb)((Class_P_2c9819bb)new Class_P_2c9819bb(null, (String)((Object)Class_bp_bf401c6e.FR("d", (int)19586, (long)(0x4DC7FAA61780EC9L ^ l))), Class_lf_d247d983.JHGge).ja(Class_jk_a0800133.mPXGi)).iY(Class_jk_a0800133.mPXGi)).hO(Class_S_f3cb3437.CLgKH);
    }

    static {
        NativeLoader.doInit(Class_bp_bf401c6e.class);
        Class_bp_bf401c6e._7dcd2c33d80d702490ca9fdc4ce2514e();
    }

    @Override
    public native float dn();

    private static native int FS(int var0, long var1);

    @Override
    public native boolean dm(int var1, int var2, int var3);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private static native CallSite FR(MethodHandles.Lookup var0, String var1, MethodType var2);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean fC(double var1, double var3, double var5);

    private static native void _7dcd2c33d80d702490ca9fdc4ce2514e();

    private native boolean FG(String var1, boolean var2, Class_nd_e33facc7 var3);

    private native Class_rk_bf8630d1 FH(Class_nd_e33facc7 var1);

    private static native String FO(byte[] var0);

    private static native int FT(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native /* synthetic */ void FM(Class_cy_687dcdb6 var1, Class_cJ_2ae1a557 var2, Class_nd_e33facc7 var3, boolean var4, Class_aj_95d0a719 var5);

    private static native Object FQ(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native MatchException FN(MatchException var0);

    private static native String FP(int var0, long var1);

    private static native CallSite FU(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native /* synthetic */ void FK(Class_nd_e33facc7 var1, Class_P_2c9819bb var2);

    private native void FI(double var1, double var3, Class_nd_e33facc7 var5);

    private native float FJ();
}

