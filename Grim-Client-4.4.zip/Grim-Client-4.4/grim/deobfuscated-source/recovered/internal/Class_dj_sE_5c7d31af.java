/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import recovered.internal.Class_dj_sC_00057dd5;
import recovered.internal.Class_dj_sD_3d735e16;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.modules.AmbienceModule;

record Class_dj_sE_5c7d31af(List<BlockPos> cells, Class_dj_sD_3d735e16 safety, Class_dj_sC_00057dd5 shape) {
    private static final long a;
    private static final long[] b;
    private static final Integer[] c;
    private static final Map d;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_dj_sE_5c7d31af.a = Class_gb_9d201141.aYR(3689833551963741353L, 3008310168974642977L, MethodHandles.lookup().lookupClass()).a(256309021222875L);
                Class_dj_sE_5c7d31af.d = new HashMap<K, V>(13);
                var0 = Class_dj_sE_5c7d31af.a ^ 65778213794508L;
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[4];
                var5_4 = 0;
                var6_5 = "\u00f9\u00fen\u00f3N\u00b13\u0085#j\u00d1!\u0012\u00be\u00c2\n";
                var7_6 = "\u00f9\u00fen\u00f3N\u00b13\u0085#j\u00d1!\u0012\u00be\u00c2\n".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl26:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = ",\u00ac\u008aZ\u00f8\u00ed\u00d9xf6\u000f\u00e7$\u0004\u009d\u0099";
                    var7_6 = ",\u00ac\u008aZ\u00f8\u00ed\u00d9xf6\u000f\u00e7$\u0004\u009d\u0099".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl52:
                // 1 sources

                ** continue;
            }
        }
        Class_dj_sE_5c7d31af.b = var8_3;
        Class_dj_sE_5c7d31af.c = new Integer[4];
    }

    private static int a(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_dj_sE_5c7d31af.a(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static int a(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5139;
        if (c[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = b[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])d.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    d.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_dj_sE_5c7d31af", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_dj_sE_5c7d31af.c[n2] = n3;
        }
        return c[n2];
    }

    private static CallSite a(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_dj_sE_5c7d31af" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    Vec3d center() {
        return this.toBox(1.0).getCenter();
    }

    Box toBox(double d) {
        Object object;
        CallSite callSite;
        Object object2;
        Object object3;
        Object object4;
        block2: {
            long l = a ^ 0x51AF077A306AL;
            object4 = Class_dj_sE_5c7d31af.a("y", (int)12408, (long)(0x712D84F258F62D59L ^ l));
            Object object5 = Class_dj_sE_5c7d31af.a("y", (int)26618, (long)(0x541708181289FAD9L ^ l));
            object3 = Class_dj_sE_5c7d31af.a("y", (int)26618, (long)(0x541708181289FAD9L ^ l));
            object2 = Class_dj_sE_5c7d31af.a("y", (int)13331, (long)(0x111A8F1F65AC2933L ^ l));
            Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
            callSite = Class_dj_sE_5c7d31af.a("y", (int)18176, (long)(0x1B6BDA1A1F115A22L ^ l));
            for (BlockPos blockPos : this.cells) {
                object4 = Math.min((int)object4, blockPos.getX());
                object5 = Math.min((int)object5, blockPos.getY());
                object3 = Math.min((int)object3, blockPos.getZ());
                object2 = Math.max((int)object2, blockPos.getX());
                object = Math.max((int)callSite, blockPos.getZ());
                if (class_iS_888f260eArray == null) {
                    callSite = object;
                    if (class_iS_888f260eArray == null) continue;
                }
                break block2;
            }
            object = object5;
        }
        double d2 = (double)object;
        double d3 = d2 + d;
        return new Box((double)object4, Math.min(d2, d3), (double)object3, (double)object2 + 1.0, Math.max(d2, d3), (double)callSite + 1.0);
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_dj_sE_5c7d31af.class, "a", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

