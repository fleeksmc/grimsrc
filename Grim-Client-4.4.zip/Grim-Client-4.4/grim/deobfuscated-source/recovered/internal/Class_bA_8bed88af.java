/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

public record Class_bA_8bed88af(float centerX, float centerY, float innerRadius, float outerRadius) {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public float diameter() {
        return this.outerRadius * 2.0f;
    }
}

