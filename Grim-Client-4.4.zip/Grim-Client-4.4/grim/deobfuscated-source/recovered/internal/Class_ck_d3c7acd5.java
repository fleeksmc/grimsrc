/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_cl_0655ee76;
import recovered.internal.Class_iS_888f260e;

public class Class_ck_d3c7acd5 {
    private final Class_cl_0655ee76 izVDT;
    private final float TbtxI;
    private boolean glfpL;
    private static Class_iS_888f260e[] UQvdU;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ck_d3c7acd5(Class_cl_0655ee76 class_cl_0655ee76, float f) {
        this.izVDT = class_cl_0655ee76;
        this.TbtxI = f;
    }

    static {
        if (Class_ck_d3c7acd5.QK() != null) {
            Class_ck_d3c7acd5.QJ(new Class_iS_888f260e[5]);
        }
    }

    public static void QJ(Class_iS_888f260e[] class_iS_888f260eArray) {
        UQvdU = class_iS_888f260eArray;
    }

    public Class_cl_0655ee76 QF() {
        return this.izVDT;
    }

    public boolean QH() {
        return this.glfpL;
    }

    public float QG() {
        return this.TbtxI;
    }

    public Class_ck_d3c7acd5 QI(boolean bl) {
        this.glfpL = bl;
        return this;
    }

    public static Class_iS_888f260e[] QK() {
        return UQvdU;
    }
}

