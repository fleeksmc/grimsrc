/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.texture.AbstractTexture
 *  org.joml.Matrix3x2fStack
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import net.minecraft.client.texture.AbstractTexture;
import org.joml.Matrix3x2fStack;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jO_tZ_935a142d;
import recovered.internal.Class_kd_dfbdd90e;
import recovered.internal.Class_kf_f68d320f;
import recovered.internal.Class_la_8f67ae40;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mG_52c8d386;

public class Class_jO_1924117a {
    private Matrix3x2fStack xSQbY;
    private float egCsl;
    private float TDmPu;
    private float dBKFM;
    private float HmcPi;
    private Class_kd_dfbdd90e eaLNK;
    private Class_kf_f68d320f DnKLZ;
    private Class_ld_bb1690e1 rRoDO;
    private Class_mG_52c8d386 FVntd;
    private Class_la_8f67ae40 itKud;
    private AbstractTexture WEuvT;
    private boolean fUfva;
    private float eFXuw;
    private float BhhVn;
    private float GPlHN;
    private float HhCMg;
    private float vBJeR;
    private float GWDND;
    private float AltXm;
    private float gvMEj;
    private float mEQGi;
    private float xwdNH;
    private float ZvmaJ;
    private static String IJQZt;
    private static final long msXQV;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_jO_1924117a(Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3, float f4, Class_kd_dfbdd90e class_kd_dfbdd90e, Class_kf_f68d320f class_kf_f68d320f, Class_ld_bb1690e1 class_ld_bb1690e1, Class_mG_52c8d386 class_mG_52c8d386, Class_la_8f67ae40 class_la_8f67ae40, AbstractTexture abstractTexture, boolean bl, float f5, float f6, float f7, float f8, float f9, float f10, float f11, float f12, float f13, float f14, float f15) {
        this.xSQbY = matrix3x2fStack;
        this.egCsl = f;
        this.TDmPu = f2;
        this.dBKFM = f3;
        this.HmcPi = f4;
        this.eaLNK = class_kd_dfbdd90e;
        this.DnKLZ = class_kf_f68d320f;
        this.rRoDO = class_ld_bb1690e1;
        this.FVntd = class_mG_52c8d386;
        this.itKud = class_la_8f67ae40;
        this.WEuvT = abstractTexture;
        this.fUfva = bl;
        this.eFXuw = f5;
        this.BhhVn = f6;
        this.GPlHN = f7;
        this.HhCMg = f8;
        this.vBJeR = f9;
        this.GWDND = f10;
        this.AltXm = f11;
        this.gvMEj = f12;
        this.mEQGi = f13;
        this.xwdNH = f14;
        this.ZvmaJ = f15;
    }

    static {
        msXQV = Class_gb_9d201141.aYR(-4971548628320570802L, 3183453657162230179L, MethodHandles.lookup().lookupClass()).a(109257558332503L);
        if (Class_jO_1924117a.bKy() == null) {
            Class_jO_1924117a.bKx("wC2Us");
        }
    }

    public float bKw() {
        return this.ZvmaJ;
    }

    public boolean bJG() {
        long l = msXQV ^ 0x300EE9E6B3A3L;
        return this.itKud != null;
    }

    public boolean bJH() {
        long l = msXQV ^ 0x2F36DFFAD6B2L;
        return this.WEuvT != null;
    }

    public static Class_jO_tZ_935a142d bJI(Matrix3x2fStack matrix3x2fStack, double d, double d2, double d3, double d4) {
        return Class_jO_1924117a.bJZ().dqc(matrix3x2fStack).dqd((float)d).dqe((float)d2).dqf((float)d3).dqg((float)d4);
    }

    public Class_ld_bb1690e1 bKh() {
        return this.rRoDO;
    }

    public float bKd() {
        return this.dBKFM;
    }

    public float bKe() {
        return this.HmcPi;
    }

    public Matrix3x2fStack bKa() {
        return this.xSQbY;
    }

    public float bKt() {
        return this.gvMEj;
    }

    public float bKu() {
        return this.mEQGi;
    }

    public AbstractTexture bKk() {
        return this.WEuvT;
    }

    public Class_mG_52c8d386 bKi() {
        return this.FVntd;
    }

    public float bKm() {
        return this.eFXuw;
    }

    public float bKb() {
        return this.egCsl;
    }

    public float bKc() {
        return this.TDmPu;
    }

    public float bKv() {
        return this.xwdNH;
    }

    public Class_la_8f67ae40 bKj() {
        return this.itKud;
    }

    public float bKr() {
        return this.GWDND;
    }

    private static boolean bJN() {
        return false;
    }

    private static MatchException bKz(MatchException matchException) {
        return matchException;
    }

    private static float bJW() {
        return 0.0f;
    }

    private static float bJX() {
        return 1.0f;
    }

    private static float bJP() {
        return 0.75f;
    }

    private static float bJQ() {
        return 1.0f;
    }

    private static Class_mG_52c8d386 bJM() {
        return Class_mG_52c8d386.hoGuU;
    }

    public Class_kf_f68d320f bKg() {
        return this.DnKLZ;
    }

    public float bKo() {
        return this.GPlHN;
    }

    private static float bJU() {
        return 0.5f;
    }

    private static float bJT() {
        return 0.0f;
    }

    public static void bKx(String string) {
        IJQZt = string;
    }

    private static Class_kf_f68d320f bJK() {
        return Class_kf_f68d320f.viqyh;
    }

    private static float bJV() {
        return 0.0f;
    }

    private static float bJR() {
        return 7.0f;
    }

    private static float bJY() {
        return 1.0f;
    }

    private static float bJO() {
        return 0.75f;
    }

    public float bKp() {
        return this.HhCMg;
    }

    public float bKs() {
        return this.AltXm;
    }

    public float bKn() {
        return this.BhhVn;
    }

    public static String bKy() {
        return IJQZt;
    }

    private static Class_kd_dfbdd90e bJJ() {
        return Class_kd_dfbdd90e.AhlXN;
    }

    public static Class_jO_tZ_935a142d bJZ() {
        return new Class_jO_tZ_935a142d();
    }

    public boolean bKl() {
        return this.fUfva;
    }

    private static Class_ld_bb1690e1 bJL() {
        return Class_ld_bb1690e1.NONE;
    }

    public float bKq() {
        return this.vBJeR;
    }

    public Class_kd_dfbdd90e bKf() {
        return this.eaLNK;
    }

    private static float bJS() {
        return 0.0f;
    }
}

