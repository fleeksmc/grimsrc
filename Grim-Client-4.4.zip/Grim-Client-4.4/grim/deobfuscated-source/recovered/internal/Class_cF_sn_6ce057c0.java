/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_jg_tJ_fb687149;

class Class_cF_sn_6ce057c0 {
    static final int[] riatK = new int[Class_jg_tJ_fb687149.values().length];
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        try {
            Class_cF_sn_6ce057c0.riatK[Class_jg_tJ_fb687149.frJIr.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class_cF_sn_6ce057c0.riatK[Class_jg_tJ_fb687149.OCdZM.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

