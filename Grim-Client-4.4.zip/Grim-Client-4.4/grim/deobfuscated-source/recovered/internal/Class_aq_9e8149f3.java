/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_aq_9e8149f3
extends Class_az_a4990dcf {
    private final String novSO;
    private final String hqfHJ;
    private Class_lq_87a74641 ertCr;
    private Class_lq_87a74641 LlHzp;
    private float YzKwy;
    private final Class_rk_bf8630d1 nAFOY;
    private static long JIlVW;
    private static long KYKwJ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aq_9e8149f3(String string, String string2) {
        long l = JIlVW ^ 0x19A00CD3D8B6L;
        this.ertCr = Class_lE_06fbe260.WTzbi.bYM(11.0f);
        this.LlHzp = Class_lE_06fbe260.joxgd.bYM(8.0f);
        this.YzKwy = 15.0f;
        this.nAFOY = new Class_rk_bf8630d1((int)KYKwJ).dhs(Class_rj_b691f4f7.UPXqT);
        this.novSO = string;
        this.hqfHJ = string2;
    }

    static {
        NativeLoader.doInit(Class_aq_9e8149f3.class);
        Class_aq_9e8149f3._767d8839a68e2c6e03076628098ed797();
    }

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    public native void qB();

    private static native void _767d8839a68e2c6e03076628098ed797();

    public native Class_aq_9e8149f3 qE(float var1);

    public native Class_aq_9e8149f3 qD(Class_lq_87a74641 var1);

    public native Class_aq_9e8149f3 qC(Class_lq_87a74641 var1);
}

