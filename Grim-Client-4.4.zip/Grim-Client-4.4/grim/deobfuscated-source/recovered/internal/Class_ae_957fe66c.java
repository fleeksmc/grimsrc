/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_ad_d4e95a2c;
import recovered.internal.Class_ae_rP_6c7ebb3c;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_ae_957fe66c
extends Class_az_a4990dcf {
    private static float xUOkU = 12.0f;
    protected final Class_rk_bf8630d1 qOjgZ;
    private final Class_rk_bf8630d1 CtXob;
    private final String RcMBn;
    private final Class_az_a4990dcf oXzPE;
    private final List<Class_ae_rP_6c7ebb3c> fTIag;
    private final List<Class_ae_rP_6c7ebb3c> fOcNI;
    private final Class_ad_d4e95a2c HekHN;
    private final int Vfhfy;
    private static long FvIcS;
    private static long[] dPHRz;
    private static Integer[] GEApw;
    private static Map ICUMP;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ae_957fe66c(String string, Class_az_a4990dcf class_az_a4990dcf, String string2, List<Class_ae_rP_6c7ebb3c> list) {
        long l = FvIcS ^ 0x33386617A5DFL;
        this.qOjgZ = new Class_rk_bf8630d1((int)Class_ae_957fe66c.na("f", (int)23141, (long)(0xB2B32A331261E11L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.CtXob = new Class_rk_bf8630d1((int)Class_ae_957fe66c.na("f", (int)1796, (long)(0x36C8F8F4BE5F4373L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.fTIag = new ArrayList<Class_ae_rP_6c7ebb3c>();
        this.fOcNI = new ArrayList<Class_ae_rP_6c7ebb3c>();
        this.RcMBn = string;
        this.oXzPE = class_az_a4990dcf;
        this.fTIag.addAll(list);
        this.HekHN = new Class_ad_d4e95a2c(Class_lE_06fbe260.joxgd.bYM(7.0f));
        this.HekHN.lZ(string2);
        this.HekHN.me((int)Class_ae_957fe66c.na("f", (int)28611, (long)(0x280C40E172A7ABB6L ^ l)));
        this.HekHN.mg(this::mS);
        this.Vfhfy = (int)Class_ae_957fe66c.na("f", (int)25308, (long)(0x5316AFB73F80A6AAL ^ l));
        this.mS();
    }

    static {
        NativeLoader.doInit(Class_ae_957fe66c.class);
        Class_ae_957fe66c._ff993d37bc17c03e3f54fc32a318cd99();
    }

    @Override
    public native float dn();

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean dm(int var1, int var2, int var3);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private static native CallSite na(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native void _ff993d37bc17c03e3f54fc32a318cd99();

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean eK(char var1);

    public native String mP();

    private native boolean mQ();

    private native float mT(int var1, float var2);

    private static native /* synthetic */ String mU(Class_ae_rP_6c7ebb3c var0);

    private native void mS();

    private static native /* synthetic */ int mV(String var0, int[] var1, Class_ae_rP_6c7ebb3c var2);

    private native Class_ae_rP_6c7ebb3c mR(String var1);

    private static native /* synthetic */ boolean mW(String var0, Class_ae_rP_6c7ebb3c var1);

    private static native MatchException mX(MatchException var0);

    private static native int mY(int var0, long var1);

    private static native int mZ(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public native Class_ae_957fe66c mO(String var1);
}

