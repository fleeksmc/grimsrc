/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.joml.Matrix3x2fStack
 */
package recovered.internal;

import org.joml.Matrix3x2fStack;
import recovered.internal.Class_jR_uc_98ee07c3;
import recovered.internal.Class_mG_52c8d386;

public class Class_jR_92e73d8b {
    private Matrix3x2fStack TuWdl;
    private float mKydf;
    private float iXUZY;
    private float SuDcj;
    private float dbElK;
    private float yFTcB;
    private float wuXmw;
    private float iqvtr;
    private float MdGcs;
    private Class_mG_52c8d386 CiMOa;
    private float BJIXk;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_jR_92e73d8b(Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, Class_mG_52c8d386 class_mG_52c8d386, float f9) {
        this.TuWdl = matrix3x2fStack;
        this.mKydf = f;
        this.iXUZY = f2;
        this.SuDcj = f3;
        this.dbElK = f4;
        this.yFTcB = f5;
        this.wuXmw = f6;
        this.iqvtr = f7;
        this.MdGcs = f8;
        this.CiMOa = class_mG_52c8d386;
        this.BJIXk = f9;
    }

    public float bLS() {
        return this.iXUZY;
    }

    public Class_mG_52c8d386 bLZ() {
        return this.CiMOa;
    }

    public float bLU() {
        return this.dbElK;
    }

    public Matrix3x2fStack bLQ() {
        return this.TuWdl;
    }

    public float bLW() {
        return this.wuXmw;
    }

    public float bLR() {
        return this.mKydf;
    }

    public float bLX() {
        return this.iqvtr;
    }

    public float bLT() {
        return this.SuDcj;
    }

    public float bMa() {
        return this.BJIXk;
    }

    public float bLY() {
        return this.MdGcs;
    }

    public static Class_jR_uc_98ee07c3 bLM(Matrix3x2fStack matrix3x2fStack, double d, double d2, double d3, double d4) {
        return Class_jR_92e73d8b.bLP().drA(matrix3x2fStack).drB((float)d).drC((float)d2).drD((float)d3).drE((float)d4);
    }

    private static float bLO() {
        return 0.75f;
    }

    private static Class_mG_52c8d386 bLN() {
        return Class_mG_52c8d386.hoGuU;
    }

    public float bLV() {
        return this.yFTcB;
    }

    public static Class_jR_uc_98ee07c3 bLP() {
        return new Class_jR_uc_98ee07c3();
    }
}

