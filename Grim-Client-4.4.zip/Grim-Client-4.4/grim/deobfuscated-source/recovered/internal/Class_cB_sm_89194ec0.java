/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.LinkedHashSet;
import java.util.Set;
import recovered.internal.Class_cB_67aec11c;

final class Class_cB_sm_89194ec0 {
    private final Set<Class_cB_67aec11c> vzghL = new LinkedHashSet<Class_cB_67aec11c>();
    private int Gkoov;
    private boolean oTCWD;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_cB_sm_89194ec0() {
    }
}

