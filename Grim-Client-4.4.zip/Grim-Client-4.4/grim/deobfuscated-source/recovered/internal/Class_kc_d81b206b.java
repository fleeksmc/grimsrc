/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.BufferBuilder
 *  org.joml.Matrix3x2fStack
 */
package recovered.internal;

import net.minecraft.client.render.BufferBuilder;
import org.joml.Matrix3x2fStack;
import recovered.internal.Class_la_8f67ae40;
import recovered.internal.Class_mG_52c8d386;

public interface Class_kc_d81b206b {
    public void uv_quad_region_color(BufferBuilder var1, Matrix3x2fStack var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10, Class_mG_52c8d386 var11);

    public void uv_quad(BufferBuilder var1, Matrix3x2fStack var2, float var3, float var4, float var5, float var6);

    public void quad(BufferBuilder var1, Matrix3x2fStack var2, float var3, float var4, float var5, float var6);

    public void quad_color(BufferBuilder var1, Matrix3x2fStack var2, float var3, float var4, float var5, float var6, Class_mG_52c8d386 var7);

    public void quad_color(BufferBuilder var1, Matrix3x2fStack var2, float var3, float var4, float var5, float var6, Class_la_8f67ae40 var7);

    public void uv_quad_color(BufferBuilder var1, Matrix3x2fStack var2, float var3, float var4, float var5, float var6, Class_mG_52c8d386 var7);
}

