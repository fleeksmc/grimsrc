/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.text.Style
 */
package recovered.internal;

import net.minecraft.text.Style;
import recovered.core.NativeLoader;

class Class_fS_sV_49fe6d13 {
    Style BmGPX;
    StringBuilder sQGRe = new StringBuilder();
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_fS_sV_49fe6d13(Style style) {
        this.BmGPX = style;
    }

    static {
        NativeLoader.doInit(Class_fS_sV_49fe6d13.class);
    }

    native int dpc();
}

