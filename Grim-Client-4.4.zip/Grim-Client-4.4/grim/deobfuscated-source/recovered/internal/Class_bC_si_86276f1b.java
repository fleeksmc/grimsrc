/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.model.PlayerEntityModel
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import recovered.internal.Class_bB_f304b0cf;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_pX_3bcb504f;
import recovered.internal.Class_pY_4f9ecc6b;

record Class_bC_si_86276f1b(Class_pY_4f9ecc6b emote) implements Class_pX_3bcb504f
{
    private static final long a = Class_gb_9d201141.aYR(1815704216569069388L, -7975721906260477380L, MethodHandles.lookup().lookupClass()).a(62026947645471L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    @Override
    public void apply(PlayerEntityModel playerEntityModel) {
        long l = a ^ 0x1A6DBEB4D848L;
        int[] nArray = Class_bB_f304b0cf.b();
        Class_pY_4f9ecc6b class_pY_4f9ecc6b = this.emote;
        if (nArray == null) {
            if (class_pY_4f9ecc6b == null) {
                return;
            }
            class_pY_4f9ecc6b = this.emote;
        }
        class_pY_4f9ecc6b.applyPreviewKeyframe(playerEntityModel);
    }

    private static MatchException a(MatchException matchException) {
        return matchException;
    }

    @Override
    public boolean finished() {
        return false;
    }
}

