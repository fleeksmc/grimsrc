/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.function.Supplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_aR_f155c393;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bd_8faff9cb;
import recovered.internal.Class_f_2512a74f;
import recovered.internal.Class_f_rF_b8400651;
import recovered.internal.Class_g_rG_db7baf92;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_h_d59300d0;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_i_a489cc15;
import recovered.internal.Class_k_759fe111;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;

public class Class_g_bd7b3df3 {
    private static Class_g_bd7b3df3 HbRlZ;
    private final Class_az_a4990dcf vSqxH = new Class_g_rG_db7baf92(this).sS(true);
    private Class_az_a4990dcf HrPEm;
    private Class_az_a4990dcf XTXbB;
    private Runnable jywVM = () -> {};
    private static int[] itovx;
    private static final long uaqcq;
    private static final long GMDRM;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    static {
        uaqcq = Class_gb_9d201141.aYR(-2937396542381063339L, -4243365711051065170L, MethodHandles.lookup().lookupClass()).a(83042438305568L);
        long l = uaqcq ^ 0x4FE7467EEADCL;
        Class_g_bd7b3df3.bz(new int[5]);
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                long l2 = 3746660340161907318L;
                byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
                GMDRM = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    public <T extends Class_az_a4990dcf> Optional<T> ba(Class<T> clazz) {
        long l = uaqcq ^ 0x6A1DFE027C63L;
        List<T> list = this.aY(clazz);
        int[] nArray = Class_g_bd7b3df3.bA();
        List<T> list2 = list;
        if (nArray != null) {
            if (list2.isEmpty()) {
                return Optional.empty();
            }
            list2 = list.getFirst();
        }
        return Optional.of((Class_az_a4990dcf)((Object)list2));
    }

    public <T extends Class_az_a4990dcf> void bb(Class<T> clazz) {
        long l = uaqcq ^ 0x742CB8213EL;
        Iterator<T> iterator = this.aY(clazz).iterator();
        int[] nArray = Class_g_bd7b3df3.bA();
        while (iterator.hasNext()) {
            block9: {
                Class_az_a4990dcf class_az_a4990dcf;
                Class_az_a4990dcf class_az_a4990dcf2;
                block8: {
                    boolean bl;
                    Class_az_a4990dcf class_az_a4990dcf3;
                    block7: {
                        class_az_a4990dcf3 = (Class_az_a4990dcf)iterator.next();
                        bl = class_az_a4990dcf3 instanceof Class_aj_95d0a719;
                        if (nArray != null) {
                            if (bl) {
                                class_az_a4990dcf2 = (Class_aj_95d0a719)class_az_a4990dcf3;
                                ((Class_aj_95d0a719)class_az_a4990dcf2).oj(false);
                            }
                            bl = class_az_a4990dcf3 instanceof Class_bd_8faff9cb;
                        }
                        if (nArray == null) break block7;
                        if (bl) {
                            class_az_a4990dcf2 = (Class_bd_8faff9cb)class_az_a4990dcf3;
                            ((Class_bd_8faff9cb)class_az_a4990dcf2).Cg(false);
                        }
                        class_az_a4990dcf = class_az_a4990dcf3;
                        if (nArray == null) break block8;
                        bl = class_az_a4990dcf instanceof Class_aR_f155c393;
                    }
                    if (!bl) break block9;
                    class_az_a4990dcf = class_az_a4990dcf3;
                }
                class_az_a4990dcf2 = (Class_aR_f155c393)class_az_a4990dcf;
                ((Class_aR_f155c393)class_az_a4990dcf2).yg(false);
            }
            if (nArray != null) continue;
        }
    }

    private void be(Class_f_2512a74f class_f_2512a74f, Class_az_a4990dcf class_az_a4990dcf) {
        Class_az_a4990dcf class_az_a4990dcf2;
        boolean bl;
        int n;
        int[] nArray;
        List<Class_az_a4990dcf> list;
        block6: {
            long l = uaqcq ^ 0x4AEDE723469DL;
            list = this.bg(class_az_a4990dcf);
            int[] nArray2 = Class_g_bd7b3df3.bA();
            class_f_2512a74f.aB(class_az_a4990dcf);
            nArray = nArray2;
            for (n = list.size() - 1; n >= 1; --n) {
                bl = class_f_2512a74f.az();
                if (nArray != null && nArray != null) {
                    if (bl) break;
                    class_az_a4990dcf2 = list.get(n);
                    class_f_2512a74f.aA(Class_i_a489cc15.YdJtr);
                    class_f_2512a74f.aC(class_az_a4990dcf2);
                    class_az_a4990dcf2.sy(class_f_2512a74f);
                    if (nArray != null) continue;
                }
                break block6;
            }
            bl = class_f_2512a74f.az();
        }
        if (nArray != null) {
            if (!bl) {
                class_f_2512a74f.aA(Class_i_a489cc15.nKqnf);
                class_f_2512a74f.aC(class_az_a4990dcf);
                class_az_a4990dcf.sz(class_f_2512a74f);
            }
            bl = true;
        }
        for (n = (int)((v87831) ? 1 : 0); n < list.size(); ++n) {
            Object object = class_f_2512a74f;
            if (nArray != null) {
                if (((Class_f_2512a74f)object).az()) break;
                object = list.get(n);
            }
            class_az_a4990dcf2 = (Class_az_a4990dcf)object;
            class_f_2512a74f.aA(Class_i_a489cc15.pEktq);
            class_f_2512a74f.aC(class_az_a4990dcf2);
            class_az_a4990dcf2.sA(class_f_2512a74f);
            if (nArray != null) continue;
        }
    }

    private boolean bi(Class_f_2512a74f class_f_2512a74f, Class_az_a4990dcf class_az_a4990dcf) {
        boolean bl;
        block7: {
            long l = uaqcq ^ 0x3BD9680DD743L;
            int[] nArray = Class_g_bd7b3df3.bA();
            if (class_f_2512a74f.ap() != Class_f_rF_b8400651.feLzE) {
                return false;
            }
            List<Class_az_a4990dcf> list = this.bp();
            for (int i = list.size() - 1; i >= 0; --i) {
                Class_az_a4990dcf class_az_a4990dcf2 = list.get(i);
                bl = this.bl(class_az_a4990dcf2, class_az_a4990dcf);
                if (nArray != null) {
                    boolean bl2;
                    if (nArray != null) {
                        if (bl) {
                            return false;
                        }
                        bl2 = class_az_a4990dcf2.ty();
                    }
                    if (nArray != null) {
                        if (bl2) continue;
                        bl2 = class_az_a4990dcf2.hc(class_f_2512a74f.aq(), class_f_2512a74f.ar());
                    }
                    if (nArray != null) {
                        if (!bl2) continue;
                        class_az_a4990dcf2.dk(class_f_2512a74f.aq(), class_f_2512a74f.ar(), class_f_2512a74f.as());
                        class_f_2512a74f.ao();
                        bl2 = true;
                    }
                    return bl2;
                }
                break block7;
            }
            bl = false;
        }
        return bl;
    }

    public Runnable bv() {
        return this.jywVM;
    }

    private void bo(Class_lC_5322e8cf class_lC_5322e8cf) {
        long l = uaqcq ^ 0x449D8A903EB1L;
        Iterator<Class_az_a4990dcf> iterator = new ArrayList<Class_az_a4990dcf>(this.vSqxH.tv().cmj()).iterator();
        int[] nArray = Class_g_bd7b3df3.bA();
        while (iterator.hasNext()) {
            Class_az_a4990dcf class_az_a4990dcf = iterator.next();
            boolean bl = class_az_a4990dcf.oi();
            boolean bl2 = class_az_a4990dcf instanceof Class_k_759fe111;
            if (nArray != null) {
                if (bl2) {
                    Class_k_759fe111 class_k_759fe111 = (Class_k_759fe111)class_az_a4990dcf;
                    bl = class_k_759fe111.bW(class_lC_5322e8cf);
                }
                bl2 = bl;
            }
            if (bl2) {
                this.aJ(class_az_a4990dcf);
            }
            if (nArray != null) continue;
        }
    }

    private List<Class_az_a4990dcf> bp() {
        ArrayList<Class_az_a4990dcf> arrayList = new ArrayList<Class_az_a4990dcf>(this.vSqxH.tv().cmj());
        arrayList.sort(Class_az_a4990dcf.VjGAm);
        return arrayList;
    }

    public Class_az_a4990dcf bt() {
        return this.HrPEm;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     */
    private boolean bc(Class_f_2512a74f var1_1) {
        var2_2 = Class_g_bd7b3df3.uaqcq ^ 91145099016606L;
        var5_3 = Class_g_bd7b3df3.HbRlZ;
        var4_4 = Class_g_bd7b3df3.bA();
        Class_g_bd7b3df3.HbRlZ = this;
        try {
            block28: {
                block27: {
                    block24: {
                        block25: {
                            block26: {
                                v0 = this;
                                if (var4_4 == null) ** GOTO lbl12
                                if (v0.XTXbB != null) {
                                    v1 = this.XTXbB;
                                } else {
                                    v0 = this;
lbl12:
                                    // 2 sources

                                    v1 = v0.aM(var1_1.aq(), var1_1.ar());
                                }
                                var6_5 = v1;
                                v2 = this.XTXbB;
                                if (var4_4 != null) {
                                    if (v2 == null) {
                                        v3 = this;
                                        if (var4_4 != null) {
                                            if (v3.bi(var1_1, var6_5)) {
                                                var7_6 = true;
                                                return var7_6;
                                            } else {
                                                ** GOTO lbl-1000
                                            }
                                        }
                                    } else lbl-1000:
                                    // 3 sources

                                    {
                                        v3 = this;
                                    }
                                    v2 = v3.XTXbB;
                                }
                                if (var4_4 == null) break block24;
                                if (v2 != null) break block25;
                                v4 = this.bj(var1_1, var6_5);
                                if (var4_4 == null) break block26;
                                if (!v4) break block25;
                                v4 = true;
                            }
                            var7_7 = v4;
                            return var7_7;
                        }
                        v2 = var6_5;
                    }
                    if (var4_4 != null && v2 == null) {
                        v2 = var6_5 = this.bh(var1_1.aq(), var1_1.ar());
                    }
                    if (var1_1.ap() != Class_f_rF_b8400651.CjcqV) break block27;
                    v5 = this.XTXbB;
                    if (var4_4 == null) break block28;
                    if (v5 == null) {
                        this.bn(var6_5);
                    }
                }
                v5 = var6_5;
            }
            if (v5 == null) {
                var7_8 = false;
                return var7_8;
            }
            this.be(var1_1, var6_5);
            var7_9 = var1_1.az();
            return var7_9;
        }
        finally {
            Class_g_bd7b3df3.HbRlZ = var5_3;
        }
    }

    private <T extends Class_az_a4990dcf> void br(Class_az_a4990dcf class_az_a4990dcf, Class<T> clazz, List<T> list) {
        int[] nArray;
        block4: {
            Class_az_a4990dcf class_az_a4990dcf2;
            Class<T> clazz2;
            block3: {
                long l = uaqcq ^ 0x3DF5E657B9C7L;
                nArray = Class_g_bd7b3df3.bA();
                clazz2 = clazz;
                class_az_a4990dcf2 = class_az_a4990dcf;
                if (nArray == null) break block3;
                if (!clazz2.isInstance(class_az_a4990dcf2)) break block4;
                clazz2 = clazz;
                class_az_a4990dcf2 = class_az_a4990dcf;
            }
            Class_az_a4990dcf class_az_a4990dcf3 = (Class_az_a4990dcf)clazz2.cast(class_az_a4990dcf2);
            list.add(class_az_a4990dcf3);
        }
        for (Class_az_a4990dcf class_az_a4990dcf4 : class_az_a4990dcf.tv().cmj()) {
            this.br(class_az_a4990dcf4, clazz, list);
            if (nArray != null) continue;
        }
    }

    private <T extends Class_az_a4990dcf> void bq(Class_az_a4990dcf class_az_a4990dcf, Class<T> clazz, Predicate<T> predicate, List<T> list) {
        Class_az_a4990dcf class_az_a4990dcf2;
        int[] nArray;
        block7: {
            block6: {
                Class_az_a4990dcf class_az_a4990dcf3;
                Class<T> clazz2;
                block5: {
                    long l = uaqcq ^ 0x16AE3FBE9F59L;
                    nArray = Class_g_bd7b3df3.bA();
                    clazz2 = clazz;
                    class_az_a4990dcf3 = class_az_a4990dcf;
                    if (nArray == null) break block5;
                    if (!clazz2.isInstance(class_az_a4990dcf3)) break block6;
                    clazz2 = clazz;
                    class_az_a4990dcf3 = class_az_a4990dcf;
                }
                class_az_a4990dcf2 = (Class_az_a4990dcf)clazz2.cast(class_az_a4990dcf3);
                if (nArray == null) break block7;
                Class_az_a4990dcf class_az_a4990dcf4 = class_az_a4990dcf2;
                if (predicate.test(class_az_a4990dcf4)) {
                    list.add(class_az_a4990dcf4);
                }
            }
            class_az_a4990dcf2 = class_az_a4990dcf;
        }
        for (Class_az_a4990dcf class_az_a4990dcf5 : class_az_a4990dcf2.tv().cmj()) {
            this.bq(class_az_a4990dcf5, clazz, predicate, list);
            if (nArray != null) continue;
        }
    }

    public Class_az_a4990dcf bs() {
        return this.vSqxH;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private boolean bd(Class_h_d59300d0 class_h_d59300d0) {
        int n;
        block7: {
            long l = uaqcq ^ 0x52846033B347L;
            Class_g_bd7b3df3 class_g_bd7b3df3 = HbRlZ;
            int[] nArray = Class_g_bd7b3df3.bA();
            HbRlZ = this;
            try {
                List<Class_az_a4990dcf> list = this.bp();
                int n2 = list.size() - 1;
                while (n2 >= 0) {
                    block10: {
                        block9: {
                            boolean bl;
                            block8: {
                                Class_az_a4990dcf class_az_a4990dcf = list.get(n2);
                                n = class_az_a4990dcf.ty();
                                if (nArray == null) break block7;
                                if (nArray == null) break block8;
                                if (n != 0 && nArray != null) break block9;
                                this.bf(class_h_d59300d0, class_az_a4990dcf);
                                if (nArray == null) break block10;
                                bl = class_h_d59300d0.bN();
                            }
                            if (bl) {
                                boolean bl2 = true;
                                HbRlZ = class_g_bd7b3df3;
                                return bl2;
                            }
                        }
                        --n2;
                    }
                    if (nArray != null) continue;
                }
                n2 = 0;
                HbRlZ = class_g_bd7b3df3;
                n = n2;
            }
            catch (Throwable throwable) {
                HbRlZ = class_g_bd7b3df3;
                throw throwable;
            }
        }
        return n != 0;
    }

    private Class_az_a4990dcf bh(double d, double d2) {
        long l = uaqcq ^ 0x7F71B8998750L;
        List<Class_az_a4990dcf> list = this.bp();
        int[] nArray = Class_g_bd7b3df3.bA();
        int n = list.size() - 1;
        while (n >= 0) {
            block3: {
                block4: {
                    Class_az_a4990dcf class_az_a4990dcf;
                    block5: {
                        Class_az_a4990dcf class_az_a4990dcf2 = list.get(n);
                        if (nArray == null) break block3;
                        if (class_az_a4990dcf2.ty()) break block4;
                        class_az_a4990dcf = class_az_a4990dcf2;
                        if (nArray == null) break block5;
                        if (!class_az_a4990dcf.hc(d, d2)) break block4;
                        class_az_a4990dcf = class_az_a4990dcf2;
                    }
                    return class_az_a4990dcf;
                }
                --n;
            }
            if (nArray != null) continue;
        }
        return null;
    }

    private List<Class_az_a4990dcf> bg(Class_az_a4990dcf class_az_a4990dcf) {
        ArrayList<Class_az_a4990dcf> arrayList;
        block2: {
            long l = uaqcq ^ 0x1B6431B03634L;
            ArrayList<Class_az_a4990dcf> arrayList2 = new ArrayList<Class_az_a4990dcf>();
            int[] nArray = Class_g_bd7b3df3.bA();
            for (Class_az_a4990dcf class_az_a4990dcf2 = class_az_a4990dcf; class_az_a4990dcf2 != null; class_az_a4990dcf2 = class_az_a4990dcf2.tu()) {
                arrayList = arrayList2;
                if (nArray != null) {
                    arrayList.add(class_az_a4990dcf2);
                    if (nArray != null) continue;
                }
                break block2;
            }
            arrayList = arrayList2;
        }
        return arrayList;
    }

    private void bf(Class_h_d59300d0 class_h_d59300d0, Class_az_a4990dcf class_az_a4990dcf) {
        Class_az_a4990dcf class_az_a4990dcf2;
        boolean bl;
        int n;
        int[] nArray;
        List<Class_az_a4990dcf> list;
        block6: {
            long l = uaqcq ^ 0x6A4ABC0DD38L;
            list = this.bg(class_az_a4990dcf);
            nArray = Class_g_bd7b3df3.bA();
            class_h_d59300d0.bP(class_az_a4990dcf);
            for (n = list.size() - 1; n >= 1; --n) {
                bl = class_h_d59300d0.bN();
                if (nArray != null && nArray != null) {
                    if (bl) break;
                    class_az_a4990dcf2 = list.get(n);
                    class_h_d59300d0.bO(Class_i_a489cc15.YdJtr);
                    class_h_d59300d0.bQ(class_az_a4990dcf2);
                    class_az_a4990dcf2.sB(class_h_d59300d0);
                    if (nArray != null) continue;
                }
                break block6;
            }
            bl = class_h_d59300d0.bN();
        }
        if (nArray != null) {
            if (!bl) {
                class_h_d59300d0.bO(Class_i_a489cc15.nKqnf);
                class_h_d59300d0.bQ(class_az_a4990dcf);
                class_az_a4990dcf.sC(class_h_d59300d0);
            }
            bl = true;
        }
        for (n = (int)((v89186) ? 1 : 0); n < list.size(); ++n) {
            Object object = class_h_d59300d0;
            if (nArray != null) {
                if (((Class_h_d59300d0)object).bN()) break;
                object = list.get(n);
            }
            class_az_a4990dcf2 = (Class_az_a4990dcf)object;
            class_h_d59300d0.bO(Class_i_a489cc15.pEktq);
            class_h_d59300d0.bQ(class_az_a4990dcf2);
            class_az_a4990dcf2.sD(class_h_d59300d0);
            if (nArray != null) continue;
        }
    }

    public Class_az_a4990dcf bu() {
        return this.XTXbB;
    }

    private void bn(Class_az_a4990dcf class_az_a4990dcf) {
        block8: {
            Class_az_a4990dcf class_az_a4990dcf2;
            block7: {
                long l = uaqcq ^ 0xFE5B756DBBBL;
                int[] nArray = Class_g_bd7b3df3.bA();
                class_az_a4990dcf2 = this.HrPEm;
                if (nArray != null) {
                    if (class_az_a4990dcf2 == class_az_a4990dcf) {
                        return;
                    }
                    class_az_a4990dcf2 = this.HrPEm;
                }
                if (nArray != null) {
                    if (class_az_a4990dcf2 != null) {
                        this.HrPEm.sx();
                    }
                    class_az_a4990dcf2 = this.HrPEm = class_az_a4990dcf;
                }
                if (nArray == null) break block7;
                if (class_az_a4990dcf2 == null) break block8;
                class_az_a4990dcf2 = this.HrPEm;
            }
            class_az_a4990dcf2.sw();
        }
    }

    public static void bz(int[] nArray) {
        itovx = nArray;
    }

    private static MatchException bB(MatchException matchException) {
        return matchException;
    }

    private boolean bj(Class_f_2512a74f class_f_2512a74f, Class_az_a4990dcf class_az_a4990dcf) {
        boolean bl;
        block7: {
            long l = uaqcq ^ 0x47407270024L;
            int[] nArray = Class_g_bd7b3df3.bA();
            if (class_f_2512a74f.ap() != Class_f_rF_b8400651.feLzE) {
                return false;
            }
            List<Class_aj_95d0a719> list = this.aY(Class_aj_95d0a719.class);
            for (int i = list.size() - 1; i >= 0; --i) {
                Class_aj_95d0a719 class_aj_95d0a719 = list.get(i);
                bl = this.bk(class_aj_95d0a719);
                if (nArray != null) {
                    boolean bl2;
                    if (nArray != null) {
                        if (!bl && nArray != null) continue;
                        bl2 = this.bl(class_aj_95d0a719, class_az_a4990dcf);
                    }
                    if (nArray != null) {
                        if (bl2) {
                            return false;
                        }
                        bl2 = class_aj_95d0a719.dk(class_f_2512a74f.aq(), class_f_2512a74f.ar(), class_f_2512a74f.as());
                    }
                    if (nArray != null) {
                        if (!bl2) continue;
                        class_f_2512a74f.ao();
                        bl2 = true;
                    }
                    return bl2;
                }
                break block7;
            }
            bl = false;
        }
        return bl;
    }

    public static int[] bA() {
        return itovx;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean bk(Class_aj_95d0a719 class_aj_95d0a719) {
        long l = uaqcq ^ 0x4425B48A95EBL;
        int[] nArray = Class_g_bd7b3df3.bA();
        int n = class_aj_95d0a719.tz();
        if (nArray != null) {
            if (n != 0) return 0 != 0;
            n = class_aj_95d0a719.tt();
        }
        if (nArray == null) return n != 0;
        if (n != (int)GMDRM) return 0 != 0;
        return 1 != 0;
    }

    private void bm(double d, double d2) {
        long l = uaqcq ^ 0x7FBF8AA2F4DAL;
        int[] nArray = Class_g_bd7b3df3.bA();
        Class_g_bd7b3df3 class_g_bd7b3df3 = this;
        if (nArray != null) {
            if (class_g_bd7b3df3.XTXbB != null) {
                return;
            }
            class_g_bd7b3df3 = this;
        }
        class_g_bd7b3df3.bn(this.aM(d, d2));
    }

    private boolean bl(Class_az_a4990dcf class_az_a4990dcf, Class_az_a4990dcf class_az_a4990dcf2) {
        long l = uaqcq ^ 0x32EE0BC710A1L;
        Class_az_a4990dcf class_az_a4990dcf3 = class_az_a4990dcf2;
        int[] nArray = Class_g_bd7b3df3.bA();
        while (class_az_a4990dcf3 != null) {
            Class_az_a4990dcf class_az_a4990dcf4 = class_az_a4990dcf3;
            if (nArray != null) {
                if (class_az_a4990dcf4 == class_az_a4990dcf) {
                    return true;
                }
                class_az_a4990dcf4 = class_az_a4990dcf3 = class_az_a4990dcf3.tu();
            }
            if (nArray != null) continue;
        }
        return false;
    }

    public <T extends Class_az_a4990dcf> List<T> aY(Class<T> clazz) {
        ArrayList<Class_az_a4990dcf> arrayList = new ArrayList<Class_az_a4990dcf>();
        this.br(this.vSqxH, clazz, arrayList);
        arrayList.sort(Class_az_a4990dcf.VjGAm);
        return arrayList;
    }

    public <T extends Class_az_a4990dcf> Optional<T> aZ(Class<T> clazz, Predicate<T> predicate) {
        long l = uaqcq ^ 0x633BB68A7C72L;
        List<T> list = this.aY(clazz);
        int n = list.size() - 1;
        int[] nArray = Class_g_bd7b3df3.bA();
        while (n >= 0) {
            Class_az_a4990dcf class_az_a4990dcf = (Class_az_a4990dcf)list.get(n);
            if (nArray != null) {
                if (predicate.test(class_az_a4990dcf)) {
                    return Optional.of(class_az_a4990dcf);
                }
                --n;
            }
            if (nArray != null) continue;
        }
        return Optional.empty();
    }

    public <T extends Class_az_a4990dcf> T aX(Class<T> clazz, Supplier<T> supplier) {
        long l = uaqcq ^ 0x4002A9F134FCL;
        Optional<Class_az_a4990dcf> optional = this.aZ(clazz, class_az_a4990dcf -> true);
        int[] nArray = Class_g_bd7b3df3.bA();
        Optional<Class_az_a4990dcf> optional2 = optional;
        if (nArray != null) {
            if (optional2.isPresent()) {
                return (T)this.aF(optional.get());
            }
            optional2 = supplier.get();
        }
        Class_az_a4990dcf class_az_a4990dcf2 = (Class_az_a4990dcf)((Object)optional2);
        return (T)this.aF(class_az_a4990dcf2);
    }

    public static Class_g_bd7b3df3 aD() {
        return HbRlZ;
    }

    public void aU(Class_az_a4990dcf class_az_a4990dcf) {
        block0: {
            long l = uaqcq ^ 0x693572EB991AL;
            if (class_az_a4990dcf == null) break block0;
            this.XTXbB = class_az_a4990dcf;
        }
    }

    public void aW(Class_az_a4990dcf class_az_a4990dcf) {
        block3: {
            block2: {
                long l = uaqcq ^ 0x540F070BD280L;
                int[] nArray = Class_g_bd7b3df3.bA();
                Class_g_bd7b3df3 class_g_bd7b3df3 = this;
                if (nArray == null) break block2;
                if (class_g_bd7b3df3.XTXbB != class_az_a4990dcf) break block3;
                class_g_bd7b3df3 = this;
            }
            class_g_bd7b3df3.XTXbB = null;
        }
    }

    public <T extends Class_az_a4990dcf> T aF(T t) {
        return this.aG(t, this.aI());
    }

    public boolean aO(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        boolean bl;
        block0: {
            long l = uaqcq ^ 0x7DAD1A8F0520L;
            bl = this.bc(Class_f_2512a74f.ak(d, d2, class_mA_32d8a5f2));
            int[] nArray = Class_g_bd7b3df3.bA();
            this.XTXbB = null;
            this.bm(d, d2);
            if (Class_iS_888f260e.bwL() != null) break block0;
            Class_g_bd7b3df3.bz(new int[2]);
        }
        return bl;
    }

    public Class_g_bd7b3df3 aV(Runnable runnable) {
        long l = uaqcq ^ 0x79CCCCBC76AL;
        int[] nArray = Class_g_bd7b3df3.bA();
        Runnable runnable2 = runnable;
        if (nArray != null) {
            runnable2 = runnable2 == null ? () -> {} : runnable;
        }
        this.jywVM = runnable2;
        return this;
    }

    public <T extends Class_az_a4990dcf> T aE(T t) {
        return this.aG(t, this.aH());
    }

    public boolean aN(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        return this.bc(Class_f_2512a74f.aj(d, d2, class_mA_32d8a5f2));
    }

    /*
     * Exception decompiling
     */
    public void aL(Class_lC_5322e8cf var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public boolean aQ(double d, double d2, double d3) {
        return this.bc(Class_f_2512a74f.am(d, d2, d3));
    }

    public boolean aT(char c) {
        return this.bd(Class_h_d59300d0.bD(c));
    }

    public boolean aP(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2, double d3, double d4) {
        return this.bc(Class_f_2512a74f.al(d, d2, class_mA_32d8a5f2, d3, d4));
    }

    public boolean aS(int n, int n2, int n3) {
        return this.bd(Class_h_d59300d0.bC(n, n2, n3));
    }

    public int aH() {
        int n;
        block2: {
            long l = uaqcq ^ 0x2DEDFB543A5BL;
            int n2 = 0;
            int[] nArray = Class_g_bd7b3df3.bA();
            for (Class_az_a4990dcf class_az_a4990dcf : this.vSqxH.tv().cmj()) {
                n = Math.max(n2, class_az_a4990dcf.sN());
                if (nArray != null) {
                    n2 = n;
                    if (nArray != null) continue;
                }
                break block2;
            }
            n = n2;
        }
        return n;
    }

    public <T extends Class_az_a4990dcf> T aG(T t, int n) {
        long l = uaqcq ^ 0x133BCED9745FL;
        int[] nArray = Class_g_bd7b3df3.bA();
        T t2 = t;
        if (nArray != null) {
            if (t2 == null) {
                return null;
            }
            t.sO(n);
            this.vSqxH.sI(t);
            t2 = t;
        }
        return t2;
    }

    public int aI() {
        return this.aH() + 1;
    }

    public void aJ(Class_az_a4990dcf class_az_a4990dcf) {
        this.vSqxH.sJ(class_az_a4990dcf);
    }

    public void aK() {
        this.vSqxH.sK();
        this.HrPEm = null;
        this.XTXbB = null;
    }

    public Class_az_a4990dcf aM(double d, double d2) {
        return this.vSqxH.sF(d, d2);
    }

    public boolean aR(double d, double d2) {
        return this.bc(Class_f_2512a74f.an(d, d2));
    }
}

