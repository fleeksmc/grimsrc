/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderPass
 *  com.mojang.blaze3d.systems.RenderSystem
 *  org.joml.Matrix3x2fStack
 *  org.joml.Matrix3x2fc
 */
package recovered.internal;

import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import java.lang.invoke.MethodHandles;
import java.util.ArrayDeque;
import java.util.Deque;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix3x2fc;
import recovered.core.ClientMain;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jG_tW_e25aac65;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lT_411dd062;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_rm_d861be3b;

public final class Class_jG_69891630 {
    private static final Deque<Class_lc_b8480f87> tyoKy;
    private static final long AJNGy;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public static boolean bHY(Class_az_a4990dcf class_az_a4990dcf) {
        return Class_jG_69891630.bHX(class_az_a4990dcf.tr(), class_az_a4990dcf.ts(), class_az_a4990dcf.kN(), class_az_a4990dcf.dn());
    }

    public static boolean bHZ(Class_lC_5322e8cf class_lC_5322e8cf) {
        return Class_jG_69891630.bIa(class_lC_5322e8cf.cff(), class_lC_5322e8cf.cfg());
    }

    static {
        AJNGy = Class_gb_9d201141.aYR(-1063796139203356576L, -8906039374498815337L, MethodHandles.lookup().lookupClass()).a(172161209956373L);
        tyoKy = new ArrayDeque<Class_lc_b8480f87>();
    }

    public static void bHP() {
        tyoKy.clear();
        Class_jG_69891630.bHT();
    }

    public static void bHS(RenderPass renderPass) {
        long l = AJNGy ^ 0x7DDAADEBDDA3L;
        Class_jG_tW_e25aac65 class_jG_tW_e25aac65 = Class_jG_69891630.bHV();
        boolean bl = Class_jF_38b68c76.bHG();
        if (bl) {
            if (class_jG_tW_e25aac65 == null) {
                renderPass.disableScissor();
                return;
            }
            renderPass.enableScissor(class_jG_tW_e25aac65.x(), class_jG_tW_e25aac65.y(), class_jG_tW_e25aac65.width(), class_jG_tW_e25aac65.height());
        }
    }

    public static void bHI(Class_lC_5322e8cf class_lC_5322e8cf, Class_lc_b8480f87 class_lc_b8480f87) {
        Class_lc_b8480f87 class_lc_b8480f872 = new Class_lc_b8480f87(class_lc_b8480f87.bXF(), class_lc_b8480f87.bXG(), class_lc_b8480f87.bXH(), class_lc_b8480f87.bXI()).bXB(class_lC_5322e8cf.cfd());
        Class_jG_69891630.bHQ(class_lc_b8480f872);
    }

    public static void bHN() {
        block4: {
            block3: {
                Object object;
                boolean bl;
                block2: {
                    boolean bl2;
                    block1: {
                        long l = AJNGy ^ 0x1C77A5E522A9L;
                        bl = Class_jF_38b68c76.bHG();
                        bl2 = tyoKy.isEmpty();
                        if (!bl) break block1;
                        if (!bl2) {
                            tyoKy.pop();
                        }
                        object = tyoKy;
                        if (!bl) break block2;
                        bl2 = object.isEmpty();
                    }
                    if (bl2) break block3;
                    object = tyoKy.peek();
                }
                Class_jG_69891630.bHR((Class_lc_b8480f87)object);
                if (bl) break block4;
            }
            Class_jG_69891630.bHT();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean bHX(float f, float f2, float f3, float f4) {
        float f5;
        block6: {
            boolean bl;
            block8: {
                Class_lc_b8480f87 class_lc_b8480f87;
                block7: {
                    float f6;
                    block5: {
                        long l = AJNGy ^ 0x1C92D5F47066L;
                        bl = Class_jF_38b68c76.bHF();
                        boolean bl2 = tyoKy.isEmpty();
                        if (bl) return bl2;
                        if (bl2) {
                            return true;
                        }
                        float f7 = f + f3;
                        f6 = f2 + f4;
                        class_lc_b8480f87 = tyoKy.peek();
                        float f8 = f7 - class_lc_b8480f87.bXF();
                        f5 = f8 == 0.0f ? 0 : (f8 > 0.0f ? 1 : -1);
                        if (bl) break block5;
                        if (f5 <= 0) break block6;
                        float f9 = f - class_lc_b8480f87.bXz();
                        f5 = f9 == 0.0f ? 0 : (f9 < 0.0f ? -1 : 1);
                    }
                    if (bl) break block7;
                    if (f5 >= 0) break block6;
                    float f10 = f6 - class_lc_b8480f87.bXG();
                    f5 = f10 == 0.0f ? 0 : (f10 > 0.0f ? 1 : -1);
                }
                if (bl) break block8;
                if (f5 <= 0) break block6;
                float f11 = f2 - class_lc_b8480f87.bXA();
                f5 = f11 == 0.0f ? 0 : (f11 < 0.0f ? -1 : 1);
            }
            if (bl) return (boolean)f5;
            if (f5 < 0) {
                f5 = 1.0f;
                return (boolean)f5;
            }
        }
        f5 = 0.0f;
        return (boolean)f5;
    }

    public static void bHK(Class_lC_5322e8cf class_lC_5322e8cf, float f, float f2, float f3, float f4) {
        Class_lc_b8480f87 class_lc_b8480f87 = new Class_lc_b8480f87(f, f2, f3, f4).bXB(class_lC_5322e8cf.cfd());
        Class_jG_69891630.bHQ(class_lc_b8480f87);
    }

    private static void bHQ(Class_lc_b8480f87 class_lc_b8480f87) {
        long l = AJNGy ^ 0x63FD0722AFL;
        boolean bl = Class_jF_38b68c76.bHG();
        Deque<Class_lc_b8480f87> deque = tyoKy;
        if (bl) {
            if (!deque.isEmpty()) {
                class_lc_b8480f87 = Class_jG_69891630.bHW(tyoKy.peek(), class_lc_b8480f87);
            }
            deque = tyoKy;
        }
        deque.push(class_lc_b8480f87);
        Class_jG_69891630.bHR(class_lc_b8480f87);
    }

    public static void bHJ(float f, float f2, float f3, float f4) {
        Class_lc_b8480f87 class_lc_b8480f87 = new Class_lc_b8480f87(f, f2, f3, f4);
        Class_jG_69891630.bHQ(class_lc_b8480f87);
    }

    public static boolean bIa(double d, double d2) {
        long l = AJNGy ^ 0x754B9B2D9D5DL;
        boolean bl = Class_jF_38b68c76.bHG();
        Object object = tyoKy;
        if (bl) {
            if (object.isEmpty()) {
                return true;
            }
            object = tyoKy.peek();
        }
        Class_lc_b8480f87 class_lc_b8480f87 = (Class_lc_b8480f87)object;
        return class_lc_b8480f87.bXD(d, d2);
    }

    public static void bHL(Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3, float f4) {
        Class_lc_b8480f87 class_lc_b8480f87 = new Class_lc_b8480f87(f, f2, f3, f4).bXC((Matrix3x2fc)matrix3x2fStack);
        Class_jG_69891630.bHQ(class_lc_b8480f87);
    }

    public static void bHM(Matrix3x2fc matrix3x2fc, float f, float f2, float f3, float f4) {
        Class_lc_b8480f87 class_lc_b8480f87 = new Class_lc_b8480f87(f, f2, f3, f4).bXC(matrix3x2fc);
        Class_jG_69891630.bHQ(class_lc_b8480f87);
    }

    public static int bIb() {
        return tyoKy.size();
    }

    private static void bHT() {
        tyoKy.clear();
        RenderSystem.disableScissorForRenderTypeDraws();
        Class_lT_411dd062.ciQ().disableScissor();
    }

    public static boolean bHO() {
        long l = AJNGy ^ 0x745B7D5EECC1L;
        boolean bl = Class_jF_38b68c76.bHG();
        boolean bl2 = tyoKy.isEmpty();
        if (bl) {
            bl2 = !bl2;
        }
        return bl2;
    }

    private static MatchException bIc(MatchException matchException) {
        return matchException;
    }

    private static Class_lc_b8480f87 bHW(Class_lc_b8480f87 class_lc_b8480f87, Class_lc_b8480f87 class_lc_b8480f872) {
        float f = Math.max(class_lc_b8480f87.bXF(), class_lc_b8480f872.bXF());
        float f2 = Math.max(class_lc_b8480f87.bXG(), class_lc_b8480f872.bXG());
        float f3 = Math.min(class_lc_b8480f87.bXz(), class_lc_b8480f872.bXz());
        float f4 = Math.min(class_lc_b8480f87.bXA(), class_lc_b8480f872.bXA());
        float f5 = Math.max(0.0f, f3 - f);
        float f6 = Math.max(0.0f, f4 - f2);
        return new Class_lc_b8480f87(f, f2, f5, f6);
    }

    private static Class_jG_tW_e25aac65 bHV() {
        long l = AJNGy ^ 0x6D363759EA31L;
        boolean bl = Class_jF_38b68c76.bHG();
        Object object = tyoKy;
        if (bl) {
            if (object.isEmpty()) {
                return null;
            }
            object = tyoKy.peek();
        }
        return Class_jG_69891630.bHU((Class_lc_b8480f87)object);
    }

    private static Class_jG_tW_e25aac65 bHU(Class_lc_b8480f87 class_lc_b8480f87) {
        int n = ClientMain.dlmvG.getWindow().getFramebufferHeight();
        double d = Class_rm_d861be3b.dio().doubleValue();
        float f = class_lc_b8480f87.bXF() * (float)d;
        float f2 = class_lc_b8480f87.bXG() * (float)d;
        float f3 = (class_lc_b8480f87.bXF() + class_lc_b8480f87.bXH()) * (float)d;
        float f4 = (class_lc_b8480f87.bXG() + class_lc_b8480f87.bXI()) * (float)d;
        int n2 = (int)Math.floor(f);
        int n3 = (int)Math.floor((double)n - Math.ceil(f4) + 0.5);
        int n4 = Math.max(0, (int)Math.ceil(f3) - n2);
        int n5 = Math.max(0, (int)Math.ceil(f4) - (int)Math.floor(f2) - 1);
        return new Class_jG_tW_e25aac65(n2, n3, n4, n5);
    }

    private static void bHR(Class_lc_b8480f87 class_lc_b8480f87) {
        Class_jG_tW_e25aac65 class_jG_tW_e25aac65 = Class_jG_69891630.bHU(class_lc_b8480f87);
        RenderSystem.enableScissorForRenderTypeDraws((int)class_jG_tW_e25aac65.x(), (int)class_jG_tW_e25aac65.y(), (int)class_jG_tW_e25aac65.width(), (int)class_jG_tW_e25aac65.height());
    }
}

