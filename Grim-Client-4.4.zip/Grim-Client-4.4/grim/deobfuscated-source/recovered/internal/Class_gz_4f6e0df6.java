/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.option.KeyBinding
 *  net.minecraft.client.util.InputUtil$Key
 */
package recovered.internal;

import java.util.List;
import java.util.Map;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gz_4f6e0df6
extends Class_hH_ae8f8f77 {
    private InputUtil.Key YKcvD;
    private Map<InputUtil.Key, List<KeyBinding>> zrjpu;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public boolean bbK(KeyBinding keyBinding) {
        return this.bbJ().contains(keyBinding);
    }

    public InputUtil.Key bbL() {
        return this.YKcvD;
    }

    public List<KeyBinding> bbJ() {
        return this.zrjpu.getOrDefault(this.YKcvD, List.of());
    }

    public Map<InputUtil.Key, List<KeyBinding>> bbM() {
        return this.zrjpu;
    }

    public Class_gz_4f6e0df6(InputUtil.Key key, Map<InputUtil.Key, List<KeyBinding>> map) {
        this.YKcvD = key;
        this.zrjpu = map;
    }
}

