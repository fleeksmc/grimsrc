/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import recovered.core.NativeLoader;
import recovered.internal.Class_iE_00f71a81;
import recovered.internal.Class_il_0e543c73;
import recovered.internal.Class_in_57efefb0;
import recovered.internal.Class_ir_8e0d90e0;
import recovered.internal.Class_iu_bf2db566;

public class Class_ik_a9845240
extends Class_iE_00f71a81
implements Class_il_0e543c73 {
    private static int SCcct;
    private static long xUpkE;
    private static String[] xAjOK;
    private static String[] KhoFn;
    private static Map leVFY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_ik_a9845240.class);
        Class_ik_a9845240._9fdcfeafceb72cd1905fd6f41467b7f1();
    }

    @Override
    public native CompletableFuture<Class_ir_8e0d90e0> fetchPreset(String var1);

    @Override
    public native CompletableFuture<Class_iu_bf2db566> importPreset(String var1);

    @Override
    public native CompletableFuture<Class_iu_bf2db566> deletePreset(String var1);

    @Override
    public native CompletableFuture<List<Class_ir_8e0d90e0>> fetchPresets();

    @Override
    public native CompletableFuture<Class_ir_8e0d90e0> createPreset(Class_in_57efefb0 var1);

    private native /* synthetic */ Class_iu_bf2db566 bkn(Throwable var1);

    private static native CallSite bkx(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native /* synthetic */ Class_iu_bf2db566 bkl(Throwable var1);

    private static native String bku(byte[] var0);

    private native /* synthetic */ Class_ir_8e0d90e0 bkp(Throwable var1);

    public static native int bks();

    private native /* synthetic */ Class_ir_8e0d90e0 bko(Throwable var1);

    @Override
    public native CompletableFuture<Class_iu_bf2db566> loadPreset(Class_in_57efefb0 var1);

    private native /* synthetic */ Class_iu_bf2db566 bkm(Throwable var1);

    private static native String bkv(int var0, long var1);

    public static native void bkq(int var0);

    private static native MatchException bkt(MatchException var0);

    private static native Object bkw(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public static native int bkr();

    private static native void _9fdcfeafceb72cd1905fd6f41467b7f1();
}

