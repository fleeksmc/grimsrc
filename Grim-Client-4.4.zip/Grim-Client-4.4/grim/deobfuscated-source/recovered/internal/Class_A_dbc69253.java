/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_M_2bae30e3;
import recovered.internal.Class_ak_2ff604c7;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_cG_6e1ba021;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;

public class Class_A_dbc69253
extends Class_ak_2ff604c7<Class_cG_6e1ba021> {
    protected Class_M_2bae30e3 OBygo;
    private static long nxTys;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_A_dbc69253(Class_cG_6e1ba021 class_cG_6e1ba021, Class_az_a4990dcf class_az_a4990dcf) {
        super(class_cG_6e1ba021, class_az_a4990dcf);
    }

    static {
        NativeLoader.doInit(Class_A_dbc69253.class);
        Class_A_dbc69253._46b011f84593da9bdca9e4c3988d9e79();
    }

    protected native void fd(Class_lC_5322e8cf var1, float var2, float var3, float var4);

    @Override
    public native float dn();

    private static native MatchException fh(MatchException var0);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    public native Class_A_dbc69253 fg(Class_M_2bae30e3 var1);

    protected native void fe();

    protected native void ff(double var1, double var3);

    @Override
    public native void dY();

    private static native void _46b011f84593da9bdca9e4c3988d9e79();
}

