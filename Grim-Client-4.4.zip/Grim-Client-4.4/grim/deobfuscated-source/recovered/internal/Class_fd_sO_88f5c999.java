/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.math.BlockPos
 */
package recovered.internal;

import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import recovered.core.NativeLoader;

final class Class_fd_sO_88f5c999
extends Record {
    private final BlockPos dripstonePos;
    private final BlockPos trapdoorPos;
    private final BlockHitResult placeHitResult;
    private final boolean secondaryUse;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_fd_sO_88f5c999(BlockPos blockPos, BlockPos blockPos2, BlockHitResult blockHitResult, boolean bl) {
        this.dripstonePos = blockPos;
        this.trapdoorPos = blockPos2;
        this.placeHitResult = blockHitResult;
        this.secondaryUse = bl;
    }

    static {
        NativeLoader.doInit(Class_fd_sO_88f5c999.class);
    }

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    public native BlockPos dripstonePos();

    public native BlockPos trapdoorPos();

    public native boolean secondaryUse();

    public native BlockHitResult placeHitResult();
}

