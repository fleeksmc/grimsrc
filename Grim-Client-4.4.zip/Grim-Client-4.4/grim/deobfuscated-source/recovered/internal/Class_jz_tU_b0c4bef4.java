/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;

public final class Class_jz_tU_b0c4bef4
extends Enum<Class_jz_tU_b0c4bef4> {
    public static final /* enum */ Class_jz_tU_b0c4bef4 GgXAb;
    public static final /* enum */ Class_jz_tU_b0c4bef4 iSvaF;
    private static final Class_jz_tU_b0c4bef4[] BWJoM;
    private static String[] RtxbG;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = Class_gb_9d201141.aYR(-6988668092185728012L, -6829450144089137423L, MethodHandles.lookup().lookupClass()).a(58555418188503L) ^ 0x5E06C3DA7F67L;
        if (Class_jz_tU_b0c4bef4.dqa() != null) {
            Class_jz_tU_b0c4bef4.dpZ(new String[4]);
        }
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[2];
        int n = 0;
        String string = "\"\u00b7\u0084T\u0084,nK\b\u001d\u00baZH\tt}J";
        int n2 = "\"\u00b7\u0084T\u0084,nK\b\u001d\u00baZH\tt}J".length();
        int n3 = 8;
        int n4 = -1;
        while (true) {
            int n5 = ++n4;
            byte[] byArray3 = cipher.doFinal(string.substring(n5, n5 + n3).getBytes("ISO-8859-1"));
            stringArray[n++] = Class_jz_tU_b0c4bef4.dqb(byArray3).intern();
            if ((n4 += n3) >= n2) {
                GgXAb = new Class_jz_tU_b0c4bef4();
                iSvaF = new Class_jz_tU_b0c4bef4();
                BWJoM = Class_jz_tU_b0c4bef4.dpY();
                return;
            }
            n3 = string.charAt(n4);
        }
    }

    public static Class_jz_tU_b0c4bef4[] values() {
        return (Class_jz_tU_b0c4bef4[])BWJoM.clone();
    }

    public static Class_jz_tU_b0c4bef4 valueOf(String string) {
        return Enum.valueOf(Class_jz_tU_b0c4bef4.class, string);
    }

    private static String dqb(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static Class_jz_tU_b0c4bef4[] dpY() {
        return new Class_jz_tU_b0c4bef4[]{GgXAb, iSvaF};
    }

    public static void dpZ(String[] stringArray) {
        RtxbG = stringArray;
    }

    public static String[] dqa() {
        return RtxbG;
    }
}

