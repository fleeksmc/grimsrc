/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;

public class Class_gu_ad4d557d
extends Class_hH_ae8f8f77 {
    private float ZkUAr;
    private float tJjPt;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gu_ad4d557d(float f, float f2) {
        this.ZkUAr = f;
        this.tJjPt = f2;
    }

    public float bbu() {
        return this.ZkUAr;
    }

    public float bbv() {
        return this.tJjPt;
    }
}

