/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 */
package recovered.internal;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import recovered.core.ModuleBase;
import recovered.core.NativeLoader;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_iS_888f260e;

public class Class_iI_6ad6be63 {
    private static int[] YCjGZ;
    private static long rflru;
    private static String[] EgIut;
    private static String[] warqp;
    private static Map nwXIy;
    private static long DhicY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public static native int bsQ(ModuleBase var0, String var1);

    private static native JsonObject bsE(JsonObject var0, JsonObject var1);

    private static native List<Map<String, Object>> bsH(Class_iS_888f260e var0);

    private static native String bsZ(byte[] var0);

    private static native /* synthetic */ void bsV(JsonArray var0, Class_iS_888f260e var1);

    public static native int[] bsX();

    private static native JsonElement bsF(JsonElement var0, JsonElement var1);

    public static native boolean bsK(Class_iS_888f260e var0, Class_cB_67aec11c var1);

    private static native <T extends Class_iS_888f260e> void bsM(T var0, JsonArray var1);

    private static native String bsT(int[] var0);

    private static native /* synthetic */ boolean bsU(ModuleBase var0, ModuleBase var1);

    private static native CallSite btc(MethodHandles.Lookup var0, String var1, MethodType var2);

    public static native void bsL(String var0, boolean var1);

    private static native Class_iS_888f260e bsR(Class_cB_67aec11c var0);

    public static native String bsD(Gson var0);

    private static native boolean bsG(JsonArray var0);

    public static native boolean bsJ(Class_cB_67aec11c var0);

    private static native void bsN(JsonObject var0);

    private static native void bsO(boolean var0, JsonObject var1);

    public static native Map<ModuleBase, Integer> bsP(String var0);

    private static native String bsS(Class_iS_888f260e var0);

    public static native void bsW(int[] var0);

    public static native void bsI();

    private static native Exception bsY(Exception var0);

    private static native String bta(int var0, long var1);

    static {
        NativeLoader.doInit(Class_iI_6ad6be63.class);
        Class_iI_6ad6be63._b931b0b121db1398e8ac964cf086ee9f();
    }

    private static native Object btb(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public static native String bsC(Gson var0);

    private static native void _b931b0b121db1398e8ac964cf086ee9f();
}

