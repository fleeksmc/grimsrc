/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_hZ_076851ce;

final class Class_ia_tF_2f11a7e4
extends Record {
    private final Class_hZ_076851ce command;
    private final int index;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public native int index();

    private Class_ia_tF_2f11a7e4(Class_hZ_076851ce class_hZ_076851ce, int n) {
        this.command = class_hZ_076851ce;
        this.index = n;
    }

    static {
        NativeLoader.doInit(Class_ia_tF_2f11a7e4.class);
    }

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    public native Class_hZ_076851ce command();
}

