/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.world.World
 *  org.joml.Matrix3x2fc
 *  org.jspecify.annotations.Nullable
 */
package recovered.internal;

import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import org.joml.Matrix3x2fc;
import org.jspecify.annotations.Nullable;
import recovered.internal.Class_ju_e398051e;
import recovered.internal.Class_ju_tT_d469d25e;
import recovered.internal.Class_jy_33e84da2;

public final class Class_jv_4c1871b8
extends Class_jy_33e84da2<Class_jv_4c1871b8> {
    private LivingEntity kyBjH;
    private World qOMFo;
    private float ZBHtA;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_jv_4c1871b8(@Nullable Matrix3x2fc matrix3x2fc, @Nullable LivingEntity livingEntity, @Nullable World world, ItemStack itemStack, float f, float f2, float f3) {
        super(matrix3x2fc, itemStack, f, f2, Class_ju_tT_d469d25e.yDoOO);
        this.kyBjH = livingEntity;
        this.qOMFo = world;
        this.ZBHtA = f3;
    }

    public Class_jv_4c1871b8 bGs(@Nullable LivingEntity livingEntity) {
        this.kyBjH = livingEntity;
        return this;
    }

    public Class_jv_4c1871b8 bGu(float f) {
        this.ZBHtA = f;
        return this;
    }

    public Class_jv_4c1871b8 bGt(@Nullable World world) {
        this.qOMFo = world;
        return this;
    }

    @Override
    public void renderIntoBatch() {
        Class_ju_e398051e.bFO(this.wvKbm, this.kyBjH, this.qOMFo, this.qeMTM, this.svsZw, this.zXQoo, this.ZBHtA, this.qxFcM);
    }
}

