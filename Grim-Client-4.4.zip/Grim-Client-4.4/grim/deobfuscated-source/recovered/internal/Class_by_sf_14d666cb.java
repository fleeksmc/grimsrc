/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

final class Class_by_sf_14d666cb
extends Record {
    private final boolean hasVisibleChips;
    private final int lines;
    private final float chipHeight;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_by_sf_14d666cb(boolean bl, int n, float f) {
        this.hasVisibleChips = bl;
        this.lines = n;
        this.chipHeight = f;
    }

    static {
        NativeLoader.doInit(Class_by_sf_14d666cb.class);
    }

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    public native int lines();

    public native boolean hasVisibleChips();

    public native float chipHeight();
}

