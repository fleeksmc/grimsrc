/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;
import recovered.internal.Class_mA_32d8a5f2;

public class Class_hA_4f0c4656
extends Class_hH_ae8f8f77 {
    private final double FcuZq;
    private final double dcpyo;
    private final Class_mA_32d8a5f2 BHdwY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hA_4f0c4656(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        this.FcuZq = d;
        this.dcpyo = d2;
        this.BHdwY = class_mA_32d8a5f2;
    }

    public double bdz() {
        return this.dcpyo;
    }

    public double bdy() {
        return this.FcuZq;
    }

    public Class_mA_32d8a5f2 bdA() {
        return this.BHdwY;
    }
}

