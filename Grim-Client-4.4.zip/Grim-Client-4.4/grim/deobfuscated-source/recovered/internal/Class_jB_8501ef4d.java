/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jC_6c1c779b;

public final class Class_jB_8501ef4d {
    private static final ThreadLocal<Class_jC_6c1c779b> kvatN;
    private static final long pshJL;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static MatchException bGS(MatchException matchException) {
        return matchException;
    }

    public static void bGR(Class_jC_6c1c779b class_jC_6c1c779b, Runnable runnable) {
        block8: {
            long l = pshJL ^ 0x1CF47752C052L;
            Class_jC_6c1c779b class_jC_6c1c779b2 = kvatN.get();
            int n = Class_jC_6c1c779b.bHc();
            kvatN.set(class_jC_6c1c779b);
            try {
                runnable.run();
                if (n != 0) break block8;
                if (class_jC_6c1c779b2 == null) {
                    kvatN.remove();
                    if (n == 0) break block8;
                }
                kvatN.set(class_jC_6c1c779b2);
            }
            catch (Throwable throwable) {
                block11: {
                    block10: {
                        block9: {
                            if (n != 0) break block9;
                            if (class_jC_6c1c779b2 != null) break block10;
                            kvatN.remove();
                        }
                        if (n == 0) break block11;
                    }
                    kvatN.set(class_jC_6c1c779b2);
                }
                throw throwable;
            }
        }
    }

    static {
        pshJL = Class_gb_9d201141.aYR(-6816820043125824775L, -8577862816213828180L, MethodHandles.lookup().lookupClass()).a(185371376800142L);
        kvatN = new ThreadLocal();
    }

    public static Class_jC_6c1c779b bGQ() {
        return kvatN.get();
    }
}

