/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.texture.AbstractTexture
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.texture.AbstractTexture;
import recovered.core.ClientMain;
import recovered.core.ModuleBase;
import recovered.internal.Class_aB_ac16df9e;
import recovered.internal.Class_aC_564007e8;
import recovered.internal.Class_aD_d91dd0e1;
import recovered.internal.Class_aE_a07172c5;
import recovered.internal.Class_aH_4cd10de1;
import recovered.internal.Class_aI_e9d321f1;
import recovered.internal.Class_aR_f155c393;
import recovered.internal.Class_an_9591fd88;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bd_8faff9cb;
import recovered.internal.Class_bg_0a91641c;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_gh_ecfd0cde;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_lx_88d1150d;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_ob_77a6de24;
import recovered.internal.Class_oe_8b69df37;
import recovered.internal.Class_ry_a5fa9042;

public class Class_aJ_1c28c0cb
extends Class_az_a4990dcf {
    private final List<Class_aH_4cd10de1> DIrGH;
    private final Map<Class_aH_4cd10de1, Class_aE_a07172c5> Sbssq;
    private Class_aE_a07172c5 AyCAC;
    private Class_aE_a07172c5 npWSx;
    private Class_aH_4cd10de1 HNIDe;
    private final Class_az_a4990dcf ngAwC;
    private static String[] erCia;
    private static final long iklvp;
    private static final String[] ElbCl;
    private static final String[] QZoSV;
    private static final Map OMsXa;
    private static final long[] IfUGU;
    private static final Integer[] KkXjw;
    private static final Map ADQrN;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aJ_1c28c0cb() {
        block9: {
            Object object;
            String string;
            block10: {
                String string2;
                Object object2;
                block11: {
                    Class_az_a4990dcf class_az_a4990dcf;
                    boolean bl;
                    String[] stringArray;
                    long l;
                    block7: {
                        block8: {
                            l = iklvp ^ 0x37A8119ECEA3L;
                            this.DIrGH = new ArrayList<Class_aH_4cd10de1>();
                            this.Sbssq = new LinkedHashMap<Class_aH_4cd10de1, Class_aE_a07172c5>();
                            float f = 18.0f;
                            stringArray = Class_aJ_1c28c0cb.wv();
                            float f2 = 7.5f;
                            float f3 = 60.0f;
                            for (Class_aI_e9d321f1 class_aI_e9d321f1 : Class_aI_e9d321f1.values()) {
                                object2 = new Class_aH_4cd10de1(this, class_aI_e9d321f1);
                                ((Class_az_a4990dcf)object2).sY(f2, f3, 80.0f, f);
                                this.DIrGH.add((Class_aH_4cd10de1)object2);
                                f3 += f + 5.0f;
                                Class_aI_e9d321f1 class_aI_e9d321f12 = class_aI_e9d321f1;
                                Class_aI_e9d321f1 class_aI_e9d321f13 = Class_aI_e9d321f1.fhJit;
                                if (stringArray == null) {
                                    if (class_aI_e9d321f12 == class_aI_e9d321f13) {
                                        f3 += 15.0f;
                                    }
                                    class_aI_e9d321f12 = class_aI_e9d321f1;
                                    class_aI_e9d321f13 = Class_aI_e9d321f1.mMivt;
                                }
                                if (class_aI_e9d321f12 != class_aI_e9d321f13) continue;
                                ((Class_aH_4cd10de1)object2).vT(class_aH_4cd10de1 -> {
                                    Class_bl_a15fbaa5.Ev();
                                    Class_bl_a15fbaa5.Ex().Es();
                                });
                                if (stringArray == null) continue;
                            }
                            Class_aC_564007e8 class_aC_564007e8 = Class_aE_a07172c5.vB(Class_aC_564007e8.class, Class_aC_564007e8::new);
                            Class_aB_ac16df9e class_aB_ac16df9e = Class_aE_a07172c5.vB(Class_aB_ac16df9e.class, Class_aB_ac16df9e::new);
                            Class_aD_d91dd0e1 class_aD_d91dd0e1 = Class_aE_a07172c5.vB(Class_aD_d91dd0e1.class, Class_aD_d91dd0e1::new);
                            this.Sbssq.put(this.DIrGH.get(0), class_aC_564007e8);
                            this.Sbssq.put(this.DIrGH.get(1), class_aC_564007e8);
                            this.Sbssq.put(this.DIrGH.get(2), class_aC_564007e8);
                            this.Sbssq.put(this.DIrGH.get(3), class_aC_564007e8);
                            this.Sbssq.put(this.DIrGH.get(4), class_aC_564007e8);
                            this.Sbssq.put(this.DIrGH.get(5), class_aB_ac16df9e);
                            this.Sbssq.put(this.DIrGH.get((int)Class_aJ_1c28c0cb.wD("m", (int)2626, (long)(0xD26DAF23B54E0C8L ^ l))), class_aD_d91dd0e1);
                            this.Sbssq.put(this.DIrGH.get((int)Class_aJ_1c28c0cb.wD("m", (int)2931, (long)(0x58D1CFA8551561FAL ^ l))), null);
                            this.we();
                            string2 = Class_ry_a5fa9042.dkB().dkL();
                            object2 = Class_aJ_1c28c0cb.wA("j", (int)10815, (long)(0x2EACF54D9316A6C3L ^ l));
                            bl = string2.endsWith((String)((Object)Class_aJ_1c28c0cb.wA("j", (int)4015, (long)(0x14F6DBF7F3BF0355L ^ l))));
                            if (stringArray != null) break block7;
                            if (!bl) break block8;
                            class_az_a4990dcf = new Class_lx_88d1150d(string2 + (String)object2);
                            ((Class_lx_88d1150d)class_az_a4990dcf).ccf(Class_ld_bb1690e1.all(4.0f));
                            this.ngAwC = class_az_a4990dcf;
                            if (stringArray == null) break block9;
                        }
                        this.ngAwC = new Class_an_9591fd88();
                        string = string2;
                        object = Class_aJ_1c28c0cb.wA("j", (int)16613, (long)(0x4CE1687CEF664C1AL ^ l));
                        if (stringArray != null) break block10;
                        bl = string.contains((CharSequence)object);
                    }
                    if (!bl) break block11;
                    class_az_a4990dcf = (Class_an_9591fd88)this.ngAwC;
                    ((Class_an_9591fd88)class_az_a4990dcf).ph(Class_ob_77a6de24.cBv((String)((Object)Class_aJ_1c28c0cb.wA("j", (int)20788, (long)(0x179580800A38DDCCL ^ l)))));
                    ((Class_an_9591fd88)class_az_a4990dcf).pi(Class_ld_bb1690e1.all(4.0f));
                    if (stringArray == null) break block9;
                }
                string = string2;
                object = object2;
            }
            Class_oe_8b69df37.cCd(string + (String)object).thenAccept(class_lv_518bbba3 -> {
                Class_an_9591fd88 class_an_9591fd88 = (Class_an_9591fd88)this.ngAwC;
                class_an_9591fd88.ph((AbstractTexture)class_lv_518bbba3);
                class_an_9591fd88.pi(Class_ld_bb1690e1.all(4.0f));
            });
        }
        this.ngAwC.sX(20.0f, 20.0f);
        if (Class_iS_888f260e.bwL() == null) {
            Class_aJ_1c28c0cb.wu(new String[5]);
        }
        this.Sbssq.remove(this.DIrGH.remove(6));
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Class_aJ_1c28c0cb.iklvp = Class_gb_9d201141.aYR(-8049947572768292019L, 7048069767684806331L, MethodHandles.lookup().lookupClass()).a(245925426125427L);
                        Class_aJ_1c28c0cb.OMsXa = new HashMap<K, V>(13);
                        var11 = Class_aJ_1c28c0cb.iklvp ^ 139714416130577L;
                        Class_aJ_1c28c0cb.wu(null);
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[8];
                        var18_4 = 0;
                        var17_5 = "8\u00aby\u00ed\u0014W\u001em\u00c1\b\u0098\u00c2\u008a\u00c9\u00af\u0089\u0092\u00a7\u00ee\u00d2x\u00a9\u007fi\u00cao\f\u00d5\u00f4\u00c8\u00b9\u00ab\u0010\u00ba\u008ef\u00b1KH\u0002\u0090\u00e1\u00edv\u00cf\\\u00a8\u00d3+ \u00f1N9K\u00e1\u00db\u00c1&\u00b2Y\u00fb\u00a7\u0088)h}Vp\u00dd\b\u00c2\u00a4A\u008bo\u00d8\u00f0B@cy\u00a4 \u000f&3$\u00b5wK\u00be\u00ea\u00e5f\u00f7\u0016\u0088\u00fb&\f\f\u007f\u00c3\u00b8\u00125\u00aeE\u008e\u00fcqXo\u00ddC\u0010\u00a4\u00c1\u0001d7\u00bb@\u00cc\u00f0jMt\u0086?\u00c2O\u0010^\\CP\u00a7\u0003q\u00cc+\u00a7\u0004f\u00c2a\u00f3\u00f9";
                        var19_6 = "8\u00aby\u00ed\u0014W\u001em\u00c1\b\u0098\u00c2\u008a\u00c9\u00af\u0089\u0092\u00a7\u00ee\u00d2x\u00a9\u007fi\u00cao\f\u00d5\u00f4\u00c8\u00b9\u00ab\u0010\u00ba\u008ef\u00b1KH\u0002\u0090\u00e1\u00edv\u00cf\\\u00a8\u00d3+ \u00f1N9K\u00e1\u00db\u00c1&\u00b2Y\u00fb\u00a7\u0088)h}Vp\u00dd\b\u00c2\u00a4A\u008bo\u00d8\u00f0B@cy\u00a4 \u000f&3$\u00b5wK\u00be\u00ea\u00e5f\u00f7\u0016\u0088\u00fb&\f\f\u007f\u00c3\u00b8\u00125\u00aeE\u008e\u00fcqXo\u00ddC\u0010\u00a4\u00c1\u0001d7\u00bb@\u00cc\u00f0jMt\u0086?\u00c2O\u0010^\\CP\u00a7\u0003q\u00cc+\u00a7\u0004f\u00c2a\u00f3\u00f9".length();
                        var16_7 = 32;
                        var15_8 = -1;
lbl21:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl26:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Class_aJ_1c28c0cb.wx(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = ",\u0096\u001c\u009e\u00c6H\u0004G\\\u000e\u0092\u00d2g\u00d4\u008e\u0095\u009b\u0004\u000f\u00ea\u00cd+\u0007\u001e\u00b2\u00b1\u007f\u00c6I\u00f9\u00dbw\u0018\u00aaN=`Q\u00e5\u00a8.\u00e3\u00de/\u0005\u00d4~\u00be\u008e\u00f5\u00df\u001f\u00a9\u008a`mX";
                            var19_6 = ",\u0096\u001c\u009e\u00c6H\u0004G\\\u000e\u0092\u00d2g\u00d4\u008e\u0095\u009b\u0004\u000f\u00ea\u00cd+\u0007\u001e\u00b2\u00b1\u007f\u00c6I\u00f9\u00dbw\u0018\u00aaN=`Q\u00e5\u00a8.\u00e3\u00de/\u0005\u00d4~\u00be\u008e\u00f5\u00df\u001f\u00a9\u008a`mX".length();
                            var16_7 = 32;
                            var15_8 = -1;
lbl35:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl40:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Class_aJ_1c28c0cb.wx(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl52:
                        // 1 sources

                        ** continue;
                    }
                }
                Class_aJ_1c28c0cb.ElbCl = var20_3;
                Class_aJ_1c28c0cb.QZoSV = new String[8];
                Class_aJ_1c28c0cb.ADQrN = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[19];
                var3_13 = 0;
                var4_14 = "\u0000\u00cf\u00a6\u009au\u00deRM\u0092\u009c)\u00d86\u00de\u00eb\u00a0'A\u00c2\u00bf\u00debA\u00b7\u0007\u00c2\u0097v\u00b1\u00e4\u00e5y\u00e3)n\u00fb\u00c8 \u00ae\u0002h\u00b1\u00ad\u001f&\u00f5\u00c3\u00e2\u00ed\u00ceR\u00cdQ<_\u001bZ\u00e8B3n\u00f1\u001a\u0082\u0091B\u001e\u008clS\u00b3\n\u00c1\u00dekBq\u00b3\u009cq\u00a2\u001a\u00fc\u009b8\u00a0C\u0010\u00b1\u00e7\u00d6\u00ad\u00c0\u00ff\u008d\u0013'\u00c1\u0090\u00057Wx\u00ae/3o\u008e\u000eK\u00b4X\u00b0\u0004\u009f\u0087.\u0088Y\u0013\u00e8\u008c{$M\u00d2\u00b8\u00d1R\u0001[N7;\u0001\u00da";
                var5_15 = "\u0000\u00cf\u00a6\u009au\u00deRM\u0092\u009c)\u00d86\u00de\u00eb\u00a0'A\u00c2\u00bf\u00debA\u00b7\u0007\u00c2\u0097v\u00b1\u00e4\u00e5y\u00e3)n\u00fb\u00c8 \u00ae\u0002h\u00b1\u00ad\u001f&\u00f5\u00c3\u00e2\u00ed\u00ceR\u00cdQ<_\u001bZ\u00e8B3n\u00f1\u001a\u0082\u0091B\u001e\u008clS\u00b3\n\u00c1\u00dekBq\u00b3\u009cq\u00a2\u001a\u00fc\u009b8\u00a0C\u0010\u00b1\u00e7\u00d6\u00ad\u00c0\u00ff\u008d\u0013'\u00c1\u0090\u00057Wx\u00ae/3o\u008e\u000eK\u00b4X\u00b0\u0004\u009f\u0087.\u0088Y\u0013\u00e8\u008c{$M\u00d2\u00b8\u00d1R\u0001[N7;\u0001\u00da".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl79:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "D\u009eyZn\u00d0&(\u00e4@\u0012\u00a7xK\u00ee\u00fb";
                    var5_15 = "D\u009eyZn\u00d0&(\u00e4@\u0012\u00a7xK\u00ee\u00fb".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl92:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl105:
                // 1 sources

                ** continue;
            }
        }
        Class_aJ_1c28c0cb.IfUGU = var6_12;
        Class_aJ_1c28c0cb.KkXjw = new Integer[19];
    }

    public void wi(Class_aE_a07172c5 class_aE_a07172c5) {
        block3: {
            block2: {
                long l = iklvp ^ 0x26F3875EDD35L;
                Class_aH_4cd10de1 class_aH_4cd10de1 = null;
                Iterator<Map.Entry<Class_aH_4cd10de1, Class_aE_a07172c5>> iterator = this.Sbssq.entrySet().iterator();
                String[] stringArray = Class_aJ_1c28c0cb.wv();
                while (iterator.hasNext()) {
                    Map.Entry<Class_aH_4cd10de1, Class_aE_a07172c5> entry = iterator.next();
                    Class_az_a4990dcf class_az_a4990dcf = entry.getValue();
                    if (stringArray == null) {
                        if (class_az_a4990dcf != class_aE_a07172c5) continue;
                        class_az_a4990dcf = entry.getKey();
                    }
                    class_aH_4cd10de1 = (Class_aH_4cd10de1)class_az_a4990dcf;
                    break;
                }
                if (class_aH_4cd10de1 == null) break block2;
                this.wf(class_aH_4cd10de1);
                if (stringArray == null) break block3;
            }
            this.wh(class_aE_a07172c5);
        }
    }

    public Class_az_a4990dcf wr() {
        return this.ngAwC;
    }

    @Override
    public boolean dk(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        boolean bl;
        block3: {
            long l = iklvp ^ 0x45EF3F5BAC8FL;
            Iterator<Class_aH_4cd10de1> iterator = this.DIrGH.iterator();
            String[] stringArray = Class_aJ_1c28c0cb.wv();
            while (iterator.hasNext()) {
                block5: {
                    boolean bl2;
                    block4: {
                        Class_aH_4cd10de1 class_aH_4cd10de1 = iterator.next();
                        bl = class_aH_4cd10de1.dk(d, d2, class_mA_32d8a5f2);
                        if (stringArray != null) break block3;
                        if (stringArray != null) break block4;
                        if (!bl) break block5;
                        bl2 = true;
                    }
                    return bl2;
                }
                if (stringArray == null) continue;
            }
            bl = super.dk(d, d2, class_mA_32d8a5f2);
        }
        return bl;
    }

    @Override
    protected void bV(Class_lC_5322e8cf class_lC_5322e8cf) {
        long l = iklvp ^ 0x187AF7F2784BL;
        float f = Class_bl_a15fbaa5.Ex().sj().dhj();
        Class_mG_52c8d386 class_mG_52c8d386 = this.CtPwV.bjb().coa(255.0f * f);
        Class_lc_b8480f87 class_lc_b8480f87 = new Class_lc_b8480f87(this.MCnYt + 5.0f, this.pNyTQ + 7.5f, 30.0f, 30.0f);
        class_lC_5322e8cf.cdU(ClientMain.dmm(), class_lc_b8480f87, Class_mG_52c8d386.hoGuU.cob(f));
        Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(9.0f);
        Class_lq_87a74641 class_lq_87a746412 = Class_lE_06fbe260.WTzbi.bYM(6.0f);
        float f2 = class_lc_b8480f87.bXz() + 5.0f;
        float f3 = class_lc_b8480f87.bXG() + 7.5f;
        int[] nArray = new int[Class_aJ_1c28c0cb.wD("m", (int)5093, (long)(0x5F4C233208514F8DL ^ l))];
        nArray[0] = (int)Class_aJ_1c28c0cb.wD("m", (int)3053, (long)(0x60C452B769A3D78DL ^ l));
        nArray[1] = (int)Class_aJ_1c28c0cb.wD("m", (int)29100, (long)(0x46CDEC666BB7ADC2L ^ l));
        nArray[2] = (int)Class_aJ_1c28c0cb.wD("m", (int)7440, (long)(0x58B56E98FA51C160L ^ l));
        nArray[3] = (int)Class_aJ_1c28c0cb.wD("m", (int)7759, (long)(0x1A91C5A6CFBCC23DL ^ l));
        nArray[4] = (int)Class_aJ_1c28c0cb.wD("m", (int)27812, (long)(0x55713330F31D30C3L ^ l));
        nArray[5] = (int)Class_aJ_1c28c0cb.wD("m", (int)3364, (long)(0x3A0200C61E94D148L ^ l));
        nArray[Class_aJ_1c28c0cb.wD("m", (int)17691, (long)(0x3B46399A9A381972L ^ l))] = (int)Class_aJ_1c28c0cb.wD("m", (int)1528, (long)(0x3F565286CA9B5997L ^ l));
        nArray[Class_aJ_1c28c0cb.wD("m", (int)2622, (long)(0x1910F7D8D69ED653L ^ l))] = (int)Class_aJ_1c28c0cb.wD("m", (int)25934, (long)(0x45AF229955E3B92AL ^ l));
        nArray[Class_aJ_1c28c0cb.wD("m", (int)18741, (long)(0x7D80A44561CE155FL ^ l))] = (int)Class_aJ_1c28c0cb.wD("m", (int)16046, (long)(0x1F9294A45895E2DDL ^ l));
        nArray[Class_aJ_1c28c0cb.wD("m", (int)23643, (long)(0x77E4BDC991E70030L ^ l))] = (int)Class_aJ_1c28c0cb.wD("m", (int)20025, (long)(0x58EE9996EBB9125FL ^ l));
        nArray[Class_aJ_1c28c0cb.wD("m", (int)30270, (long)(0x6F04B9CD0D7FAA5DL ^ l))] = (int)Class_aJ_1c28c0cb.wD("m", (int)19531, (long)(0x35A1F18E632D102EL ^ l));
        class_lC_5322e8cf.ceA(class_lq_87a74641, nArray, f2, f3, class_mG_52c8d386);
        class_lC_5322e8cf.cez(class_lq_87a746412, (String)((Object)Class_aJ_1c28c0cb.wA("j", (int)20182, (long)(0x58C85F29A32874C7L ^ l))), f2, f3 + class_lq_87a74641.cat() + 4.5f, class_mG_52c8d386.cob(0.5f));
        Class_lc_b8480f87 class_lc_b8480f872 = Class_bl_a15fbaa5.Ex().Ey();
        String[] stringArray = Class_aJ_1c28c0cb.wv();
        float f4 = class_lc_b8480f872.bXA() - this.ngAwC.dn() - 7.5f;
        this.ngAwC.sW(this.MCnYt + 7.5f, f4);
        this.ngAwC.su(class_lC_5322e8cf);
        Class_lq_87a74641 class_lq_87a746413 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
        float f5 = 4.5f;
        float f6 = class_lq_87a746413.cat() * 2.0f + f5;
        float f7 = f4 + (this.ngAwC.dn() - f6) / 2.0f;
        float f8 = this.ngAwC.tc() + 5.0f;
        Class_ry_a5fa9042.dkB();
        class_lC_5322e8cf.cez(class_lq_87a746413, "matthew", f8, f7, class_mG_52c8d386);
        Class_ry_a5fa9042.dkB();
        class_lC_5322e8cf.cez(class_lq_87a746413, (String)((Object)Class_aJ_1c28c0cb.wA("j", (int)26278, (long)(0x6CE9F5B6B07F5CB5L ^ l))) + 1337, f8, f7 + class_lq_87a746413.cat() + f5, class_mG_52c8d386.cob(0.5f));
        String[] stringArray2 = stringArray;
        Class_lq_87a74641 class_lq_87a746414 = Class_lE_06fbe260.WTzbi.bYM(5.0f);
        class_lC_5322e8cf.cez(class_lq_87a746414, (String)((Object)Class_aJ_1c28c0cb.wA("j", (int)27395, (long)(0x597161A25085D116L ^ l))), this.MCnYt + 12.5f, this.pNyTQ + 52.5f, class_mG_52c8d386.cob(0.5f));
        class_lC_5322e8cf.cez(class_lq_87a746414, (String)((Object)Class_aJ_1c28c0cb.wA("j", (int)7455, (long)(0x4EC7910A5A2CA709L ^ l))), this.MCnYt + 12.5f, this.pNyTQ + 52.5f + 130.0f, class_mG_52c8d386.cob(0.5f));
        for (Class_aH_4cd10de1 class_aH_4cd10de1 : this.DIrGH) {
            float f9 = class_aH_4cd10de1.tr();
            float f10 = class_aH_4cd10de1.ts();
            class_aH_4cd10de1.sW(this.MCnYt + f9, this.pNyTQ + f10);
            class_aH_4cd10de1.su(class_lC_5322e8cf);
            class_aH_4cd10de1.sW(f9, f10);
            if (stringArray2 == null) continue;
            Class_iS_888f260e.bwK("c9lwn");
            break;
        }
    }

    public Class_aE_a07172c5 wo() {
        return this.AyCAC;
    }

    private static String wx(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static String wy(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x82B;
        if (QZoSV[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])OMsXa.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    OMsXa.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_aJ_1c28c0cb", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = ElbCl[n2].getBytes("ISO-8859-1");
            Class_aJ_1c28c0cb.QZoSV[n2] = Class_aJ_1c28c0cb.wx(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return QZoSV[n2];
    }

    private static Object wz(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_aJ_1c28c0cb.wy(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static MatchException ww(MatchException matchException) {
        return matchException;
    }

    private static int wC(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_aJ_1c28c0cb.wB(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static CallSite wA(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_aJ_1c28c0cb" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static CallSite wD(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_aJ_1c28c0cb" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int wB(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x6E5E;
        if (KkXjw[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = IfUGU[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])ADQrN.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    ADQrN.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_aJ_1c28c0cb", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_aJ_1c28c0cb.KkXjw[n2] = n3;
        }
        return KkXjw[n2];
    }

    public void we() {
        this.HNIDe = this.DIrGH.get(0);
        this.HNIDe.vP().dhe(1.0f);
        this.npWSx = this.Sbssq.get(this.HNIDe);
        this.wl(this.npWSx);
    }

    public List<Class_aH_4cd10de1> wm() {
        return this.DIrGH;
    }

    public Map<Class_aH_4cd10de1, Class_aE_a07172c5> wn() {
        return this.Sbssq;
    }

    public static String[] wv() {
        return erCia;
    }

    public void wk() {
        block3: {
            Class_aE_a07172c5 class_aE_a07172c5;
            block4: {
                String[] stringArray;
                block2: {
                    long l = iklvp ^ 0x5BC240C9FADEL;
                    stringArray = Class_aJ_1c28c0cb.wv();
                    class_aE_a07172c5 = this.AyCAC;
                    if (stringArray != null) break block2;
                    if (class_aE_a07172c5 == null) break block3;
                    class_aE_a07172c5 = this.AyCAC;
                }
                if (stringArray != null) break block4;
                if (class_aE_a07172c5 == this.npWSx) break block3;
                class_aE_a07172c5 = this.npWSx;
            }
            Class_aE_a07172c5 class_aE_a07172c52 = class_aE_a07172c5;
            this.wh(this.AyCAC);
            this.AyCAC = class_aE_a07172c52;
        }
    }

    public static void wu(String[] stringArray) {
        erCia = stringArray;
    }

    public void wj(Class_bg_0a91641c class_bg_0a91641c) {
        long l = iklvp ^ 0x1775FA13CF39L;
        ModuleBase moduleBase = class_bg_0a91641c.CX();
        Class_gh_ecfd0cde class_gh_ecfd0cde = moduleBase.bak();
        String[] stringArray = Class_aJ_1c28c0cb.wv();
        Class_aI_e9d321f1 class_aI_e9d321f1 = switch (class_gh_ecfd0cde) {
            default -> throw new MatchException(null, null);
            case Class_gh_ecfd0cde.xwjCw -> Class_aI_e9d321f1.JkFqu;
            case Class_gh_ecfd0cde.xgeEn -> Class_aI_e9d321f1.OOZEg;
            case Class_gh_ecfd0cde.qBzlZ -> Class_aI_e9d321f1.PGwMP;
            case Class_gh_ecfd0cde.nOCvV -> Class_aI_e9d321f1.ejRch;
            case Class_gh_ecfd0cde.KfAlY -> Class_aI_e9d321f1.fhJit;
        };
        for (Class_aH_4cd10de1 class_aH_4cd10de1 : this.DIrGH) {
            block11: {
                block10: {
                    if (stringArray != null) break block10;
                    if (class_aH_4cd10de1.vM() != class_aI_e9d321f1) break block11;
                    this.wf(class_aH_4cd10de1);
                }
                if (stringArray == null) break;
            }
            if (stringArray == null) continue;
            break;
        }
    }

    public Class_aH_4cd10de1 wq() {
        return this.HNIDe;
    }

    public void wf(Class_aH_4cd10de1 class_aH_4cd10de1) {
        long l = iklvp ^ 0x3FEBC15F86FCL;
        String[] stringArray = Class_aJ_1c28c0cb.wv();
        Class_aJ_1c28c0cb class_aJ_1c28c0cb = this;
        if (stringArray == null) {
            if (class_aJ_1c28c0cb.HNIDe == class_aH_4cd10de1) {
                return;
            }
            class_aJ_1c28c0cb = this;
        }
        if (stringArray == null) {
            if (class_aJ_1c28c0cb.npWSx != null) {
                this.AyCAC = this.npWSx;
            }
            class_aJ_1c28c0cb = this;
        }
        Class_aH_4cd10de1 class_aH_4cd10de12 = class_aJ_1c28c0cb.HNIDe;
        if (stringArray == null) {
            if (class_aH_4cd10de12 != null) {
                this.HNIDe.vW(false);
            }
            class_aH_4cd10de12 = class_aH_4cd10de1.vW(true);
        }
        this.HNIDe = class_aH_4cd10de1;
        this.npWSx = this.Sbssq.get(this.HNIDe);
        this.wl(this.npWSx);
    }

    public void wh(Class_aE_a07172c5 class_aE_a07172c5) {
        long l = iklvp ^ 0x38440B13DB97L;
        String[] stringArray = Class_aJ_1c28c0cb.wv();
        Class_aJ_1c28c0cb class_aJ_1c28c0cb = this;
        if (stringArray == null) {
            if (class_aJ_1c28c0cb.npWSx != null && class_aE_a07172c5 != this.npWSx) {
                this.AyCAC = this.npWSx;
            }
            this.npWSx = class_aE_a07172c5;
            Class_bl_a15fbaa5.Ex().EC().oQ().dhg();
            class_aJ_1c28c0cb = this;
        }
        class_aJ_1c28c0cb.wl(this.npWSx);
    }

    public Class_aE_a07172c5 wp() {
        return this.npWSx;
    }

    private void wl(Class_aE_a07172c5 class_aE_a07172c5) {
        block18: {
            Object object;
            Iterator<Class_aR_f155c393> iterator;
            String[] stringArray;
            block17: {
                block20: {
                    Class_aE_a07172c5 class_aE_a07172c52;
                    block19: {
                        long l = iklvp ^ 0x3ECCA9489ACAL;
                        stringArray = Class_aJ_1c28c0cb.wv();
                        class_aE_a07172c52 = class_aE_a07172c5;
                        if (stringArray != null) break block19;
                        if (class_aE_a07172c52 == null) break block20;
                        class_aE_a07172c52 = class_aE_a07172c5;
                    }
                    if (stringArray == null) {
                        if (class_aE_a07172c52 instanceof Class_aC_564007e8) {
                            iterator = (Class_aC_564007e8)class_aE_a07172c5;
                            object = switch (this.HNIDe.vM()) {
                                case Class_aI_e9d321f1.JkFqu -> Class_gh_ecfd0cde.xwjCw;
                                case Class_aI_e9d321f1.OOZEg -> Class_gh_ecfd0cde.xgeEn;
                                case Class_aI_e9d321f1.PGwMP -> Class_gh_ecfd0cde.qBzlZ;
                                case Class_aI_e9d321f1.ejRch -> Class_gh_ecfd0cde.nOCvV;
                                case Class_aI_e9d321f1.fhJit -> Class_gh_ecfd0cde.KfAlY;
                                default -> null;
                            };
                            ((Class_aC_564007e8)((Object)iterator)).uk((Class_gh_ecfd0cde)((Object)object));
                        }
                        class_aE_a07172c52 = class_aE_a07172c5;
                    }
                    class_aE_a07172c52.dY();
                }
                iterator = Class_bl_a15fbaa5.Ex().manager().aY(Class_bd_8faff9cb.class).iterator();
                while (iterator.hasNext()) {
                    object = (Class_bd_8faff9cb)iterator.next();
                    ((Class_bd_8faff9cb)object).Cg(false);
                    if (stringArray == null) {
                        if (stringArray == null) continue;
                    }
                    break block17;
                }
                iterator = Class_bl_a15fbaa5.Ex().manager().aY(Class_aR_f155c393.class).iterator();
            }
            while (iterator.hasNext()) {
                object = iterator.next();
                ((Class_aR_f155c393)object).yg(false);
                if (stringArray == null) {
                    if (stringArray == null) continue;
                }
                break block18;
            }
            Class_bl_a15fbaa5.Ex().Ez().nI();
        }
    }

    public void wg(Class_aH_4cd10de1 class_aH_4cd10de1) {
        long l = iklvp ^ 0x127D5A9FD66AL;
        String[] stringArray = Class_aJ_1c28c0cb.wv();
        Class_aH_4cd10de1 class_aH_4cd10de12 = this.HNIDe;
        if (stringArray == null) {
            if (class_aH_4cd10de12 == class_aH_4cd10de1) {
                return;
            }
            class_aH_4cd10de12 = this.HNIDe;
        }
        if (stringArray == null) {
            if (class_aH_4cd10de12 != null) {
                this.HNIDe.vW(false);
            }
            class_aH_4cd10de12 = class_aH_4cd10de1.vW(true);
        }
        this.HNIDe = class_aH_4cd10de1;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_aJ_1c28c0cb.class, "wz", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_aJ_1c28c0cb.class, "wC", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

