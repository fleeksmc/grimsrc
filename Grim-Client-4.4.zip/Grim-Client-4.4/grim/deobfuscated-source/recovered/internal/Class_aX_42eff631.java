/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.ClientMain;
import recovered.core.NativeLoader;
import recovered.internal.Class_Q_88b47dba;
import recovered.internal.Class_R_e15da82d;
import recovered.internal.Class_aY_e9eaa44d;
import recovered.internal.Class_iM_910cda2e;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mI_uP_2bdd4f69;
import recovered.internal.Class_od_f9118ebf;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_aX_42eff631
extends Class_aY_e9eaa44d {
    Class_Q_88b47dba hFPQK;
    Class_Q_88b47dba zUhaJ;
    Class_R_e15da82d HShKv;
    Class_rk_bf8630d1 iSNKO;
    Class_rk_bf8630d1 azWgX;
    private static long GzpjW;
    private static String[] Jditj;
    private static String[] jUEck;
    private static Map cIalU;
    private static long[] pXBsX;
    private static Integer[] oqkKa;
    private static Map HaYXc;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aX_42eff631(float f, int[] nArray, Class_iM_910cda2e class_iM_910cda2e) {
        long l = GzpjW ^ 0x3DEBC44FE98CL;
        super(f, nArray, class_iM_910cda2e);
        this.iSNKO = new Class_rk_bf8630d1((int)Class_aX_42eff631.zS("q", (int)10509, (long)(0x2632ECDF01B64F8CL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.azWgX = new Class_rk_bf8630d1((int)Class_aX_42eff631.zS("q", (int)1405, (long)(0x36526396703BE3D2L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        Class_ig_ca326427 class_ig_ca326427 = ClientMain.dlM().bjG();
        this.hFPQK = (Class_Q_88b47dba)new Class_Q_88b47dba().io(Class_lf_d247d983.zNsnc).jb(this::zK).jh(class_iM_910cda2e.btX()).ji((int)Class_aX_42eff631.zS("q", (int)506, (long)(0x311246B677F1674BL ^ l))).jk(class_ig_ca326427.bio()).jm(Class_jk_a0800133.jEkxo).sX(10.0f, 10.0f);
        this.zUhaJ = (Class_Q_88b47dba)new Class_Q_88b47dba().io(Class_lf_d247d983.EQqYg).jb(this::zJ).jh(class_iM_910cda2e.btY()).ji((int)Class_aX_42eff631.zS("q", (int)6696, (long)(0x2CD4AF2F59F37C9CL ^ l))).jk(class_ig_ca326427.bio()).jm(Class_jk_a0800133.mPXGi).sX(10.0f, 10.0f);
        this.HShKv = (Class_R_e15da82d)new Class_R_e15da82d(Class_od_f9118ebf.cBP((String)((Object)Class_aX_42eff631.zP("h", (int)10050, (long)(0x7388E5AF5255AB41L ^ l))), Class_mI_uP_2bdd4f69.drPFI)).jb(this::zI).sX(12.0f, 12.0f);
    }

    static {
        NativeLoader.doInit(Class_aX_42eff631.class);
        Class_aX_42eff631._051ffc366d146155f9f57f4c960f671f();
    }

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void sv(Class_lC_5322e8cf var1);

    private native void zy();

    private native void zx();

    public native Class_Q_88b47dba zz();

    private native void zw();

    private native /* synthetic */ void zF(Class_iM_910cda2e var1);

    private static native int zR(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native /* synthetic */ void zI(Class_R_e15da82d var1);

    private static native CallSite zS(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native Class_Q_88b47dba zA();

    private static native int zQ(int var0, long var1);

    private native /* synthetic */ void zJ(Class_Q_88b47dba var1);

    public native Class_R_e15da82d zB();

    private native /* synthetic */ Void zE(boolean var1, boolean var2, Throwable var3);

    private static native String zM(byte[] var0);

    private static native Object zO(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native String zN(int var0, long var1);

    private static native CallSite zP(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native Class_rk_bf8630d1 zC();

    private native /* synthetic */ void zK(Class_Q_88b47dba var1);

    public native Class_rk_bf8630d1 zD();

    private native /* synthetic */ Void zG(boolean var1, boolean var2, Throwable var3);

    private static native MatchException zL(MatchException var0);

    private native /* synthetic */ void zH(Class_iM_910cda2e var1);

    private static native void _051ffc366d146155f9f57f4c960f671f();
}

