/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_gC_1f010b94;

public class Class_gC_tf_feb37107
extends Class_gC_1f010b94 {
    private final boolean aqPfq;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gC_tf_feb37107(boolean bl) {
        this.aqPfq = bl;
    }

    public boolean dpk() {
        return this.aqPfq;
    }
}

