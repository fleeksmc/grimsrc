/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_Q_88b47dba;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_c_b33cdc52;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;

class Class_c_rE_c9f44d07
extends Class_az_a4990dcf {
    final Class_Q_88b47dba aOPCa;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_c_rE_c9f44d07(Class_c_b33cdc52 class_c_b33cdc52, Class_Q_88b47dba class_Q_88b47dba) {
        this.aOPCa = class_Q_88b47dba;
    }

    static {
        NativeLoader.doInit(Class_c_rE_c9f44d07.class);
    }

    @Override
    public native float dn();

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);
}

