/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_aI_e9d321f1;
import recovered.internal.Class_gh_ecfd0cde;

class Class_aJ_rV_017ab99d {
    static final int[] XrLHU;
    static final int[] hlWwY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        hlWwY = new int[Class_aI_e9d321f1.values().length];
        try {
            Class_aJ_rV_017ab99d.hlWwY[Class_aI_e9d321f1.JkFqu.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class_aJ_rV_017ab99d.hlWwY[Class_aI_e9d321f1.OOZEg.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class_aJ_rV_017ab99d.hlWwY[Class_aI_e9d321f1.PGwMP.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class_aJ_rV_017ab99d.hlWwY[Class_aI_e9d321f1.ejRch.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class_aJ_rV_017ab99d.hlWwY[Class_aI_e9d321f1.fhJit.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        XrLHU = new int[Class_gh_ecfd0cde.values().length];
        try {
            Class_aJ_rV_017ab99d.XrLHU[Class_gh_ecfd0cde.xwjCw.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class_aJ_rV_017ab99d.XrLHU[Class_gh_ecfd0cde.xgeEn.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class_aJ_rV_017ab99d.XrLHU[Class_gh_ecfd0cde.qBzlZ.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class_aJ_rV_017ab99d.XrLHU[Class_gh_ecfd0cde.nOCvV.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class_aJ_rV_017ab99d.XrLHU[Class_gh_ecfd0cde.KfAlY.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

