/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.text.Text
 */
package recovered.internal;

import net.minecraft.text.Text;
import recovered.internal.Class_bX_sk_72c9b1cb;

record Class_bX_sj_c4120501(Text title, int titleWidth, int contentWidth, int backgroundWidth, int backgroundHeight, Class_bX_sk_72c9b1cb[] entries) {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

