/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_hJ_a20df6c5;
import recovered.internal.Class_hK_37a4c9e8;
import recovered.internal.Class_hU_be18db32;

class Class_hU_tC_336c2b0d
implements Class_hK_37a4c9e8 {
    private static long cXzpU;
    private static long[] REDLI;
    private static Integer[] ZHKIS;
    private static Map qGwMH;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_hU_tC_336c2b0d(Class_hU_be18db32 class_hU_be18db32) {
    }

    static {
        NativeLoader.doInit(Class_hU_tC_336c2b0d.class);
        Class_hU_tC_336c2b0d._8c75cfed8ea0d5570a74098af434d2ba();
    }

    @Override
    public native Class_hJ_a20df6c5 validate(String var1);

    @Override
    public native List<String> suggestions(String var1);

    private static native MatchException dpC(MatchException var0);

    private static native int dpD(int var0, long var1);

    private static native CallSite dpF(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native int dpE(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native void _8c75cfed8ea0d5570a74098af434d2ba();
}

