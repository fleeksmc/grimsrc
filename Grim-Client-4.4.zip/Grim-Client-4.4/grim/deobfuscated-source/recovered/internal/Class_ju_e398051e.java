/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.render.DiffuseLighting$Type
 *  net.minecraft.client.render.OutlineVertexConsumerProvider
 *  net.minecraft.client.render.OverlayTexture
 *  net.minecraft.client.render.RenderLayer
 *  net.minecraft.client.render.RenderLayers
 *  net.minecraft.client.render.TexturedRenderLayers
 *  net.minecraft.client.render.VertexConsumerProvider
 *  net.minecraft.client.render.VertexConsumerProvider$Immediate
 *  net.minecraft.client.render.command.OrderedRenderCommandQueue
 *  net.minecraft.client.render.command.OrderedRenderCommandQueueImpl
 *  net.minecraft.client.render.command.RenderDispatcher
 *  net.minecraft.client.render.item.ItemRenderState
 *  net.minecraft.client.render.item.KeyedItemRenderState
 *  net.minecraft.client.util.BufferAllocator
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.item.ItemDisplayContext
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.HeldItemContext
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.world.World
 *  org.joml.Matrix3x2fStack
 *  org.joml.Matrix3x2fc
 *  org.joml.Matrix4fc
 *  org.jspecify.annotations.Nullable
 */
package recovered.internal;

import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.render.OutlineVertexConsumerProvider;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.TexturedRenderLayers;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.command.OrderedRenderCommandQueueImpl;
import net.minecraft.client.render.command.RenderDispatcher;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.item.KeyedItemRenderState;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.HeldItemContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix3x2fc;
import org.joml.Matrix4fc;
import org.jspecify.annotations.Nullable;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jE_23f766de;
import recovered.internal.Class_jI_616cf0dd;
import recovered.internal.Class_jO_1924117a;
import recovered.internal.Class_ju_tT_d469d25e;
import recovered.internal.Class_jx_3a49ff3b;
import recovered.internal.Class_kD_58a31f48;
import recovered.internal.Class_kJ_a7cdce3d;
import recovered.internal.Class_kd_dfbdd90e;
import recovered.internal.Class_lA_428877cb;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_ln_002c2933;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mZ_07f59a29;

public final class Class_ju_e398051e
implements Class_lA_428877cb {
    private static final float vMVWK = -10850.0f;
    private static final float wSuGG = 16.0f;
    private static @Nullable Class_jx_3a49ff3b EZsoO;
    private static String XBcvw;
    private static final long SIlUv;
    private static final long[] WageH;
    private static final Integer[] jOCMz;
    private static final Map VSGjo;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_ju_e398051e.SIlUv = Class_gb_9d201141.aYR(-1711104809145699340L, 5991162868861888221L, MethodHandles.lookup().lookupClass()).a(17282826408841L);
                Class_ju_e398051e.VSGjo = new HashMap<K, V>(13);
                Class_ju_e398051e.bGm("Ie0B1b");
                var0 = Class_ju_e398051e.SIlUv ^ 44549190952295L;
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[6];
                var5_4 = 0;
                var6_5 = "\u00c1n{\u00f7\u008bO\u00f4)\u00cd\u0001\u00d8\u00e7o\u001f\u00ecD\u00d1\u0088\u00cb\u0089^\u00d0\u00ba(*D\u00e9\u00ed\u001e\u000b\u0080\u00e9";
                var7_6 = "\u00c1n{\u00f7\u008bO\u00f4)\u00cd\u0001\u00d8\u00e7o\u001f\u00ecD\u00d1\u0088\u00cb\u0089^\u00d0\u00ba(*D\u00e9\u00ed\u001e\u000b\u0080\u00e9".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl27:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = "H\u00ea\u00c6\u00de7u\u00e8\u00f5\u00bb\u00de\u00b7P\u00b5\u0005\u008b\u00eb";
                    var7_6 = "H\u00ea\u00c6\u00de7u\u00e8\u00f5\u00bb\u00de\u00b7P\u00b5\u0005\u008b\u00eb".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl40:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl53:
                // 1 sources

                ** continue;
            }
        }
        Class_ju_e398051e.WageH = var8_3;
        Class_ju_e398051e.jOCMz = new Integer[6];
    }

    public static void bFO(@Nullable Matrix3x2fc matrix3x2fc, @Nullable LivingEntity livingEntity, @Nullable World world, ItemStack itemStack, float f, float f2, float f3, Class_ju_tT_d469d25e class_ju_tT_d469d25e) {
        long l = SIlUv ^ 0x6F730F3C8F8L;
        if (itemStack.isEmpty()) {
            return;
        }
        KeyedItemRenderState keyedItemRenderState = Class_ju_e398051e.bFW(livingEntity, world, itemStack);
        Class_ju_e398051e.bFX(keyedItemRenderState, matrix3x2fc, f, f2, f3, class_ju_tT_d469d25e);
    }

    public static String bGn() {
        return XBcvw;
    }

    public static void bFT(@Nullable Matrix3x2fc matrix3x2fc, ItemStack itemStack, float f, float f2, @Nullable String string, Class_ju_tT_d469d25e class_ju_tT_d469d25e) {
        long l = SIlUv ^ 0x37AE1C990D04L;
        if (itemStack.isEmpty()) {
            return;
        }
        Matrix3x2fStack matrix3x2fStack = Class_jI_616cf0dd.bIn(matrix3x2fc);
        matrix3x2fStack.translate(f, f2);
        Class_ju_e398051e.bGf(matrix3x2fStack, itemStack);
        Class_ju_e398051e.bGg(matrix3x2fStack, itemStack);
        Class_ju_e398051e.bGh(matrix3x2fStack, itemStack, string, class_ju_tT_d469d25e);
    }

    public static void bFU(@Nullable Matrix3x2fc matrix3x2fc, ItemStack itemStack, int n, int n2, int n3, @Nullable String string, Class_ju_tT_d469d25e class_ju_tT_d469d25e) {
        long l = SIlUv ^ 0x1BEC0091E786L;
        if (itemStack.isEmpty()) {
            return;
        }
        Matrix3x2fStack matrix3x2fStack = Class_jI_616cf0dd.bIn(matrix3x2fc);
        matrix3x2fStack.translate((float)n, (float)n2);
        matrix3x2fStack.scale((float)n3 / 16.0f, (float)n3 / 16.0f);
        Class_ju_e398051e.bGf(matrix3x2fStack, itemStack);
        Class_ju_e398051e.bGg(matrix3x2fStack, itemStack);
        Class_ju_e398051e.bGh(matrix3x2fStack, itemStack, string, class_ju_tT_d469d25e);
    }

    private static boolean bFZ(KeyedItemRenderState keyedItemRenderState) {
        boolean bl;
        block3: {
            block2: {
                String string;
                block1: {
                    long l = SIlUv ^ 0x5F69965169AL;
                    string = Class_ju_e398051e.bGn();
                    boolean bl2 = keyedItemRenderState.isSideLit();
                    if (string != null) {
                        bl2 = bl = !bl2;
                    }
                    if (string == null) break block1;
                    if (!bl) break block2;
                    ClientMain.dlmvG.gameRenderer.getDiffuseLighting().setShaderLights(DiffuseLighting.Type.ITEMS_FLAT);
                }
                if (string != null) break block3;
            }
            ClientMain.dlmvG.gameRenderer.getDiffuseLighting().setShaderLights(DiffuseLighting.Type.ITEMS_3D);
        }
        return bl;
    }

    private static void bGl(Object2ObjectLinkedOpenHashMap<RenderLayer, BufferAllocator> object2ObjectLinkedOpenHashMap, RenderLayer renderLayer) {
        object2ObjectLinkedOpenHashMap.put((Object)renderLayer, (Object)new BufferAllocator(renderLayer.getExpectedBufferSize()));
    }

    private static int bGq(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_ju_e398051e.bGp(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public static void bGm(String string) {
        XBcvw = string;
    }

    public static void bFP(Class_lC_5322e8cf class_lC_5322e8cf, ItemStack itemStack, float f, float f2, @Nullable String string, Class_ju_tT_d469d25e class_ju_tT_d469d25e) {
        Class_ju_e398051e.bFT((Matrix3x2fc)class_lC_5322e8cf.cfc(), itemStack, f, f2, string, class_ju_tT_d469d25e);
    }

    private static void bFX(KeyedItemRenderState keyedItemRenderState, @Nullable Matrix3x2fc matrix3x2fc, float f, float f2, float f3, Class_ju_tT_d469d25e class_ju_tT_d469d25e) {
        Class_ju_e398051e.bFY(keyedItemRenderState, matrix3x2fc, f, f2, f3, class_ju_tT_d469d25e);
    }

    private static void bFY(KeyedItemRenderState keyedItemRenderState, @Nullable Matrix3x2fc matrix3x2fc, float f, float f2, float f3, Class_ju_tT_d469d25e class_ju_tT_d469d25e) {
        long l = SIlUv ^ 0x658210FC7110L;
        MatrixStack matrixStack = Class_ju_e398051e.bGc(matrix3x2fc);
        Class_jx_3a49ff3b class_jx_3a49ff3b = Class_ju_e398051e.bGj();
        matrixStack.push();
        Class_ju_e398051e.bGb(matrixStack, f, f2, f3);
        boolean bl = Class_ju_e398051e.bFZ(keyedItemRenderState);
        Class_ju_e398051e.bGd(keyedItemRenderState, matrixStack, class_jx_3a49ff3b.submitNodeStorage());
        if (class_ju_tT_d469d25e == Class_ju_tT_d469d25e.yDoOO) {
            Class_ju_e398051e.bFV();
        }
        if (bl) {
            Class_ju_e398051e.bGa();
        }
        matrixStack.pop();
    }

    private static void bGe(Class_jx_3a49ff3b class_jx_3a49ff3b) {
        class_jx_3a49ff3b.featureRenderDispatcher().render();
        class_jx_3a49ff3b.bufferSource().draw();
        class_jx_3a49ff3b.crumblingBufferSource().draw();
        class_jx_3a49ff3b.outlineBufferSource().draw();
    }

    public static void bFR(@Nullable Matrix3x2fc matrix3x2fc, Class_lC_5322e8cf class_lC_5322e8cf, ItemStack itemStack, int n, int n2, int n3, @Nullable String string) {
        Class_ju_e398051e.bFS(matrix3x2fc, class_lC_5322e8cf, itemStack, n, n2, n3, string, Class_ju_tT_d469d25e.yDoOO);
    }

    /*
     * Unable to fully structure code
     */
    private static void bGg(Matrix3x2fStack var0, ItemStack var1_1) {
        var2_2 = Class_ju_e398051e.SIlUv ^ 77538651439403L;
        var4_3 = Class_ju_e398051e.bGn();
        v0 = ClientMain.dlmvG.player;
        if (var4_3 == null) ** GOTO lbl9
        if (v0 == null) {
            v1 = 0.0f;
        } else {
            v0 = ClientMain.dlmvG.player;
lbl9:
            // 2 sources

            v1 = v0.getItemCooldownManager().getCooldownProgress(var1_1, ClientMain.dlmvG.getRenderTickCounter().getTickProgress(true));
        }
        var5_4 = v1;
        cfr_temp_0 = var5_4 - 0.0f;
        v2 = cfr_temp_0 == 0.0f ? 0 : (cfr_temp_0 < 0.0f ? -1 : 1);
        if (var4_3 != null) {
            if (v2 <= 0) {
                return;
            }
            v2 = MathHelper.floor((float)(16.0f * (1.0f - var5_4)));
        }
        var6_5 = v2;
        var7_6 = var6_5 + MathHelper.ceil((float)(16.0f * var5_4));
        Class_ju_e398051e.bGi(var0, 0.0f, var6_5, 16.0f, var7_6 - var6_5, Class_mG_52c8d386.cnQ((int)Class_ju_e398051e.bGr("v", (int)27453, (long)(5488763918059445983L ^ var2_2))));
    }

    private static void bGi(Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3, float f4, Class_mG_52c8d386 class_mG_52c8d386) {
        ntCFX.bMM(Class_jO_1924117a.bJI(matrix3x2fStack, f, f2, f3, f4).dqh(Class_kd_dfbdd90e.AhlXN).dqk(class_mG_52c8d386).dqz());
    }

    private static int bGp(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x236A;
        if (jOCMz[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = WageH[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])VSGjo.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    VSGjo.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_ju_e398051e", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_ju_e398051e.jOCMz[n2] = n3;
        }
        return jOCMz[n2];
    }

    private static void bGb(MatrixStack matrixStack, float f, float f2, float f3) {
        matrixStack.translate(f + f3 / 2.0f, f2 + f3 / 2.0f, -10850.0f);
        matrixStack.scale(f3, -f3, f3);
    }

    private static Object2ObjectLinkedOpenHashMap<RenderLayer, BufferAllocator> bGk() {
        Object2ObjectLinkedOpenHashMap object2ObjectLinkedOpenHashMap = new Object2ObjectLinkedOpenHashMap();
        Class_ju_e398051e.bGl((Object2ObjectLinkedOpenHashMap<RenderLayer, BufferAllocator>)object2ObjectLinkedOpenHashMap, TexturedRenderLayers.getEntityCutout());
        Class_ju_e398051e.bGl((Object2ObjectLinkedOpenHashMap<RenderLayer, BufferAllocator>)object2ObjectLinkedOpenHashMap, TexturedRenderLayers.getBlockTranslucentCull());
        Class_ju_e398051e.bGl((Object2ObjectLinkedOpenHashMap<RenderLayer, BufferAllocator>)object2ObjectLinkedOpenHashMap, TexturedRenderLayers.getItemTranslucentCull());
        Class_jE_23f766de.bHu((Object2ObjectLinkedOpenHashMap<RenderLayer, BufferAllocator>)object2ObjectLinkedOpenHashMap);
        Class_ju_e398051e.bGl((Object2ObjectLinkedOpenHashMap<RenderLayer, BufferAllocator>)object2ObjectLinkedOpenHashMap, RenderLayers.waterMask());
        return object2ObjectLinkedOpenHashMap;
    }

    private static void bGf(Matrix3x2fStack matrix3x2fStack, ItemStack itemStack) {
        long l = SIlUv ^ 0x495B539C9875L;
        String string = Class_ju_e398051e.bGn();
        if (string != null) {
            if (!itemStack.isItemBarVisible()) {
                return;
            }
            Class_ju_e398051e.bGi(matrix3x2fStack, 2.0f, 13.0f, 13.0f, 2.0f, Class_mG_52c8d386.cnQ((int)Class_ju_e398051e.bGr("v", (int)9573, (long)(0x261411F8E35A49DEL ^ l))));
            Class_ju_e398051e.bGi(matrix3x2fStack, 2.0f, 13.0f, itemStack.getItemBarStep(), 1.0f, Class_mG_52c8d386.cnQ(Class_ju_e398051e.bGr("v", (int)695, (long)(0x3BC46F3DECE2EE0FL ^ l)) | itemStack.getItemBarColor()));
        }
    }

    public static void bFQ(@Nullable Matrix3x2fc matrix3x2fc, Class_lC_5322e8cf class_lC_5322e8cf, ItemStack itemStack, int n, int n2, int n3) {
        Class_ju_e398051e.bFR(matrix3x2fc, class_lC_5322e8cf, itemStack, n, n2, n3, null);
    }

    private static void bGa() {
        MinecraftClient.getInstance().gameRenderer.getDiffuseLighting().setShaderLights(DiffuseLighting.Type.ITEMS_3D);
    }

    private static void bGd(KeyedItemRenderState keyedItemRenderState, MatrixStack matrixStack, OrderedRenderCommandQueueImpl orderedRenderCommandQueueImpl) {
        long l = SIlUv ^ 0x39A9B8DD83C1L;
        keyedItemRenderState.render(matrixStack, (OrderedRenderCommandQueue)orderedRenderCommandQueueImpl, (int)Class_ju_e398051e.bGr("v", (int)17821, (long)(0x7F4E7EC0F1CDB290L ^ l)), OverlayTexture.DEFAULT_UV, 0);
    }

    /*
     * Unable to fully structure code
     */
    private static void bGh(Matrix3x2fStack var0, ItemStack var1_1, @Nullable String var2_2, Class_ju_tT_d469d25e var3_3) {
        var4_4 = Class_ju_e398051e.SIlUv ^ 106067096257636L;
        var6_5 = Class_ju_e398051e.bGn();
        if (var1_1.getCount() == 1) {
            v0 = var2_2;
            if (var6_5 != null) {
                if (v0 == null) {
                    return;
                } else {
                    ** GOTO lbl-1000
                }
            }
        } else lbl-1000:
        // 3 sources

        {
            v0 = var2_2;
        }
        if (var6_5 != null) {
            v0 = v0 != null ? var2_2 : String.valueOf(var1_1.getCount());
        }
        var7_6 = v0;
        var8_7 = Class_lE_06fbe260.WTzbi.bYM(8.0f);
        var9_8 = 17.0f - var8_7.cao(var7_6);
        var10_9 = 17.0f - var8_7.cat();
        if (var6_5 != null) {
            if (var3_3 == Class_ju_tT_d469d25e.IHKNQ) {
                var11_10 = Class_ju_e398051e.bGj().textBatch();
                var11_10.bUc(var8_7);
                var11_10.bUd(Class_kD_58a31f48.bST(var0, var9_8, var10_9, 0.0, var8_7.caw(), Class_mZ_07f59a29.csh(var7_6)).dsX(Class_mG_52c8d386.hoGuU).dsY());
                return;
            }
            Class_ln_002c2933.bZG(var8_7.cav(), var7_6, var8_7.caw(), Class_mG_52c8d386.hoGuU, Class_jI_616cf0dd.bIl((Matrix3x2fc)var0), var9_8, var10_9, 0.0f);
        }
    }

    private static MatrixStack bGc(@Nullable Matrix3x2fc matrix3x2fc) {
        MatrixStack matrixStack;
        block0: {
            long l = SIlUv ^ 0x4E36A64A0E54L;
            matrixStack = new MatrixStack();
            if (matrix3x2fc == null) break block0;
            matrixStack.multiplyPositionMatrix((Matrix4fc)Class_jI_616cf0dd.bIl(matrix3x2fc));
        }
        return matrixStack;
    }

    private static MatchException bGo(MatchException matchException) {
        return matchException;
    }

    private static CallSite bGr(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_ju_e398051e" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public static void bFN(@Nullable Matrix3x2fc matrix3x2fc, @Nullable LivingEntity livingEntity, @Nullable World world, ItemStack itemStack, float f, float f2, float f3) {
        Class_ju_e398051e.bFO(matrix3x2fc, livingEntity, world, itemStack, f, f2, f3, Class_ju_tT_d469d25e.yDoOO);
    }

    public static void bFS(@Nullable Matrix3x2fc matrix3x2fc, Class_lC_5322e8cf class_lC_5322e8cf, ItemStack itemStack, int n, int n2, int n3, @Nullable String string, Class_ju_tT_d469d25e class_ju_tT_d469d25e) {
        Class_ju_e398051e.bFU(matrix3x2fc, itemStack, n, n2, n3, string, class_ju_tT_d469d25e);
    }

    private static KeyedItemRenderState bFW(@Nullable LivingEntity livingEntity, @Nullable World world, ItemStack itemStack) {
        KeyedItemRenderState keyedItemRenderState = new KeyedItemRenderState();
        ClientMain.dlmvG.getItemModelManager().clearAndUpdate((ItemRenderState)keyedItemRenderState, itemStack, ItemDisplayContext.GUI, world, (HeldItemContext)livingEntity, 0);
        return keyedItemRenderState;
    }

    private static Class_jx_3a49ff3b bGj() {
        long l = SIlUv ^ 0x2F2CEBD1D234L;
        String string = Class_ju_e398051e.bGn();
        Class_jx_3a49ff3b class_jx_3a49ff3b = EZsoO;
        if (string != null) {
            if (class_jx_3a49ff3b == null) {
                OrderedRenderCommandQueueImpl orderedRenderCommandQueueImpl = new OrderedRenderCommandQueueImpl();
                VertexConsumerProvider.Immediate immediate = VertexConsumerProvider.immediate(Class_ju_e398051e.bGk(), (BufferAllocator)new BufferAllocator((int)Class_ju_e398051e.bGr("v", (int)2265, (long)(0x3C967E1C3CD9AE22L ^ l))));
                OutlineVertexConsumerProvider outlineVertexConsumerProvider = new OutlineVertexConsumerProvider();
                VertexConsumerProvider.Immediate immediate2 = VertexConsumerProvider.immediate((BufferAllocator)new BufferAllocator((int)Class_ju_e398051e.bGr("v", (int)3415, (long)(0x286CFCD0C200ABABL ^ l))));
                EZsoO = new Class_jx_3a49ff3b(orderedRenderCommandQueueImpl, immediate, outlineVertexConsumerProvider, immediate2, new RenderDispatcher(orderedRenderCommandQueueImpl, ClientMain.dlmvG.getBlockRenderManager(), immediate, ClientMain.dlmvG.getAtlasManager(), outlineVertexConsumerProvider, immediate2, ClientMain.dlmvG.textRenderer), new Class_kJ_a7cdce3d());
            }
            class_jx_3a49ff3b = EZsoO;
        }
        return class_jx_3a49ff3b;
    }

    public static void bFV() {
        long l = SIlUv ^ 0xE5CD039BAE1L;
        Class_jx_3a49ff3b class_jx_3a49ff3b = EZsoO;
        String string = Class_ju_e398051e.bGn();
        Class_jx_3a49ff3b class_jx_3a49ff3b2 = class_jx_3a49ff3b;
        if (string != null) {
            if (class_jx_3a49ff3b2 == null) {
                return;
            }
            Class_ju_e398051e.bGe(class_jx_3a49ff3b);
            class_jx_3a49ff3b2 = class_jx_3a49ff3b;
        }
        class_jx_3a49ff3b2.textBatch().endBatch();
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_ju_e398051e.class, "bGq", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

