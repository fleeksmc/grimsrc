/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.packet.Packet
 */
package recovered.internal;

import net.minecraft.network.packet.Packet;
import recovered.core.NativeLoader;
import recovered.internal.Class_gG_bbb50cac;
import recovered.internal.Class_hF_7bd1921e;
import recovered.internal.Class_hG_d70cdb00;
import recovered.modules.BacktrackModule;
import recovered.modules.TargetLockModule;

public class Class_fp_sQ_90b25619 {
    final BacktrackModule mEqah;
    private static long rAQCM;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native boolean doZ(Packet var0);

    private static native void dpa(Packet var0);

    private static native MatchException dpb(MatchException var0);

    @Class_hG_d70cdb00
    public void doY(Class_gG_bbb50cac class_gG_bbb50cac) {
        block24: {
            block25: {
                BacktrackModule backtrackModule;
                boolean bl;
                block23: {
                    int[] nArray;
                    block22: {
                        BacktrackModule backtrackModule2;
                        block20: {
                            boolean bl2;
                            block18: {
                                block19: {
                                    long l = rAQCM ^ 0x5AAB0FC49D9AL;
                                    nArray = TargetLockModule.aIW();
                                    try {
                                        try {
                                            bl2 = BacktrackModule.aMu(this.mEqah);
                                            if (nArray != null) break block18;
                                            if (bl2) break block19;
                                        }
                                        catch (MatchException matchException) {
                                            throw Class_fp_sQ_90b25619.dpb(matchException);
                                        }
                                        this.mEqah.aLP(true, true, true);
                                        return;
                                    }
                                    catch (MatchException matchException) {
                                        throw Class_fp_sQ_90b25619.dpb(matchException);
                                    }
                                }
                                try {
                                    backtrackModule2 = this.mEqah;
                                    if (nArray != null) break block20;
                                    bl2 = backtrackModule2.aLS();
                                }
                                catch (MatchException matchException) {
                                    throw Class_fp_sQ_90b25619.dpb(matchException);
                                }
                            }
                            try {
                                block21: {
                                    try {
                                        if (!bl2) break block21;
                                        this.mEqah.aLN(false);
                                        if (nArray == null) break block22;
                                    }
                                    catch (MatchException matchException) {
                                        throw Class_fp_sQ_90b25619.dpb(matchException);
                                    }
                                }
                                backtrackModule2 = this.mEqah;
                            }
                            catch (MatchException matchException) {
                                throw Class_fp_sQ_90b25619.dpb(matchException);
                            }
                        }
                        backtrackModule2.aLP(true, false, true);
                    }
                    try {
                        try {
                            try {
                                this.mEqah.cDqQL.removeIf(Class_fp_sQ_90b25619::doZ);
                                bl = this.mEqah.cDqQL.isEmpty();
                                if (nArray != null) break block23;
                                if (!bl) break block24;
                            }
                            catch (MatchException matchException) {
                                throw Class_fp_sQ_90b25619.dpb(matchException);
                            }
                            backtrackModule = this.mEqah;
                            if (nArray != null) break block25;
                        }
                        catch (MatchException matchException) {
                            throw Class_fp_sQ_90b25619.dpb(matchException);
                        }
                        bl = backtrackModule.UlcPe.isEmpty();
                    }
                    catch (MatchException matchException) {
                        throw Class_fp_sQ_90b25619.dpb(matchException);
                    }
                }
                try {
                    if (!bl) break block24;
                    this.mEqah.heFtE = this.mEqah.yNflG.UN().intValue();
                    backtrackModule = this.mEqah;
                }
                catch (MatchException matchException) {
                    throw Class_fp_sQ_90b25619.dpb(matchException);
                }
            }
            backtrackModule.fNonW = this.mEqah.AJNZt.UN().intValue();
        }
    }

    public Class_fp_sQ_90b25619(BacktrackModule backtrackModule) {
        this.mEqah = backtrackModule;
        Class_hF_7bd1921e.bdI(this);
    }

    static {
        NativeLoader.doInit(Class_fp_sQ_90b25619.class);
        Class_fp_sQ_90b25619._2db8ec2939b94b3ea880a84b6606dbb5();
    }

    private static native void _2db8ec2939b94b3ea880a84b6606dbb5();
}

