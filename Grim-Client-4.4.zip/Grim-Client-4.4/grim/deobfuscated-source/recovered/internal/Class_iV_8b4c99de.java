/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$Full
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_ov_6c6757ad;

public class Class_iV_8b4c99de {
    public static final Class_ov_6c6757ad uTmcD;
    public static final Class_ov_6c6757ad XsgMs;
    public static final Class_ov_6c6757ad Qhihw;
    public static final Class_ov_6c6757ad BzuYL;
    public static final Class_ov_6c6757ad HGROY;
    public static final Class_ov_6c6757ad GDobf;
    private static final long iPecI;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        iPecI = Class_gb_9d201141.aYR(879203543032306159L, 1449607818855702903L, MethodHandles.lookup().lookupClass()).a(246983329538410L);
        uTmcD = Class_ov_6c6757ad.cGx(new Vec3d(0.0, 20.0, 0.0));
        XsgMs = Class_ov_6c6757ad.cGx(new Vec3d(0.0, -20.0, 0.0));
        Qhihw = Class_ov_6c6757ad.cGx(new Vec3d(20.0, 0.0, 0.0));
        BzuYL = Class_ov_6c6757ad.cGx(new Vec3d(-20.0, 0.0, 0.0));
        HGROY = Class_ov_6c6757ad.cGx(new Vec3d(0.0, 0.0, 20.0));
        GDobf = Class_ov_6c6757ad.cGx(new Vec3d(0.0, 0.0, -20.0));
    }

    public static Vec3d bxi(float f, float f2) {
        float f3 = f * ((float)Math.PI / 180);
        float f4 = -f2 * ((float)Math.PI / 180);
        float f5 = MathHelper.cos((double)f4);
        float f6 = MathHelper.sin((double)f4);
        float f7 = MathHelper.cos((double)f3);
        float f8 = MathHelper.sin((double)f3);
        return new Vec3d((double)(f6 * f7), (double)(-f8), (double)(f5 * f7));
    }

    public static Class_ov_6c6757ad bxe(Class_ov_6c6757ad class_ov_6c6757ad, Class_ov_6c6757ad class_ov_6c6757ad2) {
        float f;
        float f2;
        block6: {
            float f3;
            float f4;
            float f5;
            block5: {
                long l = iPecI ^ 0x72B633E619C7L;
                f5 = MathHelper.wrapDegrees((float)(class_ov_6c6757ad2.cGI() - class_ov_6c6757ad.cGI()));
                String[] stringArray = Class_jf_d1c4f950.bBe();
                f4 = MathHelper.wrapDegrees((float)(class_ov_6c6757ad2.cGJ() - class_ov_6c6757ad.cGJ()));
                float f6 = f4 - -180.0f;
                f3 = f6 == 0.0f ? 0 : (f6 > 0.0f ? 1 : -1);
                if (stringArray == null) break block5;
                if (f3 == false) {
                    f4 = 180.0f;
                }
                f2 = f5;
                f = -180.0f;
                if (stringArray == null) break block6;
                float f7 = f2 - f;
                f3 = f7 == 0.0f ? 0 : (f7 > 0.0f ? 1 : -1);
            }
            if (f3 == false) {
                f5 = 180.0f;
            }
            f2 = f5;
            f = f4;
        }
        return Class_ov_6c6757ad.cGv(f2, f);
    }

    private static MatchException bxo(MatchException matchException) {
        return matchException;
    }

    public static Vec3d bxh(PlayerEntity playerEntity) {
        float f = ClientMain.dlmvG.getRenderTickCounter().getTickProgress(true);
        return Class_iV_8b4c99de.bxi(playerEntity.getPitch(f), playerEntity.getYaw(f));
    }

    public static double bxf(Vec3d vec3d, Vec3d vec3d2, Class_ov_6c6757ad class_ov_6c6757ad) {
        Class_ov_6c6757ad class_ov_6c6757ad2 = Class_ov_6c6757ad.cGx(vec3d2.subtract(vec3d));
        Class_ov_6c6757ad class_ov_6c6757ad3 = Class_iV_8b4c99de.bxe(class_ov_6c6757ad, class_ov_6c6757ad2);
        return Math.hypot(class_ov_6c6757ad3.cGI(), class_ov_6c6757ad3.cGJ());
    }

    public static double bxg(Class_ov_6c6757ad class_ov_6c6757ad, Entity entity) {
        double d = MathHelper.wrapDegrees((float)entity.getYaw());
        double d2 = MathHelper.wrapDegrees((float)entity.getPitch());
        double d3 = MathHelper.wrapDegrees((double)(d - (double)class_ov_6c6757ad.cGI()));
        double d4 = MathHelper.wrapDegrees((double)(d2 - (double)class_ov_6c6757ad.cGJ()));
        return Math.sqrt(d3 * d3 + d4 * d4);
    }

    public static double bxj(Vec3d vec3d) {
        return Math.toDegrees(Math.atan2(vec3d.getZ(), vec3d.getX())) - 90.0;
    }

    public static void bxk(Vec3d vec3d) {
        Class_ov_6c6757ad class_ov_6c6757ad = Class_iV_8b4c99de.bxm(vec3d);
        Class_iV_8b4c99de.bxl(class_ov_6c6757ad);
    }

    public static void bxl(Class_ov_6c6757ad class_ov_6c6757ad) {
        ClientMain.dlmvG.getNetworkHandler().sendPacket((Packet)new PlayerMoveC2SPacket.Full(ClientMain.dlmvG.player.getX(), ClientMain.dlmvG.player.getY(), ClientMain.dlmvG.player.getZ(), class_ov_6c6757ad.cGI(), class_ov_6c6757ad.cGJ(), ClientMain.dlmvG.player.isOnGround(), ClientMain.dlmvG.player.horizontalCollision));
    }

    public static Class_ov_6c6757ad bxn(Vec3d vec3d, Vec3d vec3d2) {
        double d = vec3d2.x - vec3d.x;
        double d2 = vec3d2.y - vec3d.y;
        double d3 = vec3d2.z - vec3d.z;
        float f = (float)Math.toDegrees(Math.atan2(d3, d)) - 90.0f;
        double d4 = Math.sqrt(d * d + d3 * d3);
        float f2 = (float)(-Math.toDegrees(Math.atan2(d2, d4)));
        return Class_ov_6c6757ad.cGv(f, f2);
    }

    public static Class_ov_6c6757ad bxm(Vec3d vec3d) {
        Vec3d vec3d2 = new Vec3d(ClientMain.dlmvG.player.getX(), ClientMain.dlmvG.player.getY() + (double)ClientMain.dlmvG.player.getEyeHeight(ClientMain.dlmvG.player.getPose()), ClientMain.dlmvG.player.getZ());
        return Class_iV_8b4c99de.bxn(vec3d2, vec3d);
    }
}

