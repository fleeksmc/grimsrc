/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_gC_1f010b94;

public class Class_gC_tg_2cd7e753
extends Class_gC_1f010b94 {
    private final boolean LUCQZ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gC_tg_2cd7e753(boolean bl) {
        this.LUCQZ = bl;
    }

    public boolean dpl() {
        return this.LUCQZ;
    }
}

