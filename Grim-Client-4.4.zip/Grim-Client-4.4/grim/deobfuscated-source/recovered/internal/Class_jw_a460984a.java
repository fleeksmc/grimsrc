/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  org.joml.Matrix3x2fc
 *  org.jspecify.annotations.Nullable
 */
package recovered.internal;

import net.minecraft.item.ItemStack;
import org.joml.Matrix3x2fc;
import org.jspecify.annotations.Nullable;
import recovered.internal.Class_ju_e398051e;
import recovered.internal.Class_ju_tT_d469d25e;
import recovered.internal.Class_jy_33e84da2;

public final class Class_jw_a460984a
extends Class_jy_33e84da2<Class_jw_a460984a> {
    private String zujhu;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_jw_a460984a(@Nullable Matrix3x2fc matrix3x2fc, ItemStack itemStack, float f, float f2) {
        super(matrix3x2fc, itemStack, f, f2, Class_ju_tT_d469d25e.yDoOO);
    }

    public Class_jw_a460984a bGz(@Nullable String string) {
        this.zujhu = string;
        return this;
    }

    @Override
    public void renderIntoBatch() {
        Class_ju_e398051e.bFT(this.wvKbm, this.qeMTM, this.svsZw, this.zXQoo, this.zujhu, this.qxFcM);
    }
}

