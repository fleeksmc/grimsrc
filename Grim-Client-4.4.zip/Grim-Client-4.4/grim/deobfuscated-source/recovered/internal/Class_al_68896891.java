/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_Y_0432e62a;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_al_68896891
extends Class_az_a4990dcf {
    private final Class_rk_bf8630d1 YwcCr;
    private final Class_rk_bf8630d1 bVDav;
    private final Class_Y_0432e62a AAiYe;
    private static long fZIcG;
    private static long[] KtGNT;
    private static Integer[] dqbdU;
    private static Map cEnnF;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_al_68896891() {
        long l = fZIcG ^ 0x3D0CA657FBA2L;
        this.YwcCr = new Class_rk_bf8630d1((int)Class_al_68896891.oW("z", (int)2131, (long)(0x6C9D9396F94374F4L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.bVDav = new Class_rk_bf8630d1((int)Class_al_68896891.oW("z", (int)20498, (long)(0x58E7B0BCD9352CB4L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.AAiYe = new Class_Y_0432e62a().kf(Class_lE_06fbe260.WTzbi.bYM(8.0f)).kg(Class_bl_a15fbaa5.Ex().EB().wp().vD()).ki(5.0f).kj((int)Class_al_68896891.oW("z", (int)20498, (long)(0x58E7B0BCD9352CB4L ^ l))).kk(Class_rj_b691f4f7.UPXqT);
    }

    static {
        NativeLoader.doInit(Class_al_68896891.class);
        Class_al_68896891._bf34f1a8893d163f659ad88c81e89d47();
    }

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private static native void _bf34f1a8893d163f659ad88c81e89d47();

    public native Class_rk_bf8630d1 oQ();

    public native Class_rk_bf8630d1 oR();

    public native Class_Y_0432e62a oS();

    private static native CallSite oW(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native MatchException oT(MatchException var0);

    private static native int oU(int var0, long var1);

    private static native int oV(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);
}

