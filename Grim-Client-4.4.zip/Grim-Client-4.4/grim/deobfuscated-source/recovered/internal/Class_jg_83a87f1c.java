/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockState
 *  net.minecraft.block.Blocks
 *  net.minecraft.client.network.ClientPlayNetworkHandler
 *  net.minecraft.client.network.ClientPlayerEntity
 *  net.minecraft.client.network.PlayerListEntry
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityType
 *  net.minecraft.entity.EquipmentSlot
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.Items
 *  net.minecraft.network.packet.Packet
 *  net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket$PositionAndOnGround
 *  net.minecraft.util.ActionResult
 *  net.minecraft.util.ActionResult$Success
 *  net.minecraft.util.ActionResult$SwingSource
 *  net.minecraft.util.Hand
 *  net.minecraft.util.hit.BlockHitResult
 *  net.minecraft.util.hit.HitResult$Type
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.BlockPos$Mutable
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.BlockView
 *  net.minecraft.world.GameMode
 *  net.minecraft.world.RaycastContext
 *  net.minecraft.world.RaycastContext$FluidHandling
 *  net.minecraft.world.RaycastContext$ShapeType
 *  net.minecraft.world.World
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.security.Key;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import net.minecraft.world.GameMode;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_pf_5fda8840;

public class Class_jg_83a87f1c {
    public static final String gaLzx;
    public static final Set<EntityType<? extends Entity>> hZYeV;
    public static final Set<EntityType<? extends Entity>> fbEDU;
    public static final Set<EntityType<? extends Entity>> skTlu;
    private static final String[] okfwP;
    private static int aIWFT;
    private static final long CcOBc;
    private static final long[] xEBCE;
    private static final Integer[] bSsdq;
    private static final Map KBkDM;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Unable to fully structure code
     */
    static {
        block22: {
            block21: {
                block20: {
                    block19: {
                        Class_jg_83a87f1c.CcOBc = Class_gb_9d201141.aYR(-4077821107154291975L, -7390323926547277616L, MethodHandles.lookup().lookupClass()).a(133219813590623L);
                        var20 = Class_jg_83a87f1c.CcOBc ^ 116231379233606L;
                        if (Class_jg_83a87f1c.bCa() != 0) {
                            Class_jg_83a87f1c.bBY(14);
                        }
                        var12_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var20 >>> 56);
                        for (var13_2 = 1; var13_2 < 8; ++var13_2) {
                            v2 = v2;
                            v2[var13_2] = (byte)(var20 << var13_2 * 8 >>> 56);
                        }
                        var12_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var11_3 = new String[5];
                        var17_4 = 0;
                        var16_5 = "&\u0080\"\u0088\t\u009f\u008b\u00a9\b\u00a0>\u00fbK\u008e^D8\b2\u0091P\u001f\u001b\u00c2\u00de\u001c";
                        var18_6 = "&\u0080\"\u0088\t\u009f\u008b\u00a9\b\u00a0>\u00fbK\u008e^D8\b2\u0091P\u001f\u001b\u00c2\u00de\u001c".length();
                        var15_7 = 8;
                        var14_8 = -1;
lbl21:
                        // 2 sources

                        while (true) {
                            v3 = ++var14_8;
                            v4 = var16_5.substring(v3, v3 + var15_7);
                            v5 = -1;
                            break block19;
                            break;
                        }
lbl26:
                        // 1 sources

                        while (true) {
                            var11_3[var17_4++] = Class_jg_83a87f1c.bCc(var19_9).intern();
                            if ((var14_8 += var15_7) < var18_6) {
                                var15_7 = var16_5.charAt(var14_8);
                                ** continue;
                            }
                            var16_5 = "\u00eb\u00ee:\u00df\u00cd9m\u00dcAzi,+\u009a\u0099\u001b\u0093\u00b7U-Q<\u00fc\u0016\bX\u00f5t\u00bcE\u00a8\u009a!";
                            var18_6 = "\u00eb\u00ee:\u00df\u00cd9m\u00dcAzi,+\u009a\u0099\u001b\u0093\u00b7U-Q<\u00fc\u0016\bX\u00f5t\u00bcE\u00a8\u009a!".length();
                            var15_7 = 24;
                            var14_8 = -1;
lbl35:
                            // 2 sources

                            while (true) {
                                v6 = ++var14_8;
                                v4 = var16_5.substring(v6, v6 + var15_7);
                                v5 = 0;
                                break block19;
                                break;
                            }
                            break;
                        }
lbl40:
                        // 1 sources

                        while (true) {
                            var11_3[var17_4++] = Class_jg_83a87f1c.bCc(var19_9).intern();
                            if ((var14_8 += var15_7) < var18_6) {
                                var15_7 = var16_5.charAt(var14_8);
                                ** continue;
                            }
                            break block20;
                            break;
                        }
                    }
                    var19_9 = var12_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl52:
                        // 1 sources

                        ** continue;
                    }
                }
                Class_jg_83a87f1c.gaLzx = var11_3[3];
                Class_jg_83a87f1c.KBkDM = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var20 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var20 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[26];
                var3_13 = 0;
                var4_14 = "\u0011\u0083\u00ad\u00e2\u009c_c5\u00c0|q/\f\u00a6\u00f9\u0005\u00a1\u0086\u00a0\u00eeU\u00a4\u00bb\u00a8\u0098\u008e\u0001\u00cf\u00ca\u0019\u0081\u0088t\u001ek\rD.\f\u00e8v\u008c\u0081\u00e8\u00a5U\u009c\u00d4\u00d7Q^p<\u00b6Ww2/\u007fOW\u00d80~J.\u00cbD3x\u0092\u0010\u00f8\u009ez\u00e6\u009bO\t\u00c7\u0005\u00ce\u00c0\u00f7\u00d1\u00b6\u0083\u00c4q\u00f9\u001bYl\u009d\u00a6\u0095e\f\u00c6\u00a0d!\u00c3\u00a9\u0014\u00de\u008f3\u00f4\u0005\\V\u0005\u00d9\u00ac\u00f3\u00f4n\u0084\u0097+\u00b0a0\u00ec\u00e7rc=\u00cb\u0090-z\u0002E\u00cb\u00d8\u001c\u00cc\u0096\u00c8\u0011\u0090\u0094.\u001b\u00e4z\u00a2nZ5dV](\u00db\u00dc\u0089\u0018U\u00bf\nd\u0092\n\u00f5$e\u00dd\u0098\u00a1\u00e4\u00feX5V\u00c0\u00fc\u00a9~\u0007`2\u0082\u00993\u007f*\u00f8\u00e9\u0012";
                var5_15 = "\u0011\u0083\u00ad\u00e2\u009c_c5\u00c0|q/\f\u00a6\u00f9\u0005\u00a1\u0086\u00a0\u00eeU\u00a4\u00bb\u00a8\u0098\u008e\u0001\u00cf\u00ca\u0019\u0081\u0088t\u001ek\rD.\f\u00e8v\u008c\u0081\u00e8\u00a5U\u009c\u00d4\u00d7Q^p<\u00b6Ww2/\u007fOW\u00d80~J.\u00cbD3x\u0092\u0010\u00f8\u009ez\u00e6\u009bO\t\u00c7\u0005\u00ce\u00c0\u00f7\u00d1\u00b6\u0083\u00c4q\u00f9\u001bYl\u009d\u00a6\u0095e\f\u00c6\u00a0d!\u00c3\u00a9\u0014\u00de\u008f3\u00f4\u0005\\V\u0005\u00d9\u00ac\u00f3\u00f4n\u0084\u0097+\u00b0a0\u00ec\u00e7rc=\u00cb\u0090-z\u0002E\u00cb\u00d8\u001c\u00cc\u0096\u00c8\u0011\u0090\u0094.\u001b\u00e4z\u00a2nZ5dV](\u00db\u00dc\u0089\u0018U\u00bf\nd\u0092\n\u00f5$e\u00dd\u0098\u00a1\u00e4\u00feX5V\u00c0\u00fc\u00a9~\u0007`2\u0082\u00993\u007f*\u00f8\u00e9\u0012".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block21;
                    break;
                }
lbl79:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "r\u0007\u00af\u00d2\u00fb\u0097\u001b\u001f\u001c\u00d2\u00c2\u00e1\u00f8\u0097\u00af\u00d7";
                    var5_15 = "r\u0007\u00af\u00d2\u00fb\u0097\u001b\u001f\u001c\u00d2\u00c2\u00e1\u00f8\u0097\u00af\u00d7".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block21;
                        break;
                    }
                    break;
                }
lbl92:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block22;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl105:
                // 1 sources

                ** continue;
            }
        }
        Class_jg_83a87f1c.xEBCE = var6_12;
        Class_jg_83a87f1c.bSsdq = new Integer[26];
        Class_jg_83a87f1c.hZYeV = Class_jg_83a87f1c.bBS();
        Class_jg_83a87f1c.fbEDU = Class_jg_83a87f1c.bBU();
        Class_jg_83a87f1c.skTlu = Class_jg_83a87f1c.bBT();
        v15 = new String[Class_jg_83a87f1c.bCf("i", (int)6484, (long)(4565298335807544230L ^ var20))];
        v15[0] = "N";
        v15[1] = var11_3[0];
        v15[2] = "E";
        v15[3] = var11_3[4];
        v15[4] = "S";
        v15[5] = var11_3[2];
        v15[Class_jg_83a87f1c.bCf("i", (int)9041, (long)(6702167822508499371L ^ var20))] = "W";
        v15[Class_jg_83a87f1c.bCf("i", (int)22629, (long)(5563684398666701465L ^ var20))] = var11_3[1];
        Class_jg_83a87f1c.okfwP = v15;
    }

    public static double bBI(Entity entity) {
        return Class_jg_83a87f1c.bBJ(ClientMain.dlmvG.player.getEyePos(), entity.getBoundingBox());
    }

    private static CallSite bCf(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jg_83a87f1c" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public static Vec3d bBE(Vec3d vec3d, float f, float f2) {
        long l = CcOBc ^ 0x11AED5655CDAL;
        double d = vec3d.lengthSquared();
        String[] stringArray = Class_jf_d1c4f950.bBe();
        double d2 = d - 1.0E-7;
        double d3 = d2 == 0.0 ? 0 : (d2 < 0.0 ? -1 : 1);
        if (stringArray != null) {
            if (d3 < 0) {
                return Vec3d.ZERO;
            }
            double d4 = d - 1.0;
            d3 = d4 == 0.0 ? 0 : (d4 > 0.0 ? 1 : -1);
        }
        Vec3d vec3d2 = (d3 > 0 ? vec3d.normalize() : vec3d).multiply((double)f);
        float f3 = MathHelper.sin((double)(f2 * ((float)Math.PI / 180)));
        float f4 = MathHelper.cos((double)(f2 * ((float)Math.PI / 180)));
        return new Vec3d(vec3d2.x * (double)f4 - vec3d2.z * (double)f3, vec3d2.y, vec3d2.z * (double)f4 + vec3d2.x * (double)f3);
    }

    public static int bBx(PlayerEntity playerEntity) {
        PlayerListEntry playerListEntry;
        long l = CcOBc ^ 0x40F858592182L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        ClientPlayNetworkHandler clientPlayNetworkHandler = ClientMain.dlmvG.getNetworkHandler();
        if (stringArray != null) {
            if (clientPlayNetworkHandler == null) {
                return 0;
            }
            clientPlayNetworkHandler = ClientMain.dlmvG.getNetworkHandler();
        }
        PlayerListEntry playerListEntry2 = playerListEntry = clientPlayNetworkHandler.getPlayerListEntry(playerEntity.getUuid());
        if (stringArray != null) {
            if (playerListEntry2 == null) {
                return 0;
            }
            playerListEntry2 = playerListEntry;
        }
        return playerListEntry2.getLatency();
    }

    public static double bBJ(Vec3d vec3d, Box box) {
        Vec3d vec3d2 = Class_jg_83a87f1c.bBK(vec3d, box);
        return Class_jg_83a87f1c.bBH(vec3d2, vec3d);
    }

    public static boolean bBL(Entity entity, Entity entity2) {
        long l = CcOBc ^ 0x71BE319B3927L;
        Vec3d vec3d = entity.getRotationVector(0.0f, entity.getHeadYaw());
        Vec3d vec3d2 = entity2.getEntityPos().relativize(entity.getEntityPos());
        vec3d2 = new Vec3d(vec3d2.x, 0.0, vec3d2.z).normalize();
        String[] stringArray = Class_jf_d1c4f950.bBe();
        double d = vec3d2.dotProduct(vec3d) - 0.0;
        double d2 = d == 0.0 ? 0 : (d < 0.0 ? -1 : 1);
        if (stringArray != null) {
            d2 = d2 < 0 ? 1.0 : 0.0;
        }
        return (boolean)d2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean bBR(ActionResult actionResult) {
        ActionResult.Success success;
        long l = CcOBc ^ 0x3B8506D6A578L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        ActionResult actionResult2 = actionResult;
        if (stringArray != null) {
            if (!(actionResult2 instanceof ActionResult.Success)) return false;
            actionResult2 = actionResult;
        }
        if ((success = (ActionResult.Success)actionResult2).comp_2909() != ActionResult.SwingSource.CLIENT) return false;
        return true;
    }

    private static int bCe(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_jg_83a87f1c.bCd(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public static int bCa() {
        int n = Class_jg_83a87f1c.bBZ();
        if (n == 0) {
            return 51;
        }
        return 0;
    }

    private static int bCd(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x303B;
        if (bSsdq[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = xEBCE[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])KBkDM.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    KBkDM.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jg_83a87f1c", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_jg_83a87f1c.bSsdq[n2] = n3;
        }
        return bSsdq[n2];
    }

    @Deprecated
    public static void bBr() {
        double d = (double)MathHelper.floor((double)ClientMain.dlmvG.player.getX()) + 0.5;
        double d2 = (double)MathHelper.floor((double)ClientMain.dlmvG.player.getZ()) + 0.5;
        ClientMain.dlmvG.player.setPosition(d, ClientMain.dlmvG.player.getY(), d2);
        ClientMain.dlmvG.player.networkHandler.sendPacket((Packet)new PlayerMoveC2SPacket.PositionAndOnGround(ClientMain.dlmvG.player.getX(), ClientMain.dlmvG.player.getY(), ClientMain.dlmvG.player.getZ(), ClientMain.dlmvG.player.isOnGround(), ClientMain.dlmvG.player.horizontalCollision));
    }

    public static boolean bBP(LivingEntity livingEntity) {
        long l = CcOBc ^ 0x3806B136A761L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        LivingEntity livingEntity2 = livingEntity;
        if (stringArray != null) {
            if (!Class_jg_83a87f1c.bBQ(livingEntity2)) {
                return false;
            }
            livingEntity2 = livingEntity;
        }
        ClientPlayerEntity clientPlayerEntity = ClientMain.dlmvG.player;
        if (stringArray != null) {
            if (livingEntity2 == clientPlayerEntity) {
                return true;
            }
            livingEntity2 = livingEntity;
            clientPlayerEntity = ClientMain.dlmvG.player;
        }
        return Class_jg_83a87f1c.bBL((Entity)livingEntity2, (Entity)clientPlayerEntity);
    }

    public static Vec3d bBK(Vec3d vec3d, Box box) {
        double d = MathHelper.clamp((double)vec3d.x, (double)box.minX, (double)box.maxX);
        double d2 = MathHelper.clamp((double)vec3d.y, (double)box.minY, (double)box.maxY);
        double d3 = MathHelper.clamp((double)vec3d.z, (double)box.minZ, (double)box.maxZ);
        return new Vec3d(d, d2, d3);
    }

    public static int bBZ() {
        return aIWFT;
    }

    public static boolean bBM(LivingEntity livingEntity) {
        return Class_jg_83a87f1c.bBN(livingEntity, 0.0);
    }

    public static boolean bBG(Vec3d vec3d, float f) {
        long l = CcOBc ^ 0x1BFA0A0B3405L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        double d = Class_jg_83a87f1c.bBH(ClientMain.dlmvG.player.getEyePos(), vec3d) - (double)f;
        double d2 = d == 0.0 ? 0 : (d < 0.0 ? -1 : 1);
        if (stringArray != null) {
            d2 = d2 <= 0 ? 1.0 : 0.0;
        }
        return (boolean)d2;
    }

    private static Exception bCb(Exception exception) {
        return exception;
    }

    public static Set<EntityType<? extends Entity>> bBU() {
        long l = CcOBc ^ 0x5536162D0301L;
        Set<EntityType<? extends Entity>> set = Class_jg_83a87f1c.bBS();
        EntityType[] entityTypeArray = new EntityType[Class_jg_83a87f1c.bCf("i", (int)8041, (long)(0x2EFA7F0CDC6535C8L ^ l))];
        entityTypeArray[0] = EntityType.TNT;
        entityTypeArray[1] = EntityType.AREA_EFFECT_CLOUD;
        entityTypeArray[2] = EntityType.INTERACTION;
        entityTypeArray[3] = EntityType.LEASH_KNOT;
        entityTypeArray[4] = EntityType.LIGHTNING_BOLT;
        entityTypeArray[5] = EntityType.PAINTING;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)24349, (long)(0x31804D4DF2C9F5B0L ^ l))] = EntityType.ARMOR_STAND;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)22629, (long)(0x4D3611FB8CD672DEL ^ l))] = EntityType.FALLING_BLOCK;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)6776, (long)(0x233A5A59BCC8B0D6L ^ l))] = EntityType.ITEM_DISPLAY;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)31974, (long)(0x11CB3A166B5AD651L ^ l))] = EntityType.BLOCK_DISPLAY;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)26754, (long)(0x49383BB5AFA84228L ^ l))] = EntityType.TEXT_DISPLAY;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)30494, (long)(0x7A05E1D44D6ADDB6L ^ l))] = EntityType.FISHING_BOBBER;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)16810, (long)(0x1A7FE9EC5906B1CL ^ l))] = EntityType.LLAMA_SPIT;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)9548, (long)(0x7F2221B9C3CF0FFEL ^ l))] = EntityType.WITHER_SKULL;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)31941, (long)(0x5BC64F1009355679L ^ l))] = EntityType.FIREWORK_ROCKET;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)20955, (long)(0x428750170A297B65L ^ l))] = EntityType.SHULKER_BULLET;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)27411, (long)(0x41B47A0D459AC1A9L ^ l))] = EntityType.SPECTRAL_ARROW;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)25631, (long)(0x5186BA5E2D0CEA6L ^ l))] = EntityType.ARROW;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)26487, (long)(0x127EAA4AD354DDBL ^ l))] = EntityType.EYE_OF_ENDER;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)7506, (long)(0x703C9BB97AA837E2L ^ l))] = EntityType.EXPERIENCE_ORB;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)31896, (long)(0x7477598E93525637L ^ l))] = EntityType.EXPERIENCE_BOTTLE;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)18380, (long)(0x784F2EE258C76D78L ^ l))] = EntityType.EVOKER_FANGS;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)32304, (long)(0x663E2568EE215488L ^ l))] = EntityType.FIREBALL;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)11356, (long)(0x6C830121A14B86EFL ^ l))] = EntityType.SMALL_FIREBALL;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)23713, (long)(0x28096FF0A520760AL ^ l))] = EntityType.DRAGON_FIREBALL;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)22966, (long)(0x257071E7889B731FL ^ l))] = EntityType.ITEM_FRAME;
        entityTypeArray[Class_jg_83a87f1c.bCf("i", (int)22845, (long)(0x4003B554F6B07382L ^ l))] = EntityType.GLOW_ITEM_FRAME;
        Set<EntityType> set2 = Set.of(entityTypeArray);
        set.removeAll(set2);
        return set;
    }

    public static Box bBA(Entity entity) {
        Vec3d vec3d = entity.getLerpedPos(ClientMain.dlmvG.getRenderTickCounter().getTickProgress(true));
        return Class_jg_83a87f1c.bBB(entity, vec3d);
    }

    public static float bBv(LivingEntity livingEntity, float f) {
        return f / livingEntity.getMaxHealth() * 100.0f;
    }

    public static Box bBz(Entity entity) {
        Vec3d vec3d = entity.getEntityPos();
        return new Box(vec3d.x - (double)(entity.getWidth() / 2.0f), vec3d.y, vec3d.z - (double)(entity.getWidth() / 2.0f), vec3d.x + (double)(entity.getWidth() / 2.0f), vec3d.y + (double)entity.getHeight(), vec3d.z + (double)(entity.getWidth() / 2.0f));
    }

    public static double bBH(Vec3d vec3d, Vec3d vec3d2) {
        return vec3d.distanceTo(vec3d2);
    }

    public static Set<EntityType<? extends Entity>> bBS() {
        long l = CcOBc ^ 0x159125EE7B08L;
        LinkedHashSet<EntityType<? extends Entity>> linkedHashSet = new LinkedHashSet<EntityType<? extends Entity>>();
        for (Field field : EntityType.class.getDeclaredFields()) {
            if (field.getType() != EntityType.class) continue;
            field.setAccessible(true);
            try {
                Object object = field.get(null);
                if (!(object instanceof EntityType)) continue;
                linkedHashSet.add((EntityType<? extends Entity>)((EntityType)object));
            }
            catch (IllegalAccessException illegalAccessException) {
                // empty catch block
            }
        }
        return linkedHashSet;
    }

    /*
     * Unable to fully structure code
     */
    public static boolean bBQ(LivingEntity var0) {
        block20: {
            block21: {
                block22: {
                    block23: {
                        var1_1 = Class_jg_83a87f1c.CcOBc ^ 86603667627040L;
                        var4_2 = var0.getMainHandStack().isOf(Items.SHIELD);
                        var3_3 = Class_jf_d1c4f950.bBe();
                        var5_4 = var0.getOffHandStack().isOf(Items.SHIELD);
                        v0 = var4_2;
                        if (var3_3 != null) {
                            if (!v0) {
                                v0 = var5_4;
                                if (var3_3 != null) {
                                    if (!v0) {
                                        return false;
                                    } else {
                                        ** GOTO lbl-1000
                                    }
                                }
                            } else lbl-1000:
                            // 3 sources

                            {
                                v0 = var0.isBlocking();
                            }
                        }
                        if (var3_3 != null) {
                            if (v0) {
                                return true;
                            }
                            v0 = var0.isUsingItem();
                        }
                        if (var3_3 != null) {
                            if (v0) {
                                v0 = var0.getActiveItem().isOf(Items.SHIELD);
                                if (var3_3 != null) {
                                    if (v0) {
                                        return true;
                                    } else {
                                        ** GOTO lbl-1000
                                    }
                                }
                            } else lbl-1000:
                            // 3 sources

                            {
                                v0 = var0.isUsingItem();
                            }
                        }
                        if (var3_3 == null) break block20;
                        if (!v0) ** GOTO lbl-1000
                        v1 = var6_5 = var0.getActiveHand();
                        v2 = Hand.MAIN_HAND;
                        if (var3_3 == null) break block21;
                        if (v1 != v2) break block22;
                        v3 = var4_2;
                        if (var3_3 == null) break block23;
                        if (!v3) break block22;
                        v3 = true;
                    }
                    return v3;
                }
                v1 = var6_5;
                v2 = Hand.OFF_HAND;
            }
            if (v1 == v2) {
                v0 = var5_4;
                if (var3_3 != null) {
                    if (v0) {
                        return true;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 4 sources

            {
                v0 = false;
            }
        }
        return v0;
    }

    public static boolean bBq() {
        return ClientMain.dlmvG.world.getPlayers().parallelStream().filter(abstractClientPlayerEntity -> {
            long l = CcOBc ^ 0x6C149F7D9C0EL;
            return ClientMain.dlmvG.player != abstractClientPlayerEntity;
        }).filter(abstractClientPlayerEntity -> {
            long l = CcOBc ^ 0x425E81272986L;
            String[] stringArray = Class_jf_d1c4f950.bBe();
            double d = abstractClientPlayerEntity.squaredDistanceTo((Entity)ClientMain.dlmvG.player) - 36.0;
            double d2 = d == 0.0 ? 0 : (d < 0.0 ? -1 : 1);
            if (stringArray != null) {
                d2 = d2 < 0 ? 1.0 : 0.0;
            }
            return (boolean)d2;
        }).anyMatch(LivingEntity::isDead);
    }

    public static boolean bBC(Entity entity) {
        int n;
        block5: {
            long l = CcOBc ^ 0x10478013F6F8L;
            Entity entity2 = ClientMain.dlmvG.getCameraEntity();
            String[] stringArray = Class_jf_d1c4f950.bBe();
            Entity entity3 = entity2;
            if (stringArray != null) {
                if (entity3 == null) {
                    return false;
                }
                entity3 = entity;
            }
            Box box = entity3.getBoundingBox();
            Vec3d vec3d = entity2.getEyePos();
            List<Vec3d> list = Class_pf_5fda8840.cNi(vec3d, box, (int)Class_jg_83a87f1c.bCf("i", (int)491, (long)(0x7E104B483B225EB2L ^ l)));
            for (Vec3d vec3d2 : list) {
                double d = vec3d.squaredDistanceTo(vec3d2) - (double)1.0E-5f;
                n = d == 0.0 ? 0 : (d < 0.0 ? -1 : 1);
                if (stringArray != null) {
                    if (n < 0) continue;
                    RaycastContext raycastContext = new RaycastContext(vec3d, vec3d2, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, entity2);
                    BlockHitResult blockHitResult = ClientMain.dlmvG.world.raycast(raycastContext);
                    if (blockHitResult.getType() == HitResult.Type.MISS) {
                        return false;
                    }
                    if (stringArray != null) continue;
                }
                break block5;
            }
            n = 1;
        }
        return n != 0;
    }

    public static GameMode bBw(PlayerEntity playerEntity) {
        PlayerListEntry playerListEntry;
        long l = CcOBc ^ 0x401DCBDC5A30L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        ClientPlayNetworkHandler clientPlayNetworkHandler = ClientMain.dlmvG.getNetworkHandler();
        if (stringArray != null) {
            if (clientPlayNetworkHandler == null) {
                return null;
            }
            clientPlayNetworkHandler = ClientMain.dlmvG.getNetworkHandler();
        }
        PlayerListEntry playerListEntry2 = playerListEntry = clientPlayNetworkHandler.getPlayerListEntry(playerEntity.getUuid());
        if (stringArray != null) {
            if (playerListEntry2 == null) {
                return null;
            }
            playerListEntry2 = playerListEntry;
        }
        return playerListEntry2.getGameMode();
    }

    public static double bBy(Entity entity) {
        long l = CcOBc ^ 0x19F668431784L;
        World world = entity.getEntityWorld();
        BlockPos blockPos = entity.getBlockPos();
        String[] stringArray = Class_jf_d1c4f950.bBe();
        for (int i = blockPos.getY(); i >= world.getBottomY(); --i) {
            boolean bl;
            BlockPos blockPos2;
            block8: {
                BlockState blockState;
                block9: {
                    block4: {
                        block7: {
                            Block block;
                            block6: {
                                block5: {
                                    block3: {
                                        blockPos2 = new BlockPos(blockPos.getX(), i, blockPos.getZ());
                                        blockState = world.getBlockState(blockPos2);
                                        block = blockState.getBlock();
                                        bl = block.equals(Blocks.WATER);
                                        if (stringArray == null) break block3;
                                        if (bl) break block4;
                                        bl = block.equals(Blocks.LAVA);
                                    }
                                    if (stringArray == null) break block5;
                                    if (bl) break block4;
                                    bl = block.equals(Blocks.SLIME_BLOCK);
                                }
                                if (stringArray == null) break block6;
                                if (bl) break block4;
                                bl = block.equals(Blocks.HONEY_BLOCK);
                            }
                            if (stringArray == null) break block7;
                            if (bl) break block4;
                            bl = block.equals(Blocks.COBWEB);
                        }
                        if (stringArray == null) break block8;
                        if (!bl) break block9;
                    }
                    return -1.0;
                }
                bl = blockState.getCollisionShape((BlockView)world, blockPos2).isEmpty();
            }
            if (bl) continue;
            return entity.getY() - (double)blockPos2.getY() - 1.0;
        }
        return -1.0;
    }

    public static Box bBB(Entity entity, Vec3d vec3d) {
        return new Box(vec3d.x - (double)(entity.getWidth() / 2.0f), vec3d.y, vec3d.z - (double)(entity.getWidth() / 2.0f), vec3d.x + (double)(entity.getWidth() / 2.0f), vec3d.y + (double)entity.getHeight(), vec3d.z + (double)(entity.getWidth() / 2.0f));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean bBD(PlayerEntity playerEntity) {
        long l = CcOBc ^ 0x4BB63BDD1F87L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        boolean bl = playerEntity.getEquippedStack(EquipmentSlot.FEET).isEmpty();
        if (stringArray != null) {
            if (!bl) return false;
            bl = playerEntity.getEquippedStack(EquipmentSlot.LEGS).isEmpty();
        }
        if (stringArray != null) {
            if (!bl) return false;
            bl = playerEntity.getEquippedStack(EquipmentSlot.CHEST).isEmpty();
        }
        if (stringArray != null) {
            if (!bl) return false;
            bl = playerEntity.getEquippedStack(EquipmentSlot.HEAD).isEmpty();
        }
        if (stringArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    public static String bBO(float f) {
        long l = CcOBc ^ 0x381761DCEEF2L;
        float f2 = (f + 180.0f) % 360.0f;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        float f3 = f2 - 0.0f;
        float f4 = f3 == 0.0f ? 0 : (f3 < 0.0f ? -1 : 1);
        if (stringArray != null) {
            if (f4 < 0) {
                f2 += 360.0f;
            }
            f4 = (int)Math.floor((f2 + 22.5f) / 45.0f) & Class_jg_83a87f1c.bCf("i", (int)22629, (long)(0x4D367CDAFB279F2DL ^ l));
        }
        float f5 = f4;
        return okfwP[f5];
    }

    public static boolean bBs(LivingEntity livingEntity) {
        int n;
        block7: {
            long l = CcOBc ^ 0x76B66E7CD193L;
            Box box = livingEntity.getBoundingBox();
            BlockPos.Mutable mutable = new BlockPos.Mutable();
            String[] stringArray = Class_jf_d1c4f950.bBe();
            int n2 = MathHelper.floor((double)box.minX);
            block0: while (true) {
                int n3 = n2;
                block1: while (n3 <= MathHelper.floor((double)box.maxX)) {
                    n = MathHelper.floor((double)box.minY);
                    if (stringArray == null) break block7;
                    int n4 = n;
                    block2: while (true) {
                        int n5 = n4;
                        block3: while (n5 <= MathHelper.floor((double)box.maxY)) {
                            n3 = MathHelper.floor((double)box.minZ);
                            if (stringArray == null) continue block1;
                            int n6 = n3;
                            while (n6 <= MathHelper.floor((double)box.maxZ)) {
                                block8: {
                                    block9: {
                                        boolean bl;
                                        block10: {
                                            mutable.set(n2, n4, n6);
                                            if (stringArray == null) break block8;
                                            n5 = box.contains((BlockPos)mutable) ? 1 : 0;
                                            if (stringArray == null) continue block3;
                                            if (n5 == 0) break block9;
                                            bl = livingEntity.getEntityWorld().getBlockState((BlockPos)mutable).isOf(Blocks.COBWEB);
                                            if (stringArray == null) break block10;
                                            if (!bl) break block9;
                                            bl = true;
                                        }
                                        return bl;
                                    }
                                    ++n6;
                                }
                                if (stringArray != null) continue;
                            }
                            ++n4;
                            if (stringArray != null) continue block2;
                        }
                        break;
                    }
                    ++n2;
                    if (stringArray != null) continue block0;
                }
                break;
            }
            n = 0;
        }
        return n != 0;
    }

    public static boolean bBV() {
        long l = CcOBc ^ 0x62BB89257B9EL;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        ClientPlayerEntity clientPlayerEntity = ClientMain.dlmvG.player;
        if (stringArray != null) {
            if (clientPlayerEntity.getVehicle() != null) {
                return false;
            }
            clientPlayerEntity = ClientMain.dlmvG.player;
        }
        int n = clientPlayerEntity.isTouchingWater();
        if (stringArray != null) {
            if (n != 0) {
                return false;
            }
            n = ClientMain.dlmvG.player.getAbilities().creativeMode;
        }
        if (stringArray != null) {
            if (n != 0) {
                return true;
            }
            n = ClientMain.dlmvG.player.getHungerManager().getFoodLevel();
        }
        if (stringArray != null) {
            n = n >= Class_jg_83a87f1c.bCf("i", (int)20644, (long)(0x51D7598F5DCD028AL ^ l)) ? 1 : 0;
        }
        return n != 0;
    }

    public static boolean bBF(Vec3d vec3d) {
        long l = CcOBc ^ 0x52A6E1C9FD26L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        double d = Class_jg_83a87f1c.bBH(ClientMain.dlmvG.player.getEyePos(), vec3d) - ClientMain.dlmvG.player.getBlockInteractionRange();
        double d2 = d == 0.0 ? 0 : (d < 0.0 ? -1 : 1);
        if (stringArray != null) {
            d2 = d2 <= 0 ? 1.0 : 0.0;
        }
        return (boolean)d2;
    }

    public static boolean bBt(LivingEntity livingEntity, float f) {
        long l = CcOBc ^ 0x104DAD686C57L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        float f2 = livingEntity.getHealth() - f - 0.0f;
        float f3 = f2 == 0.0f ? 0 : (f2 > 0.0f ? 1 : -1);
        if (stringArray != null) {
            f3 = f3 <= 0 ? 1.0f : 0.0f;
        }
        return (boolean)f3;
    }

    public static boolean bBN(LivingEntity livingEntity, double d) {
        Box box = ClientMain.dlmvG.player.getBoundingBox().expand(d, 0.0, d);
        return livingEntity.getBoundingBox().intersects(box);
    }

    public static void bBY(int n) {
        aIWFT = n;
    }

    public static Set<EntityType<? extends Entity>> bBT() {
        long l = CcOBc ^ 0x104C128FE47BL;
        LinkedHashSet<EntityType<? extends Entity>> linkedHashSet = new LinkedHashSet<EntityType<? extends Entity>>();
        for (Field field : EntityType.class.getDeclaredFields()) {
            if (field.getType() != EntityType.class) continue;
            field.setAccessible(true);
            try {
                Class clazz;
                Type type;
                ParameterizedType parameterizedType;
                Type[] typeArray;
                Type type2;
                Object object = field.get(null);
                if (!(object instanceof EntityType) || !((type2 = field.getGenericType()) instanceof ParameterizedType) || (typeArray = (parameterizedType = (ParameterizedType)type2).getActualTypeArguments()).length != 1 || !((type = typeArray[0]) instanceof Class) || !LivingEntity.class.isAssignableFrom(clazz = (Class)type)) continue;
                linkedHashSet.add((EntityType<? extends Entity>)((EntityType)object));
            }
            catch (IllegalAccessException illegalAccessException) {
                // empty catch block
            }
        }
        linkedHashSet.remove(EntityType.ARMOR_STAND);
        return linkedHashSet;
    }

    public static float bBu(float f) {
        return f / ClientMain.dlmvG.player.getMaxHealth() * 100.0f;
    }

    private static String bCc(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jg_83a87f1c.class, "bCe", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

