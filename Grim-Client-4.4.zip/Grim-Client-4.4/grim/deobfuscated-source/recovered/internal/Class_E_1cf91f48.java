/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_F_b668cea7;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_rk_bf8630d1;

public interface Class_E_1cf91f48 {
    public static final long nHxCq = Class_gb_9d201141.aYR(-5676891595741979279L, -7249379697926721278L, MethodHandles.lookup().lookupClass()).a(42824004375287L);
    public static final String yTkpx;

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = nHxCq ^ 0x691E6816D3E7L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                byte[] byArray3 = cipher.doFinal("\u0081\u00a2\u00b0\u00e1H\u00d5\u0018\u00d6".getBytes("ISO-8859-1"));
                yTkpx = Class_E_1cf91f48.a(byArray3).intern();
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    private static MatchException b(MatchException matchException) {
        return matchException;
    }

    private static String a(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    default public void delete() {
    }

    public boolean isActive();

    public String displayName();

    public void select();

    public Class_rk_bf8630d1 hoverAnimation();

    default public List<Class_F_b668cea7> contextActions() {
        long l = nHxCq ^ 0x5ABCB04882AEL;
        if (!this.hasDeleteIcon()) {
            return List.of();
        }
        return List.of(new Class_F_b668cea7(yTkpx, Class_lf_d247d983.JHGge, Class_jk_a0800133.mPXGi, Class_jk_a0800133.mPXGi, class_aj_95d0a719 -> {
            class_aj_95d0a719.oj(false);
            this.delete();
        }));
    }

    public Class_rk_bf8630d1 activeAnimation();

    public boolean hasDeleteIcon();
}

