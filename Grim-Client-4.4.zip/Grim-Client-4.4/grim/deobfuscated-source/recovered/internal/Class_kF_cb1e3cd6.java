/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import recovered.internal.Class_kF_un_724fbccc;
import recovered.internal.Class_mG_52c8d386;

public class Class_kF_cb1e3cd6 {
    private MatrixStack gvSDk;
    private Vec3d imnbU;
    private Vec3d EnbiM;
    private Class_mG_52c8d386 ZCDlZ;
    private float KVJFP;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_kF_cb1e3cd6(MatrixStack matrixStack, Vec3d vec3d, Vec3d vec3d2, Class_mG_52c8d386 class_mG_52c8d386, float f) {
        this.gvSDk = matrixStack;
        this.imnbU = vec3d;
        this.EnbiM = vec3d2;
        this.ZCDlZ = class_mG_52c8d386;
        this.KVJFP = f;
    }

    public static Class_kF_un_724fbccc bTp() {
        return new Class_kF_un_724fbccc();
    }

    private static float bTo() {
        return 1.0f;
    }

    public MatrixStack bTq() {
        return this.gvSDk;
    }

    public static Class_kF_un_724fbccc bTn(MatrixStack matrixStack, Vec3d vec3d, Vec3d vec3d2, Class_mG_52c8d386 class_mG_52c8d386) {
        return Class_kF_cb1e3cd6.bTp().dto(matrixStack).dtp(vec3d).dtq(vec3d2).dtr(class_mG_52c8d386);
    }

    public Vec3d bTs() {
        return this.EnbiM;
    }

    public float bTu() {
        return this.KVJFP;
    }

    public Vec3d bTr() {
        return this.imnbU;
    }

    public Class_mG_52c8d386 bTt() {
        return this.ZCDlZ;
    }
}

