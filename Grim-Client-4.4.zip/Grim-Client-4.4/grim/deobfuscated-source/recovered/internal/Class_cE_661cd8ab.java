/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 */
package recovered.internal;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.MethodHandles;
import java.util.Arrays;
import java.util.Map;
import recovered.core.ClientMain;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_pG_890cf4b5;

public class Class_cE_661cd8ab
extends Class_cB_67aec11c {
    private static final long ZvRsv = Class_gb_9d201141.aYR(-7229280345741605547L, 3343296497802533714L, MethodHandles.lookup().lookupClass()).a(265290631921713L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cE_661cd8ab(Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_mr_7eac5189);
    }

    public Class_cE_661cd8ab(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    @Override
    public void SS(JsonElement jsonElement) {
        long l = ZvRsv ^ 0xBEDD13E45E1L;
        if (!jsonElement.isJsonObject()) {
            return;
        }
        if (ClientMain.dlS() == null) {
            return;
        }
        Class_pG_890cf4b5 class_pG_890cf4b5 = new Class_pG_890cf4b5();
        class_pG_890cf4b5.fromJson(jsonElement.getAsJsonObject());
        ClientMain.dlS().cSS(class_pG_890cf4b5);
        this.Vk();
    }

    @Override
    public void SR(Map<String, Object> map) {
        JsonObject jsonObject = ClientMain.dlS().cSQ().toJson();
        map.put(Arrays.toString(this.NwlSF), jsonObject);
    }

    private static MatchException VR(MatchException matchException) {
        return matchException;
    }
}

