/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mr_7eac5189;

public final class Class_gh_ecfd0cde
extends Enum<Class_gh_ecfd0cde> {
    public static /* enum */ Class_gh_ecfd0cde xwjCw;
    public static /* enum */ Class_gh_ecfd0cde xgeEn;
    public static /* enum */ Class_gh_ecfd0cde qBzlZ;
    public static /* enum */ Class_gh_ecfd0cde nOCvV;
    public static /* enum */ Class_gh_ecfd0cde KfAlY;
    private final Class_mr_7eac5189 LZXUZ;
    private static /* synthetic */ Class_gh_ecfd0cde[] mPcse;
    private static Class_iS_888f260e[] LOvFx;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_gh_ecfd0cde(Class_mr_7eac5189 class_mr_7eac5189) {
        this.LZXUZ = class_mr_7eac5189;
    }

    static {
        NativeLoader.doInit(Class_gh_ecfd0cde.class);
        Class_gh_ecfd0cde._1e273a1de4ed62c5ae82c9743435ccf8();
    }

    public static native Class_gh_ecfd0cde[] values();

    public static native Class_gh_ecfd0cde valueOf(String var0);

    public static native Class_iS_888f260e[] baJ();

    private static native /* synthetic */ Class_gh_ecfd0cde[] baH();

    public native Class_mr_7eac5189 baG();

    private static native String baK(byte[] var0);

    public static native void baI(Class_iS_888f260e[] var0);

    private static native void _1e273a1de4ed62c5ae82c9743435ccf8();
}

