/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import net.minecraft.util.math.Vec3d;

public class Class_cU_sp_803a1de3 {
    private final Vec3d WyFYf;
    private final long TJJOB;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cU_sp_803a1de3(Vec3d vec3d, long l) {
        this.WyFYf = vec3d;
        this.TJJOB = l;
    }
}

