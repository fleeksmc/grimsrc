/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.core.ClientMain;
import recovered.internal.Class_bJ_24f874fc;
import recovered.internal.Class_bS_979bca5c;
import recovered.internal.Class_bU_714b1dad;
import recovered.internal.Class_cv_f4b0140a;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_la_8f67ae40;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mr_7eac5189;

public class Class_bP_025253dc
extends Class_bS_979bca5c {
    private static final long OrHSZ;
    private static final long[] FeWAQ;
    private static final Integer[] IwENq;
    private static final Map mTYzX;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static CallSite NE(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bP_025253dc" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public Class_bP_025253dc(Class_cv_f4b0140a class_cv_f4b0140a) {
        long l = OrHSZ ^ 0x7C50F9391EA4L;
        int[] nArray = new int[Class_bP_025253dc.NE("y", (int)20142, (long)(0x4775CE005B916E97L ^ l))];
        nArray[0] = (int)Class_bP_025253dc.NE("y", (int)8616, (long)(0x344321AD6CD98197L ^ l));
        nArray[1] = (int)Class_bP_025253dc.NE("y", (int)15001, (long)(0x414EEE0D7E5F1ABCL ^ l));
        nArray[2] = (int)Class_bP_025253dc.NE("y", (int)8464, (long)(0x22F57014EF1F0133L ^ l));
        nArray[3] = (int)Class_bP_025253dc.NE("y", (int)11625, (long)(0x270F0498827C8D46L ^ l));
        nArray[4] = (int)Class_bP_025253dc.NE("y", (int)21535, (long)(0x1A76EABAB7407405L ^ l));
        nArray[5] = (int)Class_bP_025253dc.NE("y", (int)17893, (long)(0xF22B431BAEF65DBL ^ l));
        nArray[Class_bP_025253dc.NE("y", (int)10558, (long)(0x155E17AC29B00921L ^ l))] = (int)Class_bP_025253dc.NE("y", (int)4988, (long)(0x118A0D935AFE3346L ^ l));
        nArray[Class_bP_025253dc.NE("y", (int)21728, (long)(0x182EDF404A2FF4F8L ^ l))] = (int)Class_bP_025253dc.NE("y", (int)6192, (long)(0x775AFDC87311B805L ^ l));
        nArray[Class_bP_025253dc.NE("y", (int)24181, (long)(0x32E91618FF967E49L ^ l))] = (int)Class_bP_025253dc.NE("y", (int)24314, (long)(0x2F096C567E5A7ED1L ^ l));
        nArray[Class_bP_025253dc.NE("y", (int)32117, (long)(0x488C926CCD88DD4DL ^ l))] = (int)Class_bP_025253dc.NE("y", (int)23266, (long)(0x1E4CAE24E7B27AC2L ^ l));
        nArray[Class_bP_025253dc.NE("y", (int)4159, (long)(0x3E65247840D0B013L ^ l))] = (int)Class_bP_025253dc.NE("y", (int)11821, (long)(0x27BA901331C98E36L ^ l));
        nArray[Class_bP_025253dc.NE("y", (int)13224, (long)(0x272DFCCCD48138EL ^ l))] = (int)Class_bP_025253dc.NE("y", (int)23266, (long)(0x1E4CAE24E7B27AC2L ^ l));
        nArray[Class_bP_025253dc.NE("y", (int)30058, (long)(0x625B9B37661BD558L ^ l))] = (int)Class_bP_025253dc.NE("y", (int)4283, (long)(0x4F33357849233086L ^ l));
        nArray[Class_bP_025253dc.NE("y", (int)30103, (long)(0x43E780C52B655A4L ^ l))] = (int)Class_bP_025253dc.NE("y", (int)24178, (long)(0x7BEFB4EE94127E5FL ^ l));
        super(class_cv_f4b0140a, Class_mr_7eac5189.clS(nArray));
        this.TB();
        this.Tz();
    }

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_bP_025253dc.OrHSZ = Class_gb_9d201141.aYR(6415508564072682166L, 1219073124727057371L, MethodHandles.lookup().lookupClass()).a(63773572064124L);
                Class_bP_025253dc.mTYzX = new HashMap<K, V>(13);
                var0 = Class_bP_025253dc.OrHSZ ^ 108478420721736L;
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[38];
                var5_4 = 0;
                var6_5 = "\u00a1\u00dd\u0099\u0094\u000eb\u009a\u00ca \"\u00062\u009f\u009dj;\u00e5^\u0005bJCU\u00f3\u00db\u00fc\u00c1\u00cc\u0096\u008a\u00df\u001b\u0004\u00afHp\u00d4\u0085<i\u00b8n\u00c0\u00c3@gO\u00f4\u0019\u00c5\"W\u00ba\u0002.\u001ff\u008f\u00bd\u00e7\u0018\u00c9\r\u00e9Y`\u00f7R\u00b0\u00fc\u00b7\u0006\u00ef\u0083\u00c2\u00bfU\u0097%\u00d6R\u00ad\u00b1Q\u00dd\u00aa\u00ec~g\u0090\u00c6\f\u008f\u0094\u00eax\u00cdx\u001c\u00ce\f\u008a\u009c=x\u00c2\u0092\u00a6\u0094h\u008a\u00f0\u0080\u00fe\\q\u00df\u0005\\\u00c6\u0015M{zB\u00f3f\u00cc\u001c*\u00afQ`\u00f6/:\u001f\u0003\u000b\u00edi8P\u00eeEIO\u008c\u0003\u00f1~6\u008f\u00e4\u00c5\u00a5Vw\u0018\u0093\u001f\u0012l\u00a4\u00c5\u00b5l\u0014\u0007.Ie\u00b2\u00ba61\u00ac?\u00cf\u00eb\u00f3\u0006HW+1\u007f\u0000\u001e\u0017\u00db\\\u000f\u0084\u008a\fe\u00cd\u0019 Q\u00ab\u00c02p\u00cf\u00da\f\u00d0Iq\u00f6\u0007{~,\u0011\u008f\u00ec\u00df\u00d8\u00dd\u0010\u0086W\u00ab\u00ccf\u00dc\u00e3\u001c\u00a7\u00b4-]\u0095\u001e\u008f\u00c1\u0086\u00d9\u00f3\u008c3\u0098i\u00820}\u0018\u00f3\u001eBh\u00fa6\u008d\r\u00cbco?\u008a#\u009b\u0001\u00da\u00f4@l+Z\u0093\u00ec\u00f3qu\u00cd\u0007\u00f6K\u00f5\u00b1R\u00ad?\u00f0\u00a7";
                var7_6 = "\u00a1\u00dd\u0099\u0094\u000eb\u009a\u00ca \"\u00062\u009f\u009dj;\u00e5^\u0005bJCU\u00f3\u00db\u00fc\u00c1\u00cc\u0096\u008a\u00df\u001b\u0004\u00afHp\u00d4\u0085<i\u00b8n\u00c0\u00c3@gO\u00f4\u0019\u00c5\"W\u00ba\u0002.\u001ff\u008f\u00bd\u00e7\u0018\u00c9\r\u00e9Y`\u00f7R\u00b0\u00fc\u00b7\u0006\u00ef\u0083\u00c2\u00bfU\u0097%\u00d6R\u00ad\u00b1Q\u00dd\u00aa\u00ec~g\u0090\u00c6\f\u008f\u0094\u00eax\u00cdx\u001c\u00ce\f\u008a\u009c=x\u00c2\u0092\u00a6\u0094h\u008a\u00f0\u0080\u00fe\\q\u00df\u0005\\\u00c6\u0015M{zB\u00f3f\u00cc\u001c*\u00afQ`\u00f6/:\u001f\u0003\u000b\u00edi8P\u00eeEIO\u008c\u0003\u00f1~6\u008f\u00e4\u00c5\u00a5Vw\u0018\u0093\u001f\u0012l\u00a4\u00c5\u00b5l\u0014\u0007.Ie\u00b2\u00ba61\u00ac?\u00cf\u00eb\u00f3\u0006HW+1\u007f\u0000\u001e\u0017\u00db\\\u000f\u0084\u008a\fe\u00cd\u0019 Q\u00ab\u00c02p\u00cf\u00da\f\u00d0Iq\u00f6\u0007{~,\u0011\u008f\u00ec\u00df\u00d8\u00dd\u0010\u0086W\u00ab\u00ccf\u00dc\u00e3\u001c\u00a7\u00b4-]\u0095\u001e\u008f\u00c1\u0086\u00d9\u00f3\u008c3\u0098i\u00820}\u0018\u00f3\u001eBh\u00fa6\u008d\r\u00cbco?\u008a#\u009b\u0001\u00da\u00f4@l+Z\u0093\u00ec\u00f3qu\u00cd\u0007\u00f6K\u00f5\u00b1R\u00ad?\u00f0\u00a7".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl26:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = "\u000f'\u00e7.\u00ae\u00af#\u0006<\u00db\u008c$\u00a5y\u00a78";
                    var7_6 = "\u000f'\u00e7.\u00ae\u00af#\u0006<\u00db\u008c$\u00a5y\u00a78".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl52:
                // 1 sources

                ** continue;
            }
        }
        Class_bP_025253dc.FeWAQ = var8_3;
        Class_bP_025253dc.IwENq = new Integer[38];
    }

    @Override
    public boolean MH() {
        return true;
    }

    private static MatchException NB(MatchException matchException) {
        return matchException;
    }

    @Override
    public void MG(Class_lC_5322e8cf class_lC_5322e8cf, Class_ii_9b427eda class_ii_9b427eda) {
        block0: {
            long l = OrHSZ ^ 0x6CC389D53157L;
            Class_bU_714b1dad class_bU_714b1dad = ClientMain.dlK().RC();
            float f = class_bU_714b1dad.RW();
            float f2 = class_bU_714b1dad.RX();
            Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
            int[] nArray = new int[Class_bP_025253dc.NE("y", (int)31399, (long)(0x1B5FE27628C3756FL ^ l))];
            nArray[0] = (int)Class_bP_025253dc.NE("y", (int)19527, (long)(0x1F3F5EF33204383L ^ l));
            nArray[1] = (int)Class_bP_025253dc.NE("y", (int)31165, (long)(0x348797EA4B48766FL ^ l));
            nArray[2] = (int)Class_bP_025253dc.NE("y", (int)17670, (long)(0x320C2A02A347CADDL ^ l));
            nArray[3] = (int)Class_bP_025253dc.NE("y", (int)8976, (long)(0x63C953F4B2902CD2L ^ l));
            nArray[4] = (int)Class_bP_025253dc.NE("y", (int)10748, (long)(0x23FC9015B0EA2628L ^ l));
            nArray[5] = (int)Class_bP_025253dc.NE("y", (int)26194, (long)(0x397651B69878E995L ^ l));
            nArray[Class_bP_025253dc.NE("y", (int)31224, (long)(0x7BFFA2CD741A763DL ^ l))] = (int)Class_bP_025253dc.NE("y", (int)498, (long)(0x3828061B15A38E18L ^ l));
            nArray[Class_bP_025253dc.NE("y", (int)30171, (long)(0x6E503CA8B7AB7A36L ^ l))] = (int)Class_bP_025253dc.NE("y", (int)28416, (long)(0x602BE193448C60DAL ^ l));
            nArray[Class_bP_025253dc.NE("y", (int)2348, (long)(0x29C0E0D698786FBL ^ l))] = (int)Class_bP_025253dc.NE("y", (int)31712, (long)(0x1BCEF18F11BBF43DL ^ l));
            nArray[Class_bP_025253dc.NE("y", (int)28097, (long)(0xCBF53D315856218L ^ l))] = (int)Class_bP_025253dc.NE("y", (int)26229, (long)(0x2C479EACB8BD69B6L ^ l));
            nArray[Class_bP_025253dc.NE("y", (int)4789, (long)(0x3A8C793EC9A01D64L ^ l))] = (int)Class_bP_025253dc.NE("y", (int)23266, (long)(0x1E4CBEB7975E5531L ^ l));
            int[] nArray2 = nArray;
            float f3 = 20.0f + class_lq_87a74641.cap(nArray2);
            float f4 = 15.0f;
            boolean bl = Class_bJ_24f874fc.MN();
            this.fGWTH.NU(f3, f4);
            float f5 = f - 6.0f + 10.0f * this.dExGi.dhj();
            float f6 = f2 + 4.0f;
            Class_la_8f67ae40 class_la_8f67ae40 = Class_la_8f67ae40.bWA(class_ii_9b427eda.bjf(), class_ii_9b427eda.bjf().coc(Class_mG_52c8d386.hoGuU, 0.4f), class_ii_9b427eda.bjf().coc(Class_mG_52c8d386.hoGuU, 0.4f), class_ii_9b427eda.bjf().coc(Class_mG_52c8d386.hoGuU, 0.2f));
            class_lC_5322e8cf.cde(f5, f6, 7.0f, class_la_8f67ae40);
            class_lC_5322e8cf.ceA(class_lq_87a74641, nArray2, f + 25.0f - 10.0f * this.dExGi.dhj(), f2 + 5.0f, class_ii_9b427eda.bjb());
            if (!bl) break block0;
            Class_iS_888f260e.bwK("walN4b");
        }
    }

    private static int ND(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bP_025253dc.NC(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static int NC(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x2D01;
        if (IwENq[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = FeWAQ[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])mTYzX.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    mTYzX.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bP_025253dc", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bP_025253dc.IwENq[n2] = n3;
        }
        return IwENq[n2];
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bP_025253dc.class, "ND", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

