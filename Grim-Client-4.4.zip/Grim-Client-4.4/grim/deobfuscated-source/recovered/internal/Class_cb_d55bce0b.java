/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screen.ChatScreen
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.util.math.Vec2f;
import recovered.core.ClientMain;
import recovered.internal.Class_ap_f3b7a87f;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_cM_7a9de181;
import recovered.internal.Class_cN_30b69d20;
import recovered.internal.Class_cO_0438f88e;
import recovered.internal.Class_ca_75c833b3;
import recovered.internal.Class_cr_3ba4ae18;
import recovered.internal.Class_ct_fa795250;
import recovered.internal.Class_cu_7306ec45;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mT_db06bea0;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.internal.Class_rm_d861be3b;

public class Class_cb_d55bce0b
extends Class_cr_3ba4ae18 {
    private final Class_ct_fa795250 fuYts;
    private final Class_cu_7306ec45 HhBiN;
    private final Class_cu_7306ec45 XyRrY;
    private final Class_cu_7306ec45 SqYxj;
    private final Class_ct_fa795250 QBiNJ;
    private final Class_cu_7306ec45 ueekw;
    private final Class_cu_7306ec45 ubjWn;
    private final Class_cJ_2ae1a557 DlqAM;
    private final Class_mT_db06bea0 JIyxO;
    private final Class_rk_bf8630d1 DQmMN;
    private final Class_rk_bf8630d1 llsxp;
    private final Class_cO_0438f88e ubdhS;
    private static final long wnjCO;
    private static final String[] LcMNI;
    private static final String[] hBOJC;
    private static final Map dZkQt;
    private static final long[] bYzvb;
    private static final Integer[] qFnKt;
    private static final Map vUFwR;
    private static final long cIHkd;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cb_d55bce0b() {
        long l = wnjCO ^ 0x66C7837072E6L;
        int[] nArray = new int[Class_cb_d55bce0b.Pv("z", (int)6595, (long)(0x5796F0E1A15F6303L ^ l))];
        nArray[0] = (int)Class_cb_d55bce0b.Pv("z", (int)13941, (long)(0x7CAE32FFD1554CAFL ^ l));
        nArray[1] = (int)Class_cb_d55bce0b.Pv("z", (int)7374, (long)(0x41E6DF2BF2CB6603L ^ l));
        nArray[2] = (int)Class_cb_d55bce0b.Pv("z", (int)14499, (long)(0x13E654613337C269L ^ l));
        nArray[3] = (int)Class_cb_d55bce0b.Pv("z", (int)30883, (long)(0x564C0A978C730276L ^ l));
        nArray[4] = (int)Class_cb_d55bce0b.Pv("z", (int)23867, (long)(0x52A28A58E7A27C2L ^ l));
        nArray[5] = (int)Class_cb_d55bce0b.Pv("z", (int)29212, (long)(0x64F0D7F75F1788D9L ^ l));
        nArray[Class_cb_d55bce0b.Pv("z", (int)26163, (long)(0x5164A18C48B51CEBL ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)3116, (long)(0xF5071D48F8E76E4L ^ l));
        nArray[Class_cb_d55bce0b.Pv("z", (int)6193, (long)(0x404B85248B6D62A2L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)7445, (long)(0xBA99D275A07E7D7L ^ l));
        nArray[Class_cb_d55bce0b.Pv("z", (int)27212, (long)(0x19BBA71BD7D510B8L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)13630, (long)(0x39C27C08517E4FDFL ^ l));
        nArray[Class_cb_d55bce0b.Pv("z", (int)32114, (long)(0x4BD2E1AAFE27079BL ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)29212, (long)(0x64F0D7F75F1788D9L ^ l));
        nArray[Class_cb_d55bce0b.Pv("z", (int)6433, (long)(0x38E80D6DCB72E3D2L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)15593, (long)(0x10B30271A531C613L ^ l));
        nArray[Class_cb_d55bce0b.Pv("z", (int)1034, (long)(0x201652F21B637E9AL ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)2361, (long)(0x54C1C049F57A73AEL ^ l));
        nArray[Class_cb_d55bce0b.Pv("z", (int)29462, (long)(0x5098AE7D8A2D89C9L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)11737, (long)(0x75F55470DCE35715L ^ l));
        super(nArray, Class_lf_d247d983.YIqMP);
        int[] nArray2 = new int[Class_cb_d55bce0b.Pv("z", (int)19203, (long)(0x76FC3FE5EE1731C4L ^ l))];
        nArray2[0] = (int)Class_cb_d55bce0b.Pv("z", (int)16205, (long)(0x1BE09CE5EDE4C590L ^ l));
        nArray2[1] = (int)Class_cb_d55bce0b.Pv("z", (int)15593, (long)(0x10B30271A531C613L ^ l));
        nArray2[2] = (int)Class_cb_d55bce0b.Pv("z", (int)22715, (long)(0x46386E7A4C812268L ^ l));
        nArray2[3] = (int)Class_cb_d55bce0b.Pv("z", (int)29212, (long)(0x64F0D7F75F1788D9L ^ l));
        nArray2[4] = (int)Class_cb_d55bce0b.Pv("z", (int)13630, (long)(0x39C27C08517E4FDFL ^ l));
        nArray2[5] = (int)Class_cb_d55bce0b.Pv("z", (int)29212, (long)(0x64F0D7F75F1788D9L ^ l));
        nArray2[Class_cb_d55bce0b.Pv("z", (int)12217, (long)(0x362D66E1A6A25569L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)15593, (long)(0x10B30271A531C613L ^ l));
        nArray2[Class_cb_d55bce0b.Pv("z", (int)1946, (long)(0x6061063F3D167D68L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)13585, (long)(0x216953477E88CFCDL ^ l));
        this.fuYts = new Class_ct_fa795250(this, Class_mr_7eac5189.clS(nArray2)).SO(1);
        this.HhBiN = new Class_cu_7306ec45(this.fuYts, Class_mr_7eac5189.clS(new int[]{(int)Class_cb_d55bce0b.Pv("z", (int)28037, (long)(0x3B6425BCB249977DL ^ l)), (int)Class_cb_d55bce0b.Pv("z", (int)1400, (long)(0x67C4FE0A231FFF9FL ^ l)), (int)Class_cb_d55bce0b.Pv("z", (int)5935, (long)(0xDE3B9E1D7F06DCFL ^ l)), (int)Class_cb_d55bce0b.Pv("z", (int)13630, (long)(0x39C27C08517E4FDFL ^ l))}));
        int[] nArray3 = new int[Class_cb_d55bce0b.Pv("z", (int)12217, (long)(0x362D66E1A6A25569L ^ l))];
        nArray3[0] = (int)Class_cb_d55bce0b.Pv("z", (int)26296, (long)(0x76AF3BDAE8211C50L ^ l));
        nArray3[1] = (int)Class_cb_d55bce0b.Pv("z", (int)26186, (long)(0x39944E3BC7311CBBL ^ l));
        nArray3[2] = (int)Class_cb_d55bce0b.Pv("z", (int)13585, (long)(0x216953477E88CFCDL ^ l));
        nArray3[3] = (int)Class_cb_d55bce0b.Pv("z", (int)13630, (long)(0x39C27C08517E4FDFL ^ l));
        nArray3[4] = (int)Class_cb_d55bce0b.Pv("z", (int)26186, (long)(0x39944E3BC7311CBBL ^ l));
        nArray3[5] = (int)Class_cb_d55bce0b.Pv("z", (int)6835, (long)(0x6ADC431FE9F3E075L ^ l));
        this.XyRrY = new Class_cu_7306ec45(this.fuYts, Class_mr_7eac5189.clS(nArray3));
        this.SqYxj = new Class_cu_7306ec45(this.fuYts, Class_mr_7eac5189.clS(new int[]{(int)Class_cb_d55bce0b.Pv("z", (int)15169, (long)(0x757AAC0AEBCC4182L ^ l)), (int)Class_cb_d55bce0b.Pv("z", (int)29212, (long)(0x64F0D7F75F1788D9L ^ l)), (int)Class_cb_d55bce0b.Pv("z", (int)20730, (long)(0x2DD19435A75AA06L ^ l)), (int)Class_cb_d55bce0b.Pv("z", (int)29647, (long)(0x64E37A6605160914L ^ l)), (int)Class_cb_d55bce0b.Pv("z", (int)13630, (long)(0x39C27C08517E4FDFL ^ l))}));
        int[] nArray4 = new int[Class_cb_d55bce0b.Pv("z", (int)4124, (long)(0x7B1996F89E8AEADDL ^ l))];
        nArray4[0] = (int)Class_cb_d55bce0b.Pv("z", (int)9882, (long)(0x421E0BEA2C0DDC67L ^ l));
        nArray4[1] = (int)Class_cb_d55bce0b.Pv("z", (int)17032, (long)(0x66CDFA0B13243841L ^ l));
        nArray4[2] = (int)Class_cb_d55bce0b.Pv("z", (int)29212, (long)(0x64F0D7F75F1788D9L ^ l));
        nArray4[3] = (int)Class_cb_d55bce0b.Pv("z", (int)9757, (long)(0x2D7950C3DD405CCAL ^ l));
        nArray4[4] = (int)Class_cb_d55bce0b.Pv("z", (int)13585, (long)(0x216953477E88CFCDL ^ l));
        nArray4[5] = (int)Class_cb_d55bce0b.Pv("z", (int)31185, (long)(0x68CBC7EC7AB1032FL ^ l));
        nArray4[Class_cb_d55bce0b.Pv("z", (int)12217, (long)(0x362D66E1A6A25569L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)26186, (long)(0x39944E3BC7311CBBL ^ l));
        nArray4[Class_cb_d55bce0b.Pv("z", (int)1946, (long)(0x6061063F3D167D68L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)13585, (long)(0x216953477E88CFCDL ^ l));
        nArray4[Class_cb_d55bce0b.Pv("z", (int)19203, (long)(0x76FC3FE5EE1731C4L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)13630, (long)(0x39C27C08517E4FDFL ^ l));
        this.QBiNJ = new Class_ct_fa795250(this, Class_mr_7eac5189.clS(nArray4)).SO(0);
        this.ueekw = new Class_cu_7306ec45(this.QBiNJ, Class_mr_7eac5189.clS(new int[]{(int)Class_cb_d55bce0b.Pv("z", (int)32601, (long)(0x69ABDC62B94385A6L ^ l)), (int)Class_cb_d55bce0b.Pv("z", (int)15593, (long)(0x10B30271A531C613L ^ l)), (int)Class_cb_d55bce0b.Pv("z", (int)27008, (long)(0x1412B8F4660A137BL ^ l))}));
        boolean bl = Class_ca_75c833b3.OY();
        int[] nArray5 = new int[Class_cb_d55bce0b.Pv("z", (int)12217, (long)(0x362D66E1A6A25569L ^ l))];
        nArray5[0] = (int)Class_cb_d55bce0b.Pv("z", (int)1303, (long)(0x7762ABCB4A4BFFFCL ^ l));
        nArray5[1] = (int)Class_cb_d55bce0b.Pv("z", (int)15593, (long)(0x10B30271A531C613L ^ l));
        nArray5[2] = (int)Class_cb_d55bce0b.Pv("z", (int)13630, (long)(0x39C27C08517E4FDFL ^ l));
        nArray5[3] = (int)Class_cb_d55bce0b.Pv("z", (int)13630, (long)(0x39C27C08517E4FDFL ^ l));
        nArray5[4] = (int)Class_cb_d55bce0b.Pv("z", (int)15593, (long)(0x10B30271A531C613L ^ l));
        nArray5[5] = (int)Class_cb_d55bce0b.Pv("z", (int)11313, (long)(0x210FE1E7A049D6E5L ^ l));
        this.ubjWn = new Class_cu_7306ec45(this.QBiNJ, Class_mr_7eac5189.clS(nArray5));
        int[] nArray6 = new int[Class_cb_d55bce0b.Pv("z", (int)1946, (long)(0x6061063F3D167D68L ^ l))];
        nArray6[0] = (int)Class_cb_d55bce0b.Pv("z", (int)23220, (long)(0x48507062E9C2207AL ^ l));
        nArray6[1] = (int)Class_cb_d55bce0b.Pv("z", (int)15593, (long)(0x10B30271A531C613L ^ l));
        nArray6[2] = (int)Class_cb_d55bce0b.Pv("z", (int)30737, (long)(0x57D4C582AC182E6L ^ l));
        nArray6[3] = (int)Class_cb_d55bce0b.Pv("z", (int)15593, (long)(0x10B30271A531C613L ^ l));
        nArray6[4] = (int)Class_cb_d55bce0b.Pv("z", (int)19, (long)(0x724BF881ECF47A85L ^ l));
        nArray6[5] = (int)Class_cb_d55bce0b.Pv("z", (int)26186, (long)(0x39944E3BC7311CBBL ^ l));
        nArray6[Class_cb_d55bce0b.Pv("z", (int)12217, (long)(0x362D66E1A6A25569L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)745, (long)(0x7B566FFB08B7F803L ^ l));
        this.DlqAM = new Class_cJ_2ae1a557(this, Class_mr_7eac5189.clS(nArray6)).WE(false);
        this.JIyxO = Class_mT_db06bea0.cpz();
        this.DQmMN = new Class_rk_bf8630d1((int)Class_cb_d55bce0b.Pv("z", (int)14373, (long)(0x4DB58036F0E342B7L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.llsxp = new Class_rk_bf8630d1((int)Class_cb_d55bce0b.Pv("z", (int)12729, (long)(0x4872C3F61FB34B60L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        int[] nArray7 = new int[Class_cb_d55bce0b.Pv("z", (int)6316, (long)(0x5AA758CEB45B625AL ^ l))];
        nArray7[0] = (int)Class_cb_d55bce0b.Pv("z", (int)4320, (long)(0x6F57FA28DABD6A24L ^ l));
        nArray7[1] = (int)Class_cb_d55bce0b.Pv("z", (int)18233, (long)(0x2DCF68C426833DC9L ^ l));
        nArray7[2] = (int)Class_cb_d55bce0b.Pv("z", (int)29212, (long)(0x64F0D7F75F1788D9L ^ l));
        nArray7[3] = (int)Class_cb_d55bce0b.Pv("z", (int)22715, (long)(0x46386E7A4C812268L ^ l));
        nArray7[4] = (int)Class_cb_d55bce0b.Pv("z", (int)31301, (long)(0xCB823F120AE0097L ^ l));
        nArray7[5] = (int)Class_cb_d55bce0b.Pv("z", (int)29212, (long)(0x64F0D7F75F1788D9L ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)12217, (long)(0x362D66E1A6A25569L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)22715, (long)(0x46386E7A4C812268L ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)1946, (long)(0x6061063F3D167D68L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)21413, (long)(0x59BCD94FAD9EA94AL ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)19203, (long)(0x76FC3FE5EE1731C4L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)4140, (long)(0x3E4A792F4D92EAC2L ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)4124, (long)(0x7B1996F89E8AEADDL ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)15593, (long)(0x10B30271A531C613L ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)21592, (long)(0x1C20433B37B92EBDL ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)13630, (long)(0x39C27C08517E4FDFL ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)31936, (long)(0x2991346D23CC0623L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)29212, (long)(0x64F0D7F75F1788D9L ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)21099, (long)(0x7EF55015628BA8FAL ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)5935, (long)(0xDE3B9E1D7F06DCFL ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)12582, (long)(0x3CB707DDB7CACBF8L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)29212, (long)(0x64F0D7F75F1788D9L ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)26130, (long)(0x6BF02750EA6E1C87L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)16770, (long)(0x69AF492F92DD3B6FL ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)27476, (long)(0x256FE649ED979182L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)17922, (long)(0x28B1B10A03023CEEL ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)19646, (long)(0x4D0135201B06364BL ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)13630, (long)(0x39C27C08517E4FDFL ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)13049, (long)(0x63F6D37B3730C81DL ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)29212, (long)(0x64F0D7F75F1788D9L ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)10912, (long)(0x19DC1D69EFD3D046L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)15593, (long)(0x10B30271A531C613L ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)11353, (long)(0x731589195500D688L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)13585, (long)(0x216953477E88CFCDL ^ l));
        nArray7[Class_cb_d55bce0b.Pv("z", (int)12125, (long)(0x5EDADA79E875D592L ^ l))] = (int)Class_cb_d55bce0b.Pv("z", (int)10433, (long)(0x7E53C904CF715223L ^ l));
        this.ubdhS = new Class_cO_0438f88e(nArray7, Class_cM_7a9de181.MENWL);
        this.LkpAS = true;
        if (Class_iS_888f260e.bwL() == null) {
            Class_ca_75c833b3.OW(!bl);
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block24: {
            block23: {
                block22: {
                    block21: {
                        block20: {
                            Class_cb_d55bce0b.wnjCO = Class_gb_9d201141.aYR(-2867794482669780847L, -4922495639708815465L, MethodHandles.lookup().lookupClass()).a(124734560512399L);
                            Class_cb_d55bce0b.dZkQt = new HashMap<K, V>(13);
                            var16 = Class_cb_d55bce0b.wnjCO ^ 127682467402525L;
                            var18_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                            v0 = SecretKeyFactory.getInstance("DES");
                            v1 = new byte[8];
                            v2 = v1;
                            v1[0] = (byte)(var16 >>> 56);
                            for (var19_2 = 1; var19_2 < 8; ++var19_2) {
                                v2 = v2;
                                v2[var19_2] = (byte)(var16 << var19_2 * 8 >>> 56);
                            }
                            var18_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                            var25_3 = new String[4];
                            var23_4 = 0;
                            var22_5 = "\u000b\u009a\u00fd\u0002\u00df\u008d\u0000\u00dfF\u00015\u00d6$\u00f9\u00c97\u0010\u009f\u0081\u00142+\u00925Y\u00a3C\u0097Q\u00b7I \u00ee";
                            var24_6 = "\u000b\u009a\u00fd\u0002\u00df\u008d\u0000\u00dfF\u00015\u00d6$\u00f9\u00c97\u0010\u009f\u0081\u00142+\u00925Y\u00a3C\u0097Q\u00b7I \u00ee".length();
                            var21_7 = 16;
                            var20_8 = -1;
lbl20:
                            // 2 sources

                            while (true) {
                                v3 = ++var20_8;
                                v4 = var22_5.substring(v3, v3 + var21_7);
                                v5 = -1;
                                break block20;
                                break;
                            }
lbl25:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = Class_cb_d55bce0b.Pp(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                var22_5 = "\u00d5\u0095\u00d0\u009b\u00c1f\t$ZD\u008bV\u009d\u00df\u0085\u00ecF\u00cf!V\u0095\u00e5\u0089\u0091\"\u00a70\u00ba\u009ffS\u0092\u0010+f)\u00a1\u008bAu\u00ff\u00e7:TJ\u0004O\u0016F";
                                var24_6 = "\u00d5\u0095\u00d0\u009b\u00c1f\t$ZD\u008bV\u009d\u00df\u0085\u00ecF\u00cf!V\u0095\u00e5\u0089\u0091\"\u00a70\u00ba\u009ffS\u0092\u0010+f)\u00a1\u008bAu\u00ff\u00e7:TJ\u0004O\u0016F".length();
                                var21_7 = 32;
                                var20_8 = -1;
lbl34:
                                // 2 sources

                                while (true) {
                                    v6 = ++var20_8;
                                    v4 = var22_5.substring(v6, v6 + var21_7);
                                    v5 = 0;
                                    break block20;
                                    break;
                                }
                                break;
                            }
lbl39:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = Class_cb_d55bce0b.Pp(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                break block21;
                                break;
                            }
                        }
                        var26_9 = var18_1.doFinal(v4.getBytes("ISO-8859-1"));
                        switch (v5) {
                            default: {
                                ** continue;
                            }
                            ** case 0:
lbl51:
                            // 1 sources

                            ** continue;
                        }
                    }
                    Class_cb_d55bce0b.LcMNI = var25_3;
                    Class_cb_d55bce0b.hBOJC = new String[4];
                    Class_cb_d55bce0b.vUFwR = new HashMap<K, V>(13);
                    var5_10 = Cipher.getInstance("DES/CBC/NoPadding");
                    v7 = SecretKeyFactory.getInstance("DES");
                    v8 = new byte[8];
                    v9 = v8;
                    v8[0] = (byte)(var16 >>> 56);
                    for (var6_11 = 1; var6_11 < 8; ++var6_11) {
                        v9 = v9;
                        v9[var6_11] = (byte)(var16 << var6_11 * 8 >>> 56);
                    }
                    var5_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                    var11_12 = new long[71];
                    var8_13 = 0;
                    var9_14 = "\u00bawaL%O\u00f2\u009aw\u00fe\u00ebnzTNAdL\u00b0\u00ac\u001a\u00a8\u00de\u00bf\u00f0o\u00b2\u008a\u00d7\u00b7d\u0094i\u00b9B\u00b6QiUd\u00afT\u0000\u001axD\n/\nq\u00bd\u00d0\u00e0?\u00c5<\u0081yU}9\u00c5b\u00dad\u0015\b\b\u00f0x\u0007`\u00ea\u009f\u00a1\"\u009a\r'\u008dye\u00f9\u0002-\u00c2\u00cfM1\u0010\u008a\u0018\u00f4H<\u008e\u00fe\n8\u00ae\u00f5\u00a0\u00c8\u00f1\u00f0\u00a5\u00ccDc\u0004x\u0016`\u0012\u00f6\u00cd\u00f0\u00f859N'\u00b5y\u0000\u00d8]\b\u00d3\u001b\u00cdw:\u0080DwU\u00d2\u00d0\u00a1\u00d9\u00fa\u00c0\u00ebwL*\u00f7\u00fb\u00b3\u00ec\u00ff\u0017k\u0005\f\u00f0\u00b2L&pg\u00b1\u00c0\u00c7}\u00f6w\u009c\u00cd\u001e\u0010\u000f\u00c0\u0093L!\u00c5\u00c5\u0010-\u00afe\bq\u0017\u00cc\u000f\u00d1\u00f2\u00c8\u00d0\u00a7.u\u0010\u00df\u0005\u00f4\u00e0\u00a9\u0088\u00ce\u00a5\u00c7\u00fd/\u00a5'XS\u00bb>\bq\u00e4]c\u0015\u00b9s0\u0086\u00c9C\u00a7{\u0087\u00fd\u00ba\u009f\u00d0\u00eb\u00c6\\\u00f8lz\u000f\u00ad\u00aa\u00e2\u00ae(\u0006\u00dc\u00fcJ!\u00ec\u0084r\u0087Z\u00b9&\u00c8\u0096S\u00d7\"X$\u0007*fB\u00c4\u00a6*\u00e2\u00e7\u0002\u0015\u00b3\u00d6\u00bc)p!B\u00a9\u0080<\u009a\t\u00b8l\u000f\u0018fd%\u00a4\\\u00a83\u00bd\u00c9\u00dfL\"S\u0091\u0080\u000eq:\u00a5\u0001\u00a9\u00d1N\u00fbx\u00eb\u00cc(}]\u00a5\u0096\u00f4\u009a\u00cb0\u00045K\u0016\u0003R\u0099LCv/iwk\u00c2\u0007\u00983Z\u00b4\u00d3\u00b6.@\u001ccK\u00b6/x/\u00b3\u001d\n\u00c57\u008e\u00fe\u00b4,kHnV3!\u00f0\u00c3\u00cb[\u00e1n\u00b8\u00df\u00fat]\u00c6y\u001d\u008f1\u00a3\u00a3\u00ad\u00be\u00fdV\u00e8`\u00f2$\u00de\u009b\u00b7*k\u00fc\u00e9C\u00a9\u00a9W!\u00d6@\u00bds\u00cfP\u00df`\u0082F\u00ef\u008d\u0095\u00d6\u001ac\u0098O\u0002\u009a\u00ddU\u00f9z\u00f6\u00a9\u00b8\u0017\u0097\u00f8\u0002\u0000s\u00d1\u00fedJ\u001dWs\u000b\u00d3\u00cdnm\u00d3\u0094\u0086\u008b\u0005c]\u00e0\u009c\u0016\u00fd\u00bb\u00c3\u00cf&\u00df\u00dbF;n\u00b2N4r$\u0082(1b23\u00dd\u00ef\u00c8;\u00ccWu\u00cf\u00b3cZ8\u00eb\u009fE\u0090n^N\u00e3\u00c5\u0092\u00f0\u001d\u00d9\u00e3\u00b8\u0091o\u008c\u00ca\u00d9\u00e1)\u00c0\u0080F\u00bfXMI\u00c2<\u00da|\u00f0qr\u008e\u009c\u00fb\r\u00e8G\u00ec\u00f1\u0096\u0011f\u00e8\u00ff\u00b4\u00e3\u00a5X\u00e8";
                    var10_15 = "\u00bawaL%O\u00f2\u009aw\u00fe\u00ebnzTNAdL\u00b0\u00ac\u001a\u00a8\u00de\u00bf\u00f0o\u00b2\u008a\u00d7\u00b7d\u0094i\u00b9B\u00b6QiUd\u00afT\u0000\u001axD\n/\nq\u00bd\u00d0\u00e0?\u00c5<\u0081yU}9\u00c5b\u00dad\u0015\b\b\u00f0x\u0007`\u00ea\u009f\u00a1\"\u009a\r'\u008dye\u00f9\u0002-\u00c2\u00cfM1\u0010\u008a\u0018\u00f4H<\u008e\u00fe\n8\u00ae\u00f5\u00a0\u00c8\u00f1\u00f0\u00a5\u00ccDc\u0004x\u0016`\u0012\u00f6\u00cd\u00f0\u00f859N'\u00b5y\u0000\u00d8]\b\u00d3\u001b\u00cdw:\u0080DwU\u00d2\u00d0\u00a1\u00d9\u00fa\u00c0\u00ebwL*\u00f7\u00fb\u00b3\u00ec\u00ff\u0017k\u0005\f\u00f0\u00b2L&pg\u00b1\u00c0\u00c7}\u00f6w\u009c\u00cd\u001e\u0010\u000f\u00c0\u0093L!\u00c5\u00c5\u0010-\u00afe\bq\u0017\u00cc\u000f\u00d1\u00f2\u00c8\u00d0\u00a7.u\u0010\u00df\u0005\u00f4\u00e0\u00a9\u0088\u00ce\u00a5\u00c7\u00fd/\u00a5'XS\u00bb>\bq\u00e4]c\u0015\u00b9s0\u0086\u00c9C\u00a7{\u0087\u00fd\u00ba\u009f\u00d0\u00eb\u00c6\\\u00f8lz\u000f\u00ad\u00aa\u00e2\u00ae(\u0006\u00dc\u00fcJ!\u00ec\u0084r\u0087Z\u00b9&\u00c8\u0096S\u00d7\"X$\u0007*fB\u00c4\u00a6*\u00e2\u00e7\u0002\u0015\u00b3\u00d6\u00bc)p!B\u00a9\u0080<\u009a\t\u00b8l\u000f\u0018fd%\u00a4\\\u00a83\u00bd\u00c9\u00dfL\"S\u0091\u0080\u000eq:\u00a5\u0001\u00a9\u00d1N\u00fbx\u00eb\u00cc(}]\u00a5\u0096\u00f4\u009a\u00cb0\u00045K\u0016\u0003R\u0099LCv/iwk\u00c2\u0007\u00983Z\u00b4\u00d3\u00b6.@\u001ccK\u00b6/x/\u00b3\u001d\n\u00c57\u008e\u00fe\u00b4,kHnV3!\u00f0\u00c3\u00cb[\u00e1n\u00b8\u00df\u00fat]\u00c6y\u001d\u008f1\u00a3\u00a3\u00ad\u00be\u00fdV\u00e8`\u00f2$\u00de\u009b\u00b7*k\u00fc\u00e9C\u00a9\u00a9W!\u00d6@\u00bds\u00cfP\u00df`\u0082F\u00ef\u008d\u0095\u00d6\u001ac\u0098O\u0002\u009a\u00ddU\u00f9z\u00f6\u00a9\u00b8\u0017\u0097\u00f8\u0002\u0000s\u00d1\u00fedJ\u001dWs\u000b\u00d3\u00cdnm\u00d3\u0094\u0086\u008b\u0005c]\u00e0\u009c\u0016\u00fd\u00bb\u00c3\u00cf&\u00df\u00dbF;n\u00b2N4r$\u0082(1b23\u00dd\u00ef\u00c8;\u00ccWu\u00cf\u00b3cZ8\u00eb\u009fE\u0090n^N\u00e3\u00c5\u0092\u00f0\u001d\u00d9\u00e3\u00b8\u0091o\u008c\u00ca\u00d9\u00e1)\u00c0\u0080F\u00bfXMI\u00c2<\u00da|\u00f0qr\u008e\u009c\u00fb\r\u00e8G\u00ec\u00f1\u0096\u0011f\u00e8\u00ff\u00b4\u00e3\u00a5X\u00e8".length();
                    var7_16 = 0;
                    while (true) {
                        var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                        v10 = var11_12;
                        v11 = var8_13++;
                        v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                        v13 = -1;
                        break block22;
                        break;
                    }
lbl78:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        var9_14 = " <\u00ac$\u00e5\u00d9r\u0096\u00c7\u008eO3w\u00b0\u00de\u00d8";
                        var10_15 = " <\u00ac$\u00e5\u00d9r\u0096\u00c7\u008eO3w\u00b0\u00de\u00d8".length();
                        var7_16 = 0;
                        while (true) {
                            var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                            v10 = var11_12;
                            v11 = var8_13++;
                            v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                            v13 = 0;
                            break block22;
                            break;
                        }
                        break;
                    }
lbl91:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        break block23;
                        break;
                    }
                }
                var13_18 = v12;
                var15_19 = var5_10.doFinal(new byte[]{(byte)(var13_18 >>> 56), (byte)(var13_18 >>> 48), (byte)(var13_18 >>> 40), (byte)(var13_18 >>> 32), (byte)(var13_18 >>> 24), (byte)(var13_18 >>> 16), (byte)(var13_18 >>> 8), (byte)var13_18});
                v14 = ((long)var15_19[0] & 255L) << 56 | ((long)var15_19[1] & 255L) << 48 | ((long)var15_19[2] & 255L) << 40 | ((long)var15_19[3] & 255L) << 32 | ((long)var15_19[4] & 255L) << 24 | ((long)var15_19[5] & 255L) << 16 | ((long)var15_19[6] & 255L) << 8 | (long)var15_19[7] & 255L;
                switch (v13) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl104:
                    // 1 sources

                    ** continue;
                }
            }
            Class_cb_d55bce0b.bYzvb = var11_12;
            Class_cb_d55bce0b.qFnKt = new Integer[71];
            var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
            v15 = SecretKeyFactory.getInstance("DES");
            v16 = new byte[8];
            v17 = v16;
            v16[0] = (byte)(var16 >>> 56);
            for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                v17 = v17;
                v17[var1_21] = (byte)(var16 << var1_21 * 8 >>> 56);
            }
            break block24;
lbl118:
            // 1 sources

            while (true) {
                continue;
                break;
            }
        }
        var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
        var2_22 = -4335569783642720098L;
        var4_23 = var0_20.doFinal(new byte[]{(byte)(var2_22 >>> 56), (byte)(var2_22 >>> 48), (byte)(var2_22 >>> 40), (byte)(var2_22 >>> 32), (byte)(var2_22 >>> 24), (byte)(var2_22 >>> 16), (byte)(var2_22 >>> 8), (byte)var2_22});
        ** while (true)
        Class_cb_d55bce0b.cIHkd = ((long)var4_23[0] & 255L) << 56 | ((long)var4_23[1] & 255L) << 48 | ((long)var4_23[2] & 255L) << 40 | ((long)var4_23[3] & 255L) << 32 | ((long)var4_23[4] & 255L) << 24 | ((long)var4_23[5] & 255L) << 16 | ((long)var4_23[6] & 255L) << 8 | (long)var4_23[7] & 255L;
    }

    private static CallSite Ps(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cb_d55bce0b" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static MatchException Po(MatchException matchException) {
        return matchException;
    }

    /*
     * Unable to fully structure code
     */
    public float Pi() {
        var1_1 = Class_cb_d55bce0b.wnjCO ^ 55073624658575L;
        var3_2 = Class_ca_75c833b3.OY();
        v0 = Class_cN_30b69d20.YyPjC;
        if (!var3_2) ** GOTO lbl9
        if (v0.isEmpty()) {
            v1 = this.ubdhS.Ye();
        } else {
            v0 = Class_cN_30b69d20.YyPjC.peek();
lbl9:
            // 2 sources

            v1 = ((Class_cO_0438f88e)v0).Ye();
        }
        var4_3 = v1;
        return 0.5f + 0.5f * var4_3.dhj();
    }

    @Override
    public void Ph(Class_lC_5322e8cf class_lC_5322e8cf) {
        long l = wnjCO ^ 0x35343DF61EABL;
        this.LX(class_lC_5322e8cf);
        float f = this.ormBS.dhj() * this.KgDVz.dhj();
        boolean bl = Class_ca_75c833b3.OY();
        float f2 = f;
        if (bl) {
            if (f2 == 0.0f) {
                return;
            }
            f2 = this.RT();
        }
        float f3 = f2;
        float f4 = f3 - 1.0f;
        float f5 = f4 == 0.0f ? 0 : (f4 > 0.0f ? 1 : -1);
        if (bl) {
            if (f5 != false) {
                Class_jH_c1172273.bId(class_lC_5322e8cf, this.toIeR, this.QWaAn, f3);
            }
            this.NV(class_lC_5322e8cf);
            float f6 = f3 - 1.0f;
            f5 = f6 == 0.0f ? 0 : (f6 > 0.0f ? 1 : -1);
        }
        if (f5 != false) {
            Class_jH_c1172273.bIf();
        }
    }

    @Override
    protected void NV(Class_lC_5322e8cf class_lC_5322e8cf) {
        block13: {
            boolean bl;
            block17: {
                Object object;
                boolean bl2;
                long l;
                block14: {
                    Class_cb_d55bce0b class_cb_d55bce0b;
                    block16: {
                        float f;
                        block15: {
                            l = wnjCO ^ 0x1D3A2A30E2C7L;
                            bl2 = Class_ca_75c833b3.OX();
                            if (!Class_cN_30b69d20.YyPjC.isEmpty()) break block14;
                            object = this.ubdhS.Ye();
                            ((Class_rk_bf8630d1)object).dhq((int)Class_cb_d55bce0b.Pv("z", (int)9244, (long)(0x16E34C817F2A4EF6L ^ l)));
                            ((Class_rk_bf8630d1)object).dhs(ClientMain.dlmvG.currentScreen instanceof ChatScreen ? Class_rj_b691f4f7.XzDkv : Class_rj_b691f4f7.AYqck);
                            ((Class_rk_bf8630d1)object).dhd(ClientMain.dlmvG.currentScreen instanceof ChatScreen ? 1.0f : 0.0f);
                            float f2 = ((Class_rk_bf8630d1)object).dhj() - 0.0f;
                            f = f2 == 0.0f ? 0 : (f2 > 0.0f ? 1 : -1);
                            if (bl2) break block15;
                            if (f == false) {
                                return;
                            }
                            class_cb_d55bce0b = this;
                            if (bl2) break block16;
                            f = (float)class_cb_d55bce0b.JIyxO.cpC(cIHkd);
                        }
                        if (f != false) {
                            this.ubdhS.Yi(this.ubdhS.Yd().XA());
                            this.JIyxO.cpB();
                        }
                        this.ubdhS.Yh(LocalTime.now());
                        class_cb_d55bce0b = this;
                    }
                    class_cb_d55bce0b.ubdhS.XV(class_lC_5322e8cf, this.toIeR, this.QWaAn, this.jTsqG, this.Xtjvx, this.ormBS.dhj(), this.DlqAM.WF());
                    if (!bl2) break block17;
                }
                object = DateTimeFormatter.ofPattern((String)((Object)Class_cb_d55bce0b.Ps("l", (int)16951, (long)(0x20D2522006C071B7L ^ l))));
                float f = 0.0f;
                for (Class_cO_0438f88e class_cO_0438f88e : Class_cN_30b69d20.YyPjC) {
                    float f3;
                    float f4;
                    block22: {
                        float f5;
                        block21: {
                            float f6;
                            block20: {
                                Class_rk_bf8630d1 class_rk_bf8630d1;
                                block19: {
                                    block18: {
                                        class_rk_bf8630d1 = class_cO_0438f88e.Yg();
                                        class_rk_bf8630d1.dhs(Class_rj_b691f4f7.NJlxm);
                                        class_rk_bf8630d1.dhq((int)Class_cb_d55bce0b.Pv("z", (int)12729, (long)(0x4872B80BB6F3DB41L ^ l)));
                                        f6 = this.QWaAn;
                                        if (bl2) break block18;
                                        bl = this.ueekw.SZ();
                                        if (bl2) break block13;
                                        if (!bl) break block19;
                                        f6 += class_rk_bf8630d1.dhd(f);
                                    }
                                    if (!bl2) break block20;
                                }
                                f6 -= class_rk_bf8630d1.dhd(f);
                            }
                            class_cO_0438f88e.XW();
                            float f7 = this.toIeR;
                            float f8 = this.jTsqG;
                            Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.joxgd.bYM(6.0f);
                            Class_lq_87a74641 class_lq_87a746412 = Class_lE_06fbe260.WTzbi.bYM(6.0f);
                            String string = class_cO_0438f88e.Yc().format((DateTimeFormatter)object);
                            float f9 = class_lq_87a74641.cao(string);
                            float f10 = 27.0f + class_lq_87a746412.cap(class_cO_0438f88e.XZ()) + 7.0f + f9;
                            float f11 = this.jTsqG - f10;
                            f5 = f11 == 0.0f ? 0 : (f11 < 0.0f ? -1 : 1);
                            if (bl2) break block21;
                            if (f5 < 0) {
                                f8 = f10;
                                f7 = this.Pk(f8);
                            }
                            class_cO_0438f88e.XV(class_lC_5322e8cf, f7, f6, f8, this.Xtjvx, this.ormBS.dhj(), this.DlqAM.WF());
                            f4 = class_cO_0438f88e.Ye().dhj();
                            f3 = 0.5f;
                            if (bl2) break block22;
                            float f12 = f4 - f3;
                            f5 = f12 == 0.0f ? 0 : (f12 > 0.0f ? 1 : -1);
                        }
                        if (f5 < 0 && class_cO_0438f88e.Ya().cpC(class_cO_0438f88e.Yb()) && !bl2) continue;
                        f4 = f;
                        f3 = 30.0f;
                    }
                    f = f4 + f3;
                    if (!bl2) continue;
                }
            }
            bl = Class_cN_30b69d20.YyPjC.removeIf(Class_cO_0438f88e::XX);
        }
    }

    @Override
    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        super.LX(class_lC_5322e8cf);
        this.jTsqG = 175.0f;
        this.Xtjvx = 26.0f;
        this.toIeR = this.DQmMN.dhd(this.Pj());
        this.QWaAn = this.llsxp.dhd(this.Pl());
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean onMouseClicked(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        long l = wnjCO ^ 0x1649DAE650EFL;
        boolean bl = this.RP(d, d2);
        boolean bl2 = Class_ca_75c833b3.OX();
        boolean bl3 = bl;
        if (bl2) return bl3;
        if (!bl3) return false;
        bl3 = this.LkpAS;
        if (bl2) return bl3;
        if (!bl3) return false;
        if (class_mA_32d8a5f2 != Class_mA_32d8a5f2.frWTZ) return false;
        this.pAjuu = false;
        this.vCMYc = true;
        this.AyAnj.dhg();
        float f = this.toIeR + (float)(d - (double)this.toIeR) * this.RT();
        float f2 = this.QWaAn + (float)(d2 - (double)this.QWaAn) * this.RT();
        Class_ap_f3b7a87f class_ap_f3b7a87f = new Class_ap_f3b7a87f(f, f2, 110.0f, 6.0f).pW((String)((Object)(this.oZllQ.isEmpty() ? Class_cb_d55bce0b.Ps("l", (int)2912, (long)(0x7926939714A10ACAL ^ l)) : Class_cb_d55bce0b.Ps("l", (int)8079, (long)(0x10AFC6982DD91E24L ^ l))))).qq();
        for (Class_cB_67aec11c class_cB_67aec11c : this.oZllQ) {
            class_ap_f3b7a87f.pU(class_cB_67aec11c);
            if (bl2) return true;
            if (!bl2) continue;
        }
        class_ap_f3b7a87f.qn((String)((Object)Class_cb_d55bce0b.Ps("l", (int)14788, (long)(0x13FC9E2910E2386DL ^ l))), Class_lf_d247d983.JHGge, Class_jk_a0800133.mPXGi, Class_jk_a0800133.mPXGi, class_aj_95d0a719 -> {
            this.LkpAS = false;
            class_aj_95d0a719.oj(false);
        }).qo(() -> {
            this.vCMYc = false;
        });
        ClientMain.dlK().Rs(class_ap_f3b7a87f);
        return true;
    }

    private static CallSite Pv(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cb_d55bce0b" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private float Pj() {
        long l = wnjCO ^ 0x3434BA46AC50L;
        float f = this.RT();
        boolean bl = Class_ca_75c833b3.OY();
        boolean bl2 = this.HhBiN.SZ();
        if (bl) {
            if (bl2) {
                return 10.0f;
            }
            bl2 = this.SqYxj.SZ();
        }
        if (bl2) {
            Vec2f vec2f = Class_rm_d861be3b.diq();
            return vec2f.x - this.jTsqG * f - 10.0f;
        }
        Vec2f vec2f = Class_rm_d861be3b.diq();
        return vec2f.x / 2.0f - this.jTsqG * f / 2.0f;
    }

    private float Pl() {
        long l = wnjCO ^ 0x43E07E1DFA4DL;
        if (this.ueekw.SZ()) {
            return 10.0f;
        }
        Vec2f vec2f = Class_rm_d861be3b.diq();
        return vec2f.y - 90.0f * this.RT();
    }

    private static int Pt(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x326;
        if (qFnKt[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = bYzvb[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])vUFwR.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    vUFwR.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cb_d55bce0b", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_cb_d55bce0b.qFnKt[n2] = n3;
        }
        return qFnKt[n2];
    }

    private static int Pu(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_cb_d55bce0b.Pt(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static String Pq(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5A55;
        if (hBOJC[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])dZkQt.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    dZkQt.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cb_d55bce0b", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = LcMNI[n2].getBytes("ISO-8859-1");
            Class_cb_d55bce0b.hBOJC[n2] = Class_cb_d55bce0b.Pp(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return hBOJC[n2];
    }

    private float Pk(float f) {
        float f2;
        boolean bl;
        float f3;
        block7: {
            Vec2f vec2f;
            block8: {
                boolean bl2;
                block5: {
                    block6: {
                        long l = wnjCO ^ 0x202062E90337L;
                        f3 = this.RT();
                        bl = Class_ca_75c833b3.OY();
                        bl2 = this.HhBiN.SZ();
                        if (!bl) break block5;
                        if (!bl2) break block6;
                        f2 = 10.0f;
                        if (bl) break block7;
                    }
                    bl2 = this.SqYxj.SZ();
                }
                if (!bl2) break block8;
                vec2f = Class_rm_d861be3b.diq();
                f2 = vec2f.x - f * f3 - 10.0f;
                if (bl) break block7;
            }
            vec2f = Class_rm_d861be3b.diq();
            f2 = vec2f.x / 2.0f - f * f3 / 2.0f;
        }
        float f4 = f3;
        float f5 = 1.0f;
        if (bl) {
            if (f4 == f5) {
                return f2;
            }
            f4 = this.toIeR;
            f5 = (f2 - this.toIeR) / f3;
        }
        return f4 + f5;
    }

    private static String Pp(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static Object Pr(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_cb_d55bce0b.Pq(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cb_d55bce0b.class, "Pr", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_cb_d55bce0b.class, "Pu", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

