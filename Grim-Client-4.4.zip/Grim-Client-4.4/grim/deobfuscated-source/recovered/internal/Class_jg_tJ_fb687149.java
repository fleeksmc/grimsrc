/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

public final class Class_jg_tJ_fb687149
extends Enum<Class_jg_tJ_fb687149> {
    public static /* enum */ Class_jg_tJ_fb687149 frJIr;
    public static /* enum */ Class_jg_tJ_fb687149 OCdZM;
    public static /* enum */ Class_jg_tJ_fb687149 iBGoL;
    private static Class_jg_tJ_fb687149[] YNYZj;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_jg_tJ_fb687149.class);
        Class_jg_tJ_fb687149._ad0dd2d047b8701acfb73ed098f3eac4();
    }

    public static native Class_jg_tJ_fb687149[] values();

    public static native Class_jg_tJ_fb687149 valueOf(String var0);

    private static native Class_jg_tJ_fb687149[] dpI();

    private static native String dpJ(byte[] var0);

    private static native void _ad0dd2d047b8701acfb73ed098f3eac4();
}

