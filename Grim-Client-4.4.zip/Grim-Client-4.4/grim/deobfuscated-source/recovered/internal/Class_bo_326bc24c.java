/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import net.minecraft.item.Item;
import recovered.core.NativeLoader;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_jc_20aa808a;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_nf_8f40fc48;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bo_326bc24c
extends Class_az_a4990dcf {
    private final Class_nf_8f40fc48 jZEcd;
    private final Class_az_a4990dcf zxOMV;
    private final Class_ri_288534d5 jFosN;
    private final Class_rk_bf8630d1 lAJLi;
    private final Class_rk_bf8630d1 UCmRU;
    private static long ejgBq;
    private static String[] WTtGn;
    private static String[] XTYeh;
    private static Map Nufut;
    private static long[] OXgHV;
    private static Integer[] XLRYu;
    private static Map uTsCw;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native int FC(int var0, long var1);

    public Class_bo_326bc24c(Class_nf_8f40fc48 class_nf_8f40fc48, Class_az_a4990dcf class_az_a4990dcf) {
        long l = ejgBq ^ 0x3B07243AFC01L;
        this.lAJLi = new Class_rk_bf8630d1((int)Class_bo_326bc24c.FE("u", (int)21461, (long)(0x6FDB819D9CBA8DAL ^ l))).dhs(Class_rj_b691f4f7.XzDkv);
        this.UCmRU = new Class_rk_bf8630d1((int)Class_bo_326bc24c.FE("u", (int)15753, (long)(0x76B4BA64EEBB4687L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.jZEcd = class_nf_8f40fc48;
        this.zxOMV = class_az_a4990dcf;
        Item item = Class_jc_20aa808a.bzz(class_nf_8f40fc48.ctT());
        Class_mG_52c8d386 class_mG_52c8d386 = Class_jc_20aa808a.bzB(item);
        this.jFosN = new Class_ri_288534d5((int)Class_bo_326bc24c.FE("u", (int)15753, (long)(0x76B4BA64EEBB4687L ^ l)), class_mG_52c8d386);
    }

    static {
        NativeLoader.doInit(Class_bo_326bc24c.class);
        Class_bo_326bc24c._59e141878ced10e285ef05299aa3d0d3();
    }

    @Override
    public native float dn();

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native void dY();

    private static native void _59e141878ced10e285ef05299aa3d0d3();

    private static native CallSite FE(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native MatchException Fx(MatchException var0);

    private native void Fw(double var1, double var3);

    private static native Object FA(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native String Fz(int var0, long var1);

    private static native CallSite FB(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native int FD(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native String Fy(byte[] var0);
}

