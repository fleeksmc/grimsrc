/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.fluid.FluidState
 */
package recovered.internal;

import net.minecraft.fluid.FluidState;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gn_d890fa95
extends Class_hH_ae8f8f77 {
    private final FluidState THYuP;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gn_d890fa95(FluidState fluidState) {
        this.THYuP = fluidState;
    }

    public FluidState bbg() {
        return this.THYuP;
    }
}

