/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.sound.SoundInstance
 *  net.minecraft.util.math.Vec2f
 *  net.minecraft.util.math.Vec3d
 *  org.apache.commons.lang3.StringUtils
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import org.apache.commons.lang3.StringUtils;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_jI_616cf0dd;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.modules.AmbienceModule;

class Class_da_sv_d77b5a88 {
    private final SoundInstance wneJp;
    private final Vec3d izVKY;
    private final long zstpO;
    private boolean zUbCd;
    private final Class_rk_bf8630d1 Taibw;
    private static final long iFBqt = Class_gb_9d201141.aYR(7556872127427825018L, -7644387685138179365L, MethodHandles.lookup().lookupClass()).a(252502118503577L);
    private static final String ySNLn;
    private static final long xwXDE;
    private static final long YpDrW;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_da_sv_d77b5a88(SoundInstance soundInstance, Vec3d vec3d) {
        long l = iFBqt ^ 0x740C731E9204L;
        this.zUbCd = false;
        this.Taibw = new Class_rk_bf8630d1((int)xwXDE);
        this.wneJp = soundInstance;
        this.izVKY = vec3d;
        this.zstpO = System.currentTimeMillis();
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = iFBqt ^ 0x1BF16801EF5EL;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        byte[] byArray3 = cipher.doFinal("l\u008f\u00f1\u00eb9-6\u0088".getBytes("ISO-8859-1"));
        ySNLn = Class_da_sv_d77b5a88.dom(byArray3).intern();
        Cipher cipher2 = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory2 = SecretKeyFactory.getInstance("DES");
        byte[] byArray4 = new byte[8];
        byte[] byArray5 = byArray4;
        byArray4[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray5 = byArray5;
            byArray5[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher2.init(2, (Key)secretKeyFactory2.generateSecret(new DESKeySpec(byArray5)), new IvParameterSpec(new byte[8]));
        long l2 = -1541778739621727163L;
        byte[] byArray6 = cipher2.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
        xwXDE = ((long)byArray6[0] & 0xFFL) << 56 | ((long)byArray6[1] & 0xFFL) << 48 | ((long)byArray6[2] & 0xFFL) << 40 | ((long)byArray6[3] & 0xFFL) << 32 | ((long)byArray6[4] & 0xFFL) << 24 | ((long)byArray6[5] & 0xFFL) << 16 | ((long)byArray6[6] & 0xFFL) << 8 | (long)byArray6[7] & 0xFFL;
        Cipher cipher3 = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory3 = SecretKeyFactory.getInstance("DES");
        byte[] byArray7 = new byte[8];
        byte[] byArray8 = byArray7;
        byArray7[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher3.init(2, (Key)secretKeyFactory3.generateSecret(new DESKeySpec(byArray8)), new IvParameterSpec(new byte[8]));
                long l3 = -328728050007090688L;
                byte[] byArray9 = cipher3.doFinal(new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3});
                YpDrW = ((long)byArray9[0] & 0xFFL) << 56 | ((long)byArray9[1] & 0xFFL) << 48 | ((long)byArray9[2] & 0xFFL) << 40 | ((long)byArray9[3] & 0xFFL) << 32 | ((long)byArray9[4] & 0xFFL) << 24 | ((long)byArray9[5] & 0xFFL) << 16 | ((long)byArray9[6] & 0xFFL) << 8 | (long)byArray9[7] & 0xFFL;
                return;
            }
            byArray8 = byArray8;
            byArray8[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    private static String dom(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static MatchException dol(MatchException matchException) {
        return matchException;
    }

    public void doj(Class_lC_5322e8cf class_lC_5322e8cf, int n) {
        Vec2f vec2f;
        block6: {
            block5: {
                long l = iFBqt ^ 0x578E3F231214L;
                Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
                boolean bl = this.zUbCd;
                if (class_iS_888f260eArray == null) {
                    bl = !bl;
                }
                this.Taibw.dhc(bl);
                this.Taibw.dhs(!this.zUbCd ? Class_rj_b691f4f7.XzDkv : Class_rj_b691f4f7.AYqck);
                long l2 = System.currentTimeMillis() - this.zstpO;
                if (class_iS_888f260eArray != null) break block5;
                if (l2 <= (long)n * YpDrW) break block6;
                this.zUbCd = true;
            }
            this.Taibw.dhd(0.0f);
        }
        if ((vec2f = Class_jI_616cf0dd.bIw(this.izVKY)) == null) {
            return;
        }
        Class_mG_52c8d386 class_mG_52c8d386 = ClientMain.dlM().bjb();
        Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
        String string = StringUtils.capitalize((String)this.wneJp.getId().getPath().replaceAll(ySNLn, " ").replace("_", " "));
        float f = class_lq_87a74641.cao(string) + 10.0f;
        float f2 = class_lq_87a74641.cat() + 10.0f;
        float f3 = vec2f.x - f / 2.0f;
        float f4 = vec2f.y;
        float f5 = f3 + Class_jf_d1c4f950.bAH(class_lq_87a74641.cao(string), f);
        float f6 = f4 + Class_jf_d1c4f950.bAH(class_lq_87a74641.cat(), f2);
        float f7 = this.Taibw.dhj();
        Class_jH_c1172273.bId(class_lC_5322e8cf, f3 + f / 2.0f, f4 + f2 / 2.0f, 0.5f + 0.5f * f7);
        class_lC_5322e8cf.ccU(f3, f4, f, f2, this.Taibw.dhj(), 0.0f);
        class_lC_5322e8cf.cez(class_lq_87a74641, string, f5, f6, class_mG_52c8d386);
        Class_jH_c1172273.bIf();
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean dok() {
        float f;
        block5: {
            Class_iS_888f260e[] class_iS_888f260eArray;
            block4: {
                long l = iFBqt ^ 0x314210443B9DL;
                class_iS_888f260eArray = AmbienceModule.afl();
                float f2 = this.Taibw.dhj() - 0.0f;
                f = f2 == 0.0f ? 0 : (f2 > 0.0f ? 1 : -1);
                if (class_iS_888f260eArray != null) break block4;
                if (f != false) break block5;
                f = (float)this.zUbCd;
            }
            if (class_iS_888f260eArray != null) return (boolean)f;
            if (f != false) {
                f = 1.0f;
                return (boolean)f;
            }
        }
        f = 0.0f;
        return (boolean)f;
    }
}

