/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_ae_rP_6c7ebb3c {
    private final String MNrmg;
    private final String noDvP;
    private final Class_rk_bf8630d1 aRsQd;
    private static long FyIas;
    private static long AGepX;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ae_rP_6c7ebb3c(String string, String string2) {
        long l = FyIas ^ 0x135B233B14E0L;
        this.aRsQd = new Class_rk_bf8630d1((int)AGepX).dhs(Class_rj_b691f4f7.UPXqT);
        this.MNrmg = string;
        this.noDvP = string2;
    }

    static {
        NativeLoader.doInit(Class_ae_rP_6c7ebb3c.class);
        Class_ae_rP_6c7ebb3c._1c192b87da7b20b63ab1534bf843fe4b();
    }

    private static native void _1c192b87da7b20b63ab1534bf843fe4b();

    public native String dmN();

    public native String dmO();

    public native Class_rk_bf8630d1 dmP();
}

