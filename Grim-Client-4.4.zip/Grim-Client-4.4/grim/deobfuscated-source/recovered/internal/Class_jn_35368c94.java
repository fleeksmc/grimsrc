/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;

public final class Class_jn_35368c94
extends Enum<Class_jn_35368c94> {
    public static final /* enum */ Class_jn_35368c94 pWlAK;
    public static final /* enum */ Class_jn_35368c94 bxePp;
    private static final /* synthetic */ Class_jn_35368c94[] YmVPW;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = Class_gb_9d201141.aYR(8712539283763144677L, -7338924662229193353L, MethodHandles.lookup().lookupClass()).a(118375498985393L) ^ 0x81DD0D9AE45L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[2];
        int n = 0;
        String string = "\u00a7z\u00dc\u00ec\u00da\u00ba8@\b\u00f8\u0010\u00e76q\u00d0\u00c5l";
        int n2 = "\u00a7z\u00dc\u00ec\u00da\u00ba8@\b\u00f8\u0010\u00e76q\u00d0\u00c5l".length();
        int n3 = 8;
        int n4 = -1;
        while (true) {
            int n5 = ++n4;
            byte[] byArray3 = cipher.doFinal(string.substring(n5, n5 + n3).getBytes("ISO-8859-1"));
            stringArray[n++] = Class_jn_35368c94.bEb(byArray3).intern();
            if ((n4 += n3) >= n2) {
                pWlAK = new Class_jn_35368c94();
                bxePp = new Class_jn_35368c94();
                YmVPW = Class_jn_35368c94.bEa();
                return;
            }
            n3 = string.charAt(n4);
        }
    }

    public static Class_jn_35368c94[] values() {
        return (Class_jn_35368c94[])YmVPW.clone();
    }

    public static Class_jn_35368c94 valueOf(String string) {
        return Enum.valueOf(Class_jn_35368c94.class, string);
    }

    private static /* synthetic */ Class_jn_35368c94[] bEa() {
        return new Class_jn_35368c94[]{pWlAK, bxePp};
    }

    private static String bEb(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }
}

