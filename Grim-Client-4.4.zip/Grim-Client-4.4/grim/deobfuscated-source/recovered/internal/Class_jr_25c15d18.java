/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.textures.GpuTextureView
 *  net.minecraft.client.render.DiffuseLighting$Type
 *  net.minecraft.client.render.OverlayTexture
 *  net.minecraft.client.render.RenderLayer
 *  net.minecraft.client.render.VertexConsumerProvider$Immediate
 *  net.minecraft.client.render.command.OrderedRenderCommandQueue
 *  net.minecraft.client.render.entity.EntityRenderManager
 *  net.minecraft.client.render.entity.model.PlayerEntityModel
 *  net.minecraft.client.render.entity.state.EntityRenderState
 *  net.minecraft.client.render.state.CameraRenderState
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.util.math.Vec3d
 *  org.joml.Matrix3x2fc
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Quaternionf
 *  org.joml.Quaternionfc
 */
package recovered.internal;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2fc;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jC_6c1c779b;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jI_616cf0dd;
import recovered.internal.Class_js_9609134b;
import recovered.internal.Class_mG_52c8d386;

public final class Class_jr_25c15d18 {
    private static final float yNuSl = -10850.0f;
    private static Class_jC_6c1c779b ajsvX;
    private static final long xwomO;
    private static final long[] AIvOD;
    private static final Integer[] SIjrl;
    private static final Map avqBf;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    static {
        xwomO = Class_gb_9d201141.aYR(-5308184261290161932L, 8937719512333401079L, MethodHandles.lookup().lookupClass()).a(270939487081972L);
        avqBf = new HashMap(13);
        long l = xwomO ^ 0x1ECC9D577A23L;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "R\u0092\u00c5\u00d7\u0095R\u00f0p\u00ce\u0080\u0083\u00baEED\u00eb";
        int n2 = "R\u0092\u00c5\u00d7\u0095R\u00f0p\u00ce\u0080\u0083\u00baEED\u00eb".length();
        int n3 = 0;
        do {
            byte[] byArray3 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
            byte[] byArray4 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray4[0] & 0xFFL) << 56 | ((long)byArray4[1] & 0xFFL) << 48 | ((long)byArray4[2] & 0xFFL) << 40 | ((long)byArray4[3] & 0xFFL) << 32 | ((long)byArray4[4] & 0xFFL) << 24 | ((long)byArray4[5] & 0xFFL) << 16 | ((long)byArray4[6] & 0xFFL) << 8 | (long)byArray4[7] & 0xFFL;
        } while (n3 < n2);
        AIvOD = lArray;
        SIjrl = new Integer[2];
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void bFt(Matrix3x2fc matrix3x2fc, PlayerEntityModel playerEntityModel, Identifier identifier, float f, float f2, float f3, float f4, float f5, float f6, float f7) {
        block10: {
            long l = xwomO ^ 0x1D48D000140DL;
            MatrixStack matrixStack = Class_jI_616cf0dd.bIm(matrix3x2fc);
            String[] stringArray = Class_js_9609134b.bFF();
            matrixStack.push();
            matrixStack.translate(f4 + f6 / 2.0f, f5 + f7, -10850.0f);
            matrixStack.scale(f, f, f);
            matrixStack.translate(0.0f, -0.0625f, 0.0f);
            Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
            matrix4f.rotateAround((Quaternionfc)RotationAxis.POSITIVE_X.rotationDegrees(f2), 0.0f, -1.0625f, 0.0f);
            matrixStack.multiply((Quaternionfc)RotationAxis.POSITIVE_Y.rotationDegrees(f3));
            Class_jC_6c1c779b class_jC_6c1c779b = Class_jr_25c15d18.bFv();
            VertexConsumerProvider.Immediate immediate = class_jC_6c1c779b.bGU();
            GpuTextureView gpuTextureView = RenderSystem.outputColorTextureOverride;
            GpuTextureView gpuTextureView2 = RenderSystem.outputDepthTextureOverride;
            ClientMain.dlmvG.gameRenderer.getDiffuseLighting().setShaderLights(DiffuseLighting.Type.PLAYER_SKIN);
            try {
                matrixStack.push();
                matrixStack.multiplyPositionMatrix((Matrix4fc)new Matrix4f().scaling(1.0f, 1.0f, -1.0f));
                matrixStack.translate(0.0f, -1.5f, 0.0f);
                RenderLayer renderLayer = playerEntityModel.getLayer(identifier);
                int n = Class_mG_52c8d386.hoGuU.coa(255.0f * Class_jF_38b68c76.bHy()).coh();
                playerEntityModel.render(matrixStack, immediate.getBuffer(renderLayer), (int)Class_jr_25c15d18.bFz("k", (int)24324, (long)(0x5D8CEA5F4960283AL ^ l)), OverlayTexture.DEFAULT_UV, n);
                matrixStack.pop();
            }
            finally {
                try {
                    class_jC_6c1c779b.bGY();
                }
                finally {
                    ClientMain.dlmvG.gameRenderer.getDiffuseLighting().setShaderLights(DiffuseLighting.Type.ITEMS_3D);
                    RenderSystem.outputColorTextureOverride = gpuTextureView;
                    RenderSystem.outputDepthTextureOverride = gpuTextureView2;
                }
            }
            matrixStack.pop();
            if (stringArray == null) break block10;
            Class_iS_888f260e.bwK("zirxw");
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static void bFu(Matrix3x2fc matrix3x2fc, EntityRenderState entityRenderState, float f, Vec3d vec3d, Quaternionf quaternionf, Quaternionf quaternionf2, float f2, float f3, float f4, float f5) {
        block11: {
            long l = xwomO ^ 0x365609A5056AL;
            MatrixStack matrixStack = Class_jI_616cf0dd.bIm(matrix3x2fc);
            String[] stringArray = Class_js_9609134b.bFF();
            matrixStack.translate(f2 + f4 / 2.0f, f3 + f5 / 2.0f, -10850.0f);
            matrixStack.scale(f, f, -f);
            GpuTextureView gpuTextureView = RenderSystem.outputColorTextureOverride;
            GpuTextureView gpuTextureView2 = RenderSystem.outputDepthTextureOverride;
            ClientMain.dlmvG.gameRenderer.getDiffuseLighting().setShaderLights(DiffuseLighting.Type.ENTITY_IN_UI);
            entityRenderState.light = (int)Class_jr_25c15d18.bFz("k", (int)21672, (long)(0x584AE9707D0CB2F0L ^ l));
            Class_jC_6c1c779b class_jC_6c1c779b = Class_jr_25c15d18.bFv();
            Class_js_9609134b.bFA();
            try {
                matrixStack.translate(vec3d);
                matrixStack.multiply((Quaternionfc)quaternionf);
                matrixStack.multiply((Quaternionfc)RotationAxis.POSITIVE_Z.rotationDegrees(180.0f));
                CameraRenderState cameraRenderState = new CameraRenderState();
                if (quaternionf2 != null) {
                    cameraRenderState.orientation = quaternionf2.conjugate(new Quaternionf()).rotateY((float)Math.PI);
                }
                EntityRenderManager entityRenderManager = ClientMain.dlmvG.getEntityRenderDispatcher();
                entityRenderManager.render(entityRenderState, cameraRenderState, 0.0, 0.0, 0.0, matrixStack, (OrderedRenderCommandQueue)class_jC_6c1c779b.bGT());
            }
            finally {
                try {
                    Class_js_9609134b.bFB();
                    class_jC_6c1c779b.bGY();
                }
                finally {
                    ClientMain.dlmvG.gameRenderer.getDiffuseLighting().setShaderLights(DiffuseLighting.Type.ITEMS_3D);
                    RenderSystem.outputColorTextureOverride = gpuTextureView;
                    RenderSystem.outputDepthTextureOverride = gpuTextureView2;
                }
            }
            if (Class_iS_888f260e.bwL() != null) break block11;
            Class_js_9609134b.bFE(new String[2]);
        }
    }

    private static int bFx(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5448;
        if (SIjrl[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = AIvOD[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])avqBf.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    avqBf.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jr_25c15d18", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_jr_25c15d18.SIjrl[n2] = n3;
        }
        return SIjrl[n2];
    }

    private static int bFy(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_jr_25c15d18.bFx(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static MatchException bFw(MatchException matchException) {
        return matchException;
    }

    private static Class_jC_6c1c779b bFv() {
        long l = xwomO ^ 0x7989230F614FL;
        String[] stringArray = Class_js_9609134b.bFF();
        Class_jC_6c1c779b class_jC_6c1c779b = ajsvX;
        if (stringArray == null) {
            if (class_jC_6c1c779b == null) {
                ajsvX = new Class_jC_6c1c779b();
            }
            class_jC_6c1c779b = ajsvX;
        }
        return class_jC_6c1c779b;
    }

    private static CallSite bFz(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jr_25c15d18" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jr_25c15d18.class, "bFy", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

