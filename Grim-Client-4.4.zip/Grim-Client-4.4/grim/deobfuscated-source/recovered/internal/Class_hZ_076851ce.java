/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import recovered.internal.Class_hM_a36d442e;
import recovered.internal.Class_hW_98f65112;

public interface Class_hZ_076851ce {
    public boolean executable();

    public Class_hW_98f65112 handler();

    public List<Class_hM_a36d442e<?>> parameters();

    public List<String> names();

    public String description();

    public List<Class_hZ_076851ce> subcommands();
}

