/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_h_rH_195350c3;
import recovered.internal.Class_i_a489cc15;

public class Class_h_d59300d0 {
    private final Class_h_rH_195350c3 ZbGue;
    private final int DBVzo;
    private final int DGQOz;
    private final int dTqVH;
    private final char xQWfQ;
    private Class_i_a489cc15 jsZzv;
    private Class_az_a4990dcf fxVCg;
    private Class_az_a4990dcf pHPuk;
    private boolean TMeSA;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_h_d59300d0(Class_h_rH_195350c3 class_h_rH_195350c3, int n, int n2, int n3, char c) {
        this.ZbGue = class_h_rH_195350c3;
        this.DBVzo = n;
        this.DGQOz = n2;
        this.dTqVH = n3;
        this.xQWfQ = c;
    }

    public Class_h_rH_195350c3 bF() {
        return this.ZbGue;
    }

    public void bE() {
        this.TMeSA = true;
    }

    public boolean bN() {
        return this.TMeSA;
    }

    public static Class_h_d59300d0 bC(int n, int n2, int n3) {
        return new Class_h_d59300d0(Class_h_rH_195350c3.bktbd, n, n2, n3, '\u0000');
    }

    public char bJ() {
        return this.xQWfQ;
    }

    public static Class_h_d59300d0 bD(char c) {
        return new Class_h_d59300d0(Class_h_rH_195350c3.GxiIK, 0, 0, 0, c);
    }

    public int bG() {
        return this.DBVzo;
    }

    public Class_h_d59300d0 bO(Class_i_a489cc15 class_i_a489cc15) {
        this.jsZzv = class_i_a489cc15;
        return this;
    }

    public Class_az_a4990dcf bM() {
        return this.pHPuk;
    }

    public Class_h_d59300d0 bQ(Class_az_a4990dcf class_az_a4990dcf) {
        this.pHPuk = class_az_a4990dcf;
        return this;
    }

    public int bH() {
        return this.DGQOz;
    }

    public int bI() {
        return this.dTqVH;
    }

    public Class_i_a489cc15 bK() {
        return this.jsZzv;
    }

    public Class_az_a4990dcf bL() {
        return this.fxVCg;
    }

    public Class_h_d59300d0 bP(Class_az_a4990dcf class_az_a4990dcf) {
        this.fxVCg = class_az_a4990dcf;
        return this;
    }
}

