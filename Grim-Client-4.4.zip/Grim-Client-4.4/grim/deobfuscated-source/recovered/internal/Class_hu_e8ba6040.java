/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 */
package recovered.internal;

import net.minecraft.entity.Entity;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_hu_e8ba6040
extends Class_hH_ae8f8f77 {
    private Entity HQCGv;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hu_e8ba6040(Entity entity) {
        this.HQCGv = entity;
    }

    public Entity bdj() {
        return this.HQCGv;
    }
}

