/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.PlayerSkinType
 *  net.minecraft.util.AssetInfo$TextureAsset
 */
package recovered.internal;

import net.minecraft.entity.player.PlayerSkinType;
import net.minecraft.util.AssetInfo;
import recovered.core.NativeLoader;

final class Class_fN_sU_3de48adb
extends Record {
    private final int[] name;
    private final AssetInfo.TextureAsset texture;
    private final PlayerSkinType model;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_fN_sU_3de48adb(int[] nArray, AssetInfo.TextureAsset textureAsset, PlayerSkinType playerSkinType) {
        this.name = nArray;
        this.texture = textureAsset;
        this.model = playerSkinType;
    }

    static {
        NativeLoader.doInit(Class_fN_sU_3de48adb.class);
    }

    public native int[] name();

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    public native PlayerSkinType model();

    public native AssetInfo.TextureAsset texture();
}

