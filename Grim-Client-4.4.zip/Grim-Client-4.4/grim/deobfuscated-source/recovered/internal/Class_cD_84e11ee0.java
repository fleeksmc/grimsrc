/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 */
package recovered.internal;

import com.google.gson.JsonElement;
import java.lang.invoke.MethodHandles;
import java.security.Key;
import java.util.Arrays;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jb_fa6e084e;
import recovered.internal.Class_mr_7eac5189;

public class Class_cD_84e11ee0
extends Class_cB_67aec11c {
    private int taKVz;
    private static final long IeCUk = Class_gb_9d201141.aYR(-2040694330958669505L, -7978183789279250067L, MethodHandles.lookup().lookupClass()).a(28033197927207L);
    private static final long mKlzi;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cD_84e11ee0(Class_mr_7eac5189 class_mr_7eac5189) {
        long l = IeCUk ^ 0x11F064C2F402L;
        super(class_mr_7eac5189);
        this.taKVz = (int)mKlzi;
    }

    public Class_cD_84e11ee0(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = IeCUk ^ 0x2A4C297974F3L;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                long l2 = -6281860261272569937L;
                byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
                mKlzi = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    @Override
    public void SS(JsonElement jsonElement) {
        this.VO(jsonElement.getAsInt());
    }

    @Override
    public void SR(Map<String, Object> map) {
        map.put(Arrays.toString(this.NwlSF), this.taKVz);
    }

    private static MatchException VQ(MatchException matchException) {
        return matchException;
    }

    public String VN() {
        return Class_jb_fa6e084e.byM(this.taKVz);
    }

    public int VP() {
        return this.taKVz;
    }

    public Class_cD_84e11ee0 VO(int n) {
        long l = IeCUk ^ 0x84B540A01ACL;
        boolean bl = Class_cB_67aec11c.Vt();
        Class_cD_84e11ee0 class_cD_84e11ee0 = this;
        if (bl) {
            if (class_cD_84e11ee0.taKVz == n) {
                return this;
            }
            this.taKVz = n;
            this.Vk();
            class_cD_84e11ee0 = this;
        }
        return class_cD_84e11ee0;
    }
}

