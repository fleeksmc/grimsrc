/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;

public final class Class_iL_fafa72df
extends Enum<Class_iL_fafa72df> {
    public static final /* enum */ Class_iL_fafa72df iVyPd;
    public static final /* enum */ Class_iL_fafa72df dPOtD;
    public static final /* enum */ Class_iL_fafa72df GhGqr;
    private static final /* synthetic */ Class_iL_fafa72df[] XwAxA;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = Class_gb_9d201141.aYR(-672615594028914587L, -4954367533172719237L, MethodHandles.lookup().lookupClass()).a(148303297828864L) ^ 0x5AE7F2FF2436L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[3];
        int n = 0;
        String string = "\u00b9Sj\u0002\u001fy\u0087\u0099\b0\u00ac\u00c1Ki\u0012\u00c0\u0094\u0010\u00c3\u00db\u00c4\u001f|\u00a2\u0013\u0001\u0093\u00c888T\u008b\u00b6\u00e5";
        int n2 = "\u00b9Sj\u0002\u001fy\u0087\u0099\b0\u00ac\u00c1Ki\u0012\u00c0\u0094\u0010\u00c3\u00db\u00c4\u001f|\u00a2\u0013\u0001\u0093\u00c888T\u008b\u00b6\u00e5".length();
        int n3 = 8;
        int n4 = -1;
        while (true) {
            int n5 = ++n4;
            byte[] byArray3 = cipher.doFinal(string.substring(n5, n5 + n3).getBytes("ISO-8859-1"));
            stringArray[n++] = Class_iL_fafa72df.btv(byArray3).intern();
            if ((n4 += n3) >= n2) {
                iVyPd = new Class_iL_fafa72df();
                dPOtD = new Class_iL_fafa72df();
                GhGqr = new Class_iL_fafa72df();
                XwAxA = Class_iL_fafa72df.btu();
                return;
            }
            n3 = string.charAt(n4);
        }
    }

    public static Class_iL_fafa72df[] values() {
        return (Class_iL_fafa72df[])XwAxA.clone();
    }

    public static Class_iL_fafa72df valueOf(String string) {
        return Enum.valueOf(Class_iL_fafa72df.class, string);
    }

    private static /* synthetic */ Class_iL_fafa72df[] btu() {
        return new Class_iL_fafa72df[]{iVyPd, dPOtD, GhGqr};
    }

    private static String btv(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }
}

