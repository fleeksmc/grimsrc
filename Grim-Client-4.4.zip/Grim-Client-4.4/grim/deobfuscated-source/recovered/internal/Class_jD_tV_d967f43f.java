/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.model.ShieldEntityModel
 *  net.minecraft.client.util.math.MatrixStack
 *  org.joml.Matrix4f
 */
package recovered.internal;

import net.minecraft.client.render.entity.model.ShieldEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import recovered.internal.Class_mG_52c8d386;

record Class_jD_tV_d967f43f(ShieldEntityModel model, MatrixStack poseStack, Matrix4f modelViewMatrix, int lightCoords, int overlayCoords, Class_mG_52c8d386 color) {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

