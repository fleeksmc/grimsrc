/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.model.EntityModel
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.LivingEntity
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package recovered.internal;

import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import recovered.internal.Class_hH_ae8f8f77;

public abstract class Class_gp_ef102156
extends Class_hH_ae8f8f77 {
    private MatrixStack CgSWX;
    private EntityModel<?> EGzUR;
    private LivingEntity EqBST;
    private float ecyKc;
    private int pCbjK;
    private CallbackInfo zAPsl;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gp_ef102156(MatrixStack matrixStack, EntityModel<?> entityModel, LivingEntity livingEntity, float f, int n, CallbackInfo callbackInfo) {
        this.CgSWX = matrixStack;
        this.EGzUR = entityModel;
        this.EqBST = livingEntity;
        this.ecyKc = f;
        this.pCbjK = n;
        this.zAPsl = callbackInfo;
    }

    public int bbn() {
        return this.pCbjK;
    }

    public LivingEntity bbl() {
        return this.EqBST;
    }

    public CallbackInfo bbo() {
        return this.zAPsl;
    }

    public MatrixStack bbj() {
        return this.CgSWX;
    }

    public EntityModel<?> bbk() {
        return this.EGzUR;
    }

    public float bbm() {
        return this.ecyKc;
    }
}

