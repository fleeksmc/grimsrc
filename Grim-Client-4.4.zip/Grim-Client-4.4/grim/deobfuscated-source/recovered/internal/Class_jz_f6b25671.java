/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.font.TextRenderer
 *  net.minecraft.client.font.TextRenderer$TextLayerType
 *  net.minecraft.client.render.VertexConsumerProvider
 *  net.minecraft.client.util.BufferAllocator
 *  net.minecraft.text.OrderedText
 *  net.minecraft.text.Text
 *  net.minecraft.util.math.ColorHelper
 *  org.joml.Matrix3x2fc
 *  org.joml.Matrix4f
 *  org.jspecify.annotations.Nullable
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.ColorHelper;
import org.joml.Matrix3x2fc;
import org.joml.Matrix4f;
import org.jspecify.annotations.Nullable;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jA_21841da7;
import recovered.internal.Class_jI_616cf0dd;
import recovered.internal.Class_jz_tU_b0c4bef4;

public final class Class_jz_f6b25671 {
    private static final float WVGee = -11000.0f;
    private static final TextRenderer.TextLayerType zrLJA;
    private static @Nullable Class_jA_21841da7 zbhCz;
    private static final long kzcEw;
    private static final long[] onZzt;
    private static final Integer[] ERLZp;
    private static final Map RckkA;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    static {
        kzcEw = Class_gb_9d201141.aYR(-1672401726751479232L, 4739872558628929044L, MethodHandles.lookup().lookupClass()).a(242368169425296L);
        RckkA = new HashMap(13);
        long l = kzcEw ^ 0x177E182572ECL;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[3];
        int n = 0;
        String string = "\u00acjP\u00fej\u00bf\u00bc\t\u00e1\u0000\u0094\u00f9\u008a\u009c\u00b6\u00d1\u00d6\u00cf\u00cc\u00c5a\u001b\u00a1\u00b9";
        int n2 = "\u00acjP\u00fej\u00bf\u00bc\t\u00e1\u0000\u0094\u00f9\u008a\u009c\u00b6\u00d1\u00d6\u00cf\u00cc\u00c5a\u001b\u00a1\u00b9".length();
        int n3 = 0;
        do {
            byte[] byArray3 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
            byte[] byArray4 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray4[0] & 0xFFL) << 56 | ((long)byArray4[1] & 0xFFL) << 48 | ((long)byArray4[2] & 0xFFL) << 40 | ((long)byArray4[3] & 0xFFL) << 32 | ((long)byArray4[4] & 0xFFL) << 24 | ((long)byArray4[5] & 0xFFL) << 16 | ((long)byArray4[6] & 0xFFL) << 8 | (long)byArray4[7] & 0xFFL;
        } while (n3 < n2);
        onZzt = lArray;
        ERLZp = new Integer[3];
        zrLJA = TextRenderer.TextLayerType.SEE_THROUGH;
    }

    public static void bGI(@Nullable Matrix3x2fc matrix3x2fc, TextRenderer textRenderer, @Nullable Text text, float f, float f2, int n, boolean bl, Class_jz_tU_b0c4bef4 class_jz_tU_b0c4bef4) {
        block1: {
            long l = kzcEw ^ 0x50FC0DD3E176L;
            if (text == null || ColorHelper.getAlpha((int)n) == 0) {
                return;
            }
            textRenderer.draw(text, f, f2, n, bl, Class_jz_f6b25671.bGL(matrix3x2fc), (VertexConsumerProvider)Class_jz_f6b25671.bGK().bufferSource(), zrLJA, 0, (int)Class_jz_f6b25671.bGP("p", (int)17418, (long)(0x1F3A6EFE295A220BL ^ l)));
            if (class_jz_tU_b0c4bef4 != Class_jz_tU_b0c4bef4.GgXAb) break block1;
            Class_jz_f6b25671.bGJ();
        }
    }

    public static void bGJ() {
        block3: {
            Class_jA_21841da7 class_jA_21841da7;
            block2: {
                long l = kzcEw ^ 0x69953B50D625L;
                Class_jA_21841da7 class_jA_21841da72 = zbhCz;
                String[] stringArray = Class_jz_tU_b0c4bef4.dqa();
                class_jA_21841da7 = class_jA_21841da72;
                if (stringArray != null) break block2;
                if (class_jA_21841da7 == null) break block3;
                class_jA_21841da7 = class_jA_21841da72;
            }
            class_jA_21841da7.bufferSource().draw();
        }
    }

    public static void bGH(@Nullable Matrix3x2fc matrix3x2fc, TextRenderer textRenderer, @Nullable Text text, float f, float f2, int n, boolean bl) {
        block0: {
            long l = kzcEw ^ 0x7BB427F18C99L;
            String[] stringArray = Class_jz_tU_b0c4bef4.dqa();
            Class_jz_f6b25671.bGI(matrix3x2fc, textRenderer, text, f, f2, n, bl, Class_jz_tU_b0c4bef4.GgXAb);
            String[] stringArray2 = stringArray;
            if (stringArray2 == null) break block0;
            Class_iS_888f260e.bwK("frmyLb");
        }
    }

    private static CallSite bGP(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jz_f6b25671" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public static void bGD(@Nullable Matrix3x2fc matrix3x2fc, TextRenderer textRenderer, @Nullable String string, float f, float f2, int n, boolean bl) {
        Class_jz_f6b25671.bGE(matrix3x2fc, textRenderer, string, f, f2, n, bl, Class_jz_tU_b0c4bef4.GgXAb);
    }

    private static int bGN(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5F61;
        if (ERLZp[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = onZzt[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])RckkA.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    RckkA.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jz_f6b25671", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_jz_f6b25671.ERLZp[n2] = n3;
        }
        return ERLZp[n2];
    }

    private static int bGO(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_jz_f6b25671.bGN(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static MatchException bGM(MatchException matchException) {
        return matchException;
    }

    public static void bGG(@Nullable Matrix3x2fc matrix3x2fc, TextRenderer textRenderer, @Nullable OrderedText orderedText, float f, float f2, int n, boolean bl, Class_jz_tU_b0c4bef4 class_jz_tU_b0c4bef4) {
        block1: {
            long l = kzcEw ^ 0x37E1FB2782B4L;
            if (orderedText == null || ColorHelper.getAlpha((int)n) == 0) {
                return;
            }
            textRenderer.draw(orderedText, f, f2, n, bl, Class_jz_f6b25671.bGL(matrix3x2fc), (VertexConsumerProvider)Class_jz_f6b25671.bGK().bufferSource(), zrLJA, 0, (int)Class_jz_f6b25671.bGP("p", (int)14824, (long)(0x52A13E7C48A13C2AL ^ l)));
            if (class_jz_tU_b0c4bef4 != Class_jz_tU_b0c4bef4.GgXAb) break block1;
            Class_jz_f6b25671.bGJ();
        }
    }

    /*
     * Unable to fully structure code
     */
    private static Matrix4f bGL(@Nullable Matrix3x2fc var0) {
        var1_1 = Class_jz_f6b25671.kzcEw ^ 73393792341596L;
        var3_2 = Class_jz_tU_b0c4bef4.dqa();
        v0 = var0;
        if (var3_2 != null) ** GOTO lbl7
        if (v0 != null) {
            v0 = var0;
lbl7:
            // 2 sources

            v1 = Class_jI_616cf0dd.bIl(v0);
        } else {
            v1 = new Matrix4f();
        }
        var4_3 = v1;
        return var4_3.translate(0.0f, 0.0f, -11000.0f);
    }

    public static void bGF(@Nullable Matrix3x2fc matrix3x2fc, TextRenderer textRenderer, @Nullable OrderedText orderedText, float f, float f2, int n, boolean bl) {
        block0: {
            long l = kzcEw ^ 0x572286CDB98CL;
            String[] stringArray = Class_jz_tU_b0c4bef4.dqa();
            Class_jz_f6b25671.bGG(matrix3x2fc, textRenderer, orderedText, f, f2, n, bl, Class_jz_tU_b0c4bef4.GgXAb);
            String[] stringArray2 = stringArray;
            if (Class_iS_888f260e.bwL() != null) break block0;
            Class_jz_tU_b0c4bef4.dpZ(new String[2]);
        }
    }

    public static void bGE(@Nullable Matrix3x2fc matrix3x2fc, TextRenderer textRenderer, @Nullable String string, float f, float f2, int n, boolean bl, Class_jz_tU_b0c4bef4 class_jz_tU_b0c4bef4) {
        block6: {
            long l;
            block5: {
                block3: {
                    int n2;
                    block4: {
                        String string2;
                        String[] stringArray;
                        block2: {
                            l = kzcEw ^ 0x1ACDDFE0B4CFL;
                            stringArray = Class_jz_tU_b0c4bef4.dqa();
                            string2 = string;
                            if (stringArray != null) break block2;
                            if (string2 == null) break block3;
                            string2 = string;
                        }
                        n2 = string2.isEmpty();
                        if (stringArray != null) break block4;
                        if (n2 != 0) break block3;
                        n2 = ColorHelper.getAlpha((int)n);
                    }
                    if (n2 != 0) break block5;
                }
                return;
            }
            textRenderer.draw(string, f, f2, n, bl, Class_jz_f6b25671.bGL(matrix3x2fc), (VertexConsumerProvider)Class_jz_f6b25671.bGK().bufferSource(), zrLJA, 0, (int)Class_jz_f6b25671.bGP("p", (int)14824, (long)(0x52A113506C660A51L ^ l)));
            if (class_jz_tU_b0c4bef4 != Class_jz_tU_b0c4bef4.GgXAb) break block6;
            Class_jz_f6b25671.bGJ();
        }
    }

    private static Class_jA_21841da7 bGK() {
        long l = kzcEw ^ 0x1CB29CCE9891L;
        String[] stringArray = Class_jz_tU_b0c4bef4.dqa();
        Class_jA_21841da7 class_jA_21841da7 = zbhCz;
        if (stringArray == null) {
            if (class_jA_21841da7 == null) {
                zbhCz = new Class_jA_21841da7(VertexConsumerProvider.immediate((BufferAllocator)new BufferAllocator((int)Class_jz_f6b25671.bGP("p", (int)3368, (long)(0x74FA28ECF97892CCL ^ l)))));
            }
            class_jA_21841da7 = zbhCz;
        }
        return class_jA_21841da7;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jz_f6b25671.class, "bGO", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

