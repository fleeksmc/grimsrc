/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import recovered.core.NativeLoader;
import recovered.internal.Class_aD_d91dd0e1;
import recovered.internal.Class_bj_953e4f00;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_iI_6ad6be63;
import recovered.internal.Class_iK_af06a2a2;
import recovered.internal.Class_iL_fafa72df;
import recovered.internal.Class_iM_910cda2e;
import recovered.internal.Class_iN_238b4668;
import recovered.internal.Class_iO_e7bfa49a;
import recovered.internal.Class_iP_5c78454e;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_iu_bf2db566;
import recovered.internal.Class_iv_eaeaeb9a;
import recovered.internal.Class_ry_a5fa9042;

public class Class_iQ_3442de41 {
    private final Class_iN_238b4668 qxcSr;
    private final String CUNHl;
    private final Class_iP_5c78454e twrIE;
    private final Class_iK_af06a2a2 jcfyd;
    private final Class_iv_eaeaeb9a uWkVQ;
    private boolean nVklG;
    private final CompletableFuture<Void> qcuam;
    private static boolean rNaCY;
    private static long MrvMF;
    private static String[] oACCP;
    private static String[] BiDOI;
    private static Map AEinN;
    private static long[] VAzWW;
    private static Integer[] iqBhb;
    private static Map iFkNo;
    private static long QWoXv;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native /* synthetic */ Class_iM_910cda2e bvU(Class_iM_910cda2e var0, Class_iu_bf2db566 var1);

    private static native /* synthetic */ Class_iM_910cda2e bvH(Class_iM_910cda2e var0, Class_iu_bf2db566 var1);

    private native /* synthetic */ CompletionStage bvM(String var1, Class_iO_e7bfa49a var2);

    private static native /* synthetic */ List bvY(List var0, Void var1);

    private native /* synthetic */ Boolean bvQ(Class_iu_bf2db566 var1);

    private native /* synthetic */ void bvJ(Class_iM_910cda2e var1);

    private native /* synthetic */ void bvP(Class_iM_910cda2e var1);

    private static native /* synthetic */ List bvV(Throwable var0);

    private native /* synthetic */ CompletionStage bvX(List var1);

    public static native void bwb(boolean var0);

    private native /* synthetic */ void bvC(Class_iM_910cda2e var1);

    private native /* synthetic */ CompletionStage bvE(Class_iM_910cda2e var1);

    private native /* synthetic */ Class_iO_e7bfa49a bvO(Class_iM_910cda2e var1);

    private native /* synthetic */ CompletionStage bvG(Class_iM_910cda2e var1);

    private static native /* synthetic */ void bvW();

    private static native int bwj(int var0, long var1);

    private static native String bwg(int var0, long var1);

    private native /* synthetic */ Class_iO_e7bfa49a bvN(Class_iO_e7bfa49a var1, Class_iu_bf2db566 var2);

    private native /* synthetic */ Class_iM_910cda2e bvK(Class_iM_910cda2e var1);

    private static native Object bwh(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native /* synthetic */ Boolean bvB(Class_iM_910cda2e var1, Class_iu_bf2db566 var2);

    private native /* synthetic */ Class_iM_910cda2e bvI(Class_iM_910cda2e var1);

    private native /* synthetic */ CompletionStage bvT(Class_iM_910cda2e var1);

    private native /* synthetic */ CompletionStage bvZ(List var1);

    private static native String bwf(byte[] var0);

    public static native boolean bwc();

    private native /* synthetic */ void bvL(Class_iM_910cda2e var1);

    private native /* synthetic */ Class_iM_910cda2e bvR(Class_iM_910cda2e var1);

    private native /* synthetic */ void bwa(List var1, CompletableFuture var2);

    private static native int bwk(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite bwl(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native /* synthetic */ void bvS(Class_iM_910cda2e var1);

    private native /* synthetic */ CompletionStage bvD(String var1, Class_iu_bf2db566 var2);

    private static native /* synthetic */ Class_iM_910cda2e bvF(Class_iM_910cda2e var0, Class_iu_bf2db566 var1);

    public Class_iQ_3442de41(Class_iK_af06a2a2 class_iK_af06a2a2, Class_iv_eaeaeb9a class_iv_eaeaeb9a) {
        long l = MrvMF ^ 0x25D15DE99C42L;
        boolean bl = Class_iQ_3442de41.bwd();
        this.CUNHl = Class_iQ_3442de41.bwi("c", (int)31667, (long)(0x55C7F0A28B33660DL ^ l));
        boolean bl2 = bl;
        try {
            this.nVklG = false;
            this.qcuam = new CompletableFuture();
            this.jcfyd = class_iK_af06a2a2;
            this.uWkVQ = class_iv_eaeaeb9a;
            this.twrIE = new Class_iP_5c78454e();
            this.qxcSr = new Class_iN_238b4668(Class_iI_6ad6be63.bsC(Class_ry_a5fa9042.dkB().dkP()));
            class_iv_eaeaeb9a.bnI(this::bvk);
            if (!bl2) {
                Class_iS_888f260e.bwK("DU1jrc");
            }
        }
        catch (MatchException matchException) {
            throw Class_iQ_3442de41.bwe(matchException);
        }
    }

    static {
        NativeLoader.doInit(Class_iQ_3442de41.class);
        Class_iQ_3442de41._51823ea6c52cc2438437060d0f1dc7a6();
    }

    private native /* synthetic */ Boolean bvA(Class_iu_bf2db566 var1);

    private native /* synthetic */ void bvz(Class_iM_910cda2e var1, CompletableFuture var2);

    public native Class_iP_5c78454e bvp();

    public native Class_iK_af06a2a2 bvq();

    public native Class_iv_eaeaeb9a bvr();

    public native boolean bvs();

    public native Class_iN_238b4668 bvn();

    public native void buX(int[] var1, int[] var2, Class_iL_fafa72df var3);

    private static native /* synthetic */ boolean bvu(Class_bj_953e4f00 var0, Class_bj_953e4f00 var1);

    private static native /* synthetic */ void bvv(Class_aD_d91dd0e1 var0, Class_bj_953e4f00 var1);

    private static native CallSite bwi(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native /* synthetic */ void bvw(List var1, Throwable var2);

    private native /* synthetic */ CompletionStage bvy(Class_iM_910cda2e var1);

    public native void bvm();

    public native String bvo();

    public native CompletableFuture<Class_iM_910cda2e> bvc(String var1);

    public native CompletableFuture<Class_iM_910cda2e> bva(String var1, int[] var2, int[] var3, Class_iL_fafa72df var4, boolean var5);

    public native CompletableFuture<Boolean> bvf(Class_iM_910cda2e var1);

    public static native boolean bwd();

    private native void bvk();

    public native CompletableFuture<Class_iO_e7bfa49a> buZ(String var1);

    public native CompletableFuture<Boolean> bvg();

    public native CompletableFuture<Boolean> buY(String var1);

    private native void bvi(List<Class_iO_e7bfa49a> var1);

    public native CompletableFuture<Void> bvt();

    private static native /* synthetic */ Void bvx(Throwable var0);

    public native CompletableFuture<List<Class_iO_e7bfa49a>> buW();

    public native CompletableFuture<Class_iM_910cda2e> bvd(String var1);

    private native void bvj();

    public native CompletableFuture<Void> buS();

    public native void buT();

    public native boolean buU(Class_cB_67aec11c var1);

    public native boolean buV(Class_iS_888f260e var1, Class_cB_67aec11c var2);

    private static native MatchException bwe(MatchException var0);

    public native CompletableFuture<Class_iM_910cda2e> bvb(String var1);

    public native CompletableFuture<Class_iM_910cda2e> bve(String var1);

    private native CompletableFuture<Void> bvh();

    private native void bvl(Class_iM_910cda2e var1);

    private static native void _51823ea6c52cc2438437060d0f1dc7a6();
}

