/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

class Class_jl_tN_0955f362 {
    static int[] stCYF;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_jl_tN_0955f362.class);
        Class_jl_tN_0955f362._7f7fa61c37be324bb05a66ae5602bbda();
    }

    private static native void _7f7fa61c37be324bb05a66ae5602bbda();
}

