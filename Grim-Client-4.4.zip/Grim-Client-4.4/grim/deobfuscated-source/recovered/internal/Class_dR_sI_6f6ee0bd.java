/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

public final class Class_dR_sI_6f6ee0bd
extends Enum<Class_dR_sI_6f6ee0bd> {
    public static /* enum */ Class_dR_sI_6f6ee0bd qWbQG;
    public static /* enum */ Class_dR_sI_6f6ee0bd ZfrpN;
    public static /* enum */ Class_dR_sI_6f6ee0bd cgVae;
    public static /* enum */ Class_dR_sI_6f6ee0bd UPeYL;
    private static Class_dR_sI_6f6ee0bd[] czzlL;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native void _9e3b0824c1154d0aa9cc630f3c001705();

    static {
        NativeLoader.doInit(Class_dR_sI_6f6ee0bd.class);
        Class_dR_sI_6f6ee0bd._9e3b0824c1154d0aa9cc630f3c001705();
    }

    public static native Class_dR_sI_6f6ee0bd[] values();

    public static native Class_dR_sI_6f6ee0bd valueOf(String var0);

    private static native Class_dR_sI_6f6ee0bd[] doP();

    private static native String doQ(byte[] var0);
}

