/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.model.EntityModel
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.LivingEntity
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package recovered.internal;

import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import recovered.internal.Class_gp_ef102156;

public class Class_gp_sZ_0620c52a
extends Class_gp_ef102156 {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gp_sZ_0620c52a(MatrixStack matrixStack, EntityModel<?> entityModel, LivingEntity livingEntity, float f, int n, CallbackInfo callbackInfo) {
        super(matrixStack, entityModel, livingEntity, f, n, callbackInfo);
    }
}

