/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  org.joml.Matrix3x2f
 *  org.joml.Matrix3x2fc
 *  org.jspecify.annotations.Nullable
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.item.ItemStack;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fc;
import org.jspecify.annotations.Nullable;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ju_e398051e;
import recovered.internal.Class_ju_tT_d469d25e;
import recovered.internal.Class_lB_d4ece713;
import recovered.internal.Class_lF_27593463;
import recovered.internal.Class_lJ_e4c3455b;
import recovered.internal.Class_lK_10adb522;
import recovered.internal.Class_lN_5af116ef;

abstract class Class_jy_33e84da2<T extends Class_jy_33e84da2<T>>
implements Class_lK_10adb522,
Class_lJ_e4c3455b<T> {
    private static final Class_lN_5af116ef wyYmy;
    protected final Matrix3x2fc wvKbm;
    protected final ItemStack qeMTM;
    protected final float svsZw;
    protected final float zXQoo;
    protected Class_ju_tT_d469d25e qxFcM;
    private static final long NBNQu;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    @Override
    public Class_lN_5af116ef batchKey() {
        long l = NBNQu ^ 0x5B003FCE214BL;
        return this.qxFcM == Class_ju_tT_d469d25e.IHKNQ ? wyYmy : Class_lN_5af116ef.immediate();
    }

    protected Class_jy_33e84da2(@Nullable Matrix3x2fc matrix3x2fc, ItemStack itemStack, float f, float f2, Class_ju_tT_d469d25e class_ju_tT_d469d25e) {
        block1: {
            long l = NBNQu ^ 0x51FA0333682FL;
            String string = Class_ju_e398051e.bGn();
            String string2 = string;
            this.wvKbm = matrix3x2fc == null ? null : new Matrix3x2f(matrix3x2fc);
            this.qeMTM = itemStack.copy();
            this.svsZw = f;
            this.zXQoo = f2;
            Class_ju_tT_d469d25e class_ju_tT_d469d25e2 = class_ju_tT_d469d25e;
            if (string2 != null) {
                class_ju_tT_d469d25e2 = this.qxFcM = class_ju_tT_d469d25e2 == null ? Class_ju_tT_d469d25e.yDoOO : class_ju_tT_d469d25e;
            }
            if (string2 != null) break block1;
            Class_iS_888f260e.bwK("d1G9Kc");
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        NBNQu = Class_gb_9d201141.aYR(7289900486859939433L, 933198282271656753L, MethodHandles.lookup().lookupClass()).a(110455426521662L);
        long l = NBNQu ^ 0x41533ADDB5F5L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                byte[] byArray3 = cipher.doFinal("S\u0001U\u0090\u0085\u0011k\u00a6Zb\u008c\u008aF\u00b3'\r4\u00daSis\u009f\u00b8\u00c5".getBytes("ISO-8859-1"));
                String string = Class_jy_33e84da2.bGC(byArray3).intern();
                wyYmy = Class_lN_5af116ef.of(string, null, Class_lB_d4ece713.xCeuB, (Object)Class_ju_tT_d469d25e.IHKNQ);
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    @Override
    public void execute() {
        this.renderIntoBatch();
    }

    @Override
    public void endBatch() {
        block0: {
            long l = NBNQu ^ 0x7E4222B92DD5L;
            if (this.qxFcM != Class_ju_tT_d469d25e.IHKNQ) break block0;
            Class_ju_e398051e.bFV();
        }
    }

    public T bGx() {
        return this.bGy(Class_ju_tT_d469d25e.yDoOO);
    }

    public T bGy(Class_ju_tT_d469d25e class_ju_tT_d469d25e) {
        long l = NBNQu ^ 0x2A03C1A13BB4L;
        String string = Class_ju_e398051e.bGn();
        Class_ju_tT_d469d25e class_ju_tT_d469d25e2 = class_ju_tT_d469d25e;
        if (string != null) {
            class_ju_tT_d469d25e2 = class_ju_tT_d469d25e2 == null ? Class_ju_tT_d469d25e.yDoOO : class_ju_tT_d469d25e;
        }
        this.qxFcM = class_ju_tT_d469d25e2;
        return this.bGA();
    }

    private static MatchException bGB(MatchException matchException) {
        return matchException;
    }

    private T bGA() {
        return (T)this;
    }

    private static String bGC(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    @Override
    public void beginBatch() {
    }

    public T bGw() {
        return this.bGy(Class_ju_tT_d469d25e.IHKNQ);
    }

    public T bGv() {
        long l = NBNQu ^ 0x33DDEBE4B103L;
        String string = Class_ju_e398051e.bGn();
        Class_jy_33e84da2<T> class_jy_33e84da2 = this;
        if (string != null) {
            if (!class_jy_33e84da2.qeMTM.isEmpty()) {
                Class_lF_27593463.cfA(this);
            }
            class_jy_33e84da2 = this.bGA();
        }
        return (T)class_jy_33e84da2;
    }
}

