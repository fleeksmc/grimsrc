/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import recovered.core.NativeLoader;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ic_fa4de564;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_ih_ba1deb13;
import recovered.internal.Class_ij_d7bf2301;
import recovered.internal.Class_iu_bf2db566;
import recovered.internal.Class_iv_eaeaeb9a;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rk_bf8630d1;

public class Class_ii_9b427eda {
    private Class_ig_ca326427 RsLBo;
    private final Class_ih_ba1deb13 nYBiY;
    private final Class_ic_fa4de564 PtZvg;
    private final Class_iv_eaeaeb9a xYnIj;
    private final String jdaOd;
    private boolean ITejf;
    private final Class_rk_bf8630d1 lezXT;
    private final Class_rk_bf8630d1 RqSHC;
    private final Class_ri_288534d5 mifaU;
    private final Class_ri_288534d5 JzsKI;
    private final Class_ri_288534d5 FgUUQ;
    private final Class_ri_288534d5 OByKM;
    private final Class_ri_288534d5 xgjUc;
    private final Class_ri_288534d5 NmeWq;
    private final Class_ri_288534d5 HTMIp;
    private static boolean kEnHW;
    private static long AyPUv;
    private static String[] tbVJs;
    private static String[] Ykuvx;
    private static Map wRhAr;
    private static long[] JvxNu;
    private static Integer[] IzKCU;
    private static Map thTcJ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_mG_52c8d386 bjb() {
        return this.mifaU.dfT(this.RsLBo.bio());
    }

    public Class_ii_9b427eda(Class_ic_fa4de564 class_ic_fa4de564, Class_iv_eaeaeb9a class_iv_eaeaeb9a) {
        long l = AyPUv ^ 0x549B66AA2FD9L;
        this.RsLBo = Class_ig_ca326427.PtFoz;
        this.jdaOd = Class_ii_9b427eda.bjZ("w", (int)6487, (long)(0x7DC82F167070D110L ^ l));
        this.ITejf = false;
        this.lezXT = new Class_rk_bf8630d1((int)Class_ii_9b427eda.bkc("e", (int)12150, (long)(0x2BA6FE3F9537B804L ^ l)), this.RsLBo.bix().bib());
        this.RqSHC = new Class_rk_bf8630d1((int)Class_ii_9b427eda.bkc("e", (int)29753, (long)(0x6ABF5BDC261BE34AL ^ l)), this.RsLBo.bix().bic());
        this.mifaU = new Class_ri_288534d5((int)Class_ii_9b427eda.bkc("e", (int)2103, (long)(0x51A7CC3614BF1F47L ^ l)), this.RsLBo.bio());
        this.JzsKI = new Class_ri_288534d5((int)Class_ii_9b427eda.bkc("e", (int)31157, (long)(0xECC26E358166EC0L ^ l)), this.RsLBo.bip());
        boolean bl = Class_ii_9b427eda.bjT();
        try {
            this.FgUUQ = new Class_ri_288534d5((int)Class_ii_9b427eda.bkc("e", (int)31157, (long)(0xECC26E358166EC0L ^ l)), this.RsLBo.biq());
            this.OByKM = new Class_ri_288534d5((int)Class_ii_9b427eda.bkc("e", (int)31157, (long)(0xECC26E358166EC0L ^ l)), this.RsLBo.bir());
            this.xgjUc = new Class_ri_288534d5((int)Class_ii_9b427eda.bkc("e", (int)31157, (long)(0xECC26E358166EC0L ^ l)), this.RsLBo.bis());
            this.NmeWq = new Class_ri_288534d5((int)Class_ii_9b427eda.bkc("e", (int)31157, (long)(0xECC26E358166EC0L ^ l)), this.RsLBo.biy().bhe());
            this.HTMIp = new Class_ri_288534d5((int)Class_ii_9b427eda.bkc("e", (int)31157, (long)(0xECC26E358166EC0L ^ l)), this.RsLBo.biy().bhf());
            this.PtZvg = class_ic_fa4de564;
            this.xYnIj = class_iv_eaeaeb9a;
            this.nYBiY = new Class_ih_ba1deb13();
            class_iv_eaeaeb9a.bnI(this::bja);
            if (!bl) {
                Class_iS_888f260e.bwK("noa3nc");
            }
        }
        catch (MatchException matchException) {
            throw Class_ii_9b427eda.bjV(matchException);
        }
    }

    static {
        NativeLoader.doInit(Class_ii_9b427eda.class);
        Class_ii_9b427eda._5923f05a2a1794b3930e99fd0310167f();
    }

    public Class_mG_52c8d386 bjp() {
        return this.HTMIp.dfT(this.RsLBo.biy().bhf());
    }

    public Class_mG_52c8d386 bjd() {
        return this.FgUUQ.dfT(this.RsLBo.biq());
    }

    public native void bjq(Class_ig_ca326427 var1);

    private static native int bkb(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public native Class_ig_ca326427 bjG();

    public native CompletableFuture<Boolean> biV(String var1);

    public native CompletableFuture<Boolean> biW(Class_ig_ca326427 var1);

    private native void biX(List<Class_ij_d7bf2301> var1);

    private native void biY();

    private static native MatchException bjV(MatchException var0);

    public static native boolean bjT();

    private static native CallSite bjZ(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native CallSite bkc(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native void bja();

    public native CompletableFuture<List<Class_ij_d7bf2301>> biS();

    public native void biT(Class_ig_ca326427 var1);

    public native CompletableFuture<Boolean> biU(String var1);

    private native void biZ();

    public float bjm() {
        return this.RsLBo.biy().bhk();
    }

    public float bjk() {
        return this.RsLBo.biy().bhi();
    }

    public Class_mG_52c8d386 bjf() {
        return this.xgjUc.dfT(this.RsLBo.bis());
    }

    public Class_mG_52c8d386 bjn() {
        return this.NmeWq.dfT(this.RsLBo.biy().bhe());
    }

    public native void bjr(boolean var1);

    public native boolean bjw();

    public native Class_rk_bf8630d1 bjx();

    private native /* synthetic */ Boolean bjM(String var1, Class_iu_bf2db566 var2);

    public float bjj() {
        return this.RsLBo.biy().bhh();
    }

    private native /* synthetic */ CompletionStage bjN(Class_ij_d7bf2301 var1);

    public float bjg() {
        return this.lezXT.dhd(this.RsLBo.bix().bib());
    }

    public native Class_iv_eaeaeb9a bju();

    private static native /* synthetic */ Class_ij_d7bf2301 bjO(Class_ij_d7bf2301 var0, Class_iu_bf2db566 var1);

    public native Class_ic_fa4de564 bjt();

    public native Class_ri_288534d5 bjF();

    private static native /* synthetic */ List bjP(Throwable var0);

    public float bjl() {
        return this.RsLBo.biy().bhj();
    }

    public native Class_ri_288534d5 bjA();

    private native /* synthetic */ void bjL(Class_ij_d7bf2301 var1);

    public float bjo() {
        return this.RsLBo.biy().bhl();
    }

    public native Class_ri_288534d5 bjC();

    public native Class_rk_bf8630d1 bjy();

    private native /* synthetic */ Boolean bjI(Class_iu_bf2db566 var1);

    private static native /* synthetic */ void bjQ();

    private native /* synthetic */ List bjR(List var1);

    public static native void bjS(boolean var0);

    public native String bjv();

    public static native boolean bjU();

    public float bjh() {
        return this.RqSHC.dhd(this.RsLBo.bix().bic());
    }

    private static native String bjW(byte[] var0);

    private static native String bjX(int var0, long var1);

    private static native Object bjY(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public Class_mG_52c8d386 bjc() {
        return this.JzsKI.dfT(this.RsLBo.bip());
    }

    public float bji() {
        return this.RsLBo.biy().bhg();
    }

    public native Class_ri_288534d5 bjD();

    public native Class_ri_288534d5 bjB();

    public native Class_ri_288534d5 bjz();

    public Class_mG_52c8d386 bje() {
        return this.OByKM.dfT(this.RsLBo.bir());
    }

    public native Class_ih_ba1deb13 bjs();

    private native /* synthetic */ Boolean bjH(Class_ig_ca326427 var1, Class_iu_bf2db566 var2);

    private native /* synthetic */ Class_ij_d7bf2301 bjK(Class_ij_d7bf2301 var1);

    public native Class_ri_288534d5 bjE();

    private native /* synthetic */ CompletionStage bjJ(String var1, Class_ij_d7bf2301 var2);

    private static native int bka(int var0, long var1);

    private static native void _5923f05a2a1794b3930e99fd0310167f();
}

