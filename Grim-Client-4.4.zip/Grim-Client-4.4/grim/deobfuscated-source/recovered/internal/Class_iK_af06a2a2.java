/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import recovered.internal.Class_iL_fafa72df;
import recovered.internal.Class_iM_910cda2e;
import recovered.internal.Class_iO_e7bfa49a;
import recovered.internal.Class_iu_bf2db566;

public interface Class_iK_af06a2a2 {
    public CompletableFuture<Class_iM_910cda2e> likeConfig(String var1);

    public CompletableFuture<Class_iu_bf2db566> loadConfig(Class_iM_910cda2e var1);

    public CompletableFuture<Class_iu_bf2db566> importConfig(String var1);

    public CompletableFuture<Class_iu_bf2db566> deleteConfig(String var1);

    public CompletableFuture<Class_iM_910cda2e> dislikeConfig(String var1);

    public CompletableFuture<Class_iM_910cda2e> createConfig(int[] var1, int[] var2, Class_iL_fafa72df var3);

    public CompletableFuture<Class_iM_910cda2e> downloadConfig(String var1);

    public CompletableFuture<Class_iu_bf2db566> resetLoadedConfig();

    public CompletableFuture<List<Class_iO_e7bfa49a>> fetchMetadata();

    public CompletableFuture<Class_iM_910cda2e> updateConfig(String var1, int[] var2, int[] var3, Class_iL_fafa72df var4, boolean var5);

    public CompletableFuture<Class_iu_bf2db566> favouriteConfig(String var1);
}

