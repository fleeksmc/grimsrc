/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package recovered.internal;

import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_im_0fce3469;
import recovered.internal.Class_in_57efefb0;
import recovered.internal.Class_io_666f07e0;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rp_2e61368f;

public class Class_ir_8e0d90e0
extends Class_in_57efefb0
implements Class_rp_2e61368f {
    String MJxSh;
    String JrITo;
    private static long CNpfA;
    private static String[] bQYGM;
    private static String[] sbTyw;
    private static Map iJBZj;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native MatchException bmE(MatchException var0);

    public native Class_ir_8e0d90e0 bmC(String var1);

    private static native String bmF(byte[] var0);

    private static native Object bmH(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native String bmG(int var0, long var1);

    public native String bmB();

    private static native CallSite bmI(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native Class_ir_8e0d90e0 bmD(String var1);

    public Class_ir_8e0d90e0() {
    }

    public Class_ir_8e0d90e0(String string, String string2, int[] nArray, Class_io_666f07e0 class_io_666f07e0, Class_io_666f07e0 class_io_666f07e02, boolean bl, float f, boolean bl2, boolean bl3, boolean bl4, Class_im_0fce3469 class_im_0fce3469, Class_im_0fce3469 class_im_0fce34692) {
        long l = CNpfA ^ 0x1FCE3A792842L;
        super(nArray, class_io_666f07e0, class_io_666f07e02, bl, f, bl2, bl3, bl4, class_im_0fce3469, class_im_0fce34692);
        this.MJxSh = string;
        String[] stringArray = Class_rj_b691f4f7.dha();
        try {
            this.JrITo = string2;
            if (stringArray == null) {
                Class_iS_888f260e.bwK("s64be");
            }
        }
        catch (MatchException matchException) {
            throw Class_ir_8e0d90e0.bmE(matchException);
        }
    }

    static {
        NativeLoader.doInit(Class_ir_8e0d90e0.class);
        Class_ir_8e0d90e0._746b4bb81a153ba095982d63ae6cba3f();
    }

    @Override
    public native void fromJson(JsonObject var1);

    @Override
    public native JsonObject toJson();

    @Override
    public native boolean bkP();

    @Override
    public native String bkO();

    private static native void _746b4bb81a153ba095982d63ae6cba3f();
}

