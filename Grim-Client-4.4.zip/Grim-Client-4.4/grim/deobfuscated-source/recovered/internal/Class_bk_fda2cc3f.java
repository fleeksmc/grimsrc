/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.ModuleBase;
import recovered.core.NativeLoader;
import recovered.internal.Class_ak_2ff604c7;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bh_f2f50881;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bk_fda2cc3f
extends Class_ak_2ff604c7<Class_cJ_2ae1a557> {
    private final ModuleBase cpUzX;
    private Class_bh_f2f50881 HjHnW;
    protected final Class_rk_bf8630d1 FDvbN;
    private static long KbsrP;
    private static long[] ZLDda;
    private static Integer[] HlkAB;
    private static Map pwxhd;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bk_fda2cc3f(ModuleBase moduleBase, Class_az_a4990dcf class_az_a4990dcf) {
        long l = KbsrP ^ 0x113C1EBEC7C7L;
        int[] nArray = new int[Class_bk_fda2cc3f.Eo("c", (int)21192, (long)(0x3B6FEDF90971469DL ^ l))];
        nArray[0] = (int)Class_bk_fda2cc3f.Eo("c", (int)21000, (long)(0x6E006B63481FC65CL ^ l));
        nArray[1] = (int)Class_bk_fda2cc3f.Eo("c", (int)24133, (long)(0x6EBBA98E3F7A4A13L ^ l));
        nArray[2] = (int)Class_bk_fda2cc3f.Eo("c", (int)9192, (long)(0x5B68F787812A37B4L ^ l));
        nArray[3] = (int)Class_bk_fda2cc3f.Eo("c", (int)11146, (long)(0x667D9AA533583FD8L ^ l));
        nArray[4] = (int)Class_bk_fda2cc3f.Eo("c", (int)12436, (long)(0x920546EAB2CA4C9L ^ l));
        nArray[5] = (int)Class_bk_fda2cc3f.Eo("c", (int)29828, (long)(0x72A14DB8197960D5L ^ l));
        nArray[Class_bk_fda2cc3f.Eo("c", (int)7453, (long)(0xDE9E924FDD894EL ^ l))] = (int)Class_bk_fda2cc3f.Eo("c", (int)12618, (long)(0x1C16F907738A251DL ^ l));
        super(new Class_cJ_2ae1a557(Class_mr_7eac5189.clS(nArray)).WE(true), class_az_a4990dcf);
        this.FDvbN = new Class_rk_bf8630d1((int)Class_bk_fda2cc3f.Eo("c", (int)2036, (long)(0x709A169B606C93A4L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.cpUzX = moduleBase;
    }

    static {
        NativeLoader.doInit(Class_bk_fda2cc3f.class);
        Class_bk_fda2cc3f._ecdbab0718f5e953ae4b668ba3bb566a();
    }

    @Override
    public native float dn();

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native void dY();

    private static native void _ecdbab0718f5e953ae4b668ba3bb566a();

    private static native CallSite Eo(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native int Em(int var0, long var1);

    private static native int En(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native MatchException El(MatchException var0);
}

