/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.ClientConnection
 *  net.minecraft.network.listener.PacketListener
 *  net.minecraft.network.packet.Packet
 */
package recovered.internal;

import net.minecraft.network.ClientConnection;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import recovered.internal.Class_gL_cf24808b;

public class Class_gL_tj_d4448c52
extends Class_gL_cf24808b {
    private final ClientConnection EkqAB;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public <T extends PacketListener> Class_gL_tj_d4448c52(Packet<T> packet, ClientConnection clientConnection) {
        super(packet);
        this.EkqAB = clientConnection;
    }

    public ClientConnection dpm() {
        return this.EkqAB;
    }
}

