/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_hX_15329af5;
import recovered.internal.Class_hZ_076851ce;

public class Class_hQ_b8da11f4 {
    private static long VMLwp;
    private static String bidOL;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_hQ_b8da11f4.class);
        Class_hQ_b8da11f4._540e4eccbd8d85cbde722c1236da0720();
    }

    private static native void _540e4eccbd8d85cbde722c1236da0720();

    private static native String beM(byte[] var0);

    private static native /* synthetic */ void beL(Class_hX_15329af5 var0);

    public native Class_hZ_076851ce beK();
}

