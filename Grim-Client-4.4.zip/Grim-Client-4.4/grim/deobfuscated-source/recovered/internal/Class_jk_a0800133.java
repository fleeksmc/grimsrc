/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mZ_07f59a29;

public class Class_jk_a0800133 {
    private static final long zumTM;
    public static Class_mG_52c8d386 tSRYI;
    public static Class_mG_52c8d386 mPXGi;
    public static Class_mG_52c8d386 jEkxo;
    private static final long khXTS;
    private static final long[] HAejn;
    private static final Integer[] kyDxg;
    private static final Map kgjMD;
    private static final long[] TscJs;
    private static final Long[] pPJRe;
    private static final Map kFdBt;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Unable to fully structure code
     */
    static {
        block14: {
            block13: {
                block12: {
                    block11: {
                        Class_jk_a0800133.khXTS = Class_gb_9d201141.aYR(2329779219362319924L, 2320449836084100065L, MethodHandles.lookup().lookupClass()).a(162797656028928L);
                        var22 = Class_jk_a0800133.khXTS ^ 113185465516712L;
                        Class_jk_a0800133.kgjMD = new HashMap<K, V>(13);
                        var11_1 = Cipher.getInstance("DES/CBC/NoPadding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var22 >>> 56);
                        for (var12_2 = 1; var12_2 < 8; ++var12_2) {
                            v2 = v2;
                            v2[var12_2] = (byte)(var22 << var12_2 * 8 >>> 56);
                        }
                        var11_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var17_3 = new long[33];
                        var14_4 = 0;
                        var15_5 = "tc\u00ad\u0005\u00d7\u00bat\u00b7\r\u0081k\u0083'\u009f\u00e4\u00cc\u00a79\u008fm/\u0083\u0087\r\u00cey\u001d\u00dc1\u00e13\u00d1\u00c6\u0094\u00897\u0006\u00903V\u001e\u001b\u0006\u0098~\u00a4\\\u0097\u000f\u008d\u00be\u00ab,\u00afVdA\u00d3\u00d9\u00bbU\u0089\t\u00c9\u0006M\u0091\u00dc\u00d4A\u00a7\u00bc}\u00e4:\u00dc\u00ec\t\u000b,\u00e0\u00fa\u00f1\u00d7\u0085F\u00b0\u00afh<k\u00b7v;\u00e3\u00a4\u0082By\u00ef%\u00c4$\u0003|\u008c@\r\u00d5B\u00ee\u0096\u00f0Q\u00ec\u00e2g\u00e6v\u00cd\u00e5\u00e92\n\u00bdJ\u0087\u00d6:6\u00bd8{\u0089V\u00e3\u00b4\u000e\u00d6\u00d6)=\u00f9\u00aa+\u00dd\u00be\u00e5\u00e7W-\u00fe\u0014)?\u00eb\u0012\u00a6J\u0089\u001aM\u00acWl\u00d6\u00cb\u00a8\u009e:\u008a\u00b76\u00a0p\u00ed\u0093\u00f7\u009f\u00bc\u00ab\u0088u\"\u00c2)Z\u001d\u00847\u007f\u008232\u00b8\u00fdF\u00eb*\u0002\u00d7\u00b4\u00bc\u00a7\u00c0<\u008d\b\u00f5\u0012C\u00daS\u00de\u0007\u00af\u00a4\u0004\f\u00cf6&\u00a6\u009a\u0016\u00c1\u00e3\u00c9\u0086\u00e3D\u0003\u0090Q|&\u00b6\u008f\u00f2\u00130\u00ccNva\u0013\u0013#";
                        var16_6 = "tc\u00ad\u0005\u00d7\u00bat\u00b7\r\u0081k\u0083'\u009f\u00e4\u00cc\u00a79\u008fm/\u0083\u0087\r\u00cey\u001d\u00dc1\u00e13\u00d1\u00c6\u0094\u00897\u0006\u00903V\u001e\u001b\u0006\u0098~\u00a4\\\u0097\u000f\u008d\u00be\u00ab,\u00afVdA\u00d3\u00d9\u00bbU\u0089\t\u00c9\u0006M\u0091\u00dc\u00d4A\u00a7\u00bc}\u00e4:\u00dc\u00ec\t\u000b,\u00e0\u00fa\u00f1\u00d7\u0085F\u00b0\u00afh<k\u00b7v;\u00e3\u00a4\u0082By\u00ef%\u00c4$\u0003|\u008c@\r\u00d5B\u00ee\u0096\u00f0Q\u00ec\u00e2g\u00e6v\u00cd\u00e5\u00e92\n\u00bdJ\u0087\u00d6:6\u00bd8{\u0089V\u00e3\u00b4\u000e\u00d6\u00d6)=\u00f9\u00aa+\u00dd\u00be\u00e5\u00e7W-\u00fe\u0014)?\u00eb\u0012\u00a6J\u0089\u001aM\u00acWl\u00d6\u00cb\u00a8\u009e:\u008a\u00b76\u00a0p\u00ed\u0093\u00f7\u009f\u00bc\u00ab\u0088u\"\u00c2)Z\u001d\u00847\u007f\u008232\u00b8\u00fdF\u00eb*\u0002\u00d7\u00b4\u00bc\u00a7\u00c0<\u008d\b\u00f5\u0012C\u00daS\u00de\u0007\u00af\u00a4\u0004\f\u00cf6&\u00a6\u009a\u0016\u00c1\u00e3\u00c9\u0086\u00e3D\u0003\u0090Q|&\u00b6\u008f\u00f2\u00130\u00ccNva\u0013\u0013#".length();
                        var13_7 = 0;
                        while (true) {
                            var18_8 = var15_5.substring(var13_7, var13_7 += 8).getBytes("ISO-8859-1");
                            v3 = var17_3;
                            v4 = var14_4++;
                            v5 = ((long)var18_8[0] & 255L) << 56 | ((long)var18_8[1] & 255L) << 48 | ((long)var18_8[2] & 255L) << 40 | ((long)var18_8[3] & 255L) << 32 | ((long)var18_8[4] & 255L) << 24 | ((long)var18_8[5] & 255L) << 16 | ((long)var18_8[6] & 255L) << 8 | (long)var18_8[7] & 255L;
                            v6 = -1;
                            break block11;
                            break;
                        }
lbl26:
                        // 1 sources

                        while (true) {
                            v3[v4] = v7;
                            if (var13_7 < var16_6) ** continue;
                            var15_5 = ";\u000f\u0019^\u0096}\u00cd\u0007W\u00beR\u00b8\u0090\u00ad\n\u0098";
                            var16_6 = ";\u000f\u0019^\u0096}\u00cd\u0007W\u00beR\u00b8\u0090\u00ad\n\u0098".length();
                            var13_7 = 0;
                            while (true) {
                                var18_8 = var15_5.substring(var13_7, var13_7 += 8).getBytes("ISO-8859-1");
                                v3 = var17_3;
                                v4 = var14_4++;
                                v5 = ((long)var18_8[0] & 255L) << 56 | ((long)var18_8[1] & 255L) << 48 | ((long)var18_8[2] & 255L) << 40 | ((long)var18_8[3] & 255L) << 32 | ((long)var18_8[4] & 255L) << 24 | ((long)var18_8[5] & 255L) << 16 | ((long)var18_8[6] & 255L) << 8 | (long)var18_8[7] & 255L;
                                v6 = 0;
                                break block11;
                                break;
                            }
                            break;
                        }
lbl39:
                        // 1 sources

                        while (true) {
                            v3[v4] = v7;
                            if (var13_7 < var16_6) ** continue;
                            break block12;
                            break;
                        }
                    }
                    var19_9 = v5;
                    var21_10 = var11_1.doFinal(new byte[]{(byte)(var19_9 >>> 56), (byte)(var19_9 >>> 48), (byte)(var19_9 >>> 40), (byte)(var19_9 >>> 32), (byte)(var19_9 >>> 24), (byte)(var19_9 >>> 16), (byte)(var19_9 >>> 8), (byte)var19_9});
                    v7 = ((long)var21_10[0] & 255L) << 56 | ((long)var21_10[1] & 255L) << 48 | ((long)var21_10[2] & 255L) << 40 | ((long)var21_10[3] & 255L) << 32 | ((long)var21_10[4] & 255L) << 24 | ((long)var21_10[5] & 255L) << 16 | ((long)var21_10[6] & 255L) << 8 | (long)var21_10[7] & 255L;
                    switch (v6) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl52:
                        // 1 sources

                        ** continue;
                    }
                }
                Class_jk_a0800133.HAejn = var17_3;
                Class_jk_a0800133.kyDxg = new Integer[33];
                Class_jk_a0800133.kFdBt = new HashMap<K, V>(13);
                var0_11 = Cipher.getInstance("DES/CBC/NoPadding");
                v8 = SecretKeyFactory.getInstance("DES");
                v9 = new byte[8];
                v10 = v9;
                v9[0] = (byte)(var22 >>> 56);
                for (var1_12 = 1; var1_12 < 8; ++var1_12) {
                    v10 = v10;
                    v10[var1_12] = (byte)(var22 << var1_12 * 8 >>> 56);
                }
                var0_11.init(2, (Key)v8.generateSecret(new DESKeySpec(v10)), new IvParameterSpec(new byte[8]));
                var6_13 = new long[2];
                var3_14 = 0;
                var4_15 = "\t2R\u00a9\u008f\u00c1\u00af\u00c9(\u00f1\u00c8\u00f81\u00b8\"\u0010";
                var5_16 = "\t2R\u00a9\u008f\u00c1\u00af\u00c9(\u00f1\u00c8\u00f81\u00b8\"\u0010".length();
                var2_17 = 0;
                while (true) {
                    break block13;
                    break;
                }
lbl74:
                // 1 sources

                while (true) {
                    var6_13[v11] = ((long)var10_20[0] & 255L) << 56 | ((long)var10_20[1] & 255L) << 48 | ((long)var10_20[2] & 255L) << 40 | ((long)var10_20[3] & 255L) << 32 | ((long)var10_20[4] & 255L) << 24 | ((long)var10_20[5] & 255L) << 16 | ((long)var10_20[6] & 255L) << 8 | (long)var10_20[7] & 255L;
                    if (var2_17 < var5_16) ** continue;
                    break block14;
                    break;
                }
            }
            var7_18 = var4_15.substring(var2_17, var2_17 += 8).getBytes("ISO-8859-1");
            v11 = var3_14++;
            var8_19 = ((long)var7_18[0] & 255L) << 56 | ((long)var7_18[1] & 255L) << 48 | ((long)var7_18[2] & 255L) << 40 | ((long)var7_18[3] & 255L) << 32 | ((long)var7_18[4] & 255L) << 24 | ((long)var7_18[5] & 255L) << 16 | ((long)var7_18[6] & 255L) << 8 | (long)var7_18[7] & 255L;
            var10_20 = var0_11.doFinal(new byte[]{(byte)(var8_19 >>> 56), (byte)(var8_19 >>> 48), (byte)(var8_19 >>> 40), (byte)(var8_19 >>> 32), (byte)(var8_19 >>> 24), (byte)(var8_19 >>> 16), (byte)(var8_19 >>> 8), (byte)var8_19});
            ** while (true)
        }
        Class_jk_a0800133.TscJs = var6_13;
        Class_jk_a0800133.pPJRe = new Long[2];
        Class_jk_a0800133.zumTM = System.currentTimeMillis();
        Class_jk_a0800133.tSRYI = Class_mG_52c8d386.cnQ((int)Class_jk_a0800133.bDE("c", (int)9271, (long)(1435092371162270167L ^ var22)));
        Class_jk_a0800133.mPXGi = Class_mG_52c8d386.cnQ((int)Class_jk_a0800133.bDE("c", (int)13768, (long)(9103059913970685985L ^ var22)));
        Class_jk_a0800133.jEkxo = Class_mG_52c8d386.cnQ((int)Class_jk_a0800133.bDE("c", (int)10008, (long)(6923302068871629549L ^ var22)));
    }

    private static CallSite bDH(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jk_a0800133" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public static float[] bDt(int n) {
        float[] fArray = new float[]{(float)Class_jk_a0800133.bDp(n) / 255.0f, (float)Class_jk_a0800133.bDq(n) / 255.0f, (float)Class_jk_a0800133.bDr(n) / 255.0f, (float)Class_jk_a0800133.bDs(n) / 255.0f};
        return fArray;
    }

    public static int bDs(int n) {
        long l = khXTS ^ 0x7FDAC3BFC62CL;
        return n >> Class_jk_a0800133.bDE("c", (int)23397, (long)(0x25C9EAADB39A721FL ^ l)) & Class_jk_a0800133.bDE("c", (int)25251, (long)(0x77D9A11E0CB64BCBL ^ l));
    }

    public static int bDp(int n) {
        long l = khXTS ^ 0x74BF4DB58CC4L;
        return n >> Class_jk_a0800133.bDE("c", (int)1963, (long)(0x57464CA3A87AE429L ^ l)) & Class_jk_a0800133.bDE("c", (int)25251, (long)(0x77D9AA7B82BC0123L ^ l));
    }

    public static int bDr(int n) {
        long l = khXTS ^ 0x276882AAC2DDL;
        return n & Class_jk_a0800133.bDE("c", (int)19322, (long)(0x7F2D3A4DD23BE6CCL ^ l));
    }

    public static int bDq(int n) {
        long l = khXTS ^ 0x50E1310C92A6L;
        return n >> Class_jk_a0800133.bDE("c", (int)17155, (long)(0x310CADB810383EF6L ^ l)) & Class_jk_a0800133.bDE("c", (int)25251, (long)(0x77D98E25FE051F41L ^ l));
    }

    public static Class_mG_52c8d386 bDw(char c, float f) {
        long l = khXTS ^ 0x15B8E51D569BL;
        return switch (c) {
            case '0' -> Class_mG_52c8d386.cnR(0.0f, 0.0f, 0.0f, f);
            case '1' -> Class_mG_52c8d386.cnR(0.0f, 0.0f, 170.0f, f);
            case '2' -> Class_mG_52c8d386.cnR(0.0f, 170.0f, 0.0f, f);
            case '3' -> Class_mG_52c8d386.cnR(0.0f, 170.0f, 170.0f, f);
            case '4' -> Class_mG_52c8d386.cnR(170.0f, 0.0f, 0.0f, f);
            case '5' -> Class_mG_52c8d386.cnR(170.0f, 0.0f, 170.0f, f);
            case '6' -> Class_mG_52c8d386.cnR(255.0f, 170.0f, 0.0f, f);
            case '7' -> Class_mG_52c8d386.cnR(170.0f, 170.0f, 170.0f, f);
            case '8' -> Class_mG_52c8d386.cnR(85.0f, 85.0f, 85.0f, f);
            case '9' -> Class_mG_52c8d386.cnR(85.0f, 85.0f, 255.0f, f);
            case 'a' -> Class_mG_52c8d386.cnR(85.0f, 255.0f, 85.0f, f);
            case 'b' -> Class_mG_52c8d386.cnR(85.0f, 255.0f, 255.0f, f);
            case 'c' -> Class_mG_52c8d386.cnR(255.0f, 85.0f, 85.0f, f);
            case 'd' -> Class_mG_52c8d386.cnR(255.0f, 85.0f, 255.0f, f);
            case 'e' -> Class_mG_52c8d386.cnR(255.0f, 255.0f, 85.0f, f);
            case 'f' -> Class_mG_52c8d386.cnR(255.0f, 255.0f, 255.0f, f);
            default -> Class_mG_52c8d386.hoGuU.coa(f);
        };
    }

    private static int bDD(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_jk_a0800133.bDC(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public static Class_mG_52c8d386 bDl(int n, float f, float f2, int n2, float f3) {
        float f4 = (float)(System.currentTimeMillis() - zumTM) / f3;
        float f5 = (float)(n * n2) / f3;
        float f6 = Math.abs((f4 + f5) % 2.0f - 1.0f) * (f2 - f) + f;
        return Class_mG_52c8d386.cnS(f6, 0.7f, 1.0f);
    }

    private static long bDF(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x7BD0;
        if (pPJRe[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = TscJs[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])kFdBt.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    kFdBt.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jk_a0800133", exception);
            }
            long l4 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            Class_jk_a0800133.pPJRe[n2] = l4;
        }
        return pPJRe[n2];
    }

    public static Class_mG_52c8d386 bDn(int n, Class_mG_52c8d386 class_mG_52c8d386, int n2) {
        return Class_jk_a0800133.bDm(n, class_mG_52c8d386, n2);
    }

    private static long bDG(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        long l2 = Class_jk_a0800133.bDF(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l2;
    }

    public static Class_mG_52c8d386 bDm(int n, Class_mG_52c8d386 class_mG_52c8d386, int n2) {
        Class_mG_52c8d386 class_mG_52c8d3862 = class_mG_52c8d386.coe(0.5f);
        return Class_jk_a0800133.bDo(n2, n, class_mG_52c8d386, class_mG_52c8d3862);
    }

    public static boolean bDz(String string) {
        long l = khXTS ^ 0x4A547F249E71L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        boolean bl = string.indexOf((int)Class_jk_a0800133.bDE("c", (int)17394, (long)(0x2DCD92A069D032DAL ^ l)));
        if (stringArray != null) {
            bl = bl >= false;
        }
        return bl;
    }

    private static CallSite bDE(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jk_a0800133" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int bDC(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x7B2A;
        if (kyDxg[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = HAejn[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])kgjMD.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    kgjMD.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jk_a0800133", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_jk_a0800133.kyDxg[n2] = n3;
        }
        return kyDxg[n2];
    }

    public static boolean bDA(int[] nArray) {
        int n;
        block4: {
            long l = khXTS ^ 0x57F03E2725C5L;
            int[] nArray2 = nArray;
            int n2 = nArray2.length;
            int n3 = 0;
            String[] stringArray = Class_jf_d1c4f950.bBe();
            while (n3 < n2) {
                int n4 = nArray2[n3];
                if (stringArray != null) {
                    n = n4;
                    if (stringArray == null) break block4;
                    if (n == Class_jk_a0800133.bDE("c", (int)15359, (long)(0x2ADE2210A7F47174L ^ l))) {
                        return true;
                    }
                    ++n3;
                }
                if (stringArray != null) continue;
            }
            n = 0;
        }
        return n != 0;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public static Character bDx(int var0) {
        var1_1 = Class_jk_a0800133.khXTS ^ 76022883398906L;
        var3_2 = Class_jf_d1c4f950.bBe();
        v0 /* !! */  = var0;
        if (var3_2 == null) ** GOTO lbl8
        switch (v0 /* !! */ ) {
            case '\u0000': {
                v0 /* !! */  = (char)Class_jk_a0800133.bDE("c", (int)2712, (long)(8931741584885698876L ^ var1_1));
lbl8:
                // 2 sources

                v1 = Character.valueOf(v0 /* !! */ );
                break;
            }
            case '\u00aa': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)23376, (long)(7126584669265592553L ^ var1_1)));
                break;
            }
            case '\uaa00': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)2454, (long)(6836223952805745204L ^ var1_1)));
                break;
            }
            case '\uaaaa': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)28196, (long)(4171240892031382940L ^ var1_1)));
                break;
            }
            case '\uaa0000': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)28399, (long)(3620412094595478873L ^ var1_1)));
                break;
            }
            case '\uaa00aa': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)23643, (long)(218901521598446L ^ var1_1)));
                break;
            }
            case '\uffaa00': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)1470, (long)(8740296862895988239L ^ var1_1)));
                break;
            }
            case '\uaaaaaa': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)8392, (long)(553822879079693176L ^ var1_1)));
                break;
            }
            case '\u555555': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)18106, (long)(7038008272829816095L ^ var1_1)));
                break;
            }
            case '\u5555ff': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)16753, (long)(5499769290555267778L ^ var1_1)));
                break;
            }
            case '\u55ff55': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)24054, (long)(3776547647052973648L ^ var1_1)));
                break;
            }
            case '\u55ffff': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)21219, (long)(7251249371611695438L ^ var1_1)));
                break;
            }
            case '\uff5555': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)13430, (long)(44418181251690460L ^ var1_1)));
                break;
            }
            case '\uff55ff': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)18973, (long)(1600679749416817058L ^ var1_1)));
                break;
            }
            case '\uffff55': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)25271, (long)(6350869116562684185L ^ var1_1)));
                break;
            }
            case '\uffffff': {
                v1 = Character.valueOf((char)Class_jk_a0800133.bDE("c", (int)1941, (long)(2291648465477459005L ^ var1_1)));
                break;
            }
            default: {
                v1 = null;
            }
        }
        return v1;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public static Class_mG_52c8d386 bDo(int var0, int var1_1, Class_mG_52c8d386 ... var2_2) {
        var3_3 = Class_jk_a0800133.khXTS ^ 11357095698851L;
        var6_4 = (int)((System.currentTimeMillis() / (long)var0 + (long)var1_1) % Class_jk_a0800133.bDH("o", (int)6194, (long)(7486879851048228385L ^ var3_3)));
        var5_5 = Class_jf_d1c4f950.bBe();
        v0 /* !! */  = var6_4;
        v1 /* !! */  = Class_jk_a0800133.bDE("c", (int)19179, (long)(2616894344674313234L ^ var3_3));
        if (var5_5 == null) ** GOTO lbl10
        if (v0 /* !! */  > v1 /* !! */ ) {
            v0 /* !! */  = (int)Class_jk_a0800133.bDE("c", (int)4276, (long)(1915280933525839447L ^ var3_3));
            v1 /* !! */  = (CallSite)var6_4;
lbl10:
            // 2 sources

            v2 = v0 /* !! */  - v1 /* !! */ ;
        } else {
            v2 = var6_4;
        }
        var6_4 = v2 + Class_jk_a0800133.bDE("c", (int)6441, (long)(2888322174864775121L ^ var3_3));
        var7_6 = (int)((float)var6_4 / 360.0f * (float)var2_2.length);
        if (var7_6 == var2_2.length) {
            --var7_6;
        }
        var8_7 = var2_2[var7_6];
        v3 = var7_6;
        v4 = var2_2.length - 1;
        if (var5_5 == null) ** GOTO lbl26
        if (v3 == v4) {
            v5 = 0;
        } else {
            v3 = var7_6;
            v4 = 1;
lbl26:
            // 2 sources

            v5 = v3 + v4;
        }
        var9_8 = var2_2[v5];
        return Class_jk_a0800133.bDu(var8_7, var9_8, (float)var6_4 / 360.0f * (float)var2_2.length - (float)var7_6);
    }

    public static int bDv(int n, int n2) {
        return Class_mG_52c8d386.cnR(Class_jk_a0800133.bDp(n), Class_jk_a0800133.bDq(n), Class_jk_a0800133.bDr(n), n2).coh();
    }

    private static MatchException bDB(MatchException matchException) {
        return matchException;
    }

    /*
     * Unable to fully structure code
     */
    public static Class_mG_52c8d386 bDu(Class_mG_52c8d386 var0, Class_mG_52c8d386 var1_1, double var2_2) {
        var4_3 = Class_jk_a0800133.khXTS ^ 119503211124990L;
        var6_4 = Class_jf_d1c4f950.bBe();
        v0 = var1_1;
        if (var6_4 == null) ** GOTO lbl9
        if (v0 == null) {
            v1 = 0.0f;
        } else {
            v0 = var1_1;
lbl9:
            // 2 sources

            v1 = v0.cor();
        }
        v2 = var0;
        if (var6_4 == null) ** GOTO lbl16
        if (v2 == null) {
            v3 = 0.0f;
        } else {
            v2 = var0;
lbl16:
            // 2 sources

            v3 = v2.cor();
        }
        var7_5 = Class_mZ_07f59a29.csm(v1, v3, var2_2);
        v4 = var1_1;
        if (var6_4 == null) ** GOTO lbl24
        if (v4 == null) {
            v5 = 0.0f;
        } else {
            v4 = var1_1;
lbl24:
            // 2 sources

            v5 = v4.cos();
        }
        v6 = var0;
        if (var6_4 == null) ** GOTO lbl31
        if (v6 == null) {
            v7 = 0.0f;
        } else {
            v6 = var0;
lbl31:
            // 2 sources

            v7 = v6.cos();
        }
        var8_6 = Class_mZ_07f59a29.csm(v5, v7, var2_2);
        v8 = var1_1;
        if (var6_4 == null) ** GOTO lbl39
        if (v8 == null) {
            v9 = 0.0f;
        } else {
            v8 = var1_1;
lbl39:
            // 2 sources

            v9 = v8.cot();
        }
        v10 = var0;
        if (var6_4 == null) ** GOTO lbl46
        if (v10 == null) {
            v11 = 0.0f;
        } else {
            v10 = var0;
lbl46:
            // 2 sources

            v11 = v10.cot();
        }
        var9_7 = Class_mZ_07f59a29.csm(v9, v11, var2_2);
        v12 = var1_1;
        if (var6_4 == null) ** GOTO lbl54
        if (v12 == null) {
            v13 = 0.0f;
        } else {
            v12 = var1_1;
lbl54:
            // 2 sources

            v13 = v12.cou();
        }
        v14 = var0;
        if (var6_4 == null) ** GOTO lbl61
        if (v14 == null) {
            v15 = 0.0f;
        } else {
            v14 = var0;
lbl61:
            // 2 sources

            v15 = v14.cou();
        }
        var10_8 = Class_mZ_07f59a29.csm(v13, v15, var2_2);
        return Class_mG_52c8d386.cnR(var7_5, var8_6, var9_7, var10_8);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean bDy(char c) {
        long l = khXTS ^ 0x2BAC316C89CDL;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        boolean bl = c;
        CallSite callSite = Class_jk_a0800133.bDE("c", (int)28278, (long)(0x532052380AF588FCL ^ l));
        if (stringArray != null) {
            if (bl >= callSite) {
                bl = c;
                if (stringArray == null) return bl;
                if (bl <= Class_jk_a0800133.bDE("c", (int)2977, (long)(0x266195C93B926D3DL ^ l))) return true;
            }
            bl = c;
            callSite = Class_jk_a0800133.bDE("c", (int)14196, (long)(0xD00556A128C51ECL ^ l));
        }
        if (stringArray != null) {
            if (bl < callSite) return false;
            bl = c;
            if (stringArray == null) return bl;
            callSite = Class_jk_a0800133.bDE("c", (int)12745, (long)(0xADA89C0D7CED749L ^ l));
        }
        if (bl > callSite) return false;
        return true;
    }

    public static Class_mG_52c8d386 bDk() {
        long l = khXTS ^ 0x5F3AF2DDC7B8L;
        double d = Math.ceil((double)(System.currentTimeMillis() + Class_jk_a0800133.bDH("o", (int)28833, (long)(0x307D0A1E950C58A8L ^ l))) / 20.0);
        return Class_mG_52c8d386.cnS((float)((d %= 360.0) / 360.0), 0.5f, 1.0f);
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jk_a0800133.class, "bDG", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_jk_a0800133.class, "bDD", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

