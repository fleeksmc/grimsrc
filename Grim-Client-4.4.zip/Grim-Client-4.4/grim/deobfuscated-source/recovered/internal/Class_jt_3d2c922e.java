/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.entity.state.EntityRenderState
 *  net.minecraft.util.math.Vec3d
 *  org.joml.Matrix3x2f
 *  org.joml.Matrix3x2fc
 *  org.joml.Quaternionf
 *  org.joml.Quaternionfc
 */
package recovered.internal;

import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fc;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import recovered.internal.Class_jr_25c15d18;
import recovered.internal.Class_lF_27593463;
import recovered.internal.Class_lJ_e4c3455b;
import recovered.internal.Class_lN_5af116ef;

public final class Class_jt_3d2c922e
implements Class_lJ_e4c3455b<Class_jt_3d2c922e> {
    private final Matrix3x2fc TvcWs;
    private final EntityRenderState fgeSN;
    private final float frbJF;
    private final float KeAxW;
    private final float khKKF;
    private final float uTgLo;
    private float QomKU = 1.0f;
    private Vec3d hXKLQ = Vec3d.ZERO;
    private Quaternionf xZTHX = new Quaternionf();
    private Quaternionf pZyIu;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    @Override
    public Class_lN_5af116ef batchKey() {
        return Class_lN_5af116ef.immediate();
    }

    public Class_jt_3d2c922e(Matrix3x2fc matrix3x2fc, EntityRenderState entityRenderState, float f, float f2, float f3, float f4) {
        this.TvcWs = new Matrix3x2f(matrix3x2fc);
        this.fgeSN = entityRenderState;
        this.frbJF = f;
        this.KeAxW = f2;
        this.khKKF = f3;
        this.uTgLo = f4;
    }

    @Override
    public void execute() {
        Class_jr_25c15d18.bFu(this.TvcWs, this.fgeSN, this.QomKU, this.hXKLQ, this.xZTHX, this.pZyIu, this.frbJF, this.KeAxW, this.khKKF, this.uTgLo);
    }

    public Class_jt_3d2c922e bFH(float f) {
        this.QomKU = f;
        return this;
    }

    public Class_jt_3d2c922e bFI(Vec3d vec3d) {
        this.hXKLQ = vec3d;
        return this;
    }

    public Class_jt_3d2c922e bFL(Quaternionf quaternionf) {
        this.pZyIu = new Quaternionf((Quaternionfc)quaternionf);
        return this;
    }

    public Class_jt_3d2c922e bFK(Quaternionf quaternionf) {
        this.xZTHX = new Quaternionf((Quaternionfc)quaternionf);
        return this;
    }

    public Class_jt_3d2c922e bFJ(float f, float f2, float f3) {
        this.hXKLQ = new Vec3d((double)f, (double)f2, (double)f3);
        return this;
    }

    public Class_jt_3d2c922e bFM() {
        Class_lF_27593463.cfA(this);
        return this;
    }
}

