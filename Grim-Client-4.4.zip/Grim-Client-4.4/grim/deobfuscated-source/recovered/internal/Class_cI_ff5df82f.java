/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 */
package recovered.internal;

import com.google.gson.JsonElement;
import java.lang.invoke.MethodHandles;
import java.util.Map;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mr_7eac5189;

public class Class_cI_ff5df82f
extends Class_cB_67aec11c {
    private Runnable sAiGw = () -> {};
    private static final long CGjNX = Class_gb_9d201141.aYR(5579284435811150568L, -1393473000424632907L, MethodHandles.lookup().lookupClass()).a(260687920679028L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cI_ff5df82f(Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_mr_7eac5189);
    }

    public Class_cI_ff5df82f(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    @Override
    public void SS(JsonElement jsonElement) {
    }

    @Override
    public void SR(Map<String, Object> map) {
    }

    public Class_cI_ff5df82f Wx(Runnable runnable) {
        long l = CGjNX ^ 0x21ADDC3DD7ADL;
        boolean bl = Class_cB_67aec11c.Vt();
        Runnable runnable2 = runnable;
        if (bl) {
            runnable2 = runnable2 == null ? () -> {} : runnable;
        }
        this.sAiGw = runnable2;
        return this;
    }

    private static MatchException WC(MatchException matchException) {
        return matchException;
    }

    public Runnable Wy() {
        return this.sAiGw;
    }
}

