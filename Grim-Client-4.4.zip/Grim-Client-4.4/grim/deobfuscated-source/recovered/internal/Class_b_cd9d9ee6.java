/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import recovered.core.NativeLoader;
import recovered.internal.Class_E_1cf91f48;
import recovered.internal.Class_G_9e5c41dd;
import recovered.internal.Class_ir_8e0d90e0;

public class Class_b_cd9d9ee6
extends Class_G_9e5c41dd {
    private static long kSCdo;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native void _44a053bfb442a1d0c6a857ca21e80386();

    static {
        NativeLoader.doInit(Class_b_cd9d9ee6.class);
        Class_b_cd9d9ee6._44a053bfb442a1d0c6a857ca21e80386();
    }

    @Override
    protected native List<Class_E_1cf91f48> i();

    private static native MatchException l(MatchException var0);

    private static native /* synthetic */ void k(Class_ir_8e0d90e0 var0);

    @Override
    protected native void j(int[] var1);
}

