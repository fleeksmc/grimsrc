/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.core.ModuleBase;
import recovered.internal.Class_aC_564007e8;
import recovered.internal.Class_aE_a07172c5;
import recovered.internal.Class_aw_dcb9764f;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bd_8faff9cb;
import recovered.internal.Class_bg_sc_56033ca3;
import recovered.internal.Class_bh_f2f50881;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.modules.InterfaceModule;

public class Class_bg_0a91641c
extends Class_az_a4990dcf {
    private final Class_rk_bf8630d1 yScCM;
    private final Class_rk_bf8630d1 CUqhT;
    private final Class_rk_bf8630d1 Mgsdz;
    private final Class_rk_bf8630d1 fSVRe;
    private final Class_rk_bf8630d1 DAnVX;
    private final Class_ri_288534d5 UjiHh;
    private final ModuleBase leLdq;
    private Class_bh_f2f50881 MPosk;
    private boolean OfuUM;
    private boolean wAIFj;
    private static int BIqnm;
    private static final long CEakp;
    private static final long[] tfkIz;
    private static final Integer[] figLz;
    private static final Map aaqZK;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bg_0a91641c(ModuleBase moduleBase) {
        long l = CEakp ^ 0x7ECF36AE8632L;
        this.yScCM = new Class_rk_bf8630d1((int)Class_bg_0a91641c.Di("b", (int)10421, (long)(0x4F4B818F43028D54L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.CUqhT = new Class_rk_bf8630d1((int)Class_bg_0a91641c.Di("b", (int)27352, (long)(0x1954B17DF5B5CF3AL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.Mgsdz = new Class_rk_bf8630d1((int)Class_bg_0a91641c.Di("b", (int)27352, (long)(0x1954B17DF5B5CF3AL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.fSVRe = new Class_rk_bf8630d1((int)Class_bg_0a91641c.Di("b", (int)12257, (long)(0x37718A3A4CFF8A01L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.DAnVX = new Class_rk_bf8630d1((int)Class_bg_0a91641c.Di("b", (int)29257, (long)(0x71DF45F5814F57AAL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.UjiHh = new Class_ri_288534d5((int)Class_bg_0a91641c.Di("b", (int)23869, (long)(0x2710EB64C97A78DAL ^ l)), Class_mG_52c8d386.hoGuU);
        this.leLdq = moduleBase;
        this.BcpIo = 175.0f;
        this.WjISQ = 28.0f;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_bg_0a91641c.CEakp = Class_gb_9d201141.aYR(1510145277589715049L, -9149368666420411358L, MethodHandles.lookup().lookupClass()).a(12342236566515L);
                Class_bg_0a91641c.aaqZK = new HashMap<K, V>(13);
                var0 = Class_bg_0a91641c.CEakp ^ 90933238133144L;
                Class_bg_0a91641c.Dc(0);
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[5];
                var5_4 = 0;
                var6_5 = "\u008f5\u0095\u00a6;P\u00fcr;\u00a5`\u00b2\u00b6\u00a0\u00f0\u009a\u00e2r8H\u009b\u00ac\u00af\u0092";
                var7_6 = "\u008f5\u0095\u00a6;P\u00fcr;\u00a5`\u00b2\u00b6\u00a0\u00f0\u009a\u00e2r8H\u009b\u00ac\u00af\u0092".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl27:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = "\u00f9\u00f3XT\u0011e\u0012i\u00ef\u008a\u008a\u0001@\u0089!\u00ee";
                    var7_6 = "\u00f9\u00f3XT\u0011e\u0012i\u00ef\u008a\u008a\u0001@\u0089!\u00ee".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl40:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl53:
                // 1 sources

                ** continue;
            }
        }
        Class_bg_0a91641c.tfkIz = var8_3;
        Class_bg_0a91641c.figLz = new Integer[5];
    }

    public Class_rk_bf8630d1 CR() {
        return this.yScCM;
    }

    private boolean CN(Class_bg_0a91641c class_bg_0a91641c) {
        return Class_bl_a15fbaa5.Ex().manager().aY(Class_bd_8faff9cb.class).stream().anyMatch(class_bd_8faff9cb -> {
            long l = CEakp ^ 0x163652EB9610L;
            return class_bd_8faff9cb.BS() == class_bg_0a91641c;
        });
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean dk(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        long l = CEakp ^ 0x18EE790551BL;
        int n = Class_bg_0a91641c.De();
        boolean bl = this.tg(d, d2);
        if (n == 0) return bl;
        if (bl) {
            float f = this.yScCM.dhj() - 0.0f;
            bl = f == 0.0f ? 0 : (f > 0.0f ? 1 : -1);
            if (n == 0) return bl;
            if (bl) {
                boolean bl2 = Class_bg_sc_56033ca3.gbAZn[class_mA_32d8a5f2.ordinal()];
                if (n == 0) return bl2;
                switch (bl2 ? 1 : 0) {
                    case 1: {
                        ModuleBase moduleBase = this.leLdq;
                        if (n != 0) {
                            if (moduleBase == InterfaceModule.aYl()) {
                                this.OfuUM = true;
                                this.wAIFj = true;
                                if (n != 0) return true;
                            }
                            moduleBase = this.leLdq;
                        }
                        moduleBase.aZZ();
                        if (n != 0) return true;
                    }
                    case 2: {
                        this.CO(d, d2);
                        if (n != 0) return true;
                    }
                    case 3: {
                        this.CP();
                        return true;
                    }
                }
                return true;
            }
        }
        bl = super.dk(d, d2, class_mA_32d8a5f2);
        return bl;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    protected void bV(Class_lC_5322e8cf var1_1) {
        block22: {
            block21: {
                block20: {
                    block18: {
                        block19: {
                            block16: {
                                block17: {
                                    var2_2 = Class_bg_0a91641c.CEakp ^ 101271826170335L;
                                    v0 = Class_bg_0a91641c.Dd();
                                    this.Mgsdz.dhs(Class_rj_b691f4f7.JbGQS);
                                    this.Mgsdz.dhc(this.leLdq.bag());
                                    var4_3 = v0;
                                    var5_4 = this.ti(var1_1);
                                    if (var4_3 != 0) break block16;
                                    if (!var5_4) break block17;
                                    var6_5 = Class_aE_a07172c5.vA(Class_aC_564007e8.class);
                                    if (var4_3 != 0) break block16;
                                    if (var6_5 != null) {
                                        var6_5.ul(this);
                                    }
                                }
                                this.CUqhT.dhc(var5_4);
                                this.DAnVX.dhc(this.OfuUM);
                            }
                            v1 = this.CN(this);
                            if (var4_3 == 0) {
                                v1 = v1 == false;
                            }
                            this.yScCM.dhc(v1);
                            var6_6 = 7.0f;
                            var7_7 = Math.min(1.0f, this.yScCM.dhj());
                            var8_8 = this.CtPwV.bje().coa(204.0f).cob(var7_7);
                            v2 = this.OfuUM;
                            if (var4_3 != 0) break block18;
                            if (!v2) break block19;
                            v3 = Class_jk_a0800133.mPXGi;
                            break block20;
                        }
                        v4 = this;
                        if (var4_3 != 0) ** GOTO lbl40
                        v2 = v4.leLdq.bag();
                    }
                    if (v2) {
                        v3 = this.CtPwV.bjf();
                    } else {
                        v4 = this;
lbl40:
                        // 2 sources

                        v3 = v4.CtPwV.bjb();
                    }
                }
                this.UjiHh.dfT(v3);
                v5 = this.OfuUM;
                if (var4_3 != 0) ** GOTO lbl48
                if (v5) {
                    v5 = this.wAIFj;
lbl48:
                    // 2 sources

                    v6 = v5 ? 1.0f : -1.0f;
                } else {
                    v6 = 0.0f;
                }
                this.fSVRe.dhd(v6);
                cfr_temp_0 = this.DAnVX.dhj() - 1.0f;
                v7 = cfr_temp_0 == 0.0f ? 0 : (cfr_temp_0 > 0.0f ? 1 : -1);
                if (var4_3 == 0) {
                    if (v7 == false) {
                        this.OfuUM = false;
                    }
                    v7 = (cfr_temp_1 = this.fSVRe.dhj() - 1.0f) == 0.0f ? 0 : (cfr_temp_1 > 0.0f ? 1 : -1);
                }
                if (var4_3 != 0) break block21;
                if (v7 == false) {
                    this.wAIFj = false;
                }
                v8 = this;
                if (var4_3 != 0) break block22;
                cfr_temp_2 = v8.fSVRe.dhj() - -1.0f;
                v7 = cfr_temp_2 == 0.0f ? 0 : (cfr_temp_2 > 0.0f ? 1 : -1);
            }
            if (v7 == false) {
                this.wAIFj = true;
            }
            var1_1.cdm(this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ, 5.0f, Class_ld_bb1690e1.M, var8_8);
            v8 = this;
        }
        var9_9 = v8.UjiHh.dfU().coa(255.0f * var7_7).cob(Class_jF_38b68c76.bHw()[3] * 0.75f + 0.25f * this.Mgsdz.dhj() + 0.25f * this.CUqhT.dhj());
        var10_10 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
        var11_11 = this.MCnYt + var6_6 + this.fSVRe.dhj();
        var12_12 = this.pNyTQ + 8.0f;
        var1_1.ceA(var10_10, this.leLdq.bad(), var11_11, var12_12, var9_9);
        var13_13 = this.CtPwV.bjb().coa(255.0f * var7_7).cob(0.5f * var7_7);
        var14_14 = Class_lE_06fbe260.joxgd.bYM(6.0f);
        var15_15 = this.MCnYt + var6_6;
        var16_16 = this.pNyTQ + 16.0f;
        var1_1.ceI(var14_14, this.leLdq.bae(), var15_15, var16_16, var13_13, 0.7f, 0.99f, this.BcpIo - var6_6 * 2.0f);
    }

    public Class_rk_bf8630d1 CS() {
        return this.CUqhT;
    }

    public void CO(double d, double d2) {
        this.MPosk = new Class_bh_f2f50881((float)d, (float)d2, 6.0f, this.leLdq);
        Class_aw_dcb9764f.route(this.MPosk);
    }

    public ModuleBase CX() {
        return this.leLdq;
    }

    public Class_bh_f2f50881 CY() {
        return this.MPosk;
    }

    public boolean CZ() {
        return this.OfuUM;
    }

    public static int Dd() {
        return BIqnm;
    }

    public static int De() {
        int n = Class_bg_0a91641c.Dd();
        if (n == 0) {
            return 76;
        }
        return 0;
    }

    public static void Dc(int n) {
        BIqnm = n;
    }

    private static CallSite Di(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bg_0a91641c" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static MatchException Df(MatchException matchException) {
        return matchException;
    }

    public boolean Da() {
        return this.wAIFj;
    }

    public void CP() {
        this.CQ(null);
    }

    public void CQ(Class_cB_67aec11c class_cB_67aec11c) {
        block7: {
            Class_bg_0a91641c class_bg_0a91641c;
            block6: {
                long l = CEakp ^ 0x661D4E217520L;
                Class_lc_b8480f87 class_lc_b8480f87 = Class_bl_a15fbaa5.Ex().Ey();
                List<Class_bd_8faff9cb> list = Class_bl_a15fbaa5.Ex().manager().aY(Class_bd_8faff9cb.class);
                float f = class_lc_b8480f87.bXF() + class_lc_b8480f87.bXH() + 10.0f;
                int n = Class_bg_0a91641c.Dd();
                float f2 = class_lc_b8480f87.bXG();
                for (Class_bd_8faff9cb class_bd_8faff9cb : list) {
                    class_bg_0a91641c = class_bd_8faff9cb.BS();
                    if (n == 0) {
                        if (class_bg_0a91641c == this) {
                            if (class_cB_67aec11c != null) {
                                class_bd_8faff9cb.BQ(class_cB_67aec11c);
                            }
                            class_bd_8faff9cb.Cg(true);
                            return;
                        }
                        if (n == 0) continue;
                    }
                    break block6;
                }
                for (Class_bd_8faff9cb class_bd_8faff9cb : list) {
                    class_bd_8faff9cb.Cg(false);
                    if (n == 0) {
                        if (n == 0) continue;
                    }
                    break block7;
                }
                Class_bl_a15fbaa5.Ex().Eq(new Class_bd_8faff9cb(this, f, f2, class_cB_67aec11c));
                class_bg_0a91641c = this;
            }
            class_bg_0a91641c.yScCM.dhg();
        }
    }

    private static int Dh(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bg_0a91641c.Dg(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public Class_rk_bf8630d1 CT() {
        return this.Mgsdz;
    }

    public Class_rk_bf8630d1 CU() {
        return this.fSVRe;
    }

    public Class_rk_bf8630d1 CV() {
        return this.DAnVX;
    }

    private static int Dg(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x1032;
        if (figLz[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = tfkIz[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])aaqZK.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    aaqZK.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bg_0a91641c", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bg_0a91641c.figLz[n2] = n3;
        }
        return figLz[n2];
    }

    public Class_ri_288534d5 CW() {
        return this.UjiHh;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bg_0a91641c.class, "Dh", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

