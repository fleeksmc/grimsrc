/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.concurrent.CompletableFuture;
import recovered.internal.Class_iu_bf2db566;

public interface Class_it_6213c445 {
    public CompletableFuture<Class_iu_bf2db566> fetchProfile();
}

