/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import recovered.core.ClientMain;
import recovered.core.NativeLoader;
import recovered.internal.Class_P_2c9819bb;
import recovered.internal.Class_S_f3cb3437;
import recovered.internal.Class_ae_957fe66c;
import recovered.internal.Class_ae_rP_6c7ebb3c;
import recovered.internal.Class_ah_02444db4;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_cy_687dcdb6;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_ng_91317468;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bq_8edccbef
extends Class_az_a4990dcf {
    private static float PssWv = 12.0f;
    private static float FlVBu = 0.5f;
    private static float mGFYO = 4.0f;
    private static float rsiUA = 12.5f;
    private final List<Class_ng_91317468> oosnB;
    private final Class_az_a4990dcf gonlP;
    private final Class_rk_bf8630d1 hfuSd;
    private final Class_rk_bf8630d1 Izzcw;
    private final Class_rk_bf8630d1 fViQp;
    private final Class_P_2c9819bb LvcHh;
    private final Class_P_2c9819bb dATEM;
    private final Class_ah_02444db4 BOvEx;
    private static long eduFT;
    private static String[] WzteC;
    private static String[] UASzT;
    private static Map BepdG;
    private static long[] rMScF;
    private static Integer[] WokSU;
    private static Map rSYQq;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bq_8edccbef(List<Class_ng_91317468> list, Class_az_a4990dcf class_az_a4990dcf) {
        long l = eduFT ^ 0x539C4B614D99L;
        this.hfuSd = new Class_rk_bf8630d1((int)Class_bq_8edccbef.Gm("t", (int)10292, (long)(0x68EA343430FD7320L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.Izzcw = new Class_rk_bf8630d1((int)Class_bq_8edccbef.Gm("t", (int)2500, (long)(0x51E03B68728ED2D5L ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        this.fViQp = new Class_rk_bf8630d1((int)Class_bq_8edccbef.Gm("t", (int)2500, (long)(0x51E03B68728ED2D5L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.BOvEx = new Class_ah_02444db4();
        this.oosnB = list;
        this.gonlP = class_az_a4990dcf;
        Class_ig_ca326427 class_ig_ca326427 = ClientMain.dlM().bjG();
        this.LvcHh = ((Class_P_2c9819bb)new Class_P_2c9819bb(null, (String)((Object)Class_bq_8edccbef.Gj("l", (int)18793, (long)(0x749F4B38429EF6E4L ^ l))), Class_lf_d247d983.cuxpa).ja(class_ig_ca326427.biw().bhF())).hO(Class_S_f3cb3437.CLgKH);
        this.dATEM = ((Class_P_2c9819bb)((Class_P_2c9819bb)new Class_P_2c9819bb(null, (String)((Object)Class_bq_8edccbef.Gj("l", (int)24111, (long)(0x7ADADE1ECD8FE1AEL ^ l))), Class_lf_d247d983.JHGge).ja(Class_jk_a0800133.mPXGi)).iY(Class_jk_a0800133.mPXGi)).hO(Class_S_f3cb3437.CLgKH);
    }

    static {
        NativeLoader.doInit(Class_bq_8edccbef.class);
        Class_bq_8edccbef._566eb1eeb5f605d6540f908d7417f39d();
    }

    @Override
    public native float dn();

    @Override
    public native boolean dm(int var1, int var2, int var3);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean fC(double var1, double var3, double var5);

    private static native void _566eb1eeb5f605d6540f908d7417f39d();

    private native /* synthetic */ void Ge(Class_ae_957fe66c var1, Class_ng_91317468 var2, Class_cJ_2ae1a557 var3, Class_cJ_2ae1a557 var4, Class_cy_687dcdb6 var5, boolean var6, Class_aj_95d0a719 var7);

    private native void FZ(double var1, double var3, Class_ng_91317468 var5);

    private native /* synthetic */ void Gb(Class_ng_91317468 var1, Class_P_2c9819bb var2);

    private native boolean FW(String var1, Class_ng_91317468 var2);

    private static native /* synthetic */ String Gd(Class_ae_rP_6c7ebb3c var0);

    private static native int Gl(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native int FX(String var1) throws NumberFormatException;

    private static native String Gg(byte[] var0);

    private native /* synthetic */ void Gc(double var1, double var3, Class_ng_91317468 var5, Class_P_2c9819bb var6);

    private static native int Gk(int var0, long var1);

    private static native List<Class_ae_rP_6c7ebb3c> FY();

    private static native CallSite Gm(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native CallSite Gj(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native NumberFormatException Gf(NumberFormatException var0);

    private static native String Gh(int var0, long var1);

    private static native Object Gi(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native void FV(double var1, double var3, Class_ng_91317468 var5);

    private native float Ga();
}

