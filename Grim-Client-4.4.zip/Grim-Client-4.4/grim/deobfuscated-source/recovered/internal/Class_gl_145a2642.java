/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.Arm
 *  net.minecraft.util.Hand
 */
package recovered.internal;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gl_145a2642
extends Class_hH_ae8f8f77 {
    private Hand vymrZ;
    private Arm EAANp;
    private float NcQJW;
    private ItemStack AhPGQ;
    private float xnMqJ;
    private MatrixStack WigNW;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gl_145a2642(Hand hand, Arm arm, float f, ItemStack itemStack, float f2, MatrixStack matrixStack) {
        this.vymrZ = hand;
        this.EAANp = arm;
        this.NcQJW = f;
        this.AhPGQ = itemStack;
        this.xnMqJ = f2;
        this.WigNW = matrixStack;
    }

    public Hand baU() {
        return this.vymrZ;
    }

    public float baW() {
        return this.NcQJW;
    }

    public ItemStack baX() {
        return this.AhPGQ;
    }

    public float baY() {
        return this.xnMqJ;
    }

    public Arm baV() {
        return this.EAANp;
    }

    public MatrixStack baZ() {
        return this.WigNW;
    }
}

