/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 */
package recovered.internal;

import com.google.gson.JsonElement;
import java.lang.invoke.MethodHandles;
import java.security.Key;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mZ_07f59a29;
import recovered.internal.Class_mr_7eac5189;

public class Class_cy_687dcdb6
extends Class_cB_67aec11c {
    private int dVhKN;
    private String KGEbC;
    private String SKWJA;
    private static final long BJDNi = Class_gb_9d201141.aYR(697931624956062612L, -6996857525835252864L, MethodHandles.lookup().lookupClass()).a(133051153534346L);
    private static final String AckiN;
    private static final long ObnMN;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cy_687dcdb6(Class_mr_7eac5189 class_mr_7eac5189) {
        long l = BJDNi ^ 0x6E4DD9EF648AL;
        super(class_mr_7eac5189);
        this.SKWJA = AckiN;
        this.KGEbC = "";
        this.dVhKN = (int)ObnMN;
    }

    public Class_cy_687dcdb6(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = BJDNi ^ 0x46BAF8902C4L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        byte[] byArray3 = cipher.doFinal("\u00cb\u00c2\u00f3h>\u00af\u0090\u00f9\u00ab\u009b\u00b1\u0090\u0005o\u00a7\u00da".getBytes("ISO-8859-1"));
        AckiN = Class_cy_687dcdb6.Uv(byArray3).intern();
        Cipher cipher2 = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory2 = SecretKeyFactory.getInstance("DES");
        byte[] byArray4 = new byte[8];
        byte[] byArray5 = byArray4;
        byArray4[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher2.init(2, (Key)secretKeyFactory2.generateSecret(new DESKeySpec(byArray5)), new IvParameterSpec(new byte[8]));
                long l2 = -3224779342212499987L;
                byte[] byArray6 = cipher2.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
                ObnMN = ((long)byArray6[0] & 0xFFL) << 56 | ((long)byArray6[1] & 0xFFL) << 48 | ((long)byArray6[2] & 0xFFL) << 40 | ((long)byArray6[3] & 0xFFL) << 32 | ((long)byArray6[4] & 0xFFL) << 24 | ((long)byArray6[5] & 0xFFL) << 16 | ((long)byArray6[6] & 0xFFL) << 8 | (long)byArray6[7] & 0xFFL;
                return;
            }
            byArray5 = byArray5;
            byArray5[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    public Class_cy_687dcdb6 Uo(String string) {
        long l = BJDNi ^ 0x219A478D33D0L;
        boolean bl = Class_cB_67aec11c.Vt();
        String string2 = string;
        if (bl) {
            string2 = string2 == null ? "" : string;
        }
        this.SKWJA = string2;
        return this;
    }

    private static MatchException Uu(MatchException matchException) {
        return matchException;
    }

    public String Ut() {
        return this.SKWJA;
    }

    public int[] Uq() {
        return Class_mZ_07f59a29.csh(this.KGEbC);
    }

    private static String Uv(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public int Ur() {
        return this.dVhKN;
    }

    public Class_cy_687dcdb6 Un(int n) {
        this.dVhKN = Math.max(0, n);
        return this.Up(this.KGEbC);
    }

    public Class_cy_687dcdb6 Up(String string) {
        Class_cy_687dcdb6 class_cy_687dcdb6;
        block7: {
            int n;
            String string2;
            block6: {
                long l = BJDNi ^ 0x7903240B5DDFL;
                boolean bl = Class_cB_67aec11c.Vu();
                String string3 = string;
                if (!bl) {
                    string3 = string3 == null ? "" : string;
                }
                string2 = string3;
                n = string2.length();
                if (bl) break block6;
                if (n > this.dVhKN) {
                    string2 = string2.substring(0, this.dVhKN);
                }
                class_cy_687dcdb6 = this;
                if (bl) break block7;
                n = Objects.equals(class_cy_687dcdb6.KGEbC, string2) ? 1 : 0;
            }
            if (n != 0) {
                return this;
            }
            this.KGEbC = string2;
            this.Vk();
            class_cy_687dcdb6 = this;
        }
        return class_cy_687dcdb6;
    }

    public String Us() {
        return this.KGEbC;
    }

    @Override
    public void SS(JsonElement jsonElement) {
        this.Up(jsonElement.getAsString());
    }

    @Override
    public void SR(Map<String, Object> map) {
        map.put(Arrays.toString(this.NwlSF), this.KGEbC);
    }
}

