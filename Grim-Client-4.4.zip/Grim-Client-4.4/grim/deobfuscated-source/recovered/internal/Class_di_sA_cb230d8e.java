/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import net.minecraft.util.math.Vec2f;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_lc_b8480f87;
import recovered.modules.AmbienceModule;

final class Class_di_sA_cb230d8e {
    private float UcFvW = Float.POSITIVE_INFINITY;
    private float ARrvJ = Float.POSITIVE_INFINITY;
    private float MRZOj = Float.NEGATIVE_INFINITY;
    private float VRpNr = Float.NEGATIVE_INFINITY;
    private int TomLU;
    private static final long osDYz = Class_gb_9d201141.aYR(4529541263180445756L, 6623467899913022852L, MethodHandles.lookup().lookupClass()).a(149834542413418L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_di_sA_cb230d8e() {
    }

    private static MatchException doE(MatchException matchException) {
        return matchException;
    }

    private Class_lc_b8480f87 doD() {
        float f;
        float f2;
        block7: {
            block6: {
                float f3;
                block5: {
                    long l = osDYz ^ 0x1B5697821F33L;
                    Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
                    Class_di_sA_cb230d8e class_di_sA_cb230d8e = this;
                    if (class_iS_888f260eArray == null) {
                        if (class_di_sA_cb230d8e.TomLU == 0) {
                            return null;
                        }
                        class_di_sA_cb230d8e = this;
                    }
                    f2 = class_di_sA_cb230d8e.MRZOj - this.UcFvW;
                    f = this.VRpNr - this.ARrvJ;
                    float f4 = f2 - 1.0f;
                    f3 = f4 == 0.0f ? 0 : (f4 < 0.0f ? -1 : 1);
                    if (class_iS_888f260eArray != null) break block5;
                    if (f3 <= 0) break block6;
                    float f5 = f - 1.0f;
                    f3 = f5 == 0.0f ? 0 : (f5 < 0.0f ? -1 : 1);
                }
                if (f3 > 0) break block7;
            }
            return null;
        }
        return new Class_lc_b8480f87(this.UcFvW, this.ARrvJ, f2, f);
    }

    private void doC(Vec2f vec2f) {
        ++this.TomLU;
        this.UcFvW = Math.min(this.UcFvW, vec2f.x);
        this.ARrvJ = Math.min(this.ARrvJ, vec2f.y);
        this.MRZOj = Math.max(this.MRZOj, vec2f.x);
        this.VRpNr = Math.max(this.VRpNr, vec2f.y);
    }
}

