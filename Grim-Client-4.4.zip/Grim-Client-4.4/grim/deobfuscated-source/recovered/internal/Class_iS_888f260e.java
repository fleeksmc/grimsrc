/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.ArrayList;
import java.util.List;
import recovered.core.NativeLoader;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gf_c6fc2a98;

public class Class_iS_888f260e {
    protected List<Class_cB_67aec11c> oZllQ;
    private static String GYeud;
    private static long kFZrs;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_iS_888f260e() {
        long l = kFZrs ^ 0xF80494B2485L;
        String string = Class_gf_c6fc2a98.aZY();
        String string2 = string;
        try {
            this.oZllQ = new ArrayList<Class_cB_67aec11c>();
            if (string2 != null) {
                Class_iS_888f260e.bwK("qLIdWc");
            }
        }
        catch (MatchException matchException) {
            throw Class_iS_888f260e.bwM(matchException);
        }
    }

    static {
        NativeLoader.doInit(Class_iS_888f260e.class);
        Class_iS_888f260e._3e90acdd50c76b988d525cf192640a11();
    }

    public static native String bwL();

    private static native MatchException bwM(MatchException var0);

    public native <T extends Class_cB_67aec11c> T bwH(T var1);

    public native List<Class_cB_67aec11c> bwI();

    public static native void bwK(String var0);

    public native Class_iS_888f260e bwJ(List<Class_cB_67aec11c> var1);

    private static native void _3e90acdd50c76b988d525cf192640a11();
}

