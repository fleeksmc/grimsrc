/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec2f
 *  org.joml.Matrix3x2fStack
 */
package recovered.internal;

import net.minecraft.util.math.Vec2f;
import org.joml.Matrix3x2fStack;
import recovered.internal.Class_jQ_ub_ee126734;
import recovered.internal.Class_mG_52c8d386;

public class Class_jQ_28340a81 {
    private Matrix3x2fStack OnmFi;
    private Vec2f SACMG;
    private Vec2f xZJck;
    private Vec2f hgzSE;
    private Vec2f DILdN;
    private Class_mG_52c8d386 dqFYn;
    private float UCEil;
    private float GeRqt;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_jQ_28340a81(Matrix3x2fStack matrix3x2fStack, Vec2f vec2f, Vec2f vec2f2, Vec2f vec2f3, Vec2f vec2f4, Class_mG_52c8d386 class_mG_52c8d386, float f, float f2) {
        this.OnmFi = matrix3x2fStack;
        this.SACMG = vec2f;
        this.xZJck = vec2f2;
        this.hgzSE = vec2f3;
        this.DILdN = vec2f4;
        this.dqFYn = class_mG_52c8d386;
        this.UCEil = f;
        this.GeRqt = f2;
    }

    public Vec2f bLG() {
        return this.xZJck;
    }

    public Vec2f bLH() {
        return this.hgzSE;
    }

    public Vec2f bLF() {
        return this.SACMG;
    }

    public Matrix3x2fStack bLE() {
        return this.OnmFi;
    }

    public Vec2f bLI() {
        return this.DILdN;
    }

    public float bLK() {
        return this.UCEil;
    }

    public float bLL() {
        return this.GeRqt;
    }

    public Class_mG_52c8d386 bLJ() {
        return this.dqFYn;
    }

    public static Class_jQ_ub_ee126734 bLD() {
        return new Class_jQ_ub_ee126734();
    }

    private static float bLC() {
        return 0.75f;
    }

    private static Class_mG_52c8d386 bLA() {
        return Class_mG_52c8d386.hoGuU;
    }

    private static float bLB() {
        return 1.0f;
    }

    public static Class_jQ_ub_ee126734 bLz(Matrix3x2fStack matrix3x2fStack, Vec2f vec2f, Vec2f vec2f2, Vec2f vec2f3, Vec2f vec2f4) {
        return Class_jQ_28340a81.bLD().drm(matrix3x2fStack).drn(vec2f).dro(vec2f2).drp(vec2f3).drq(vec2f4);
    }
}

