/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.math.Vec2f;
import recovered.core.ClientMain;
import recovered.internal.Class_ad_d4e95a2c;
import recovered.internal.Class_ah_02444db4;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_ap_f3b7a87f;
import recovered.internal.Class_aq_9e8149f3;
import recovered.internal.Class_av_ffcf74a1;
import recovered.internal.Class_aw_dcb9764f;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bd_8faff9cb;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_br_e9f7a55a;
import recovered.internal.Class_bt_551ea435;
import recovered.internal.Class_bw_21f72edc;
import recovered.internal.Class_by_7f4c6e69;
import recovered.internal.Class_bz_sh_3463383a;
import recovered.internal.Class_cN_30b69d20;
import recovered.internal.Class_g_bd7b3df3;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_iy_c88c0f4f;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jG_69891630;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_k_759fe111;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mZ_07f59a29;
import recovered.internal.Class_mu_a94f6370;
import recovered.internal.Class_nf_8f40fc48;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.internal.Class_rm_d861be3b;

public class Class_bz_8cac7329
extends Class_av_ffcf74a1
implements Class_aw_dcb9764f {
    private static Class_bz_8cac7329 EjcFr;
    private final Class_lc_b8480f87 DZWUG;
    private final Class_lc_b8480f87 aZGpn;
    private final Class_lc_b8480f87 mbChM;
    private final Class_bw_21f72edc HDtRm;
    private final Class_aq_9e8149f3 vhydZ;
    private final Class_aq_9e8149f3 rzpmv;
    private final Class_ah_02444db4 dimez;
    private final Class_mu_a94f6370<Class_by_7f4c6e69> RHgUi;
    private final Class_g_bd7b3df3 bvQae;
    private final Class_az_a4990dcf DNlcF;
    private Class_iy_c88c0f4f LlNRn;
    private boolean OwOuM;
    private boolean aXfUv;
    private Class_iy_c88c0f4f LhWtM;
    private Class_nf_8f40fc48 KLjmC;
    private final Class_rk_bf8630d1 OjRjG;
    private final Class_rk_bf8630d1 PrMWO;
    private final Class_rk_bf8630d1 wgnWc;
    private static String bTgYE;
    private static final long kleqM;
    private static final String[] BuVTR;
    private static final String[] OcNPP;
    private static final Map nMXOH;
    private static final long[] BMxWP;
    private static final Integer[] lmFlx;
    private static final Map ugCiQ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bz_8cac7329() {
        block0: {
            long l = kleqM ^ 0x123561A66D49L;
            this.dimez = new Class_ah_02444db4();
            this.RHgUi = new Class_mu_a94f6370();
            this.bvQae = new Class_g_bd7b3df3();
            this.OjRjG = new Class_rk_bf8630d1((int)Class_bz_8cac7329.Lp("t", (int)24533, (long)(0x6CCA0F798A0D53C4L ^ l))).dhs(Class_rj_b691f4f7.yiIHY);
            this.PrMWO = new Class_rk_bf8630d1((int)Class_bz_8cac7329.Lp("t", (int)30600, (long)(0x1C29370BC276FB9BL ^ l))).dhs(Class_rj_b691f4f7.yiIHY);
            this.wgnWc = new Class_rk_bf8630d1((int)Class_bz_8cac7329.Lp("t", (int)18830, (long)(0x35486FA930BAC598L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
            EjcFr = this;
            this.bvQae.aV(() -> this.sg());
            float f = 402.0f;
            float f2 = 220.0f;
            Vec2f vec2f = Class_rm_d861be3b.diq();
            this.DZWUG = new Class_lc_b8480f87(vec2f.x / 2.0f - f / 2.0f, vec2f.y / 2.0f - f2 / 2.0f, f, f2);
            this.aZGpn = new Class_lc_b8480f87(this.DZWUG.bXF(), this.DZWUG.bXA() + 7.0f, f, 30.0f);
            this.mbChM = new Class_lc_b8480f87(this.DZWUG.bXF() + 8.0f, this.DZWUG.bXG() + 8.0f, this.DZWUG.bXH() - 16.0f, this.DZWUG.bXI() - 16.0f);
            this.vhydZ = new Class_aq_9e8149f3((String)((Object)Class_bz_8cac7329.Lm("c", (int)12435, (long)(0x4471CA09396F6025L ^ l))), (String)((Object)Class_bz_8cac7329.Lm("c", (int)9397, (long)(0x6DD8C95CD03EF404L ^ l))));
            String string = Class_bz_8cac7329.Lh();
            this.rzpmv = new Class_aq_9e8149f3((String)((Object)Class_bz_8cac7329.Lm("c", (int)25044, (long)(0x3FDDCAC3DD52B16FL ^ l))), (String)((Object)Class_bz_8cac7329.Lm("c", (int)29576, (long)(0x2809E51B0BE22338L ^ l))));
            this.HDtRm = new Class_bw_21f72edc();
            this.DNlcF = new Class_bz_sh_3463383a(this);
            this.DNlcF.sI(this.HDtRm);
            String string2 = string;
            this.bvQae.aE(this.DNlcF);
            if (string2 != null) break block0;
            Class_iS_888f260e.bwK("HdjxFc");
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Class_bz_8cac7329.kleqM = Class_gb_9d201141.aYR(-6241896568748446855L, -7788375777216042359L, MethodHandles.lookup().lookupClass()).a(171208799013154L);
                        Class_bz_8cac7329.nMXOH = new HashMap<K, V>(13);
                        var11 = Class_bz_8cac7329.kleqM ^ 89972296966990L;
                        Class_bz_8cac7329.Lg("SC1U6b");
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[9];
                        var18_4 = 0;
                        var17_5 = "\u00d17\u00cf\u00b8\u00c2\u00e5\u001c\u0000\u0094\u00b1]+d\u00f0\u0003\u00c3\u00f1OO9\u00fc\u00ab\u000b\u00ac\u00a4\u00e5\u00a8\u00ac'-P\u0003\u008a\u00b7\u0019!\u00bdO\u0010L(\u0012\t\u00977\u0002\u00f5\u00acA<\u00d1\u0094\u00fa4\u00bc\u00b8$]\u00aet\u00d2\u0085\u00c7\u0095\u008f\u0087\u0010\u001f\u00bd_\u0091\u00a5;\u00a9\u00f9]h\u0018\u00c8N\u0080X\u0010(\u009c{g`}e\u00ae>\u00c0o\u001f\u00d5\u0002\u00af\u00c70\u00a0E6\u00ac\u00af1\u00a3]\u0082\u0016\u00b3\u00fd\u00f0[\u00c4Z\u0091\u0096\u0081\u00eb\t\b\u00cf\u0007\u0086\u00cd3!\u00d9\u00bb-\u00e4\u0081.y\u0083d\u0016[\u00cb\u001e6\u0097\u00d9\u00e8\u00e1h4\u00ec\u0089':MI\u000b\u00b1-j\u00e8\u000e\u00feb\u009c\u00d1\u00bbS\u0099\u00a3qfP\u00a3\u00f7*\u0091&\u00e5\u00cb1kt\u00c3'\u00a7\u00c6D\u00d8\u00bfC\u00ee=\u00d1/lx`/[\u00ca\u009e\\\u00c8\u00b6}\u00c6\u00a3\u00f6\fg\u00be'\u0088H\u00e8v\u001e\u0089\u00c3\u00a1\u00d3az\u0013\u00cc\u00b1\u00f7\u00fc\u00d5\u00c6H2\u00d1\u00a7\u009b\u00d5\u00f3X)\u00bf\u008c\u009bzp(\u00b9;\u00b7\u00c5\u0006\u00b5u@\u000f\u0088\u00db\u009f\u00fa\u00daq\u00a3\u0087\u00aen\u00c8\u0013/\u00baY\u000b\u00f8\u000b\u000e\u0087\u00ca\u00bb\u0082\u00cf\u009cCG\u00e3JP\\\u0001\u00dd\u0002(\u00887\u0082\u0016\u001e\u00f5N\\\u00939\u00e03\bq\u009b\u009c\u008e\u0090E4acr\u0014\u00b6\u00b5\u00bf]8\u009e\u000f\u0015\u00d8\u00b3\u00fb\u00fb\u00d7\u008d\u00c2\u00dd\u009bCk\u0097h\u00bc\u008ap\u00c2\u009bXh\u001e\u001c\u009b\u00a4\u00b7\u00d9\u0085\u0007^\u00d5\u00bd\u0006}\u009d) 2\u0096\u00d8\u00bfw\u00b9\u001a*\u00d8\u0016z\u00ef\u00c7Iet\u008b 1[4I|\u00df\u00f6+\u00d7\u008a\u00b8\u00c6\u001eGlG<\u008c\u0095\u00a4\u0087\u0006.\u008d\u00b1F\u00d4\u00b9\u00e4^\u0019\u00c7";
                        var19_6 = "\u00d17\u00cf\u00b8\u00c2\u00e5\u001c\u0000\u0094\u00b1]+d\u00f0\u0003\u00c3\u00f1OO9\u00fc\u00ab\u000b\u00ac\u00a4\u00e5\u00a8\u00ac'-P\u0003\u008a\u00b7\u0019!\u00bdO\u0010L(\u0012\t\u00977\u0002\u00f5\u00acA<\u00d1\u0094\u00fa4\u00bc\u00b8$]\u00aet\u00d2\u0085\u00c7\u0095\u008f\u0087\u0010\u001f\u00bd_\u0091\u00a5;\u00a9\u00f9]h\u0018\u00c8N\u0080X\u0010(\u009c{g`}e\u00ae>\u00c0o\u001f\u00d5\u0002\u00af\u00c70\u00a0E6\u00ac\u00af1\u00a3]\u0082\u0016\u00b3\u00fd\u00f0[\u00c4Z\u0091\u0096\u0081\u00eb\t\b\u00cf\u0007\u0086\u00cd3!\u00d9\u00bb-\u00e4\u0081.y\u0083d\u0016[\u00cb\u001e6\u0097\u00d9\u00e8\u00e1h4\u00ec\u0089':MI\u000b\u00b1-j\u00e8\u000e\u00feb\u009c\u00d1\u00bbS\u0099\u00a3qfP\u00a3\u00f7*\u0091&\u00e5\u00cb1kt\u00c3'\u00a7\u00c6D\u00d8\u00bfC\u00ee=\u00d1/lx`/[\u00ca\u009e\\\u00c8\u00b6}\u00c6\u00a3\u00f6\fg\u00be'\u0088H\u00e8v\u001e\u0089\u00c3\u00a1\u00d3az\u0013\u00cc\u00b1\u00f7\u00fc\u00d5\u00c6H2\u00d1\u00a7\u009b\u00d5\u00f3X)\u00bf\u008c\u009bzp(\u00b9;\u00b7\u00c5\u0006\u00b5u@\u000f\u0088\u00db\u009f\u00fa\u00daq\u00a3\u0087\u00aen\u00c8\u0013/\u00baY\u000b\u00f8\u000b\u000e\u0087\u00ca\u00bb\u0082\u00cf\u009cCG\u00e3JP\\\u0001\u00dd\u0002(\u00887\u0082\u0016\u001e\u00f5N\\\u00939\u00e03\bq\u009b\u009c\u008e\u0090E4acr\u0014\u00b6\u00b5\u00bf]8\u009e\u000f\u0015\u00d8\u00b3\u00fb\u00fb\u00d7\u008d\u00c2\u00dd\u009bCk\u0097h\u00bc\u008ap\u00c2\u009bXh\u001e\u001c\u009b\u00a4\u00b7\u00d9\u0085\u0007^\u00d5\u00bd\u0006}\u009d) 2\u0096\u00d8\u00bfw\u00b9\u001a*\u00d8\u0016z\u00ef\u00c7Iet\u008b 1[4I|\u00df\u00f6+\u00d7\u008a\u00b8\u00c6\u001eGlG<\u008c\u0095\u00a4\u0087\u0006.\u008d\u00b1F\u00d4\u00b9\u00e4^\u0019\u00c7".length();
                        var16_7 = 40;
                        var15_8 = -1;
lbl21:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl26:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Class_bz_8cac7329.Lj(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00e1S\u0017\u00f3\u00efn\u0000\u009bS\u0099\u00c2N\u00a1\u00d4^\u00a74g\u00ffE\u008c\"\u0003OJ\u00aeK\u0086\u00ea\u00cfF\u0093\u00acq\u00c7\u0091\u00b4B@\u001a@u\u00c4\u00d55\u00a9\u00b37\u00a0\n\u0017\u0091\u00ee\u00b9\u001f\u0005U\u0080\u000fG\b\nNj\u00db\u00eb\u0093\u00bc\u0002\u00d2\u0096\u00bb.\t*\b[O\u00d2\u00d1a\u0005\u00d9\u00be\n\u0019k'\u00bf S\u0019~\u00edh\u00baw\r\u009eB\u0089\u00c6\u00ab/0";
                            var19_6 = "\u00e1S\u0017\u00f3\u00efn\u0000\u009bS\u0099\u00c2N\u00a1\u00d4^\u00a74g\u00ffE\u008c\"\u0003OJ\u00aeK\u0086\u00ea\u00cfF\u0093\u00acq\u00c7\u0091\u00b4B@\u001a@u\u00c4\u00d55\u00a9\u00b37\u00a0\n\u0017\u0091\u00ee\u00b9\u001f\u0005U\u0080\u000fG\b\nNj\u00db\u00eb\u0093\u00bc\u0002\u00d2\u0096\u00bb.\t*\b[O\u00d2\u00d1a\u0005\u00d9\u00be\n\u0019k'\u00bf S\u0019~\u00edh\u00baw\r\u009eB\u0089\u00c6\u00ab/0".length();
                            var16_7 = 40;
                            var15_8 = -1;
lbl35:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl40:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Class_bz_8cac7329.Lj(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl52:
                        // 1 sources

                        ** continue;
                    }
                }
                Class_bz_8cac7329.BuVTR = var20_3;
                Class_bz_8cac7329.OcNPP = new String[9];
                Class_bz_8cac7329.ugCiQ = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[6];
                var3_13 = 0;
                var4_14 = "\u0085\u00e0\u00db,\u0019\u0016\u00c8\u00ee\u00c4\u00aa]\u0099\u0098\u00b9\u00d5\u00fa\u00fe\u008b4_q\u0005\u0090s\u0001\u00d5R#\u00a1\u009b}P";
                var5_15 = "\u0085\u00e0\u00db,\u0019\u0016\u00c8\u00ee\u00c4\u00aa]\u0099\u0098\u00b9\u00d5\u00fa\u00fe\u008b4_q\u0005\u0090s\u0001\u00d5R#\u00a1\u009b}P".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl79:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00f24\u009fB\u00e9;i\u00ff\u009e\u001f\u0005\u00d6/\u00be\u00e4d";
                    var5_15 = "\u00f24\u009fB\u00e9;i\u00ff\u009e\u001f\u0005\u00d6/\u00be\u00e4d".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl92:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl105:
                // 1 sources

                ** continue;
            }
        }
        Class_bz_8cac7329.BMxWP = var6_12;
        Class_bz_8cac7329.lmFlx = new Integer[6];
    }

    @Override
    protected Vec2f n() {
        float f = this.DZWUG.bXI() + 7.0f + this.aZGpn.bXI();
        return new Vec2f(this.DZWUG.bXH() + 14.0f, f + 14.0f);
    }

    /*
     * Exception decompiling
     */
    @Override
    public void m(Class_lC_5322e8cf var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public Class_g_bd7b3df3 manager() {
        return this.bvQae;
    }

    private static Object Ll(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_bz_8cac7329.Lk(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite Lm(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bz_8cac7329" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int Lo(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bz_8cac7329.Ln(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public Class_iy_c88c0f4f KR() {
        return this.LlNRn;
    }

    public Class_rk_bf8630d1 KW() {
        return this.OjRjG;
    }

    public void KC() {
        this.KD(null);
    }

    public void KB(Class_iy_c88c0f4f class_iy_c88c0f4f) {
        block3: {
            long l = kleqM ^ 0x2CB03B603A62L;
            Iterator<Class_aj_95d0a719> iterator = this.Kz().iterator();
            String string = Class_bz_8cac7329.Lh();
            while (iterator.hasNext()) {
                block4: {
                    Class_aj_95d0a719 class_aj_95d0a719;
                    Class_aj_95d0a719 class_aj_95d0a7192;
                    block5: {
                        class_aj_95d0a7192 = iterator.next();
                        if (string == null) break block3;
                        class_aj_95d0a719 = class_aj_95d0a7192;
                        if (string == null) break block4;
                        if (class_aj_95d0a719 instanceof Class_bt_551ea435) break block5;
                        class_aj_95d0a719 = class_aj_95d0a7192;
                        if (string == null || !(class_aj_95d0a719 instanceof Class_br_e9f7a55a)) break block4;
                    }
                    class_aj_95d0a719 = class_aj_95d0a7192.oj(false);
                }
                if (string != null) continue;
            }
            this.aXfUv = false;
            this.KLjmC = null;
            this.OwOuM = true;
            this.LhWtM = class_iy_c88c0f4f;
        }
    }

    public static void KE() {
        long l = kleqM ^ 0x5EC48BA3191BL;
        if (ClientMain.dlmvG.world == null) {
            return;
        }
        Class_bz_8cac7329 class_bz_8cac7329 = Class_bz_8cac7329.KH();
        class_bz_8cac7329.VWsmm = false;
        class_bz_8cac7329.sj().dhg();
        ClientMain.dlmvG.setScreen((Screen)class_bz_8cac7329);
    }

    public void KG() {
        long l = kleqM ^ 0x73A5DFA5E16FL;
        this.VWsmm = true;
        this.OwOuM = false;
        this.aXfUv = false;
        this.LhWtM = null;
        this.KLjmC = null;
        Iterator<Class_aj_95d0a719> iterator = this.bvQae.aY(Class_aj_95d0a719.class).iterator();
        String string = Class_bz_8cac7329.Lh();
        while (iterator.hasNext()) {
            Class_aj_95d0a719 class_aj_95d0a719 = iterator.next();
            class_aj_95d0a719.oj(false);
            if (string != null) continue;
        }
    }

    public static void KF() {
        Class_bz_8cac7329.KH().KG();
    }

    public void KA() {
        boolean bl;
        block6: {
            long l = kleqM ^ 0x6F2DC5C87FAL;
            boolean bl2 = false;
            String string = Class_bz_8cac7329.Lh();
            for (Class_aj_95d0a719 class_aj_95d0a719 : this.Kz()) {
                block9: {
                    boolean bl3;
                    Class_aj_95d0a719 class_aj_95d0a7192;
                    block7: {
                        block8: {
                            bl = class_aj_95d0a719 instanceof Class_bt_551ea435;
                            if (string == null) break block6;
                            if (string == null) break block7;
                            if (!bl) break block8;
                            bl2 = true;
                            if (string != null) break block9;
                        }
                        class_aj_95d0a7192 = class_aj_95d0a719;
                        if (string == null) break block9;
                        bl3 = class_aj_95d0a7192 instanceof Class_br_e9f7a55a;
                    }
                    if (bl3) {
                        class_aj_95d0a7192 = class_aj_95d0a719.oj(false);
                    }
                }
                if (string != null) continue;
            }
            bl = bl2;
        }
        if (bl) {
            return;
        }
        this.aXfUv = false;
        this.KLjmC = null;
        this.LhWtM = null;
        this.OwOuM = true;
    }

    public boolean KS() {
        return this.OwOuM;
    }

    @Override
    public boolean onMouseDragged(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2, double d3, double d4) {
        return this.bvQae.aP(d, d2, class_mA_32d8a5f2, d3, d4);
    }

    @Override
    public boolean onCharTyped(char c) {
        return this.bvQae.aT(c);
    }

    @Override
    public boolean onMouseClicked(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        return this.bvQae.aN(d, d2, class_mA_32d8a5f2);
    }

    @Override
    public boolean onKeyPressed(int n, int n2, int n3) {
        long l = kleqM ^ 0x78EE3853607L;
        String string = Class_bz_8cac7329.Lh();
        int n4 = this.bvQae.aS(n, n2, n3);
        if (string != null) {
            if (n4 != 0) {
                return true;
            }
            n4 = n;
        }
        if (string != null) {
            if (n4 == Class_bz_8cac7329.Lp("t", (int)29799, (long)(0x3BCDF54FC395A33EL ^ l))) {
                this.KG();
                return true;
            }
            n4 = 0;
        }
        return n4 != 0;
    }

    @Override
    public boolean onMouseReleased(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        return this.bvQae.aO(d, d2, class_mA_32d8a5f2);
    }

    @Override
    public boolean onMouseScrolled(double d, double d2, double d3) {
        return this.bvQae.aQ(d, d2, d3);
    }

    @Override
    public void addTooltip(Class_k_759fe111 class_k_759fe111) {
        block3: {
            Class_az_a4990dcf class_az_a4990dcf;
            long l = kleqM ^ 0x5720157FFDDFL;
            Iterator<Class_k_759fe111> iterator = this.bvQae.aY(Class_k_759fe111.class).iterator();
            String string = Class_bz_8cac7329.Lh();
            while (iterator.hasNext()) {
                Class_k_759fe111 class_k_759fe1112 = iterator.next();
                class_az_a4990dcf = class_k_759fe1112.cn();
                if (string != null) {
                    if (class_az_a4990dcf == class_k_759fe111.cn()) {
                        return;
                    }
                    if (string != null) continue;
                }
                break block3;
            }
            class_k_759fe111.sS(true);
            class_az_a4990dcf = this.bvQae.aF(class_k_759fe111);
        }
    }

    @Override
    public void addPopup(Class_ap_f3b7a87f class_ap_f3b7a87f) {
        long l = kleqM ^ 0x7ABAA3144E46L;
        class_ap_f3b7a87f.sP((int)Class_bz_8cac7329.Lp("t", (int)24316, (long)(0x6F6B32FD300AF1E1L ^ l))).sT(false);
        this.bvQae.aF(class_ap_f3b7a87f);
        Iterator<Class_ap_f3b7a87f> iterator = this.bvQae.aY(Class_ap_f3b7a87f.class).iterator();
        String string = Class_bz_8cac7329.Lh();
        while (iterator.hasNext()) {
            block6: {
                Class_ap_f3b7a87f class_ap_f3b7a87f2;
                int n;
                Class_ap_f3b7a87f class_ap_f3b7a87f3;
                block7: {
                    Class_ap_f3b7a87f class_ap_f3b7a87f4;
                    block5: {
                        class_ap_f3b7a87f4 = class_ap_f3b7a87f3 = iterator.next();
                        if (string == null) break block5;
                        if (class_ap_f3b7a87f4 == class_ap_f3b7a87f) break block6;
                        class_ap_f3b7a87f4 = class_ap_f3b7a87f3;
                    }
                    n = class_ap_f3b7a87f4.sN();
                    if (string == null) break block7;
                    if (n <= 0) break block6;
                    class_ap_f3b7a87f2 = class_ap_f3b7a87f3;
                    if (string == null) break block6;
                    n = class_ap_f3b7a87f2.tz() ? 1 : 0;
                }
                if (n == 0) {
                    class_ap_f3b7a87f2 = class_ap_f3b7a87f3.oj(false);
                }
            }
            if (string != null) continue;
        }
    }

    @Override
    public void addPopupComponent(Class_aj_95d0a719 class_aj_95d0a719) {
        long l = kleqM ^ 0x518288A03DA9L;
        class_aj_95d0a719.sP((int)Class_bz_8cac7329.Lp("t", (int)31464, (long)(0x352B55A139B2A618L ^ l))).sT(false);
        this.bvQae.aF(class_aj_95d0a719);
    }

    public void close() {
        block8: {
            block9: {
                String string;
                block6: {
                    int n;
                    block7: {
                        long l = kleqM ^ 0xD749E97DF37L;
                        string = Class_bz_8cac7329.Lh();
                        n = this.VWsmm;
                        if (string == null) break block7;
                        if (n == 0) break block8;
                        this.Weytw.dhd(0.0f);
                        float f = this.Weytw.dhj() - 0.0f;
                        n = f == 0.0f ? 0 : (f < 0.0f ? -1 : 1);
                    }
                    if (n > 0) break block8;
                    Class_ad_d4e95a2c class_ad_d4e95a2c = Class_ad_d4e95a2c.rmmkh;
                    if (string != null && class_ad_d4e95a2c != null) {
                        class_ad_d4e95a2c = Class_ad_d4e95a2c.rmmkh.lQ(false);
                    }
                    if (ClientMain.dlmvG.world == null) break block9;
                    for (Class_bd_8faff9cb class_bd_8faff9cb : Class_bl_a15fbaa5.Ex().manager().aY(Class_bd_8faff9cb.class)) {
                        block11: {
                            Class_bd_8faff9cb class_bd_8faff9cb2;
                            block10: {
                                if (string == null) break block6;
                                class_bd_8faff9cb2 = class_bd_8faff9cb;
                                if (string == null) break block10;
                                if (!class_bd_8faff9cb2.Ca()) break block11;
                                class_bd_8faff9cb2 = class_bd_8faff9cb;
                            }
                            class_bd_8faff9cb2.BU().dhg();
                        }
                        if (string != null) continue;
                    }
                    Class_bl_a15fbaa5.Eu();
                }
                if (string != null) break block8;
            }
            super.close();
        }
    }

    public void init() {
        this.VWsmm = false;
        this.HDtRm.dY();
        this.OwOuM = false;
        this.aXfUv = false;
        this.LhWtM = null;
        this.KLjmC = null;
        this.rzpmv.qB();
        this.vhydZ.qB();
        this.OjRjG.dhg();
        this.PrMWO.dhg();
        this.Kx();
    }

    public void tick() {
        this.si();
        this.close();
    }

    public static Class_bz_8cac7329 KH() {
        long l = kleqM ^ 0x4F21C7F997E0L;
        String string = Class_bz_8cac7329.Lh();
        Class_bz_8cac7329 class_bz_8cac7329 = EjcFr;
        if (string != null) {
            if (class_bz_8cac7329 == null) {
                new Class_bz_8cac7329();
            }
            class_bz_8cac7329 = EjcFr;
        }
        return class_bz_8cac7329;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public void KD(Class_nf_8f40fc48 var1_1) {
        block10: {
            var2_2 = Class_bz_8cac7329.kleqM ^ 27999608984664L;
            var5_3 = ClientMain.dlV().bnM();
            var4_4 = Class_bz_8cac7329.Lh();
            v0 = var5_3;
            if (var4_4 == null) ** GOTO lbl10
            if (v0 == null) {
                v1 /* !! */  = Optional.empty();
            } else {
                v0 = var5_3;
lbl10:
                // 2 sources

                v1 /* !! */  = v0.bmP();
            }
            var6_5 = v1 /* !! */ ;
            v2 = var6_5.isEmpty();
            if (var4_4 != null) {
                if (v2) {
                    return;
                }
                v2 = false;
            }
            var7_6 = v2;
            for (Class_aj_95d0a719 var9_8 : this.Kz()) {
                block13: {
                    block11: {
                        block12: {
                            v3 = var9_8 instanceof Class_br_e9f7a55a;
                            if (var4_4 == null) break block10;
                            if (var4_4 == null) break block11;
                            if (!v3) break block12;
                            var10_9 = (Class_br_e9f7a55a)var9_8;
                            var7_6 = true;
                            var10_9.Go(var1_1);
                            if (var4_4 != null) break block13;
                        }
                        v4 /* !! */  = var9_8;
                        if (var4_4 == null) break block13;
                        v5 = v4 /* !! */  instanceof Class_bt_551ea435;
                    }
                    if (v5) {
                        v4 /* !! */  = var9_8.oj(false);
                    }
                }
                if (var4_4 != null) continue;
            }
            v3 = var7_6;
        }
        if (v3) {
            return;
        }
        this.OwOuM = false;
        this.aXfUv = true;
        this.LhWtM = null;
        this.KLjmC = var1_1;
    }

    /*
     * Unable to fully structure code
     */
    private void Kv(Class_iy_c88c0f4f var1_1) {
        block22: {
            block23: {
                block25: {
                    block24: {
                        block20: {
                            block21: {
                                block14: {
                                    block15: {
                                        block18: {
                                            block19: {
                                                block17: {
                                                    block16: {
                                                        var2_2 = Class_bz_8cac7329.kleqM ^ 7537572510979L;
                                                        var5_3 = var1_1.boD();
                                                        var4_4 = Class_bz_8cac7329.Lh();
                                                        var6_5 = var1_1.boj();
                                                        v0 = this.LlNRn;
                                                        if (var4_4 == null) ** GOTO lbl11
                                                        if (v0 == null) {
                                                            v1 = null;
                                                        } else {
                                                            v0 = this.LlNRn;
lbl11:
                                                            // 2 sources

                                                            v1 = var7_6 = v0.boj();
                                                        }
                                                        if (var4_4 == null) break block14;
                                                        if (Objects.equals(var6_5, var7_6)) break block15;
                                                        this.LlNRn = var1_1;
                                                        this.RHgUi.clear();
                                                        this.dimez.nI();
                                                        v2 = var5_3;
                                                        if (var4_4 == null) break block16;
                                                        if (v2 == null) break block17;
                                                        v2 = var5_3;
                                                    }
                                                    if (var4_4 == null) break block18;
                                                    if (!v2.isEmpty()) break block19;
                                                }
                                                return;
                                            }
                                            v2 = var5_3;
                                        }
                                        for (Class_nf_8f40fc48 var9_9 : v2) {
                                            if (var4_4 != null) {
                                                if (var9_9 == null && var4_4 != null) continue;
                                                this.RHgUi.add(new Class_by_7f4c6e69(var1_1, var9_9));
                                            }
                                            if (var4_4 != null) continue;
                                        }
                                        return;
                                    }
                                    v3 = this;
                                    if (var4_4 == null) break block20;
                                    v3.LlNRn = var1_1;
                                }
                                if (var5_3 == null) break block21;
                                v4 = var5_3.isEmpty();
                                if (var4_4 == null) break block22;
                                if (!v4) break block23;
                            }
                            v3 = this;
                        }
                        v5 = v3.RHgUi;
                        if (var4_4 == null) break block24;
                        if (v5.isEmpty()) break block25;
                        v5 = this.RHgUi;
                    }
                    v5.clear();
                    this.dimez.nI();
                }
                return;
            }
            v4 = this.RHgUi.removeIf((Predicate<Class_by_7f4c6e69>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, La(java.util.List recovered.internal.Class_by_7f4c6e69 ), (Lrecovered/internal/Class_by_7f4c6e69;)Z)(var5_3));
        }
        for (Class_nf_8f40fc48 var9_10 : var5_3) {
            block26: {
                block27: {
                    if (var9_10 == null && var4_4 != null) continue;
                    v6 = var10_11 = this.Kw(var9_10);
                    if (var4_4 == null) break block26;
                    if (v6 != null) break block27;
                    this.RHgUi.add(new Class_by_7f4c6e69(var1_1, var9_10));
                    if (var4_4 != null) break block26;
                }
                var10_11.JS(var1_1);
                v6 = var10_11.IU(var9_10);
            }
            if (var4_4 != null) continue;
        }
    }

    private void Ku(Class_lC_5322e8cf class_lC_5322e8cf) {
        block11: {
            float f;
            Object object32;
            String string;
            float[] fArray;
            float[] fArray2;
            int n;
            float f2;
            float f3;
            int n2;
            block10: {
                long l = kleqM ^ 0x152A57EBF0F6L;
                n2 = 2;
                f3 = 5.0f;
                f2 = (this.mbChM.bXH() - f3 * (float)(n2 - 1)) / (float)n2;
                n = this.RHgUi.size();
                fArray2 = new float[n];
                fArray = new float[n];
                float[] fArray3 = new float[n2];
                int[] nArray = new int[n2];
                string = Class_bz_8cac7329.Lh();
                for (int i = 0; i < n; ++i) {
                    float f4;
                    Object object2 = this.RHgUi.get(i);
                    ((Class_az_a4990dcf)object2).tn(f2);
                    int n3 = i % n2;
                    if (nArray[n3] > 0) {
                        int n4 = n3;
                        fArray3[n4] = fArray3[n4] + f3;
                    }
                    fArray2[i] = f4 = ((Class_by_7f4c6e69)object2).dn();
                    fArray[i] = fArray3[n3];
                    int n5 = n3;
                    fArray3[n5] = fArray3[n5] + f4;
                    int n6 = n3;
                    nArray[n6] = nArray[n6] + 1;
                    if (string != null) continue;
                }
                float f5 = 0.0f;
                for (Object object32 : fArray3) {
                    f = Math.max(f5, (float)object32);
                    if (string != null) {
                        f5 = f;
                        if (string != null) continue;
                    }
                    break block10;
                }
                f = f5 - this.mbChM.bXI();
            }
            float f6 = f;
            double d = Math.max(0.0f, f6);
            float f4 = f6;
            if (string != null) {
                if (f4 > 0.0f) {
                    d += 8.0;
                }
                this.dimez.nQ(d);
                this.dimez.nG();
                Class_jG_69891630.bHI(class_lC_5322e8cf, this.mbChM);
                f4 = (float)this.dimez.nH();
            }
            object32 = f4;
            for (int i = 0; i < n; ++i) {
                int n7 = i % n2;
                float f8 = this.mbChM.bXF() + (float)n7 * (f2 + f3);
                float f9 = this.mbChM.bXG() + fArray[i] - object32;
                Class_by_7f4c6e69 class_by_7f4c6e69 = this.RHgUi.get(i);
                class_by_7f4c6e69.tn(f2);
                Class_by_7f4c6e69 class_by_7f4c6e692 = class_by_7f4c6e69;
                if (string != null) {
                    class_by_7f4c6e692.tG(f8, f9);
                    if (string == null) break block11;
                    if (!Class_jG_69891630.bHX(f8, f9, f2, fArray2[i]) && string != null) continue;
                    class_by_7f4c6e692 = class_by_7f4c6e69;
                }
                class_by_7f4c6e692.su(class_lC_5322e8cf);
                if (string != null) continue;
            }
            Class_jG_69891630.bHN();
        }
    }

    /*
     * Exception decompiling
     */
    private void Kt(Class_iy_c88c0f4f var1_1, Class_nf_8f40fc48 var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static /* synthetic */ boolean La(List list, Class_by_7f4c6e69 class_by_7f4c6e69) {
        long l = kleqM ^ 0x7DBA0DA51561L;
        String string = Class_bz_8cac7329.Lh();
        boolean bl = class_by_7f4c6e69.JN();
        if (string != null) {
            if (bl) {
                return false;
            }
            bl = list.contains(class_by_7f4c6e69.Js());
        }
        if (string != null) {
            bl = !bl;
        }
        return bl;
    }

    private Class_by_7f4c6e69 Kw(Class_nf_8f40fc48 class_nf_8f40fc48) {
        long l = kleqM ^ 0x78DA7002FAE7L;
        Iterator<Class_by_7f4c6e69> iterator = this.RHgUi.cmj().iterator();
        String string = Class_bz_8cac7329.Lh();
        while (iterator.hasNext()) {
            block4: {
                Class_by_7f4c6e69 class_by_7f4c6e69;
                block3: {
                    Class_by_7f4c6e69 class_by_7f4c6e692;
                    class_by_7f4c6e69 = class_by_7f4c6e692 = iterator.next();
                    if (string == null) break block3;
                    if (!Objects.equals(class_by_7f4c6e69.Js(), class_nf_8f40fc48)) break block4;
                    class_by_7f4c6e69 = class_by_7f4c6e692;
                }
                return class_by_7f4c6e69;
            }
            if (string != null) continue;
        }
        return null;
    }

    private static /* synthetic */ void Lc(Class_iy_c88c0f4f class_iy_c88c0f4f) {
        long l = kleqM ^ 0x3BFC66987CA2L;
        String string = Class_bz_8cac7329.Lh();
        if (string != null) {
            if (class_iy_c88c0f4f == null) {
                Class_cN_30b69d20.XI((String)((Object)Class_bz_8cac7329.Lm("c", (int)27259, (long)(0x3756FFA5849C2B23L ^ l))));
                return;
            }
            ClientMain.dlO().bqc(class_iy_c88c0f4f);
            Class_cN_30b69d20.XG((String)((Object)Class_bz_8cac7329.Lm("c", (int)28745, (long)(0x6E950073B24C3115L ^ l))));
        }
    }

    private static MatchException Li(MatchException matchException) {
        return matchException;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void Kp(Class_lC_5322e8cf var1_1, Class_ii_9b427eda var2_2, float var3_3) {
        block7: {
            block6: {
                block5: {
                    var4_4 = Class_bz_8cac7329.kleqM ^ 79474065778805L;
                    Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, var3_3);
                    v0 = Class_bz_8cac7329.Lh();
                    Class_jH_c1172273.bId(var1_1, this.DZWUG.bXF() + this.DZWUG.bXH() / 2.0f, this.DZWUG.bXG() + this.DZWUG.bXI() / 2.0f, this.sf());
                    var1_1.cej(this.DZWUG.bXF(), this.DZWUG.bXG(), this.DZWUG.bXH(), this.DZWUG.bXI(), 5.0f, Class_ld_bb1690e1.all(11.0f), var3_3);
                    var1_1.cdm(this.DZWUG.bXF(), this.DZWUG.bXG(), this.DZWUG.bXH(), this.DZWUG.bXI(), 5.0f, Class_ld_bb1690e1.all(6.0f + 5.0f * var3_3), var2_2.bjd().coa(255.0f * var3_3).coc(var2_2.bje(), 0.3f).coc(var2_2.bjd().cob(0.75f), var3_3));
                    var7_5 = ClientMain.dlV().bnM();
                    var6_6 = v0;
                    v1 = var7_5;
                    if (var6_6 == null) ** GOTO lbl15
                    if (v1 == null) {
                        v2 /* !! */  = Optional.empty();
                    } else {
                        v1 = var7_5;
lbl15:
                        // 2 sources

                        v2 /* !! */  = var8_7 = v1.bmP();
                    }
                    if (var6_6 == null) break block5;
                    if (!var8_7.isEmpty()) break block6;
                    this.Kx();
                    this.vhydZ.sZ(this.DZWUG);
                    this.vhydZ.su(var1_1);
                }
                if (var6_6 != null) break block7;
            }
            this.Kr(var1_1, var8_7.get());
        }
        Class_jH_c1172273.bIf();
        Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, 1.0f);
    }

    private static CallSite Lp(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bz_8cac7329" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static /* synthetic */ boolean Ld(Class_nf_8f40fc48 class_nf_8f40fc48, Class_nf_8f40fc48 class_nf_8f40fc482) {
        long l = kleqM ^ 0x3E2CBF080043L;
        return class_nf_8f40fc482 == class_nf_8f40fc48;
    }

    /*
     * Unable to fully structure code
     */
    private void Ko() {
        block25: {
            block31: {
                block29: {
                    block30: {
                        block28: {
                            block27: {
                                block26: {
                                    block20: {
                                        block21: {
                                            block24: {
                                                block22: {
                                                    block23: {
                                                        block13: {
                                                            block15: {
                                                                block14: {
                                                                    var1_1 = Class_bz_8cac7329.kleqM ^ 68207306208302L;
                                                                    var4_2 = this.Kz();
                                                                    var3_3 = Class_bz_8cac7329.Lh();
                                                                    v0 = var4_2.isEmpty();
                                                                    if (var3_3 != null) {
                                                                        v0 = v0 == false;
                                                                    }
                                                                    var5_4 = v0;
                                                                    var6_5 = 140.0f;
                                                                    var7_6 = 10.0f;
                                                                    v1 = var5_4;
                                                                    if (var3_3 == null) break block14;
                                                                    if (v1) ** GOTO lbl-1000
                                                                    v1 = this.OwOuM;
                                                                }
                                                                if (var3_3 == null) break block15;
                                                                if (v1) ** GOTO lbl-1000
                                                                v1 = this.aXfUv;
                                                            }
                                                            if (v1) lbl-1000:
                                                            // 3 sources

                                                            {
                                                                v2 = (var6_5 + var7_6) / 2.0f;
                                                            } else {
                                                                v2 = 0.0f;
                                                            }
                                                            var8_7 = v2;
                                                            var9_8 = this.PrMWO.dhd(var8_7);
                                                            var10_9 = Class_rm_d861be3b.diq();
                                                            var11_10 = var10_9.x / 2.0f - this.DZWUG.bXH() / 2.0f - var9_8;
                                                            var12_11 = var10_9.y / 2.0f - this.DZWUG.bXI() / 2.0f;
                                                            this.DZWUG.bXt(var11_10, var12_11);
                                                            this.aZGpn.bXt(var11_10, this.DZWUG.bXA() + 7.0f);
                                                            this.mbChM.bXt(var11_10 + 8.0f, var12_11 + 8.0f);
                                                            var13_12 = this.DZWUG.bXz() + var7_6;
                                                            var14_13 = this.DZWUG.bXG();
                                                            var15_14 = this.DZWUG.bXI() + 10.0f + this.aZGpn.bXI();
                                                            for (Class_aj_95d0a719 var17_16 : var4_2) {
                                                                block18: {
                                                                    block19: {
                                                                        block16: {
                                                                            block17: {
                                                                                v3 = var17_16 instanceof Class_bt_551ea435;
                                                                                if (var3_3 == null) break block13;
                                                                                if (var3_3 == null) break block16;
                                                                                if (!v3) break block17;
                                                                                var18_17 = (Class_bt_551ea435)var17_16;
                                                                                var18_17.HB(var13_12, var14_13, var15_14);
                                                                                if (var3_3 != null) break block18;
                                                                            }
                                                                            v4 = var17_16;
                                                                            if (var3_3 == null) break block19;
                                                                            v5 = v4 instanceof Class_br_e9f7a55a;
                                                                        }
                                                                        if (!v5) break block18;
                                                                        v4 = var17_16;
                                                                    }
                                                                    var19_18 = (Class_br_e9f7a55a)v4;
                                                                    var19_18.Gn(var13_12, var14_13, var15_14);
                                                                }
                                                                if (var3_3 != null) continue;
                                                            }
                                                            v3 = this.OwOuM;
                                                        }
                                                        if (var3_3 == null) break block20;
                                                        if (!v3) break block21;
                                                        v3 = var5_4;
                                                        if (var3_3 == null) break block20;
                                                        if (v3) break block21;
                                                        v3 = this.PrMWO.dho();
                                                        if (var3_3 == null) break block20;
                                                        if (!v3) break block21;
                                                        v6 = this;
                                                        if (var3_3 == null) break block22;
                                                        if (v6.LhWtM != null) break block23;
                                                        this.Ky(new Class_bt_551ea435());
                                                        if (var3_3 != null) break block24;
                                                    }
                                                    v6 = this;
                                                }
                                                v6.Ky(new Class_bt_551ea435(this.LhWtM));
                                            }
                                            this.OwOuM = false;
                                            this.LhWtM = null;
                                            if (var3_3 != null) break block25;
                                        }
                                        v3 = this.aXfUv;
                                    }
                                    if (var3_3 == null) break block26;
                                    if (!v3) break block25;
                                    v3 = var5_4;
                                }
                                if (var3_3 == null) break block27;
                                if (v3) break block25;
                                v7 = this;
                                if (var3_3 == null) break block28;
                                v3 = v7.PrMWO.dho();
                            }
                            if (!v3) break block25;
                            v7 = this;
                        }
                        if (var3_3 == null) break block29;
                        if (v7.KLjmC != null) break block30;
                        this.Ky(new Class_br_e9f7a55a());
                        if (var3_3 != null) break block31;
                    }
                    v7 = this;
                }
                v7.Ky(new Class_br_e9f7a55a(this.KLjmC));
            }
            this.aXfUv = false;
            this.KLjmC = null;
        }
    }

    private List<Class_aj_95d0a719> Kz() {
        return this.bvQae.aY(Class_aj_95d0a719.class).stream().filter(class_aj_95d0a719 -> {
            long l = kleqM ^ 0x5129B91C3CD9L;
            String string = Class_bz_8cac7329.Lh();
            boolean bl = class_aj_95d0a719 instanceof Class_bt_551ea435;
            if (string == null) return bl;
            if (bl) return true;
            bl = class_aj_95d0a719 instanceof Class_br_e9f7a55a;
            if (string == null) return bl;
            if (!bl) return false;
            return true;
        }).toList();
    }

    private static /* synthetic */ void Lb(Class_iy_c88c0f4f class_iy_c88c0f4f, Class_iy_c88c0f4f class_iy_c88c0f4f2) {
        long l = kleqM ^ 0x2812A04B1394L;
        String string = Class_bz_8cac7329.Lh();
        Class_iy_c88c0f4f class_iy_c88c0f4f3 = class_iy_c88c0f4f2;
        if (string != null) {
            if (class_iy_c88c0f4f3 == null) {
                Class_cN_30b69d20.XI((String)((Object)Class_bz_8cac7329.Lm("c", (int)1918, (long)(0x6B6D1AE3F350A911L ^ l))));
                return;
            }
            class_iy_c88c0f4f3 = class_iy_c88c0f4f.boY(class_iy_c88c0f4f2.boD());
        }
        Class_cN_30b69d20.XG((String)((Object)Class_bz_8cac7329.Lm("c", (int)22109, (long)(0x71A12B257E5F835L ^ l))));
    }

    private void Ks() {
        this.RHgUi.removeIf(var1_1 -> {
            /*
             * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
             * 
             * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
             *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
             *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1050)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
             *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
             *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
             *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
             *     at org.benf.cfr.reader.Main.main(Main.java:54)
             */
            throw new IllegalStateException("Decompilation failed");
        });
    }

    private void Kq(Class_lC_5322e8cf class_lC_5322e8cf, Class_ii_9b427eda class_ii_9b427eda, float f) {
        long l = kleqM ^ 0x7CE6F2047D78L;
        float f2 = this.OjRjG.dhj();
        String string = Class_bz_8cac7329.Lh();
        float f3 = f2;
        float f4 = 0.0f;
        if (string != null) {
            if (f3 == f4) {
                return;
            }
            f3 = f;
            f4 = f2;
        }
        float f5 = f3 * f4;
        float f6 = Class_mZ_07f59a29.csl(this.aZGpn.bXG() - 12.0f, this.aZGpn.bXG(), f2);
        Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, f5);
        class_lC_5322e8cf.cej(this.aZGpn.bXF(), f6, this.aZGpn.bXH(), this.aZGpn.bXI(), 5.0f, Class_ld_bb1690e1.all(11.0f), f);
        class_lC_5322e8cf.cdm(this.aZGpn.bXF(), f6, this.aZGpn.bXH(), this.aZGpn.bXI(), 5.0f, Class_ld_bb1690e1.all(6.0f + 5.0f * f5), class_ii_9b427eda.bjd().coa(255.0f * f5).coc(class_ii_9b427eda.bje(), 0.3f).coc(class_ii_9b427eda.bjd().cob(0.75f), f5));
        Class_jG_69891630.bHI(class_lC_5322e8cf, this.aZGpn);
        this.HDtRm.sW(this.aZGpn.bXF(), f6);
        this.HDtRm.sX(this.aZGpn.bXH(), this.aZGpn.bXI());
        this.HDtRm.su(class_lC_5322e8cf);
        Class_jG_69891630.bHN();
        Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public static String Lh() {
        return bTgYE;
    }

    public static void Lg(String string) {
        bTgYE = string;
    }

    public void Ky(Class_aj_95d0a719 class_aj_95d0a719) {
        long l = kleqM ^ 0x502D008AF7BL;
        String string = Class_bz_8cac7329.Lh();
        class_aj_95d0a719.sP(0).sT(false);
        String string2 = string;
        this.bvQae.aF(class_aj_95d0a719);
        Iterator<Class_aj_95d0a719> iterator = this.Kz().iterator();
        while (iterator.hasNext()) {
            Class_aj_95d0a719 class_aj_95d0a7192;
            Class_aj_95d0a719 class_aj_95d0a7193 = class_aj_95d0a7192 = iterator.next();
            if (string2 != null && class_aj_95d0a7193 != class_aj_95d0a719) {
                class_aj_95d0a7193 = class_aj_95d0a7192.oj(false);
            }
            if (string2 != null) continue;
        }
    }

    private void Kn(Class_lC_5322e8cf class_lC_5322e8cf) {
        Class_ii_9b427eda class_ii_9b427eda = ClientMain.dlM();
        float f = Math.min(1.0f, this.Weytw.dhj());
        this.Kp(class_lC_5322e8cf, class_ii_9b427eda, f);
        this.Kq(class_lC_5322e8cf, class_ii_9b427eda, f);
    }

    private void Kx() {
        this.LlNRn = null;
        this.RHgUi.clear();
        this.dimez.nI();
    }

    private void Kr(Class_lC_5322e8cf class_lC_5322e8cf, Class_iy_c88c0f4f class_iy_c88c0f4f) {
        block4: {
            Class_bz_8cac7329 class_bz_8cac7329;
            block2: {
                block3: {
                    long l = kleqM ^ 0x7175BF77D53FL;
                    String string = Class_bz_8cac7329.Lh();
                    this.Ks();
                    String string2 = string;
                    this.Kv(class_iy_c88c0f4f);
                    class_bz_8cac7329 = this;
                    if (string2 == null) break block2;
                    if (!class_bz_8cac7329.RHgUi.isEmpty()) break block3;
                    this.rzpmv.sZ(this.DZWUG);
                    this.rzpmv.su(class_lC_5322e8cf);
                    if (string2 != null) break block4;
                }
                class_bz_8cac7329 = this;
            }
            class_bz_8cac7329.Ku(class_lC_5322e8cf);
        }
    }

    public Class_aq_9e8149f3 KM() {
        return this.vhydZ;
    }

    public Class_az_a4990dcf KQ() {
        return this.DNlcF;
    }

    public Class_aq_9e8149f3 KN() {
        return this.rzpmv;
    }

    public Class_mu_a94f6370<Class_by_7f4c6e69> KP() {
        return this.RHgUi;
    }

    public Class_bw_21f72edc KL() {
        return this.HDtRm;
    }

    public Class_ah_02444db4 KO() {
        return this.dimez;
    }

    private static String Lj(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public boolean KT() {
        return this.aXfUv;
    }

    public Class_rk_bf8630d1 KY() {
        return this.wgnWc;
    }

    private static String Lk(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x4AE;
        if (OcNPP[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])nMXOH.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    nMXOH.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bz_8cac7329", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = BuVTR[n2].getBytes("ISO-8859-1");
            Class_bz_8cac7329.OcNPP[n2] = Class_bz_8cac7329.Lj(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return OcNPP[n2];
    }

    public Class_iy_c88c0f4f KU() {
        return this.LhWtM;
    }

    public Class_nf_8f40fc48 KV() {
        return this.KLjmC;
    }

    public Class_lc_b8480f87 KK() {
        return this.mbChM;
    }

    private static int Ln(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x580F;
        if (lmFlx[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = BMxWP[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])ugCiQ.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    ugCiQ.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bz_8cac7329", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bz_8cac7329.lmFlx[n2] = n3;
        }
        return lmFlx[n2];
    }

    public Class_lc_b8480f87 KJ() {
        return this.aZGpn;
    }

    public Class_lc_b8480f87 KI() {
        return this.DZWUG;
    }

    public Class_rk_bf8630d1 KX() {
        return this.PrMWO;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bz_8cac7329.class, "Ll", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_bz_8cac7329.class, "Lo", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

