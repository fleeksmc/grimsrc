/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.LivingEntity
 */
package recovered.internal;

import net.minecraft.entity.LivingEntity;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_hs_b35e46d0
extends Class_hH_ae8f8f77 {
    private final LivingEntity SfqRA;
    private float KXEMk;
    private float daZxT;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hs_b35e46d0(LivingEntity livingEntity, float f, float f2) {
        this.SfqRA = livingEntity;
        this.KXEMk = f;
        this.daZxT = f2;
    }

    public float bde() {
        return this.KXEMk;
    }

    public float bdf() {
        return this.daZxT;
    }

    public LivingEntity bdd() {
        return this.SfqRA;
    }

    public void bdg(float f) {
        this.KXEMk = f;
    }

    public void bdh(float f) {
        this.daZxT = f;
    }
}

