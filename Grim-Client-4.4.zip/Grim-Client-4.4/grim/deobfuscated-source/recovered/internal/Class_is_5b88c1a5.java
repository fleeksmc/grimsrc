/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.concurrent.CompletableFuture;
import recovered.core.NativeLoader;
import recovered.internal.Class_iE_00f71a81;
import recovered.internal.Class_it_6213c445;
import recovered.internal.Class_iu_bf2db566;

public class Class_is_5b88c1a5
extends Class_iE_00f71a81
implements Class_it_6213c445 {
    private static String[] ykGsx;
    private static long XJwCK;
    private static String yHmZL;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_is_5b88c1a5.class);
        Class_is_5b88c1a5._8334f049a30c12a06eb2511895198da0();
    }

    public static native String[] bmK();

    private static native MatchException bmL(MatchException var0);

    private static native String bmM(byte[] var0);

    public static native void bmJ(String[] var0);

    private static native void _8334f049a30c12a06eb2511895198da0();

    @Override
    public native CompletableFuture<Class_iu_bf2db566> fetchProfile();
}

