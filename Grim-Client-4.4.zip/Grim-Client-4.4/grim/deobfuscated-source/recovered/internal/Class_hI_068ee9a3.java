/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandle;

public record Class_hI_068ee9a3(Object source, MethodHandle target, int value) {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

