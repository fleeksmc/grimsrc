/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import net.minecraft.util.math.Vec2f;
import recovered.core.NativeLoader;
import recovered.internal.Class_ad_d4e95a2c;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_bc_sa_c60341ff;
import recovered.internal.Class_bc_sb_c78d652e;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mZ_07f59a29;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bc_f7ef99a1
extends Class_aj_95d0a719 {
    private final int[] fZkgb;
    private final int[] jEyGM;
    private final int[] rHkCQ;
    private final Class_ad_d4e95a2c UfSoS;
    private final Class_bc_sb_c78d652e[] HukvJ;
    private final Class_rk_bf8630d1 wGCjB;
    private int gXowZ;
    private static long UIUKy;
    private static String[] CKdwN;
    private static String[] foWfj;
    private static Map egBGR;
    private static long[] ZCGIw;
    private static Integer[] HkqAD;
    private static Map CcEgB;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static native /* synthetic */ float BD(Class_bc_f7ef99a1 var0);

    public Class_bc_f7ef99a1() {
        long l = UIUKy ^ 0x1B1440D561A9L;
        this.fZkgb = Class_mZ_07f59a29.csh((String)((Object)Class_bc_f7ef99a1.BK("f", (int)14155, (long)(0x6EA5391802432842L ^ l))));
        this.jEyGM = Class_mZ_07f59a29.csh((String)((Object)Class_bc_f7ef99a1.BK("f", (int)5930, (long)(0x2CFA42ACD5C40820L ^ l))));
        this.rHkCQ = Class_mZ_07f59a29.csh((String)((Object)Class_bc_f7ef99a1.BK("f", (int)2664, (long)(0x2130278349869563L ^ l))));
        this.HukvJ = new Class_bc_sb_c78d652e[Class_bc_f7ef99a1.BN("k", (int)25163, (long)(0x20A3CB2A80991D29L ^ l))];
        this.gXowZ = -1;
        Class_lc_b8480f87 class_lc_b8480f87 = Class_bl_a15fbaa5.Ex().Ey();
        Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(9.0f);
        this.bQoPs = 5.0f;
        this.BcpIo = class_lc_b8480f87.bXH() / 2.25f;
        this.WjISQ = class_lq_87a74641.caw() * 2.0f + this.bQoPs * 2.0f;
        float f = class_lc_b8480f87.bXF() + Class_jf_d1c4f950.bAH(this.BcpIo, class_lc_b8480f87.bXH());
        float f2 = class_lc_b8480f87.bXG() - this.bQoPs * 2.0f;
        this.MCnYt = f;
        this.pNyTQ = f2;
        this.UfSoS = new Class_ad_d4e95a2c(Class_lE_06fbe260.WTzbi.bYM(9.0f));
        this.UfSoS.lZ((String)((Object)Class_bc_f7ef99a1.BK("f", (int)27198, (long)(0x72D2A946419D7536L ^ l))));
        this.UfSoS.me((int)Class_bc_f7ef99a1.BN("k", (int)5575, (long)(0xE5EB661F9C0EAA6L ^ l)));
        this.UfSoS.mg(this::Br);
        this.wGCjB = new Class_rk_bf8630d1((int)Class_bc_f7ef99a1.BN("k", (int)13217, (long)(0x13CAEEA2C0D3CCC2L ^ l)), this.WjISQ).dhs(Class_rj_b691f4f7.NJlxm);
    }

    static {
        NativeLoader.doInit(Class_bc_f7ef99a1.class);
        Class_bc_f7ef99a1._c3587351bd7b3f25ef6a6c2432b254b1();
    }

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    static native /* synthetic */ float BE(Class_bc_f7ef99a1 var0);

    static native /* synthetic */ Class_rk_bf8630d1 BC(Class_bc_f7ef99a1 var0);

    @Override
    public native boolean dm(int var1, int var2, int var3);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private static native void _c3587351bd7b3f25ef6a6c2432b254b1();

    private static native CallSite BN(MethodHandles.Lookup var0, String var1, MethodType var2);

    @Override
    public native boolean eK(char var1);

    private native /* synthetic */ void BB(Class_lC_5322e8cf var1);

    public native Class_ad_d4e95a2c Bv();

    public native Class_rk_bf8630d1 Bx();

    public native int By();

    private static native int BL(int var0, long var1);

    private static native String BH(byte[] var0);

    private static native CallSite BK(MethodHandles.Lookup var0, String var1, MethodType var2);

    static native /* synthetic */ float BF(Class_bc_f7ef99a1 var0);

    private static native /* synthetic */ boolean Bz(Vec2f var0, Class_bc_sb_c78d652e var1);

    private static native MatchException BG(MatchException var0);

    public native int[] Bt();

    private static native /* synthetic */ int BA(Class_bc_sa_c60341ff var0, Class_bc_sa_c60341ff var1);

    public native int[] Bu();

    private static native String BI(int var0, long var1);

    private static native Object BJ(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public native Class_bc_sb_c78d652e[] Bw();

    public native int[] Bs();

    private static native int BM(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native void Br();
}

