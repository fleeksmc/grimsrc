/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.MathHelper
 */
package recovered.internal;

import net.minecraft.util.math.MathHelper;

public final class Class_kA_55f27465 {
    private static float oYWsU;
    private static float BBpyW;
    private static String wtYmY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        if (Class_kA_55f27465.bSv() == null) {
            Class_kA_55f27465.bSu("DFjU2b");
        }
    }

    public static float bSt(float f) {
        return MathHelper.lerp((float)f, (float)oYWsU, (float)BBpyW);
    }

    public static void bSu(String string) {
        wtYmY = string;
    }

    public static String bSv() {
        return wtYmY;
    }

    public static void bSs(float f) {
        oYWsU = BBpyW;
        BBpyW += f;
    }
}

