/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.util.math.Vec3d;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_mT_db06bea0;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

class Class_dh_sz_cf3a7413 {
    Vec3d vxPfu;
    Vec3d euQyK;
    Vec3d AbOcV;
    Vec3d zgdiH;
    Vec3d aoOwi;
    Vec3d FoYEg;
    long JoZky;
    float uTzzU;
    boolean WWClU;
    Class_mT_db06bea0 jYAnc;
    Class_rk_bf8630d1 JiVPB;
    private static final long lQGTL = Class_gb_9d201141.aYR(-1412005196320346377L, 1304572542534617863L, MethodHandles.lookup().lookupClass()).a(151037727181724L);
    private static final long IWwlL;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_dh_sz_cf3a7413(Vec3d vec3d, Vec3d vec3d2, Vec3d vec3d3, Vec3d vec3d4, long l, float f) {
        long l2 = lQGTL ^ 0x1293FA5AABBBL;
        this.WWClU = false;
        this.jYAnc = Class_mT_db06bea0.cpz();
        this.JiVPB = new Class_rk_bf8630d1((int)IWwlL).dhs(Class_rj_b691f4f7.UPXqT);
        this.vxPfu = vec3d;
        this.euQyK = vec3d2;
        this.aoOwi = vec3d3.multiply((double)0.04f);
        this.FoYEg = vec3d4.multiply((double)0.04f);
        this.JoZky = l;
        this.uTzzU = f;
        this.zgdiH = vec3d2;
        this.AbOcV = vec3d;
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = lQGTL ^ 0x7F2D7980976L;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                long l2 = 1077618560853009042L;
                byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
                IWwlL = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    void doB() {
        this.AbOcV = this.vxPfu;
        this.zgdiH = this.euQyK;
        this.vxPfu = this.vxPfu.add(this.aoOwi);
        this.euQyK = this.euQyK.add(this.FoYEg);
        this.aoOwi = this.aoOwi.multiply(0.98);
        this.FoYEg = this.FoYEg.multiply(0.98);
    }
}

