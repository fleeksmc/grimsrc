/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;

public final class Class_h_rH_195350c3
extends Enum<Class_h_rH_195350c3> {
    public static final /* enum */ Class_h_rH_195350c3 bktbd;
    public static final /* enum */ Class_h_rH_195350c3 GxiIK;
    private static final Class_h_rH_195350c3[] rhyQj;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static Class_h_rH_195350c3[] dmB() {
        return new Class_h_rH_195350c3[]{bktbd, GxiIK};
    }

    private static String dmC(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = Class_gb_9d201141.aYR(4006739308957434599L, -8543177723033228369L, MethodHandles.lookup().lookupClass()).a(22456261100548L) ^ 0x58D646ABD68BL;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[2];
        int n = 0;
        String string = "\u00b6\u00d9\u0084\u000e\u00e2'\u00b5\u00a0\u00128'+\u0003\u00b8&\u000b\u0010\u00ac\u00ac\u00d3l$0o\u00bd.0\u0007\u0016I\u00fbP\u00ed";
        int n2 = "\u00b6\u00d9\u0084\u000e\u00e2'\u00b5\u00a0\u00128'+\u0003\u00b8&\u000b\u0010\u00ac\u00ac\u00d3l$0o\u00bd.0\u0007\u0016I\u00fbP\u00ed".length();
        int n3 = 16;
        int n4 = -1;
        while (true) {
            int n5 = ++n4;
            byte[] byArray3 = cipher.doFinal(string.substring(n5, n5 + n3).getBytes("ISO-8859-1"));
            stringArray[n++] = Class_h_rH_195350c3.dmC(byArray3).intern();
            if ((n4 += n3) >= n2) {
                bktbd = new Class_h_rH_195350c3();
                GxiIK = new Class_h_rH_195350c3();
                rhyQj = Class_h_rH_195350c3.dmB();
                return;
            }
            n3 = string.charAt(n4);
        }
    }

    public static Class_h_rH_195350c3[] values() {
        return (Class_h_rH_195350c3[])rhyQj.clone();
    }

    public static Class_h_rH_195350c3 valueOf(String string) {
        return Enum.valueOf(Class_h_rH_195350c3.class, string);
    }
}

