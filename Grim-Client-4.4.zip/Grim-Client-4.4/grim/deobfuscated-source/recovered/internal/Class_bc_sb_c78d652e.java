/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bc_f7ef99a1;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;

class Class_bc_sb_c78d652e
extends Class_az_a4990dcf {
    private final Object bAjVG;
    private final Class_cB_67aec11c ghlhU;
    private final int[] hhZmz;
    private final int[] jLLoD;
    private final int[] whbju;
    final Class_bc_f7ef99a1 fJevp;
    private static long ENaeo;
    private static String LgTly;
    private static long aupXC;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bc_sb_c78d652e(Class_bc_f7ef99a1 class_bc_f7ef99a1, Object object, Class_cB_67aec11c class_cB_67aec11c, int[] nArray, int[] nArray2, int[] nArray3) {
        this.fJevp = class_bc_f7ef99a1;
        this.bAjVG = object;
        this.ghlhU = class_cB_67aec11c;
        this.hhZmz = nArray;
        this.jLLoD = nArray2;
        this.whbju = nArray3;
    }

    static {
        NativeLoader.doInit(Class_bc_sb_c78d652e.class);
        Class_bc_sb_c78d652e._5ba714509a8f0b92bcd19ff33b74b026();
    }

    @Override
    public native boolean dm(int var1, int var2, int var3);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private static native void _5ba714509a8f0b92bcd19ff33b74b026();

    private static native MatchException dnh(MatchException var0);

    private native void dng();

    private native boolean dnf();

    private static native String dni(byte[] var0);
}

