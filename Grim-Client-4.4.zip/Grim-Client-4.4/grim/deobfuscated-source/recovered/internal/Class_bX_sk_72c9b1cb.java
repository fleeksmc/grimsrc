/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.text.Text
 */
package recovered.internal;

import net.minecraft.text.Text;

record Class_bX_sk_72c9b1cb(Text name, Text score, int scoreWidth) {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

