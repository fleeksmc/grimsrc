/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import recovered.core.NativeLoader;
import recovered.internal.Class_hL_db8a30f6;
import recovered.internal.Class_hM_a36d442e;
import recovered.internal.Class_hW_98f65112;
import recovered.internal.Class_hZ_076851ce;

public final class Class_hY_45e5cf97 {
    private final List<String> huuGZ;
    private String esozW;
    private final List<Class_hM_a36d442e<?>> YGIZc;
    private final List<Class_hZ_076851ce> yrZSL;
    private boolean bfJkD;
    private Class_hW_98f65112 vFrMb;
    private static String FjqAL;
    private static long nERmS;
    private static String[] RYRfJ;
    private static String[] uJbis;
    private static Map bgxIp;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_hY_45e5cf97(String string) {
        long l = nERmS ^ 0x425CD004E9C2L;
        this.huuGZ = new ArrayList<String>();
        this.esozW = "";
        this.YGIZc = new ArrayList();
        this.yrZSL = new ArrayList<Class_hZ_076851ce>();
        this.bfJkD = true;
        this.huuGZ.add(Objects.requireNonNull(string, (String)((Object)Class_hY_45e5cf97.bgt("n", (int)4008, (long)(0x719FB42A95BC1EC5L ^ l)))));
    }

    static {
        NativeLoader.doInit(Class_hY_45e5cf97.class);
        Class_hY_45e5cf97._e7aab09eec9026eec250230f05631b70();
    }

    public static native Class_hY_45e5cf97 bge(String var0);

    public native Class_hZ_076851ce bgm();

    public native Class_hY_45e5cf97 bgj(Class_hZ_076851ce var1);

    public native Class_hY_45e5cf97 bgl(Class_hW_98f65112 var1);

    public static native void bgn(String var0);

    public static native String bgo();

    private static native IllegalStateException bgp(IllegalStateException var0);

    private static native String bgr(int var0, long var1);

    private static native String bgq(byte[] var0);

    private static native Object bgs(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite bgt(MethodHandles.Lookup var0, String var1, MethodType var2);

    public static native Class_hY_45e5cf97 bgf(String var0, Consumer<Class_hY_45e5cf97> var1);

    public native Class_hY_45e5cf97 bgg(String ... var1);

    public native <T> Class_hY_45e5cf97 bgi(String var1, Consumer<Class_hL_db8a30f6<T>> var2);

    public native Class_hY_45e5cf97 bgh(String var1);

    public native Class_hY_45e5cf97 bgk();

    private static native void _e7aab09eec9026eec250230f05631b70();
}

