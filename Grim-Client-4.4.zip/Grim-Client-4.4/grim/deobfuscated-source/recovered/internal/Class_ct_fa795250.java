/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 */
package recovered.internal;

import com.google.gson.JsonElement;
import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_cu_7306ec45;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mr_7eac5189;

public class Class_ct_fa795250
extends Class_cB_67aec11c {
    private final List<Class_cu_7306ec45> kwiHL;
    private int kErPl;
    private static Class_iS_888f260e[] qAFpE;
    private static final long moIkZ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public int ST() {
        return this.kErPl;
    }

    public Class_ct_fa795250(Class_mr_7eac5189 class_mr_7eac5189) {
        block0: {
            long l = moIkZ ^ 0x17E6F811B103L;
            Class_iS_888f260e[] class_iS_888f260eArray = Class_ct_fa795250.SW();
            super(class_mr_7eac5189);
            Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
            this.kwiHL = new ArrayList<Class_cu_7306ec45>();
            this.kErPl = 0;
            if (Class_iS_888f260e.bwL() != null) break block0;
            Class_ct_fa795250.SV(new Class_iS_888f260e[3]);
        }
    }

    public Class_ct_fa795250(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    static {
        moIkZ = Class_gb_9d201141.aYR(7043047839429379363L, -5324473541524081038L, MethodHandles.lookup().lookupClass()).a(52170070807811L);
        if (Class_ct_fa795250.SW() == null) {
            Class_ct_fa795250.SV(new Class_iS_888f260e[2]);
        }
    }

    public static Class_iS_888f260e[] SW() {
        return qAFpE;
    }

    @Override
    public void SS(JsonElement jsonElement) {
        int n;
        block4: {
            block3: {
                int n2;
                block2: {
                    long l = moIkZ ^ 0x76451EC4E465L;
                    n = jsonElement.getAsInt();
                    Class_iS_888f260e[] class_iS_888f260eArray = Class_ct_fa795250.SW();
                    n2 = n;
                    if (class_iS_888f260eArray == null) break block2;
                    if (n2 < 0) break block3;
                    n2 = n;
                }
                if (n2 < this.kwiHL.size()) break block4;
            }
            return;
        }
        this.SN(n);
    }

    @Override
    public void SR(Map<String, Object> map) {
        map.put(Arrays.toString(this.NwlSF), this.kErPl);
    }

    public static void SV(Class_iS_888f260e[] class_iS_888f260eArray) {
        qAFpE = class_iS_888f260eArray;
    }

    private static MatchException SX(MatchException matchException) {
        return matchException;
    }

    public Class_cu_7306ec45 SL() {
        return this.kwiHL.get(this.kErPl);
    }

    public int[] SM() {
        return this.kwiHL.get(this.kErPl).Tb();
    }

    public boolean SP(Class_cu_7306ec45 class_cu_7306ec45) {
        long l = moIkZ ^ 0x3016DB78E54EL;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_ct_fa795250.SW();
        int n = this.kErPl;
        if (class_iS_888f260eArray != null) {
            n = n == this.kwiHL.indexOf(class_cu_7306ec45) ? 1 : 0;
        }
        return n != 0;
    }

    public List<Class_cu_7306ec45> SU() {
        return this.kwiHL;
    }

    public void SN(int n) {
        long l = moIkZ ^ 0x2CA2B809E166L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_ct_fa795250.SW();
        Class_ct_fa795250 class_ct_fa795250 = this;
        if (class_iS_888f260eArray != null) {
            if (class_ct_fa795250.kErPl == n) {
                return;
            }
            this.kErPl = n;
            class_ct_fa795250 = this;
        }
        class_ct_fa795250.Vk();
    }

    public boolean SQ(int n) {
        long l = moIkZ ^ 0x3D343AB6EDD4L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_ct_fa795250.SW();
        int n2 = this.kErPl;
        if (class_iS_888f260eArray != null) {
            n2 = n2 == n ? 1 : 0;
        }
        return n2 != 0;
    }

    public Class_ct_fa795250 SO(int n) {
        this.SN(n);
        return this;
    }
}

