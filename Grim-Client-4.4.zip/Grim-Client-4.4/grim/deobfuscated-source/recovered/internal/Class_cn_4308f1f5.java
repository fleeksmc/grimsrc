/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_cr_3ba4ae18;
import recovered.internal.Class_cv_f4b0140a;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lG_79349165;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mr_7eac5189;

public abstract class Class_cn_4308f1f5
extends Class_cr_3ba4ae18
implements Class_lG_79349165 {
    protected Class_cv_f4b0140a ZpVra;
    protected boolean bwIta;
    private static final long pgClt;
    private static final long[] wCpej;
    private static final Integer[] Xqssr;
    private static final Map myifd;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cn_4308f1f5(int[] nArray, Class_lf_d247d983 class_lf_d247d983) {
        long l = pgClt ^ 0x77040A6B4705L;
        super(nArray, class_lf_d247d983);
        int[] nArray2 = new int[Class_cn_4308f1f5.QV("x", (int)23009, (long)(0x474FABB0636BA18BL ^ l))];
        nArray2[0] = (int)Class_cn_4308f1f5.QV("x", (int)26978, (long)(0x1C5781796C209100L ^ l));
        nArray2[1] = (int)Class_cn_4308f1f5.QV("x", (int)31218, (long)(0x7C8DD25199500193L ^ l));
        nArray2[2] = (int)Class_cn_4308f1f5.QV("x", (int)32758, (long)(0x7FFB613E7AF8798L ^ l));
        nArray2[3] = (int)Class_cn_4308f1f5.QV("x", (int)28964, (long)(0x1D62AF6F61AD895AL ^ l));
        nArray2[4] = (int)Class_cn_4308f1f5.QV("x", (int)7278, (long)(0x412B927AE3EDE40BL ^ l));
        nArray2[5] = (int)Class_cn_4308f1f5.QV("x", (int)13797, (long)(0x314F08B9DA09CD98L ^ l));
        nArray2[Class_cn_4308f1f5.QV("x", (int)3400, (long)(0x456DB8E536597537L ^ l))] = (int)Class_cn_4308f1f5.QV("x", (int)25201, (long)(0x1B24F0B26829A19L ^ l));
        nArray2[Class_cn_4308f1f5.QV("x", (int)28162, (long)(0x69449837CF911665L ^ l))] = (int)Class_cn_4308f1f5.QV("x", (int)21034, (long)(0x29F568279D3D2A49L ^ l));
        this.ZpVra = new Class_cv_f4b0140a(this, Class_mr_7eac5189.clS(nArray2)).Tm(1).Tl(true);
    }

    public Class_cn_4308f1f5(int[] nArray, Class_lf_d247d983 class_lf_d247d983, boolean bl) {
        long l = pgClt ^ 0xB69293D7B57L;
        super(nArray, class_lf_d247d983);
        int[] nArray2 = new int[Class_cn_4308f1f5.QV("x", (int)12655, (long)(0x387AEF827113F559L ^ l))];
        nArray2[0] = (int)Class_cn_4308f1f5.QV("x", (int)14497, (long)(0x57185EF84CF5FC8FL ^ l));
        nArray2[1] = (int)Class_cn_4308f1f5.QV("x", (int)12842, (long)(0x31B1A88E8FC07611L ^ l));
        nArray2[2] = (int)Class_cn_4308f1f5.QV("x", (int)7278, (long)(0x412BEE17C0BBD859L ^ l));
        nArray2[3] = (int)Class_cn_4308f1f5.QV("x", (int)27754, (long)(0x5C478C9061392855L ^ l));
        nArray2[4] = (int)Class_cn_4308f1f5.QV("x", (int)7278, (long)(0x412BEE17C0BBD859L ^ l));
        nArray2[5] = (int)Class_cn_4308f1f5.QV("x", (int)30522, (long)(0x5B5D28D8E7ACB307L ^ l));
        nArray2[Class_cn_4308f1f5.QV("x", (int)21400, (long)(0x7EF727E5143E17A6L ^ l))] = (int)Class_cn_4308f1f5.QV("x", (int)1591, (long)(0x4ECE29BB3DDAC205L ^ l));
        nArray2[Class_cn_4308f1f5.QV("x", (int)9741, (long)(0x2A4320222F64E234L ^ l))] = (int)Class_cn_4308f1f5.QV("x", (int)29654, (long)(0x6A7C8964404BB7E2L ^ l));
        this.ZpVra = new Class_cv_f4b0140a(this, Class_mr_7eac5189.clS(nArray2)).Tm(1).Tl(true);
        this.bwIta = bl;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_cn_4308f1f5.pgClt = Class_gb_9d201141.aYR(-7849409131986101059L, 8932095221979411149L, MethodHandles.lookup().lookupClass()).a(272723144141615L);
                Class_cn_4308f1f5.myifd = new HashMap<K, V>(13);
                var0 = Class_cn_4308f1f5.pgClt ^ 35969654478808L;
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[20];
                var5_4 = 0;
                var6_5 = "\u0086}\u0014\u0082>\u000ea\u00e5\u00fd\u00f1\u0010Q\u00aa\u00e2\u0019\u008c\u00aa0Q\u00f7\u00b7\u008d\u00ff\u00da\u001dX\u00f6\u00cc|\u00c3\u00ce\u0016\u0007Q#f\u008a\u00c5\u0000\u0014\u00f9\u00ba6\u00f6\u00eb\u00e1\u00ce\u00ee*\u00886\n\u00b5l\u00c0Z\u00afF\u008b\u00f4A~\u00f1\u009b1>\u00c2L\u00eb\u00e8$M\u00d7g\u00b2\u00ef\u00e3\u0085\b\u00bc\u0011\u00cb(u*\u00fa8J2\u0095\u0001%kV\u0091\u00a8\u00fc\u0016`VTC\u0018K\u00c8v\u0000\u00bdYC7\u00d21>\"\u00cf\u00b5\u0086\u001f\u0091\u0012~\u0002\u008c\u00de\u00a3\"\u000e\u00bdnHr,|\u009akD>\rT\u00cb\u00b4\\\u008c";
                var7_6 = "\u0086}\u0014\u0082>\u000ea\u00e5\u00fd\u00f1\u0010Q\u00aa\u00e2\u0019\u008c\u00aa0Q\u00f7\u00b7\u008d\u00ff\u00da\u001dX\u00f6\u00cc|\u00c3\u00ce\u0016\u0007Q#f\u008a\u00c5\u0000\u0014\u00f9\u00ba6\u00f6\u00eb\u00e1\u00ce\u00ee*\u00886\n\u00b5l\u00c0Z\u00afF\u008b\u00f4A~\u00f1\u009b1>\u00c2L\u00eb\u00e8$M\u00d7g\u00b2\u00ef\u00e3\u0085\b\u00bc\u0011\u00cb(u*\u00fa8J2\u0095\u0001%kV\u0091\u00a8\u00fc\u0016`VTC\u0018K\u00c8v\u0000\u00bdYC7\u00d21>\"\u00cf\u00b5\u0086\u001f\u0091\u0012~\u0002\u008c\u00de\u00a3\"\u000e\u00bdnHr,|\u009akD>\rT\u00cb\u00b4\\\u008c".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl26:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = "\u00a5\u0005\u008f\u00db\u00a4<\u00eaW\u00b7:A\u00ba\u00a9\u00a4x\u0099";
                    var7_6 = "\u00a5\u0005\u008f\u00db\u00a4<\u00eaW\u00b7:A\u00ba\u00a9\u00a4x\u0099".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl52:
                // 1 sources

                ** continue;
            }
        }
        Class_cn_4308f1f5.wCpej = var8_3;
        Class_cn_4308f1f5.Xqssr = new Integer[20];
    }

    private static int QU(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_cn_4308f1f5.QT(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    /*
     * Exception decompiling
     */
    @Override
    protected void NV(Class_lC_5322e8cf var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        this.Xtjvx = 18.0f;
        super.LX(class_lC_5322e8cf);
    }

    private static MatchException QS(MatchException matchException) {
        return matchException;
    }

    private static int QT(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x38D2;
        if (Xqssr[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = wCpej[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])myifd.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    myifd.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cn_4308f1f5", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_cn_4308f1f5.Xqssr[n2] = n3;
        }
        return Xqssr[n2];
    }

    private static CallSite QV(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cn_4308f1f5" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cn_4308f1f5.class, "QU", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

