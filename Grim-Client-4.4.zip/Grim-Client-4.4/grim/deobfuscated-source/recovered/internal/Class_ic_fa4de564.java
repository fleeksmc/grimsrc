/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_ij_d7bf2301;
import recovered.internal.Class_iu_bf2db566;

public interface Class_ic_fa4de564 {
    public CompletableFuture<Class_ij_d7bf2301> createTheme(Class_ig_ca326427 var1);

    public CompletableFuture<List<Class_ij_d7bf2301>> fetchThemes();

    public CompletableFuture<Class_iu_bf2db566> deleteTheme(String var1);

    public CompletableFuture<Class_iu_bf2db566> importTheme(String var1);

    public CompletableFuture<Class_ij_d7bf2301> fetchTheme(String var1);

    public CompletableFuture<Class_iu_bf2db566> loadTheme(Class_ig_ca326427 var1);
}

