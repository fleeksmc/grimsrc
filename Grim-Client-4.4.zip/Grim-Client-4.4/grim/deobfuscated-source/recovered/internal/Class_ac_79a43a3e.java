/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_ac_rM_8a33ea18;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mZ_07f59a29;

public class Class_ac_79a43a3e
extends Class_az_a4990dcf {
    private final int[] RETKy;
    private Class_lq_87a74641 QihaT = Class_lE_06fbe260.SVnNc.bYM(8.0f);
    private int[] OpPmd;
    private Class_lq_87a74641 dEwPE = Class_lE_06fbe260.ePKsc.bYM(6.0f);
    private Class_ac_rM_8a33ea18 rHoip = Class_ac_rM_8a33ea18.WpzHJ;
    private Class_lf_d247d983 PdJLB;
    private float BkqcE = 6.0f;
    private Class_mG_52c8d386 rutmI = null;
    private Class_mG_52c8d386 WITgX = null;
    private static long NmAXG;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ac_79a43a3e(int[] nArray) {
        this.RETKy = nArray;
    }

    public Class_ac_79a43a3e(String string) {
        this.RETKy = Class_mZ_07f59a29.csh(string);
    }

    static {
        NativeLoader.doInit(Class_ac_79a43a3e.class);
        Class_ac_79a43a3e._02bd1d3bd637361662bfc18f5ab75acb();
    }

    public native Class_ac_79a43a3e lr(Class_ac_rM_8a33ea18 var1);

    @Override
    public native float dn();

    public native Class_ac_79a43a3e lo(String var1);

    public native Class_ac_79a43a3e lt(Class_lq_87a74641 var1);

    public native Class_ac_79a43a3e ls(Class_lq_87a74641 var1);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    public native Class_ac_79a43a3e lp(Class_lf_d247d983 var1);

    public native Class_ac_79a43a3e lv(Class_mG_52c8d386 var1);

    private static native void _02bd1d3bd637361662bfc18f5ab75acb();

    public native Class_ac_79a43a3e lq(float var1);

    private static native MatchException lw(MatchException var0);

    public native Class_ac_79a43a3e lu(Class_mG_52c8d386 var1);
}

