/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  sixtwo.hJ$ty
 */
package recovered.internal;

import recovered.internal.Class_hJ_tx_aa3012d6;
import sixtwo.hJ;

public sealed interface Class_hJ_a20df6c5
permits Class_hJ_tx_aa3012d6, hJ.ty {
}

