/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 */
package recovered.internal;

import net.minecraft.entity.Entity;
import recovered.internal.Class_hH_ae8f8f77;

public abstract class Class_hw_ffa47777
extends Class_hH_ae8f8f77 {
    private Entity XMyDA;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hw_ffa47777(Entity entity) {
        this.XMyDA = entity;
    }

    public Entity bdm() {
        return this.XMyDA;
    }
}

