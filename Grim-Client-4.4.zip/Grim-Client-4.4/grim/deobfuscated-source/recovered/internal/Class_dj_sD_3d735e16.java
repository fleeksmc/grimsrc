/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;

final class Class_dj_sD_3d735e16
extends Enum<Class_dj_sD_3d735e16> {
    public static final /* enum */ Class_dj_sD_3d735e16 zrNsv;
    public static final /* enum */ Class_dj_sD_3d735e16 WBAxv;
    public static final /* enum */ Class_dj_sD_3d735e16 XoavU;
    public static final /* enum */ Class_dj_sD_3d735e16 btXid;
    private static final Class_dj_sD_3d735e16[] KvDCE;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                var9 = Class_gb_9d201141.aYR(-2441115255596974848L, 2426708390590760851L, MethodHandles.lookup().lookupClass()).a(40586858923298L) ^ 63169491643275L;
                var1_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var9 >>> 56);
                for (var2_2 = 1; var2_2 < 8; ++var2_2) {
                    v2 = v2;
                    v2[var2_2] = (byte)(var9 << var2_2 * 8 >>> 56);
                }
                var1_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var0_3 = new String[4];
                var6_4 = 0;
                var5_5 = "\u0014\u00fdJsN\u0005!\u00bb\bU`\u0094$2\f\u00e7<";
                var7_6 = "\u0014\u00fdJsN\u0005!\u00bb\bU`\u0094$2\f\u00e7<".length();
                var4_7 = 8;
                var3_8 = -1;
lbl18:
                // 2 sources

                while (true) {
                    v3 = ++var3_8;
                    v4 = var5_5.substring(v3, v3 + var4_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl23:
                // 1 sources

                while (true) {
                    var0_3[var6_4++] = Class_dj_sD_3d735e16.doI(var8_9).intern();
                    if ((var3_8 += var4_7) < var7_6) {
                        var4_7 = var5_5.charAt(var3_8);
                        ** continue;
                    }
                    var5_5 = "\u00e8|\u00b5\u0005\u00adyQj\u00c3;~\u00d5\u008b'\u00a8\u00f5\u0018\u00e8|\u00b5\u0005\u00adyQje\u001a\u00d5\u00dcbv3oJ\u0014\u0083L\u00df{FO";
                    var7_6 = "\u00e8|\u00b5\u0005\u00adyQj\u00c3;~\u00d5\u008b'\u00a8\u00f5\u0018\u00e8|\u00b5\u0005\u00adyQje\u001a\u00d5\u00dcbv3oJ\u0014\u0083L\u00df{FO".length();
                    var4_7 = 16;
                    var3_8 = -1;
lbl32:
                    // 2 sources

                    while (true) {
                        v6 = ++var3_8;
                        v4 = var5_5.substring(v6, v6 + var4_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl37:
                // 1 sources

                while (true) {
                    var0_3[var6_4++] = Class_dj_sD_3d735e16.doI(var8_9).intern();
                    if ((var3_8 += var4_7) < var7_6) {
                        var4_7 = var5_5.charAt(var3_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var8_9 = var1_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl49:
                // 1 sources

                ** continue;
            }
        }
        Class_dj_sD_3d735e16.zrNsv = new Class_dj_sD_3d735e16();
        Class_dj_sD_3d735e16.WBAxv = new Class_dj_sD_3d735e16();
        Class_dj_sD_3d735e16.XoavU = new Class_dj_sD_3d735e16();
        Class_dj_sD_3d735e16.btXid = new Class_dj_sD_3d735e16();
        Class_dj_sD_3d735e16.KvDCE = Class_dj_sD_3d735e16.doH();
    }

    public static Class_dj_sD_3d735e16[] values() {
        return (Class_dj_sD_3d735e16[])KvDCE.clone();
    }

    public static Class_dj_sD_3d735e16 valueOf(String string) {
        return Enum.valueOf(Class_dj_sD_3d735e16.class, string);
    }

    private static Class_dj_sD_3d735e16[] doH() {
        return new Class_dj_sD_3d735e16[]{zrNsv, WBAxv, XoavU, btXid};
    }

    private static String doI(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }
}

