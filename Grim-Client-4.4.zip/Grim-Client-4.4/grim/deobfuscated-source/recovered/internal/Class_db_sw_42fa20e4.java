/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.util.math.Vec3d;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_mT_db06bea0;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_db_sw_42fa20e4 {
    Vec3d AUTLH;
    Class_mT_db06bea0 QWqhb;
    boolean PaBdV;
    Class_rk_bf8630d1 pvrxH;
    private static final long SbMHh = Class_gb_9d201141.aYR(-6341233503068354144L, 3941715898052231776L, MethodHandles.lookup().lookupClass()).a(15977905994038L);
    private static final long yqWBV;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_db_sw_42fa20e4(Vec3d vec3d) {
        long l = SbMHh ^ 0x77C09A61AE33L;
        this.PaBdV = false;
        this.pvrxH = new Class_rk_bf8630d1((int)yqWBV).dhs(Class_rj_b691f4f7.XzDkv);
        this.AUTLH = vec3d;
        this.QWqhb = Class_mT_db06bea0.cpz();
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = SbMHh ^ 0x222E6A942B0EL;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                long l2 = -2372792555177154564L;
                byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
                yqWBV = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }
}

