/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_gC_1f010b94;

public class Class_gC_te_8753e369
extends Class_gC_1f010b94 {
    private final int QeZoI;
    private final int QTGHV;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gC_te_8753e369(int n, int n2) {
        this.QeZoI = n;
        this.QTGHV = n2;
    }

    public int dpj() {
        return this.QTGHV;
    }

    public int dpi() {
        return this.QeZoI;
    }
}

