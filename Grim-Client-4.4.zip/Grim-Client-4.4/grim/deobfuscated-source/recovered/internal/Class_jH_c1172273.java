/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.joml.Matrix3x2fStack
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.util.Stack;
import org.joml.Matrix3x2fStack;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_lC_5322e8cf;

public class Class_jH_c1172273 {
    private static final Stack<Matrix3x2fStack> uQzaj;
    private static String[] qPLFl;
    private static final long cgTUn;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public static String[] bIh() {
        return qPLFl;
    }

    public static void bIg(String[] stringArray) {
        qPLFl = stringArray;
    }

    static {
        cgTUn = Class_gb_9d201141.aYR(7714846715772269806L, -3538060880037723863L, MethodHandles.lookup().lookupClass()).a(133043786062544L);
        uQzaj = new Stack();
        Class_jH_c1172273.bIg(null);
    }

    public static void bIf() {
        long l = cgTUn ^ 0x3227F30D6F98L;
        String[] stringArray = Class_jH_c1172273.bIh();
        Matrix3x2fStack matrix3x2fStack = uQzaj;
        if (stringArray == null) {
            if (matrix3x2fStack.isEmpty()) {
                return;
            }
            matrix3x2fStack = uQzaj.pop();
        }
        Matrix3x2fStack matrix3x2fStack2 = matrix3x2fStack;
        matrix3x2fStack2.popMatrix();
    }

    public static void bId(Class_lC_5322e8cf class_lC_5322e8cf, float f, float f2, float f3) {
        long l = cgTUn ^ 0xE32DA2D9B56L;
        String[] stringArray = Class_jH_c1172273.bIh();
        Class_lC_5322e8cf class_lC_5322e8cf2 = class_lC_5322e8cf;
        if (stringArray == null) {
            if (class_lC_5322e8cf2 == null) {
                return;
            }
            class_lC_5322e8cf2 = class_lC_5322e8cf;
        }
        Matrix3x2fStack matrix3x2fStack = class_lC_5322e8cf2.cfe().getMatrices();
        uQzaj.push(matrix3x2fStack);
        matrix3x2fStack.pushMatrix();
        matrix3x2fStack.translate(f, f2);
        matrix3x2fStack.scale(f3, f3);
        matrix3x2fStack.translate(-f, -f2);
    }

    public static void bIe(Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3) {
        long l = cgTUn ^ 0x8C2773AB828L;
        String[] stringArray = Class_jH_c1172273.bIh();
        Matrix3x2fStack matrix3x2fStack2 = matrix3x2fStack;
        if (stringArray == null) {
            if (matrix3x2fStack2 == null) {
                return;
            }
            uQzaj.push(matrix3x2fStack);
            matrix3x2fStack.pushMatrix();
            matrix3x2fStack.translate(f, f2);
            matrix3x2fStack.scale(f3, f3);
            matrix3x2fStack2 = matrix3x2fStack.translate(-f, -f2);
        }
    }

    private static MatchException bIi(MatchException matchException) {
        return matchException;
    }
}

