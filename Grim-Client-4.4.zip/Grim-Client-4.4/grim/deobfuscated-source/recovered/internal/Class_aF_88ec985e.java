/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import recovered.internal.Class_aE_a07172c5;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_lC_5322e8cf;

public abstract class Class_aF_88ec985e
extends Class_aE_a07172c5 {
    private static final long wQvIR = Class_gb_9d201141.aYR(-5792822587876812145L, -1424579896363128256L, MethodHandles.lookup().lookupClass()).a(161422166250848L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aF_88ec985e(int[] nArray) {
        super(nArray);
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void fX(Class_lC_5322e8cf var1_1) {
        var2_2 = Class_aF_88ec985e.wQvIR ^ 61936028460497L;
        var5_3 = this.MCnYt;
        var4_4 = Class_aE_a07172c5.vG();
        var6_5 = this.pNyTQ;
        var7_6 = this.tR();
        var8_7 = 10.0f;
        var9_8 = this.vI();
        var10_9 = this.vJ();
        v0 = var11_10 = this.LGwHI.size();
        if (var4_4 != null) ** GOTO lbl15
        if (v0 == 0) {
            v1 = 0;
        } else {
            v0 = var11_10 + var7_6 - 1;
lbl15:
            // 2 sources

            v1 = v0 / var7_6;
        }
        var12_11 = v1;
        var13_12 = 0.0f;
        v2 = var11_10;
        if (var4_4 == null) {
            if (v2 > 0) {
                var14_13 = (Class_az_a4990dcf)this.LGwHI.get(0);
                var13_12 = var14_13.dn();
            }
            v2 = var12_11;
        }
        if (var4_4 != null) ** GOTO lbl29
        if (v2 <= 0) {
            v3 = 0.0f;
        } else {
            v2 = var12_11;
lbl29:
            // 2 sources

            v3 = (float)v2 * var13_12 + (float)Math.max(0, var12_11 - 1) * var10_9;
        }
        var14_14 = v3;
        var15_15 = Math.max(0.0f, this.WjISQ);
        var16_16 = var14_14 - var15_15;
        var17_17 = Math.max(0.0f, var16_16);
        v4 = var16_16;
        if (var4_4 == null) {
            if (v4 > 0.0f) {
                var17_17 += (double)var8_7;
            }
            Class_bl_a15fbaa5.Ex().Ez().nQ(var17_17);
            v4 = var5_3;
        }
        var19_18 = v4;
        var20_19 = (float)((double)var6_5 - Class_bl_a15fbaa5.Ex().Ez().nH());
        var21_20 = 0;
        while (var21_20 < this.LGwHI.size()) {
            var22_21 = (Class_az_a4990dcf)this.LGwHI.get(var21_20);
            var22_21.sW(var19_18, var20_19);
            var19_18 += var22_21.kN() + var9_8;
            if (var4_4 == null) {
                if ((var21_20 + 1) % var7_6 == 0) {
                    var19_18 = var5_3;
                    var20_19 += var22_21.dn() + var10_9;
                }
                ++var21_20;
            }
            if (var4_4 == null) continue;
            Class_iS_888f260e.bwK("yXAPCc");
            break;
        }
    }

    public float vJ() {
        return 5.0f;
    }

    public float vI() {
        return 5.0f;
    }

    protected abstract int tR();

    private static MatchException vK(MatchException matchException) {
        return matchException;
    }
}

