/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_ai_36ccd007;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mG_52c8d386;

public final class Class_F_b668cea7
extends Record {
    private final String text;
    private final Class_lf_d247d983 icon;
    private final Class_mG_52c8d386 textColor;
    private final Class_mG_52c8d386 iconColor;
    private final Class_ai_36ccd007 action;
    private static String[] a;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_F_b668cea7(String string, Class_lf_d247d983 class_lf_d247d983, Class_ai_36ccd007 class_ai_36ccd007) {
        this(string, class_lf_d247d983, null, null, class_ai_36ccd007);
    }

    public Class_F_b668cea7(String string, Class_lf_d247d983 class_lf_d247d983, Class_mG_52c8d386 class_mG_52c8d386, Class_mG_52c8d386 class_mG_52c8d3862, Class_ai_36ccd007 class_ai_36ccd007) {
        this.text = string;
        this.icon = class_lf_d247d983;
        this.textColor = class_mG_52c8d386;
        this.iconColor = class_mG_52c8d3862;
        this.action = class_ai_36ccd007;
    }

    static {
        NativeLoader.doInit(Class_F_b668cea7.class);
        Class_F_b668cea7._a8272f08dc4ef3746d6c262c44bd92e3();
    }

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    public static native void b(String[] var0);

    public static native String[] b();

    public native Class_ai_36ccd007 action();

    public native String text();

    public native Class_mG_52c8d386 textColor();

    public native Class_mG_52c8d386 iconColor();

    public native Class_lf_d247d983 icon();

    private static native void _a8272f08dc4ef3746d6c262c44bd92e3();
}

