/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import recovered.core.NativeLoader;
import recovered.internal.Class_bj_953e4f00;
import recovered.internal.Class_iM_910cda2e;
import recovered.internal.Class_iO_e7bfa49a;

public class Class_iP_5c78454e {
    private final Map<String, Class_iO_e7bfa49a> kHIxx = new ConcurrentHashMap<String, Class_iO_e7bfa49a>();
    private final Map<String, int[]> POcAW = new ConcurrentHashMap<String, int[]>();
    private static long vJphY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public native void buJ(Class_iO_e7bfa49a var1);

    public native Class_iO_e7bfa49a buK(String var1);

    public native boolean buL(String var1);

    public native void buM(String var1);

    public native void buI(Class_iM_910cda2e var1);

    private static native /* synthetic */ boolean buQ(Class_iO_e7bfa49a var0, Class_bj_953e4f00 var1);

    private static native MatchException buR(MatchException var0);

    private static native /* synthetic */ boolean buP(Class_iO_e7bfa49a var0, Class_bj_953e4f00 var1);

    public native Map<String, Class_iO_e7bfa49a> buN();

    public native Map<String, int[]> buO();

    static {
        NativeLoader.doInit(Class_iP_5c78454e.class);
        Class_iP_5c78454e._f128db71b91b598847d95e7f5457b384();
    }

    private static native void _f128db71b91b598847d95e7f5457b384();
}

