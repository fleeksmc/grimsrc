/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 */
package recovered.internal;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mr_7eac5189;

public class Class_cH_5b9db066
extends Class_cB_67aec11c {
    private final List<Class_cB_67aec11c> sdWIG = new ArrayList<Class_cB_67aec11c>();
    private static final long ZdDfg = Class_gb_9d201141.aYR(-2240991886133654468L, 2263670644429913216L, MethodHandles.lookup().lookupClass()).a(173865963928684L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cH_5b9db066(Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_mr_7eac5189);
    }

    public Class_cH_5b9db066(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    private static Exception Ww(Exception exception) {
        return exception;
    }

    public Class_cH_5b9db066 Wu(Class_cB_67aec11c ... class_cB_67aec11cArray) {
        this.sdWIG.addAll(List.of(class_cB_67aec11cArray));
        return this;
    }

    public List<Class_cB_67aec11c> Wv() {
        return this.sdWIG;
    }

    @Override
    public void SS(JsonElement jsonElement) {
        long l = ZdDfg ^ 0x22FD5813A742L;
        boolean bl = Class_cB_67aec11c.Vu();
        JsonElement jsonElement2 = jsonElement;
        if (!bl) {
            if (!jsonElement2.isJsonObject()) {
                return;
            }
            jsonElement2 = jsonElement;
        }
        JsonObject jsonObject = jsonElement2.getAsJsonObject();
        for (Class_cB_67aec11c class_cB_67aec11c : this.sdWIG) {
            String string = Arrays.toString(class_cB_67aec11c.Vm());
            if (!bl && jsonObject.has(string)) {
                try {
                    class_cB_67aec11c.SS(jsonObject.get(string));
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            if (!bl) continue;
        }
    }

    @Override
    public void SR(Map<String, Object> map) {
        block2: {
            long l = ZdDfg ^ 0x7184D2713AEEL;
            HashMap<String, Object> hashMap = new HashMap<String, Object>();
            boolean bl = Class_cB_67aec11c.Vu();
            for (Class_cB_67aec11c class_cB_67aec11c : this.sdWIG) {
                class_cB_67aec11c.SR(hashMap);
                if (!bl) {
                    if (!bl) continue;
                }
                break block2;
            }
            map.put(Arrays.toString(this.NwlSF), hashMap);
        }
    }
}

