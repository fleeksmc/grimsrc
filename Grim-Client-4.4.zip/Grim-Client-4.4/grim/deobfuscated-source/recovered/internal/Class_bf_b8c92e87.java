/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_aA_8076b584;
import recovered.internal.Class_ag_8130246f;
import recovered.internal.Class_ag_rR_5deaebc6;
import recovered.internal.Class_bg_0a91641c;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mE_e0ac7db3;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bf_b8c92e87
extends Class_aA_8076b584 {
    private final Class_rk_bf8630d1 WZJax;
    private final Class_rk_bf8630d1 LfVhX;
    private final Class_mE_e0ac7db3 QmUDf;
    private final Class_ag_8130246f StMVo;
    private boolean lGpSg;
    private static final long yhsxx = Class_gb_9d201141.aYR(-2964692983370650862L, 5945782339383189539L, MethodHandles.lookup().lookupClass()).a(67608889055075L);
    private static final String ZzLYN;
    private static final long[] xkIge;
    private static final Integer[] BNxZH;
    private static final Map dVkdH;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bf_b8c92e87(Class_mE_e0ac7db3 class_mE_e0ac7db3) {
        long l = yhsxx ^ 0x2A9F930E0F22L;
        this.WZJax = new Class_rk_bf8630d1((int)Class_bf_b8c92e87.CM("z", (int)481, (long)(0x7A26127DD9FF9257L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.LfVhX = new Class_rk_bf8630d1((int)Class_bf_b8c92e87.CM("z", (int)11671, (long)(0x50F5C399B4423E20L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.lGpSg = false;
        this.QmUDf = class_mE_e0ac7db3;
        this.StMVo = new Class_ag_8130246f(class_mE_e0ac7db3.cnD(), Class_ag_rR_5deaebc6.VdGoA);
        this.StMVo.sX(15.0f, 45.0f);
        this.BcpIo = 115.0f;
        this.WjISQ = 55.0f;
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = yhsxx ^ 0x56554218C519L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        byte[] byArray3 = cipher.doFinal("\u0012\u0087\u0090\u00c2\u00ba(\u00db\u0012\u000bX<S\u00d4\u00de\u0088P".getBytes("ISO-8859-1"));
        ZzLYN = Class_bf_b8c92e87.CJ(byArray3).intern();
        dVkdH = new HashMap(13);
        Cipher cipher2 = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory2 = SecretKeyFactory.getInstance("DES");
        byte[] byArray4 = new byte[8];
        byte[] byArray5 = byArray4;
        byArray4[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray5 = byArray5;
            byArray5[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher2.init(2, (Key)secretKeyFactory2.generateSecret(new DESKeySpec(byArray5)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "\u00cd\u0007g\u0099iK\u00bc\u00b5j8\u00d8\u008c\u00ff\u00cd\u00fc\u00b3";
        int n2 = "\u00cd\u0007g\u0099iK\u00bc\u00b5j8\u00d8\u008c\u00ff\u00cd\u00fc\u00b3".length();
        int n3 = 0;
        do {
            byte[] byArray6 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray6[0] & 0xFFL) << 56 | ((long)byArray6[1] & 0xFFL) << 48 | ((long)byArray6[2] & 0xFFL) << 40 | ((long)byArray6[3] & 0xFFL) << 32 | ((long)byArray6[4] & 0xFFL) << 24 | ((long)byArray6[5] & 0xFFL) << 16 | ((long)byArray6[6] & 0xFFL) << 8 | (long)byArray6[7] & 0xFFL;
            byte[] byArray7 = cipher2.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray7[0] & 0xFFL) << 56 | ((long)byArray7[1] & 0xFFL) << 48 | ((long)byArray7[2] & 0xFFL) << 40 | ((long)byArray7[3] & 0xFFL) << 32 | ((long)byArray7[4] & 0xFFL) << 24 | ((long)byArray7[5] & 0xFFL) << 16 | ((long)byArray7[6] & 0xFFL) << 8 | (long)byArray7[7] & 0xFFL;
        } while (n3 < n2);
        xkIge = lArray;
        BNxZH = new Integer[2];
    }

    @Override
    public void dl(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        this.StMVo.dl(d, d2, class_mA_32d8a5f2);
        super.dl(d, d2, class_mA_32d8a5f2);
    }

    public Class_mE_e0ac7db3 CE() {
        return this.QmUDf;
    }

    private static MatchException CI(MatchException matchException) {
        return matchException;
    }

    public Class_bf_b8c92e87 CH(boolean bl) {
        this.lGpSg = bl;
        return this;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean dk(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        boolean bl;
        long l = yhsxx ^ 0x2B63723D23AFL;
        int n = Class_bg_0a91641c.De();
        boolean bl2 = this.StMVo.dk(d, d2, class_mA_32d8a5f2);
        if (n == 0) return bl2;
        if (bl2) {
            return true;
        }
        if (class_mA_32d8a5f2 == Class_mA_32d8a5f2.sCBUa) {
            Class_lc_b8480f87 class_lc_b8480f87 = new Class_lc_b8480f87(this.MCnYt + this.BcpIo - 15.0f, this.pNyTQ + this.WjISQ - 15.0f, 8.0f, 8.0f);
            bl = class_lc_b8480f87.bXD(d, d2);
            if (n == 0) return bl;
            if (bl) {
                this.QmUDf.cnB();
                return true;
            }
        }
        bl = super.dk(d, d2, class_mA_32d8a5f2);
        return bl;
    }

    @Override
    protected void bV(Class_lC_5322e8cf class_lC_5322e8cf) {
        float f;
        float f2;
        block6: {
            block7: {
                block5: {
                    float f3;
                    block4: {
                        long l = yhsxx ^ 0x76F6BA94F76BL;
                        int n = Class_bg_0a91641c.De();
                        this.LfVhX.dhc(this.ti(class_lC_5322e8cf));
                        int n2 = n;
                        boolean bl = this.lGpSg;
                        if (n2 != 0) {
                            bl = !bl;
                        }
                        this.WZJax.dhc(bl);
                        float f4 = 7.0f;
                        f2 = this.WZJax.dhj();
                        Class_mG_52c8d386 class_mG_52c8d386 = this.CtPwV.bje().cob(0.8f).cob(f2);
                        class_lC_5322e8cf.cdm(this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ, 5.0f, Class_ld_bb1690e1.M, class_mG_52c8d386);
                        Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
                        float f5 = this.MCnYt + 15.0f + this.StMVo.kN() + 15.0f;
                        float f6 = this.pNyTQ + 8.0f;
                        Class_mG_52c8d386 class_mG_52c8d3862 = this.CtPwV.bjb().cob(Class_jF_38b68c76.bHw()[3] * 0.75f + 0.25f * this.LfVhX.dhj()).cob(f2);
                        class_lC_5322e8cf.cez(class_lq_87a74641, this.QmUDf.cnD(), f5, f6, class_mG_52c8d3862);
                        Class_mG_52c8d386 class_mG_52c8d3863 = this.CtPwV.bjb().cob(0.5f * f2);
                        Class_lq_87a74641 class_lq_87a746412 = Class_lE_06fbe260.joxgd.bYM(6.0f);
                        float f7 = f6 + class_lq_87a74641.cat() + 3.0f;
                        class_lC_5322e8cf.cez(class_lq_87a746412, ZzLYN, f5, f7, class_mG_52c8d3863);
                        float f8 = f7 + class_lq_87a746412.cat() + 3.0f;
                        class_lC_5322e8cf.ceH(class_lq_87a746412, Class_jf_d1c4f950.bAS(Instant.ofEpochSecond(this.QmUDf.cnE())), f5, f8, class_mG_52c8d3863, 0.8f, 0.99f, this.BcpIo - (f5 - this.MCnYt) - 7.0f);
                        Class_lc_b8480f87 class_lc_b8480f87 = new Class_lc_b8480f87(this.MCnYt + this.BcpIo - 15.0f, this.pNyTQ + this.WjISQ - 15.0f, 8.0f, 8.0f);
                        class_lC_5322e8cf.ceq(Class_lf_d247d983.JHGge, class_lc_b8480f87, Class_jk_a0800133.mPXGi.cob(f2));
                        this.StMVo.sW(this.MCnYt + 15.0f, this.pNyTQ + f4);
                        float f9 = Class_bl_a15fbaa5.Ex().sf() - 0.8f;
                        f3 = f9 == 0.0f ? 0 : (f9 < 0.0f ? -1 : 1);
                        if (n2 == 0) break block4;
                        if (f3 <= 0) break block5;
                        f = f2;
                        if (n2 == 0) break block6;
                        float f10 = f - 0.8f;
                        f3 = f10 == 0.0f ? 0 : (f10 < 0.0f ? -1 : 1);
                    }
                    if (f3 >= 0) break block7;
                }
                return;
            }
            f = Class_jF_38b68c76.bHw()[3];
        }
        float f11 = f;
        Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, Math.min(1.0f, f2));
        this.StMVo.su(class_lC_5322e8cf);
        Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, f11);
    }

    @Override
    public boolean dB(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2, double d3, double d4) {
        long l = yhsxx ^ 0x3B3D1BD1362L;
        int n = Class_bg_0a91641c.De();
        boolean bl = this.StMVo.dB(d, d2, class_mA_32d8a5f2, d3, d4);
        if (n != 0) {
            if (bl) {
                return true;
            }
            bl = super.dB(d, d2, class_mA_32d8a5f2, d3, d4);
        }
        return bl;
    }

    @Override
    public void dY() {
        super.dY();
        this.StMVo.dY();
    }

    private static CallSite CM(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bf_b8c92e87" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public Class_rk_bf8630d1 CC() {
        return this.WZJax;
    }

    private static String CJ(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public Class_ag_8130246f CF() {
        return this.StMVo;
    }

    private static int CK(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x59C2;
        if (BNxZH[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = xkIge[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])dVkdH.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    dVkdH.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bf_b8c92e87", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bf_b8c92e87.BNxZH[n2] = n3;
        }
        return BNxZH[n2];
    }

    private static int CL(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bf_b8c92e87.CK(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public Class_rk_bf8630d1 CD() {
        return this.LfVhX;
    }

    public boolean CG() {
        return this.lGpSg;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bf_b8c92e87.class, "CL", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

