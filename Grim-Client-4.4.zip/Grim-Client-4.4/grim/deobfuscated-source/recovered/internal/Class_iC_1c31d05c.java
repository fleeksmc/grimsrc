/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import recovered.core.NativeLoader;
import recovered.internal.Class_iz_2ddebd14;

public class Class_iC_1c31d05c {
    private volatile Class_iz_2ddebd14 oGlJN;
    private final Set<String> ZfUZZ = ConcurrentHashMap.newKeySet();
    private final List<Class_iz_2ddebd14> gHFYR = new ArrayList<Class_iz_2ddebd14>();
    private static long pCyOc;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_iC_1c31d05c.class);
        Class_iC_1c31d05c._edcaa3034d725d5fb4641f753cf52629();
    }

    public native boolean bqL(String var1);

    public native Class_iz_2ddebd14 bqM();

    public native Class_iz_2ddebd14 bqJ(String var1);

    public native void bqP(Class_iz_2ddebd14 var1);

    public native Set<String> bqN();

    private static native /* synthetic */ boolean bqQ(String var0, Class_iz_2ddebd14 var1);

    private static native MatchException bqR(MatchException var0);

    public native List<Class_iz_2ddebd14> bqO();

    private static native void _edcaa3034d725d5fb4641f753cf52629();

    public native boolean bqK(String var1);

    public native Class_iz_2ddebd14 bqI(String var1);
}

