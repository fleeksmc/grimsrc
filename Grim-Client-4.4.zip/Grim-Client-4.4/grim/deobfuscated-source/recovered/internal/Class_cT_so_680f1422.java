/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.client.render.entity.model.EntityModelLayers
 *  net.minecraft.client.render.entity.model.PlayerEntityModel
 *  net.minecraft.entity.Entity$RemovalReason
 *  net.minecraft.util.Identifier
 *  org.joml.Vector3f
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import org.joml.Vector3f;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mT_db06bea0;
import recovered.modules.AmbienceModule;
import recovered.modules.PopChamsModule;

class Class_cT_so_680f1422 {
    private final AbstractClientPlayerEntity VwpaT;
    private final PlayerEntityModel ugYAv;
    private final Identifier UvTDM;
    private final Class_mT_db06bea0 hKtLW;
    final PopChamsModule RqOGl;
    private static final long BAIKm = Class_gb_9d201141.aYR(-6992043895842856326L, -3835896092020489527L, MethodHandles.lookup().lookupClass()).a(133161837207714L);
    private static final long[] bZlSN;
    private static final Long[] OQynS;
    private static final Map qYOrT;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cT_so_680f1422(PopChamsModule popChamsModule, AbstractClientPlayerEntity abstractClientPlayerEntity, Identifier identifier) {
        this.RqOGl = popChamsModule;
        this.hKtLW = Class_mT_db06bea0.cpz();
        this.VwpaT = abstractClientPlayerEntity;
        this.ugYAv = new PlayerEntityModel(ClientMain.dlmvG.getLoadedEntityModels().getModelPart(EntityModelLayers.PLAYER), true);
        this.ugYAv.getHead().scale(new Vector3f(-0.3f, -0.3f, -0.3f));
        this.UvTDM = identifier;
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        qYOrT = new HashMap(13);
        long l = BAIKm ^ 0x24FD9749B256L;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "\u0081\u00d2\u00d2??R\u0010\u009b\u0088\u001c-U\u0014T\u00e6t";
        int n2 = "\u0081\u00d2\u00d2??R\u0010\u009b\u0088\u001c-U\u0014T\u00e6t".length();
        int n3 = 0;
        do {
            byte[] byArray3 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
            byte[] byArray4 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray4[0] & 0xFFL) << 56 | ((long)byArray4[1] & 0xFFL) << 48 | ((long)byArray4[2] & 0xFFL) << 40 | ((long)byArray4[3] & 0xFFL) << 32 | ((long)byArray4[4] & 0xFFL) << 24 | ((long)byArray4[5] & 0xFFL) << 16 | ((long)byArray4[6] & 0xFFL) << 8 | (long)byArray4[7] & 0xFFL;
        } while (n3 < n2);
        bZlSN = lArray;
        OQynS = new Long[2];
    }

    private static CallSite dnF(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cT_so_680f1422" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public AbstractClientPlayerEntity dny() {
        return this.VwpaT;
    }

    public PlayerEntityModel dnz() {
        return this.ugYAv;
    }

    public Identifier dnA() {
        return this.UvTDM;
    }

    private static MatchException dnC(MatchException matchException) {
        return matchException;
    }

    private static long dnD(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x31F0;
        if (OQynS[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = bZlSN[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])qYOrT.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    qYOrT.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cT_so_680f1422", exception);
            }
            long l4 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            Class_cT_so_680f1422.OQynS[n2] = l4;
        }
        return OQynS[n2];
    }

    private static long dnE(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        long l2 = Class_cT_so_680f1422.dnD(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l2;
    }

    public Class_mT_db06bea0 dnB() {
        return this.hKtLW;
    }

    public float dnx() {
        long l = BAIKm ^ 0x3FEEA2D85EDAL;
        long l2 = (long)this.RqOGl.CeLKq.VC() * Class_cT_so_680f1422.dnF("b", (int)13391, (long)(0x6F4A376321917BDL ^ l));
        long l3 = this.hKtLW.cpF();
        long l4 = Math.max(0L, l2 - l3);
        return Math.min(1.0f, (float)l4 / (float)l2);
    }

    public void dnw(CopyOnWriteArrayList<Class_cT_so_680f1422> copyOnWriteArrayList) {
        block3: {
            block2: {
                long l = BAIKm ^ 0x5F85C16CF253L;
                Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
                boolean bl = this.hKtLW.cpC((long)this.RqOGl.CeLKq.VC() * Class_cT_so_680f1422.dnF("b", (int)12519, (long)(0x5B9AADF360153F9DL ^ l)));
                if (class_iS_888f260eArray != null) break block2;
                if (!bl) break block3;
                bl = copyOnWriteArrayList.remove(this);
            }
            ClientMain.dlmvG.world.removeEntity(this.VwpaT.getId(), Entity.RemovalReason.DISCARDED);
            this.VwpaT.setRemoved(Entity.RemovalReason.DISCARDED);
            this.VwpaT.onRemoved();
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cT_so_680f1422.class, "dnE", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

