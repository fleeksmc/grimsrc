/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.Arm
 *  net.minecraft.util.Hand
 */
package recovered.internal;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gm_427382bb
extends Class_hH_ae8f8f77 {
    private Hand ZSWTm;
    private Arm TEGQu;
    private float CSsHU;
    private ItemStack QDpDW;
    private float oeAfQ;
    private MatrixStack UUADX;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public float bbe() {
        return this.oeAfQ;
    }

    public Hand bba() {
        return this.ZSWTm;
    }

    public Class_gm_427382bb(Hand hand, Arm arm, float f, ItemStack itemStack, float f2, MatrixStack matrixStack) {
        this.ZSWTm = hand;
        this.TEGQu = arm;
        this.CSsHU = f;
        this.QDpDW = itemStack;
        this.oeAfQ = f2;
        this.UUADX = matrixStack;
    }

    public float bbc() {
        return this.CSsHU;
    }

    public ItemStack bbd() {
        return this.QDpDW;
    }

    public Arm bbb() {
        return this.TEGQu;
    }

    public MatrixStack bbf() {
        return this.UUADX;
    }
}

