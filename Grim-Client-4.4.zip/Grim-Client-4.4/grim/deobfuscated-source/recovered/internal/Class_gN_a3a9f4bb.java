/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;

public class Class_gN_a3a9f4bb
extends Class_hH_ae8f8f77 {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

