/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public abstract class Class_aj_95d0a719
extends Class_az_a4990dcf {
    public static float BxXRB = 7.5f;
    protected final Class_rk_bf8630d1 nXrOu;
    protected final Class_rk_bf8630d1 Rpjei;
    protected boolean FHbTC;
    protected float IzFhM;
    protected boolean fWqrr;
    protected boolean rjDwh;
    protected float dWFbt;
    protected float DHgsI;
    protected float bQoPs;
    protected static float TRsBX = 5.0f;
    protected boolean ImWAC;
    private static String[] XrosG;
    private static long xPnXy;
    private static long[] mJOOd;
    private static Integer[] PlKvG;
    private static Map Nupxb;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native void _bb4768691cd64636a3a9c49f7274580e();

    public native float ow();

    protected Class_aj_95d0a719(float f, float f2, float f3, float f4) {
        long l = xPnXy ^ 0x73D0EEA6FE5CL;
        super(f, f2, f3, f4);
        this.nXrOu = new Class_rk_bf8630d1((int)Class_aj_95d0a719.oE("b", (int)13266, (long)(0x7E70EA3448AF52D3L ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        this.Rpjei = new Class_rk_bf8630d1((int)Class_aj_95d0a719.oE("b", (int)4740, (long)(0x717D3902F5237384L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.IzFhM = 2.0f;
        this.fWqrr = true;
        this.bQoPs = 7.5f;
        this.ImWAC = false;
    }

    protected Class_aj_95d0a719() {
        this(0.0f, 0.0f, 0.0f, 0.0f);
    }

    static {
        NativeLoader.doInit(Class_aj_95d0a719.class);
        Class_aj_95d0a719._bb4768691cd64636a3a9c49f7274580e();
    }

    public native void of(double var1, double var3);

    public native float ov();

    protected native float gc();

    public native Class_rk_bf8630d1 op();

    public native <T extends Class_aj_95d0a719> T on(float var1);

    public native boolean os();

    public native <T extends Class_aj_95d0a719> T om(boolean var1);

    @Override
    public native boolean hc(double var1, double var3);

    protected native void oa();

    public native <T extends Class_aj_95d0a719> T ob(boolean var1);

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    public native <T extends Class_aj_95d0a719> T ok(float var1);

    public native float or();

    protected native void oc(Class_lC_5322e8cf var1, Runnable var2, Runnable var3);

    public native boolean ox();

    protected native void gd(Class_lC_5322e8cf var1, Runnable var2);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    protected native boolean oe();

    private native /* synthetic */ void oy(Class_lC_5322e8cf var1);

    public static native void oz(String[] var0);

    protected native Class_rj_b691f4f7 ga();

    protected native float gb();

    public native void og(Class_lC_5322e8cf var1);

    public native boolean oh(double var1, double var3);

    protected native int fY();

    @Override
    public native void fX(Class_lC_5322e8cf var1);

    protected native Class_rj_b691f4f7 fZ();

    @Override
    public native boolean oi();

    public static native String[] oA();

    @Override
    protected native boolean nZ();

    protected native boolean od();

    public native <T extends Class_aj_95d0a719> T oj(boolean var1);

    public native Class_rk_bf8630d1 oo();

    private static native int oC(int var0, long var1);

    private static native int oD(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public native <T extends Class_aj_95d0a719> T ol(boolean var1);

    public native boolean oq();

    private static native MatchException oB(MatchException var0);

    private static native CallSite oE(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native float ou();

    public native boolean ot();
}

