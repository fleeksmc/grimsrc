/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.VertexFormat
 *  it.unimi.dsi.fastutil.objects.Object2IntMap
 *  it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 */
package recovered.internal;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.io.Closeable;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.FloatBuffer;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jI_616cf0dd;
import recovered.internal.Class_jL_e8aba6a1;
import recovered.internal.Class_jM_559f0f92;
import recovered.internal.Class_jN_tY_89627430;
import recovered.internal.Class_lB_d4ece713;
import recovered.internal.Class_lF_27593463;
import recovered.internal.Class_lT_411dd062;
import recovered.internal.Class_lU_0bc40754;
import recovered.internal.Class_lV_1a2d8b8e;
import recovered.internal.Class_lW_585bdacf;
import recovered.internal.Class_rm_d861be3b;

public class Class_jN_f0c1545a
implements Closeable {
    private static final String kPOcq;
    private static final String SQSpe;
    private final Class_lU_0bc40754 hbdsS;
    private final Class_lW_585bdacf pqgLF;
    private final Object2IntMap<String> UMoVo;
    private final int hxaAS;
    private final int BvSGk;
    private final Matrix4f gsSlM;
    private final Matrix4f QdyLm;
    private final Matrix4f jiKOF;
    private static final long EuHrv;
    private static final String[] fAbkF;
    private static final String[] SUbhZ;
    private static final Map NLXzj;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Class_jN_f0c1545a(VertexFormat vertexFormat, Class_jM_559f0f92 ... class_jM_559f0f92Array) {
        block7: {
            int n;
            long l;
            block6: {
                l = EuHrv ^ 0x111D94268A50L;
                this.UMoVo = new Object2IntOpenHashMap();
                this.gsSlM = new Matrix4f();
                this.QdyLm = new Matrix4f();
                this.jiKOF = new Matrix4f();
                n = Class_jL_e8aba6a1.bIQ();
                this.hbdsS = Class_lT_411dd062.ciQ();
                Class_lV_1a2d8b8e[] class_lV_1a2d8b8eArray = new Class_lV_1a2d8b8e[class_jM_559f0f92Array.length];
                for (int i = 0; i < class_jM_559f0f92Array.length; ++i) {
                    class_lV_1a2d8b8eArray[i] = class_jM_559f0f92Array[i].bJb();
                    if (n != 0) {
                        if (n != 0) continue;
                        Class_iS_888f260e.bwK("OOfzgb");
                        break;
                    }
                    break block6;
                }
                try {
                    this.pqgLF = this.hbdsS.createProgram(vertexFormat, class_lV_1a2d8b8eArray);
                }
                catch (Throwable throwable) {
                    for (Class_jM_559f0f92 class_jM_559f0f92 : class_jM_559f0f92Array) {
                        class_jM_559f0f92.close();
                        if (n != 0) continue;
                    }
                    throw throwable;
                }
            }
            for (Class_jM_559f0f92 class_jM_559f0f92 : class_jM_559f0f92Array) {
                class_jM_559f0f92.close();
                if (n == 0) break block7;
                if (n != 0) continue;
                break;
            }
            this.hxaAS = this.bJn((String)((Object)Class_jN_f0c1545a.bJF("b", (int)25374, (long)(0x54041DF41FB8CB65L ^ l))));
            this.BvSGk = this.bJn((String)((Object)Class_jN_f0c1545a.bJF("b", (int)4349, (long)(0x6A655B854DDEB887L ^ l))));
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_jN_f0c1545a.EuHrv = Class_gb_9d201141.aYR(-4188272765790085521L, 2895016500510754455L, MethodHandles.lookup().lookupClass()).a(24422337496964L);
                Class_jN_f0c1545a.NLXzj = new HashMap<K, V>(13);
                var0 = Class_jN_f0c1545a.EuHrv ^ 52998875579115L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[4];
                var7_4 = 0;
                var6_5 = "\u00b8\u00fe\u00e0|\u00d1\u00e3\u00b8\f\u00a5\u00d5\u00d1G{2\u00d2\t bP\u00dd\u00d0@#io\u00ccbML\u0087\u00de\u00a3hU\u00171\u00cdl\u00cf\u0013\u0003F\u00ec^\u0094\u00bf\u0089\u00af\u00f8";
                var8_6 = "\u00b8\u00fe\u00e0|\u00d1\u00e3\u00b8\f\u00a5\u00d5\u00d1G{2\u00d2\t bP\u00dd\u00d0@#io\u00ccbML\u0087\u00de\u00a3hU\u00171\u00cdl\u00cf\u0013\u0003F\u00ec^\u0094\u00bf\u0089\u00af\u00f8".length();
                var5_7 = 16;
                var4_8 = -1;
lbl20:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl25:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jN_f0c1545a.bJC(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "\u0005\u00ec\u0012\u00e8\u00fd9\u001dF`\u0003\u00fcH\u00ea:.\u00f7\u00c5Y\u00fc\u0014\u0016\u00a6\u00af\u00d1\u0010\u0089\u00a8\u00a2\u00c7\u00b5\u001b \u00f6\u00be)\u0019Y\u00c9Ii\u00d3";
                    var8_6 = "\u0005\u00ec\u0012\u00e8\u00fd9\u001dF`\u0003\u00fcH\u00ea:.\u00f7\u00c5Y\u00fc\u0014\u0016\u00a6\u00af\u00d1\u0010\u0089\u00a8\u00a2\u00c7\u00b5\u001b \u00f6\u00be)\u0019Y\u00c9Ii\u00d3".length();
                    var5_7 = 24;
                    var4_8 = -1;
lbl34:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jN_f0c1545a.bJC(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl51:
                // 1 sources

                ** continue;
            }
        }
        Class_jN_f0c1545a.fAbkF = var9_3;
        Class_jN_f0c1545a.SUbhZ = new String[4];
        Class_jN_f0c1545a.SQSpe = Class_jN_f0c1545a.bJF("b", (int)31567, (long)(1357790180969962381L ^ var0));
        Class_jN_f0c1545a.kPOcq = Class_jN_f0c1545a.bJF("b", (int)860, (long)(7210030969419703199L ^ var0));
    }

    @Override
    public void close() {
        this.pqgLF.close();
    }

    public Class_lW_585bdacf bJz() {
        return this.pqgLF;
    }

    /*
     * Unable to fully structure code
     */
    private void bJp() {
        var1_1 = Class_jN_f0c1545a.EuHrv ^ 101114897597933L;
        var3_2 = Class_jL_e8aba6a1.bIQ();
        if (var3_2 == 0) ** GOTO lbl9
        switch (Class_jN_tY_89627430.gCqNy[Class_lF_27593463.cfY().ordinal()]) {
            case 1: {
                this.gsSlM.identity().translate(0.0f, 0.0f, -11000.0f);
                this.bJw(this.BvSGk, this.gsSlM);
lbl9:
                // 2 sources

                if (var3_2 != 0) break;
            }
            case 2: {
                this.QdyLm.identity();
                this.bJw(this.BvSGk, this.QdyLm);
                if (var3_2 != 0) break;
            }
            case 3: {
                this.jiKOF.set((Matrix4fc)RenderSystem.getModelViewMatrix());
                this.bJw(this.BvSGk, this.jiKOF);
                break;
            }
        }
    }

    public static Class_jN_f0c1545a bJk(VertexFormat vertexFormat, Class_jM_559f0f92 ... class_jM_559f0f92Array) {
        return new Class_jN_f0c1545a(vertexFormat, class_jM_559f0f92Array);
    }

    private void bJw(int n, Matrix4f matrix4f) {
        this.hbdsS.setUniform(n, matrix4f);
    }

    private static String bJC(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public void bJv(String string, Matrix4f matrix4f) {
        int n = this.bJn(string);
        this.bJw(n, matrix4f);
    }

    public void bJx(String string, int n) {
        this.hbdsS.setUniform(this.bJn(string), n);
    }

    public void bJr(String string, float f, float f2) {
        this.hbdsS.setUniform(this.bJn(string), f, f2);
    }

    public void bJt(String string, float f, float f2, float f3, float f4) {
        this.hbdsS.setUniform(this.bJn(string), f, f2, f3, f4);
    }

    public void bJl() {
        block6: {
            Class_jN_f0c1545a class_jN_f0c1545a;
            block5: {
                int n;
                int n2;
                block4: {
                    long l = EuHrv ^ 0x15F8BAD6F5EDL;
                    int n3 = Class_jL_e8aba6a1.bIQ();
                    this.hbdsS.bindProgram(this.pqgLF);
                    int n4 = n3;
                    n2 = this.hxaAS;
                    n = -1;
                    if (n4 == 0) break block4;
                    if (n2 != n) {
                        this.bJo();
                    }
                    class_jN_f0c1545a = this;
                    if (n4 == 0) break block5;
                    n2 = class_jN_f0c1545a.BvSGk;
                    n = -1;
                }
                if (n2 == n) break block6;
                class_jN_f0c1545a = this;
            }
            class_jN_f0c1545a.bJp();
        }
    }

    private void bJo() {
        long l = EuHrv ^ 0x5E9A21CB7241L;
        int n = Class_jL_e8aba6a1.bIQ();
        if (n != 0) {
            if (Class_lF_27593463.cfY() == Class_lB_d4ece713.xCeuB) {
                this.bJw(this.hxaAS, Class_rm_d861be3b.dij());
                return;
            }
            this.bJw(this.hxaAS, Class_jI_616cf0dd.bIk());
        }
    }

    public void bJm() {
        this.hbdsS.unbindProgram();
    }

    private static CallSite bJF(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jN_f0c1545a" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public int bJn(String string) {
        return this.UMoVo.computeIfAbsent((Object)string, object -> this.hbdsS.uniformLocation(this.pqgLF, (String)object));
    }

    public void bJq(String string, float f) {
        this.hbdsS.setUniform(this.bJn(string), f);
    }

    private static MatchException bJB(MatchException matchException) {
        return matchException;
    }

    public void bJy(String string, FloatBuffer floatBuffer) {
        this.hbdsS.setUniform(this.bJn(string), floatBuffer);
    }

    private static String bJD(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5FB4;
        if (SUbhZ[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])NLXzj.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    NLXzj.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jN_f0c1545a", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = fAbkF[n2].getBytes("ISO-8859-1");
            Class_jN_f0c1545a.SUbhZ[n2] = Class_jN_f0c1545a.bJC(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return SUbhZ[n2];
    }

    public void bJu(String string, float[] fArray) {
        this.hbdsS.setUniform(this.bJn(string), fArray);
    }

    private static Object bJE(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_jN_f0c1545a.bJD(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    public void bJs(String string, float f, float f2, float f3) {
        this.hbdsS.setUniform(this.bJn(string), f, f2, f3);
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jN_f0c1545a.class, "bJE", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

