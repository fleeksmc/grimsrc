/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.Collections;
import java.util.List;
import recovered.internal.Class_hJ_a20df6c5;

@FunctionalInterface
public interface Class_hK_37a4c9e8 {
    public Class_hJ_a20df6c5 validate(String var1);

    default public List<String> suggestions(String string) {
        return Collections.emptyList();
    }
}

