/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockState
 *  net.minecraft.util.math.BlockPos
 */
package recovered.internal;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gV_2c6a67ee
extends Class_hH_ae8f8f77 {
    private BlockPos SUWLv;
    private BlockState nBwjZ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gV_2c6a67ee(BlockPos blockPos, BlockState blockState) {
        this.SUWLv = blockPos;
        this.nBwjZ = blockState;
    }

    public BlockState bcl() {
        return this.nBwjZ;
    }

    public BlockPos bck() {
        return this.SUWLv;
    }
}

