/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderPass
 *  com.mojang.blaze3d.vertex.VertexFormat$DrawMode
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.texture.AbstractTexture
 *  net.minecraft.client.util.BufferAllocator
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.RotationAxis
 *  org.joml.Matrix4fc
 *  org.joml.Quaternionfc
 */
package recovered.internal;

import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4fc;
import org.joml.Quaternionfc;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jI_616cf0dd;
import recovered.internal.Class_jL_e8aba6a1;
import recovered.internal.Class_kR_e9b8cad1;
import recovered.internal.Class_kS_ba7468b5;
import recovered.internal.Class_lF_27593463;
import recovered.internal.Class_lh_fe04e581;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_ob_77a6de24;

public final class Class_kB_0c4c7339 {
    private static final float zDHsL = 1.5f;
    private static final Class_kS_ba7468b5 gjoAf;
    private static float ViGYP;
    private static float aRpoV;
    private static float DyNKu;
    private static boolean OoDnB;
    private static Class_iS_888f260e[] PgIMH;
    private static final long ydRat;
    private static final String[] GnaPL;
    private static final String[] CvKvX;
    private static final Map kJuha;
    private static final long[] AiQKY;
    private static final Integer[] OUraq;
    private static final Map SyQMN;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        Class_kB_0c4c7339.ydRat = Class_gb_9d201141.aYR(-7885859841398095174L, -8548699133457943515L, MethodHandles.lookup().lookupClass()).a(220053362696368L);
                        Class_kB_0c4c7339.kJuha = new HashMap<K, V>(13);
                        Class_kB_0c4c7339.bSA(new Class_iS_888f260e[3]);
                        var11 = Class_kB_0c4c7339.ydRat ^ 29959417532715L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[6];
                        var18_4 = 0;
                        var17_5 = "x\u008c\u00f3\f\u008b\u00bf\u00faP\u00f6\u0010\u0086J\u009e\u00d3o\u00e4\b\u00c0\u0004\u000f\u0003t$\u0002\u00eax\u009d\u00a5\u00cfi\u0003\u001f \u0005ykT=Y\u00ca\u009e\u00c5Z\u00aa\u00f2\u00ecp\u0015\u0018%2_M\u00ca\u00cc\\?\u009b\u00f0Ty\u00e3\u00c2\u0085\u009a _\u00b5H\u00f1\u008ej\u00d7(\u0000\u00fa\u00b3~\u00f0F[\u0089\u00c5Kt\u0006\u0095\u0084L\u009a\u0087\u00d3\u00df\u00c6fT\u00e6\u0091\u0010\b\u0093.\u0002\bU\u008bb`@/\u0091\u00a34m4";
                        var19_6 = "x\u008c\u00f3\f\u008b\u00bf\u00faP\u00f6\u0010\u0086J\u009e\u00d3o\u00e4\b\u00c0\u0004\u000f\u0003t$\u0002\u00eax\u009d\u00a5\u00cfi\u0003\u001f \u0005ykT=Y\u00ca\u009e\u00c5Z\u00aa\u00f2\u00ecp\u0015\u0018%2_M\u00ca\u00cc\\?\u009b\u00f0Ty\u00e3\u00c2\u0085\u009a _\u00b5H\u00f1\u008ej\u00d7(\u0000\u00fa\u00b3~\u00f0F[\u0089\u00c5Kt\u0006\u0095\u0084L\u009a\u0087\u00d3\u00df\u00c6fT\u00e6\u0091\u0010\b\u0093.\u0002\bU\u008bb`@/\u0091\u00a34m4".length();
                        var16_7 = 32;
                        var15_8 = -1;
lbl21:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl26:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Class_kB_0c4c7339.bSD(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "b:rf\u00a9\u001a \u00a4\u00da\u0086\u00da\u00e0\u00fdL\u00a2\u00c0&\u008f\u0099\u00f9\u00dc\u00e64\u00f8\u00cb&\"\u00a6)\u0010\f~\u001b\u00ff\u00e0J\u0007\u00fc\u00b53 \u0005tq\u00e2\u0004\u00f4\u00a3\u009c\u00ec\u00ae\u001e\u00a2T0\u00c9\u00ad\u0096\u0090\u009f\u00adtr#R5p+\u0083\u00d7\u001f\u009ez";
                            var19_6 = "b:rf\u00a9\u001a \u00a4\u00da\u0086\u00da\u00e0\u00fdL\u00a2\u00c0&\u008f\u0099\u00f9\u00dc\u00e64\u00f8\u00cb&\"\u00a6)\u0010\f~\u001b\u00ff\u00e0J\u0007\u00fc\u00b53 \u0005tq\u00e2\u0004\u00f4\u00a3\u009c\u00ec\u00ae\u001e\u00a2T0\u00c9\u00ad\u0096\u0090\u009f\u00adtr#R5p+\u0083\u00d7\u001f\u009ez".length();
                            var16_7 = 40;
                            var15_8 = -1;
lbl35:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl40:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Class_kB_0c4c7339.bSD(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl52:
                        // 1 sources

                        ** continue;
                    }
                }
                Class_kB_0c4c7339.GnaPL = var20_3;
                Class_kB_0c4c7339.CvKvX = new String[6];
                Class_kB_0c4c7339.SyQMN = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[2];
                var3_13 = 0;
                var4_14 = "\u00f0\u0097\u00ff\u008a\u00f9d?\u0011\u00bd\u0088\u0014:>!~\u0082";
                var5_15 = "\u00f0\u0097\u00ff\u008a\u00f9d?\u0011\u00bd\u0088\u0014:>!~\u0082".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl74:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        Class_kB_0c4c7339.AiQKY = var6_12;
        Class_kB_0c4c7339.OUraq = new Integer[2];
        Class_kB_0c4c7339.gjoAf = Class_kS_ba7468b5.bVE().duk(Class_lh_fe04e581.aApMr).duo(false).dul(false).dun(true).dup();
        Class_kB_0c4c7339.ViGYP = 1.0f;
        Class_kB_0c4c7339.DyNKu = 1.0f;
    }

    public static void bSw() {
        block4: {
            long l = ydRat ^ 0x3235024049E2L;
            aRpoV = ViGYP;
            ViGYP += DyNKu;
            Class_iS_888f260e[] class_iS_888f260eArray = Class_kB_0c4c7339.bSB();
            float f = DyNKu - 25.0f;
            float f2 = f == 0.0f ? 0 : (f > 0.0f ? 1 : -1);
            if (class_iS_888f260eArray != null) {
                float f3;
                if (f2 > 0) {
                    OoDnB = true;
                }
                f2 = (f3 = DyNKu - -25.0f) == 0.0f ? 0 : (f3 < 0.0f ? -1 : 1);
            }
            if (class_iS_888f260eArray != null) {
                if (f2 < 0) {
                    OoDnB = false;
                }
                f2 = (float)OoDnB;
            }
            float f4 = DyNKu = f2 != false ? DyNKu - 0.5f : DyNKu + 0.5f;
            if (Class_iS_888f260e.bwL() != null) break block4;
            Class_kB_0c4c7339.bSA(new Class_iS_888f260e[5]);
        }
    }

    public static Class_iS_888f260e[] bSB() {
        return PgIMH;
    }

    private static CallSite bSJ(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_kB_0c4c7339" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static /* synthetic */ void bSz(AbstractTexture abstractTexture, RenderPass renderPass) {
        block0: {
            long l = ydRat ^ 0x5BB2DBC11864L;
            Class_jL_e8aba6a1.SUknV.bJl();
            Class_jL_e8aba6a1.SUknV.bJu((String)((Object)Class_kB_0c4c7339.bSG("q", (int)27761, (long)(0x7A049AB9311558A1L ^ l))), Class_jF_38b68c76.bHw());
            if (abstractTexture == null) break block0;
            renderPass.bindTexture((String)((Object)Class_kB_0c4c7339.bSG("q", (int)27865, (long)(0x7A3F391E3A8580EL ^ l))), abstractTexture.getGlTextureView(), abstractTexture.getSampler());
        }
    }

    private static String bSD(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static Throwable bSC(Throwable throwable) {
        return throwable;
    }

    private static int bSH(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x3B4;
        if (OUraq[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = AiQKY[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])SyQMN.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    SyQMN.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_kB_0c4c7339", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_kB_0c4c7339.OUraq[n2] = n3;
        }
        return OUraq[n2];
    }

    private static CallSite bSG(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_kB_0c4c7339" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static AbstractTexture bSy(int n) {
        long l = ydRat ^ 0x5E8191208F97L;
        return switch (n) {
            case 1 -> Class_ob_77a6de24.cBv((String)((Object)Class_kB_0c4c7339.bSG("q", (int)31752, (long)(0x29ACBF0755625F2EL ^ l))));
            case 2 -> Class_ob_77a6de24.cBv((String)((Object)Class_kB_0c4c7339.bSG("q", (int)1490, (long)(0x3A9DF9F2D7C0A6F0L ^ l))));
            case 3 -> Class_ob_77a6de24.cBv((String)((Object)Class_kB_0c4c7339.bSG("q", (int)9476, (long)(0x1F7978F0C0778623L ^ l))));
            default -> Class_ob_77a6de24.cBv((String)((Object)Class_kB_0c4c7339.bSG("q", (int)27061, (long)(0x786F1C6C9A36CA90L ^ l))));
        };
    }

    private static String bSE(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x370;
        if (CvKvX[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])kJuha.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    kJuha.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_kB_0c4c7339", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = GnaPL[n2].getBytes("ISO-8859-1");
            Class_kB_0c4c7339.CvKvX[n2] = Class_kB_0c4c7339.bSD(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return CvKvX[n2];
    }

    private static int bSI(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_kB_0c4c7339.bSH(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public static void bSA(Class_iS_888f260e[] class_iS_888f260eArray) {
        PgIMH = class_iS_888f260eArray;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     */
    public static void bSx(MatrixStack var0, Entity var1_1, Class_mG_52c8d386 var2_2, float var3_3, int var4_4) {
        block18: {
            block16: {
                var5_5 = Class_kB_0c4c7339.ydRat ^ 138533319396081L;
                var7_6 = Class_kB_0c4c7339.bSB();
                try {
                    var0.push();
                    var8_7 = var1_1.getLerpedPos(var3_3).add(0.0, (double)(var1_1.getEyeHeight(var1_1.getPose()) / 2.0f), 0.0);
                    Class_jI_616cf0dd.bIs(var0, var8_7);
                    Class_jI_616cf0dd.bIu(var0);
                    var0.multiply((Quaternionfc)RotationAxis.POSITIVE_Z.rotationDegrees(MathHelper.lerp((float)var3_3, (float)Class_kB_0c4c7339.aRpoV, (float)Class_kB_0c4c7339.ViGYP)));
                    var0.translate(-0.75f, -0.75f, 0.01f);
                    var9_8 = new BufferAllocator(VertexFormats.POSITION_COLOR_TEXTURE_LIGHT.getVertexSize() * 4);
                    try {
                        var10_9 = new BufferBuilder(var9_8, VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR_TEXTURE_LIGHT);
                        var11_11 = var0.peek().getPositionMatrix();
                        var10_9.vertex((Matrix4fc)var11_11, 0.0f, 1.5f, 0.0f).color(var2_2.coh()).texture(0.0f, 0.0f).light(0, (int)Class_kB_0c4c7339.bSJ("g", (int)24439, (long)(5899735386516666866L ^ var5_5)));
                        var10_9.vertex((Matrix4fc)var11_11, 1.5f, 1.5f, 0.0f).color(var2_2.coh()).texture(1.0f, 0.0f).light(0, (int)Class_kB_0c4c7339.bSJ("g", (int)17493, (long)(6517679418648011473L ^ var5_5)));
                        var10_9.vertex((Matrix4fc)var11_11, 1.5f, 0.0f, 0.0f).color(var2_2.coh()).texture(1.0f, 1.0f).light(0, (int)Class_kB_0c4c7339.bSJ("g", (int)17493, (long)(6517679418648011473L ^ var5_5)));
                        var10_9.vertex((Matrix4fc)var11_11, 0.0f, 0.0f, 0.0f).color(var2_2.coh()).texture(0.0f, 1.0f).light(0, (int)Class_kB_0c4c7339.bSJ("g", (int)17493, (long)(6517679418648011473L ^ var5_5)));
                        var12_13 = var10_9.end();
                        try {
                            var13_14 = Class_kR_e9b8cad1.Dmmsd.bUZ(Class_kB_0c4c7339.gjoAf);
                            var14_16 = Class_kB_0c4c7339.bSy(var4_4);
                            Class_lF_27593463.cfD(var13_14, var12_13, (Consumer<RenderPass>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, bSz(net.minecraft.client.texture.AbstractTexture com.mojang.blaze3d.systems.RenderPass ), (Lcom/mojang/blaze3d/systems/RenderPass;)V)((AbstractTexture)var14_16));
                            if (var7_6 == null) break block16;
                            ** if (var12_13 == null) goto lbl-1000
                        }
                        catch (Throwable var13_15) {
                            block17: {
                                v0 = var12_13;
                                if (var7_6 == null) ** GOTO lbl37
                                if (v0 == null) break block17;
                                try {
                                    v0 = var12_13;
lbl37:
                                    // 2 sources

                                    v0.close();
                                }
                                catch (Throwable var14_17) {
                                    var13_15.addSuppressed(var14_17);
                                }
                            }
                            throw var13_15;
                        }
lbl-1000:
                        // 1 sources

                        {
                            var12_13.close();
                        }
lbl-1000:
                        // 2 sources

                        {
                        }
                    }
                    catch (Throwable var10_10) {
                        try {
                            var9_8.close();
                        }
                        catch (Throwable var11_12) {
                            var10_10.addSuppressed(var11_12);
                        }
                        throw var10_10;
                    }
                    var9_8.close();
                }
                finally {
                    var0.pop();
                }
            }
            if (var7_6 != null) break block18;
            Class_iS_888f260e.bwK("NNCN2");
        }
    }

    private static Object bSF(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_kB_0c4c7339.bSE(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_kB_0c4c7339.class, "bSI", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_kB_0c4c7339.class, "bSF", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

