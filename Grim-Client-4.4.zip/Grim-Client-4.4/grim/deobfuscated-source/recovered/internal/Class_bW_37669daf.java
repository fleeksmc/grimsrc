/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.core.ClientMain;
import recovered.internal.Class_bS_979bca5c;
import recovered.internal.Class_bU_714b1dad;
import recovered.internal.Class_cv_f4b0140a;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bW_37669daf
extends Class_bS_979bca5c {
    private float ukVVb;
    private int[] hTEif;
    private Class_mG_52c8d386 VoZgJ;
    private final Class_rk_bf8630d1 leDSE;
    private static final long xRlZx = Class_gb_9d201141.aYR(704933532158531826L, -7429875036314705378L, MethodHandles.lookup().lookupClass()).a(212489494341447L);
    private static final long qkDkP;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bW_37669daf(Class_cv_f4b0140a class_cv_f4b0140a, Class_mr_7eac5189 class_mr_7eac5189) {
        long l = xRlZx ^ 0x2FE1C88604DFL;
        super(class_cv_f4b0140a, class_mr_7eac5189);
        this.ukVVb = Float.NaN;
        this.leDSE = new Class_rk_bf8630d1((int)qkDkP).dhs(Class_rj_b691f4f7.NJlxm);
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = xRlZx ^ 0x1C86D7F4A2A2L;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                long l2 = -562286198288578174L;
                byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
                qkDkP = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    @Override
    public boolean MH() {
        long l = xRlZx ^ 0x70C25544E1BAL;
        int n = Class_bS_979bca5c.NS();
        boolean bl = Float.isNaN(this.ukVVb);
        if (n == 0) {
            bl = !bl;
        }
        return bl;
    }

    @Override
    public void MG(Class_lC_5322e8cf class_lC_5322e8cf, Class_ii_9b427eda class_ii_9b427eda) {
        block4: {
            block3: {
                Class_bW_37669daf class_bW_37669daf;
                block2: {
                    long l = xRlZx ^ 0x7FC27D5EDB75L;
                    int n = Class_bS_979bca5c.NS();
                    class_bW_37669daf = this;
                    if (n != 0) break block2;
                    if (class_bW_37669daf.VoZgJ == null) break block3;
                    class_bW_37669daf = this;
                }
                if (class_bW_37669daf.hTEif != null) break block4;
            }
            return;
        }
        Class_bU_714b1dad class_bU_714b1dad = ClientMain.dlK().RC();
        float f = class_bU_714b1dad.RW();
        float f2 = class_bU_714b1dad.RX();
        Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
        float f3 = 255.0f * this.dExGi.dhj();
        float f4 = 20.0f * this.dExGi.dhj();
        float f5 = class_lq_87a74641.cap(this.hTEif);
        float f6 = 3.5f;
        float f7 = f - 16.0f + f4;
        float f8 = f2 + 3.5f;
        float f9 = 2.0f * f6 + 6.0f;
        float f10 = 8.0f;
        this.fGWTH.NU(f9 + 8.0f + f5 + 5.0f, 15.0f);
        class_lC_5322e8cf.cdg(f7, f8, f9, f10, Class_ld_bb1690e1.all(3.0f), this.VoZgJ.coa(f3));
        float f11 = 6.0f;
        float f12 = f7 + f9 * 0.5f;
        float f13 = f8 + f10 * 0.5f;
        class_lC_5322e8cf.ceV();
        class_lC_5322e8cf.cfb(f12, f13, this.leDSE.dhj());
        class_lC_5322e8cf.cem(Class_lf_d247d983.hzyQG, f12 - f11 * 0.5f, f13 - f11 * 0.5f, f11, Class_mG_52c8d386.hoGuU.coa(f3));
        class_lC_5322e8cf.ceW();
        Class_mG_52c8d386 class_mG_52c8d386 = class_ii_9b427eda.bjb().coa(255.0f * this.dExGi.dhj());
        float f14 = f + 31.0f - 10.0f * this.dExGi.dhj();
        class_lC_5322e8cf.ceA(class_lq_87a74641, this.hTEif, f14, f2 + 5.0f, class_mG_52c8d386);
    }

    public void Oj(float f, int[] nArray, Class_mG_52c8d386 class_mG_52c8d386) {
        block4: {
            float f2;
            block2: {
                block3: {
                    long l = xRlZx ^ 0x18E051F61592L;
                    int n = Class_bS_979bca5c.NS();
                    f2 = this.ukVVb;
                    if (n != 0) break block2;
                    if (!Float.isNaN(f2)) break block3;
                    this.leDSE.dhf(f);
                    if (n == 0) break block4;
                }
                f2 = this.leDSE.dhj();
            }
            float f3 = f2;
            float f4 = ((f - f3) % 360.0f + 540.0f) % 360.0f - 180.0f;
            this.leDSE.dhd(f3 + f4);
        }
        this.ukVVb = f;
        this.hTEif = nArray;
        this.VoZgJ = class_mG_52c8d386;
    }

    private static MatchException Ok(MatchException matchException) {
        return matchException;
    }
}

