/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec2f
 *  org.joml.Matrix3x2fStack
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.util.math.Vec2f;
import org.joml.Matrix3x2fStack;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jO_1924117a;
import recovered.internal.Class_jQ_28340a81;
import recovered.internal.Class_mG_52c8d386;

public class Class_jQ_ub_ee126734 {
    private Matrix3x2fStack jUlYD;
    private Vec2f aBdrz;
    private Vec2f jyGVB;
    private Vec2f KEhXG;
    private Vec2f XiiWF;
    private boolean xhAIf;
    private Class_mG_52c8d386 nAKto;
    private boolean gKWoY;
    private float zacIX;
    private boolean crNIb;
    private float RYmQU;
    private static final long KDywn;
    private static final String[] EhNUi;
    private static final String[] sFHyX;
    private static final Map YgyYc;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_jQ_ub_ee126734() {
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_jQ_ub_ee126734.KDywn = Class_gb_9d201141.aYR(-8288943320250390552L, -1596514271136119552L, MethodHandles.lookup().lookupClass()).a(210490629004726L);
                Class_jQ_ub_ee126734.YgyYc = new HashMap<K, V>(13);
                var0 = Class_jQ_ub_ee126734.KDywn ^ 99102793713177L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[8];
                var7_4 = 0;
                var6_5 = "+j\u001b;pC,\u00dc\u00f1\u00f5b\u00cd\u00fc\u00c6?\u00f9p\u00fe]\u00ae\u00f7\u00cf\u00a9lP\u00c4\u0007\u00f3\u00ac#,0\u00b7\u00f0!|<B/4\u000b\u001a\u00ca\u000f\u00aa\u00ac+&\u00e9\u0096'\u00c1XvKN1\u0089\u008d\u00c4G\u00d1\u0088\u001bJ\u008bt\u008cM\u00cc&B\u0098R\u00a91\n^\u008c\u00b9oT\u00ab\u00b4\u009d2L\u00b7\u0084\u00d6\u001eX\u0016J7\u00c8\u00a0\u00adG&\u00c6\u0095\u00a8aI\u0010\u00cb\u0083\u00f5\u0016\u001b\u0000&|\u00c2\u00a9\u00e8\u00b5\u00fb\u00ec\u0013<\u0010\u0089\u00f2\u00c7\u00f1\u00a2\u00ff\u00fe\u00e0H@\u0000\u00e3\u00ae\u009e\u00f0<(\u00fe\u0099\u00f6Ta$\u0000\u0010\u0006R\u00a1\u009c\"\u00bat\u00c1\u00fc#\u0090\u00b3\u009e\u008a^\u00dc\u00d17\u00cb\u00ed\u00a2\u0018.my\u00d0\u00eax\u0000\u00b1\u0019\u00e6(\u00f96c)\u0013\u0091I\u00c4\u00f9\u0092\u00c0\u008e\u0092q\u0095\u0099\u00b0\u00fd\u00f3=\u0086meddQ\u00ddl\u00cc\u007f&\u00ce\u00c6q\u00a0\u00f3_\u00f3?b";
                var8_6 = "+j\u001b;pC,\u00dc\u00f1\u00f5b\u00cd\u00fc\u00c6?\u00f9p\u00fe]\u00ae\u00f7\u00cf\u00a9lP\u00c4\u0007\u00f3\u00ac#,0\u00b7\u00f0!|<B/4\u000b\u001a\u00ca\u000f\u00aa\u00ac+&\u00e9\u0096'\u00c1XvKN1\u0089\u008d\u00c4G\u00d1\u0088\u001bJ\u008bt\u008cM\u00cc&B\u0098R\u00a91\n^\u008c\u00b9oT\u00ab\u00b4\u009d2L\u00b7\u0084\u00d6\u001eX\u0016J7\u00c8\u00a0\u00adG&\u00c6\u0095\u00a8aI\u0010\u00cb\u0083\u00f5\u0016\u001b\u0000&|\u00c2\u00a9\u00e8\u00b5\u00fb\u00ec\u0013<\u0010\u0089\u00f2\u00c7\u00f1\u00a2\u00ff\u00fe\u00e0H@\u0000\u00e3\u00ae\u009e\u00f0<(\u00fe\u0099\u00f6Ta$\u0000\u0010\u0006R\u00a1\u009c\"\u00bat\u00c1\u00fc#\u0090\u00b3\u009e\u008a^\u00dc\u00d17\u00cb\u00ed\u00a2\u0018.my\u00d0\u00eax\u0000\u00b1\u0019\u00e6(\u00f96c)\u0013\u0091I\u00c4\u00f9\u0092\u00c0\u008e\u0092q\u0095\u0099\u00b0\u00fd\u00f3=\u0086meddQ\u00ddl\u00cc\u007f&\u00ce\u00c6q\u00a0\u00f3_\u00f3?b".length();
                var5_7 = 24;
                var4_8 = -1;
lbl20:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl25:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jQ_ub_ee126734.drw(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "\u00de\u00eb(\u009c\u00f5[\u00144\u00c6<.^\u00b6\u00dcO\u0007\u00f3|\u0098D\u0091\u009d\u00de!\u00ea\u0085,\u00e4\u00f0\u00ae\u0085\u001c\u0010l\u0003\u0091{\u0002\u00a6\u00c5\u0015\u001c*^T\u00a0!\u00a4#";
                    var8_6 = "\u00de\u00eb(\u009c\u00f5[\u00144\u00c6<.^\u00b6\u00dcO\u0007\u00f3|\u0098D\u0091\u009d\u00de!\u00ea\u0085,\u00e4\u00f0\u00ae\u0085\u001c\u0010l\u0003\u0091{\u0002\u00a6\u00c5\u0015\u001c*^T\u00a0!\u00a4#".length();
                    var5_7 = 32;
                    var4_8 = -1;
lbl34:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jQ_ub_ee126734.drw(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl51:
                // 1 sources

                ** continue;
            }
        }
        Class_jQ_ub_ee126734.EhNUi = var9_3;
        Class_jQ_ub_ee126734.sFHyX = new String[8];
    }

    public String toString() {
        long l = KDywn ^ 0x65F5C198CB81L;
        float f = this.RYmQU;
        float f2 = this.zacIX;
        String string = String.valueOf(this.nAKto);
        String string2 = String.valueOf(this.XiiWF);
        String string3 = String.valueOf(this.KEhXG);
        String string4 = String.valueOf(this.jyGVB);
        String string5 = String.valueOf(this.aBdrz);
        String string6 = String.valueOf(this.jUlYD);
        return (String)((Object)Class_jQ_ub_ee126734.drz("a", (int)12840, (long)(0x28CC42607A5D682DL ^ l))) + string6 + (String)((Object)Class_jQ_ub_ee126734.drz("a", (int)12887, (long)(0x652D9976EAC3E851L ^ l))) + string5 + (String)((Object)Class_jQ_ub_ee126734.drz("a", (int)25888, (long)(0x478AFC8C68CC3F27L ^ l))) + string4 + (String)((Object)Class_jQ_ub_ee126734.drz("a", (int)15780, (long)(0x823828ED85D67A7L ^ l))) + string3 + (String)((Object)Class_jQ_ub_ee126734.drz("a", (int)3700, (long)(0x73D1508165075470L ^ l))) + string2 + (String)((Object)Class_jQ_ub_ee126734.drz("a", (int)16753, (long)(0x5AE30CF249AD1B73L ^ l))) + string + (String)((Object)Class_jQ_ub_ee126734.drz("a", (int)27083, (long)(0x5AD78124871933CAL ^ l))) + f2 + (String)((Object)Class_jQ_ub_ee126734.drz("a", (int)6273, (long)(0x18D5835062B9C281L ^ l))) + f + ")";
    }

    public Class_jQ_ub_ee126734 drr(Class_mG_52c8d386 class_mG_52c8d386) {
        this.nAKto = class_mG_52c8d386;
        this.xhAIf = true;
        return this;
    }

    private static String drw(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public Class_jQ_ub_ee126734 drs(float f) {
        this.zacIX = f;
        this.gKWoY = true;
        return this;
    }

    private static MatchException drv(MatchException matchException) {
        return matchException;
    }

    public Class_jQ_ub_ee126734 drn(Vec2f vec2f) {
        this.aBdrz = vec2f;
        return this;
    }

    public Class_jQ_ub_ee126734 dro(Vec2f vec2f) {
        this.jyGVB = vec2f;
        return this;
    }

    public Class_jQ_ub_ee126734 drp(Vec2f vec2f) {
        this.KEhXG = vec2f;
        return this;
    }

    public Class_jQ_ub_ee126734 drq(Vec2f vec2f) {
        this.XiiWF = vec2f;
        return this;
    }

    public Class_jQ_ub_ee126734 drm(Matrix3x2fStack matrix3x2fStack) {
        this.jUlYD = matrix3x2fStack;
        return this;
    }

    public Class_jQ_28340a81 dru() {
        long l = KDywn ^ 0x37852B56FF5DL;
        Class_mG_52c8d386 class_mG_52c8d386 = this.nAKto;
        String string = Class_jO_1924117a.bKy();
        Class_jQ_ub_ee126734 class_jQ_ub_ee126734 = this;
        if (string != null) {
            if (!class_jQ_ub_ee126734.xhAIf) {
                class_mG_52c8d386 = Class_jQ_28340a81.bLA();
            }
            class_jQ_ub_ee126734 = this;
        }
        float f = class_jQ_ub_ee126734.zacIX;
        Class_jQ_ub_ee126734 class_jQ_ub_ee1267342 = this;
        if (string != null) {
            if (!class_jQ_ub_ee1267342.gKWoY) {
                f = Class_jQ_28340a81.bLB();
            }
            class_jQ_ub_ee1267342 = this;
        }
        float f2 = class_jQ_ub_ee1267342.RYmQU;
        if (!this.crNIb) {
            f2 = Class_jQ_28340a81.bLC();
        }
        return new Class_jQ_28340a81(this.jUlYD, this.aBdrz, this.jyGVB, this.KEhXG, this.XiiWF, class_mG_52c8d386, f, f2);
    }

    public Class_jQ_ub_ee126734 drt(float f) {
        this.RYmQU = f;
        this.crNIb = true;
        return this;
    }

    private static CallSite drz(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jQ_ub_ee126734" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static String drx(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5039;
        if (sFHyX[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])YgyYc.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    YgyYc.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jQ_ub_ee126734", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = EhNUi[n2].getBytes("ISO-8859-1");
            Class_jQ_ub_ee126734.sFHyX[n2] = Class_jQ_ub_ee126734.drw(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return sFHyX[n2];
    }

    private static Object dry(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_jQ_ub_ee126734.drx(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jQ_ub_ee126734.class, "dry", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

