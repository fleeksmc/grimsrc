/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_gZ_7f253658;

public class Class_gZ_tt_1a0b4de2
extends Class_gZ_7f253658 {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

