/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.VertexConsumerProvider$Immediate
 */
package recovered.internal;

import net.minecraft.client.render.VertexConsumerProvider;

public record Class_jA_21841da7(VertexConsumerProvider.Immediate bufferSource) {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

