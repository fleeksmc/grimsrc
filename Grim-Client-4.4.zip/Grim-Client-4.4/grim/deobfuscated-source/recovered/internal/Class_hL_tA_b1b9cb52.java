/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import recovered.core.NativeLoader;
import recovered.internal.Class_hJ_a20df6c5;
import recovered.internal.Class_hK_37a4c9e8;
import recovered.internal.Class_hL_db8a30f6;

class Class_hL_tA_b1b9cb52
implements Class_hK_37a4c9e8 {
    final List PfxnI;
    final String nlvqT;
    private static long fLZhy;
    private static String vIVbz;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Ignored method signature, as it can't be verified against descriptor
     */
    Class_hL_tA_b1b9cb52(Class_hL_db8a30f6 class_hL_db8a30f6, List list, String string) {
        this.PfxnI = list;
        this.nlvqT = string;
    }

    static {
        NativeLoader.doInit(Class_hL_tA_b1b9cb52.class);
        Class_hL_tA_b1b9cb52._b7f2afaf3d867f5f84c292d44cd543bc();
    }

    @Override
    public native Class_hJ_a20df6c5 validate(String var1);

    @Override
    public native List<String> suggestions(String var1);

    private static native void _b7f2afaf3d867f5f84c292d44cd543bc();

    private static native String dpx(byte[] var0);

    private static native boolean dpv(String var0, String var1);

    private static native MatchException dpw(MatchException var0);
}

