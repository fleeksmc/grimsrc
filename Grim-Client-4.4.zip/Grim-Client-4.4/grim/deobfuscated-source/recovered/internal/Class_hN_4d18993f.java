/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_hL_db8a30f6;
import recovered.internal.Class_hX_15329af5;
import recovered.internal.Class_hZ_076851ce;

public class Class_hN_4d18993f {
    private static long ZIbsd;
    private static String[] gqKFb;
    private static String[] gtSbR;
    private static Map GNElG;
    private static long KYpYH;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_hN_4d18993f.class);
        Class_hN_4d18993f._1203f8110a281d05ed03f9ba362499ec();
    }

    public native Class_hZ_076851ce ber();

    private static native MatchException beu(MatchException var0);

    private static native String bew(int var0, long var1);

    private static native Object bex(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native String bev(byte[] var0);

    private static native /* synthetic */ void bes(Class_hX_15329af5 var0);

    private static native /* synthetic */ void bet(Class_hL_db8a30f6 var0);

    private static native CallSite bey(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native void _1203f8110a281d05ed03f9ba362499ec();
}

