/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

class Class_ar_rT_99a3d414 {
    private final Class_rk_bf8630d1 djTyU;
    private final Class_rk_bf8630d1 WfbkF;
    private final Class_rk_bf8630d1 PYnOc;
    private final Class_rk_bf8630d1 AtkkH;
    private final Class_mG_52c8d386 sBzpH;
    private final int RshAW;
    private boolean HEngx;
    private static long hCewy;
    private static long[] cXHaj;
    private static Integer[] tlgoG;
    private static Map OsgTH;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_ar_rT_99a3d414(Class_mG_52c8d386 class_mG_52c8d386) {
        long l = hCewy ^ 0x551842701B7BL;
        this.djTyU = new Class_rk_bf8630d1((int)Class_ar_rT_99a3d414.dnc("l", (int)4833, (long)(0x6A37947008BEFA43L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.WfbkF = new Class_rk_bf8630d1((int)Class_ar_rT_99a3d414.dnc("l", (int)31529, (long)(0x188F294D2079388L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.PYnOc = new Class_rk_bf8630d1((int)Class_ar_rT_99a3d414.dnc("l", (int)22178, (long)(0x1180D31074333E01L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.AtkkH = new Class_rk_bf8630d1((int)Class_ar_rT_99a3d414.dnc("l", (int)14751, (long)(0x4BC4D69AAC84513FL ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.HEngx = true;
        this.sBzpH = class_mG_52c8d386;
        this.RshAW = class_mG_52c8d386.coh();
    }

    static {
        NativeLoader.doInit(Class_ar_rT_99a3d414.class);
        Class_ar_rT_99a3d414._41499fd393f6cea041c30dfbc357fbb5();
    }

    private native Class_rk_bf8630d1 dmT();

    private native Class_mG_52c8d386 dmW();

    private native Class_rk_bf8630d1 dmU();

    private native Class_rk_bf8630d1 dmV();

    private native int dmX();

    private native boolean dmY();

    private native void dmZ(boolean var1);

    private static native int dna(int var0, long var1);

    private static native int dnb(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native void _41499fd393f6cea041c30dfbc357fbb5();

    private native Class_rk_bf8630d1 dmS();

    private static native CallSite dnc(MethodHandles.Lookup var0, String var1, MethodType var2);
}

