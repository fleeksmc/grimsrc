/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.world.World
 */
package recovered.internal;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gE_dd587720
extends Class_hH_ae8f8f77 {
    private final ItemStack LZFXO;
    private final World hXHRe;
    private final PlayerEntity dDyGN;
    private final int boXDo;
    private final int pUfOw;
    private final float LPbwe;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gE_dd587720(ItemStack itemStack, World world, PlayerEntity playerEntity, int n, int n2, float f) {
        this.LZFXO = itemStack;
        this.hXHRe = world;
        this.dDyGN = playerEntity;
        this.boXDo = n;
        this.pUfOw = n2;
        this.LPbwe = f;
    }

    public int bbZ() {
        return this.boXDo;
    }

    public ItemStack bbW() {
        return this.LZFXO;
    }

    public World bbX() {
        return this.hXHRe;
    }

    public PlayerEntity bbY() {
        return this.dDyGN;
    }

    public int bca() {
        return this.pUfOw;
    }

    public float bcb() {
        return this.LPbwe;
    }
}

