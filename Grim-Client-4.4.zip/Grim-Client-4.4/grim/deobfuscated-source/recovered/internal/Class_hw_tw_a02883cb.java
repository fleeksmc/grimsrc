/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 */
package recovered.internal;

import net.minecraft.entity.Entity;
import recovered.internal.Class_hw_ffa47777;

public class Class_hw_tw_a02883cb
extends Class_hw_ffa47777 {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hw_tw_a02883cb(Entity entity) {
        super(entity);
    }
}

