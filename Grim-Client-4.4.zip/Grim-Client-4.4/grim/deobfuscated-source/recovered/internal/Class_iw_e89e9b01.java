/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import recovered.core.NativeLoader;
import recovered.internal.Class_iD_f0bb28c7;
import recovered.internal.Class_iE_00f71a81;
import recovered.internal.Class_iu_bf2db566;
import recovered.internal.Class_ix_05f2a225;
import recovered.internal.Class_iy_c88c0f4f;
import recovered.internal.Class_iz_2ddebd14;

public class Class_iw_e89e9b01
extends Class_iE_00f71a81
implements Class_ix_05f2a225 {
    private static boolean LhKUM;
    private static long xOjin;
    private static String[] hpuQi;
    private static String[] KQSlf;
    private static Map UMEjF;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_iw_e89e9b01.class);
        Class_iw_e89e9b01._cae88d6de7415b60c56646d26e06ceb6();
    }

    private static native String bof(int var0, long var1);

    @Override
    public native CompletableFuture<Class_iz_2ddebd14> fetchKeyPreset(String var1);

    @Override
    public native CompletableFuture<Class_iy_c88c0f4f> updateProfile(String var1, Class_iD_f0bb28c7 var2);

    @Override
    public native CompletableFuture<Class_iy_c88c0f4f> createProfile(Class_iD_f0bb28c7 var1);

    @Override
    public native CompletableFuture<Class_iu_bf2db566> deleteProfile(String var1);

    @Override
    public native CompletableFuture<Class_iu_bf2db566> importProfile(String var1);

    @Override
    public native CompletableFuture<List<Class_iy_c88c0f4f>> fetchProfiles();

    private static native /* synthetic */ Class_iz_2ddebd14 bnZ(Throwable var0);

    private static native CallSite boh(MethodHandles.Lookup var0, String var1, MethodType var2);

    public static native void boa(boolean var0);

    private static native MatchException bod(MatchException var0);

    private static native Object bog(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public static native boolean boc();

    private native /* synthetic */ Class_iy_c88c0f4f bnV(Throwable var1);

    private native /* synthetic */ Class_iu_bf2db566 bnW(Throwable var1);

    private static native String boe(byte[] var0);

    public static native boolean bob();

    private native /* synthetic */ Class_iu_bf2db566 bnU(Throwable var1);

    private native /* synthetic */ Class_iy_c88c0f4f bnX(Throwable var1);

    private native /* synthetic */ Class_iu_bf2db566 bnT(Throwable var1);

    private native /* synthetic */ Class_iy_c88c0f4f bnY(Throwable var1);

    @Override
    public native CompletableFuture<Class_iu_bf2db566> loadProfile(Class_iy_c88c0f4f var1);

    private static native void _cae88d6de7415b60c56646d26e06ceb6();

    @Override
    public native CompletableFuture<Class_iy_c88c0f4f> fetchProfile(String var1);
}

