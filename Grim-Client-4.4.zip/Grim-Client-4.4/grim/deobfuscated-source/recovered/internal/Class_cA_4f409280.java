/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  org.apache.commons.lang3.tuple.MutablePair
 */
package recovered.internal;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.tuple.MutablePair;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mU_1ea4466c;
import recovered.internal.Class_mr_7eac5189;

public class Class_cA_4f409280
extends Class_cB_67aec11c {
    private double PTaqi = -1.7976931348623157E308;
    private double GOtZp = Double.MAX_VALUE;
    private double thjOL;
    private final MutablePair<Double, Double> wJgtl = MutablePair.of((Object)0.0, (Object)0.0);
    private String pSPRn = "";
    private static final long ohlej;
    private static final String[] hoqLM;
    private static final String[] xcUqQ;
    private static final Map wtWpm;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cA_4f409280(Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_mr_7eac5189);
    }

    public Class_cA_4f409280(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_cA_4f409280.ohlej = Class_gb_9d201141.aYR(8502255672634985563L, -6050114685291028941L, MethodHandles.lookup().lookupClass()).a(40475717437278L);
                Class_cA_4f409280.wtWpm = new HashMap<K, V>(13);
                var0 = Class_cA_4f409280.ohlej ^ 79353097297229L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[4];
                var7_4 = 0;
                var6_5 = "\u00d4\u00af\u00a2\u0010\u0096\u00ab \u00e3\u00eb\u0016\u00c0cE\u00c1\u0097\u00e4\u0010FF\u009a\u0019:m\"<kwZ)B\\v\u0082";
                var8_6 = "\u00d4\u00af\u00a2\u0010\u0096\u00ab \u00e3\u00eb\u0016\u00c0cE\u00c1\u0097\u00e4\u0010FF\u009a\u0019:m\"<kwZ)B\\v\u0082".length();
                var5_7 = 16;
                var4_8 = -1;
lbl20:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl25:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_cA_4f409280.UZ(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "\u00834\u00f79\u00bce\u0080]\u008c\u00c0\u00fb\u00f5'\u00f2\u0081\u00fa\u0010lm\u000e\u00da\u00a0UT\u00b3@\u00a0\u00b0+m\u00ab_\t";
                    var8_6 = "\u00834\u00f79\u00bce\u0080]\u008c\u00c0\u00fb\u00f5'\u00f2\u0081\u00fa\u0010lm\u000e\u00da\u00a0UT\u00b3@\u00a0\u00b0+m\u00ab_\t".length();
                    var5_7 = 16;
                    var4_8 = -1;
lbl34:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_cA_4f409280.UZ(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl51:
                // 1 sources

                ** continue;
            }
        }
        Class_cA_4f409280.hoqLM = var9_3;
        Class_cA_4f409280.xcUqQ = new String[4];
    }

    public float UP(int n) {
        long l = ohlej ^ 0x4D0425BDF478L;
        return n == 0 ? ((Double)this.wJgtl.getLeft()).floatValue() : ((Double)this.wJgtl.getRight()).floatValue();
    }

    public double UT() {
        return this.PTaqi;
    }

    private double US(double d) {
        long l = ohlej ^ 0x26FCCC042FD8L;
        double d2 = Math.min(this.PTaqi, this.GOtZp);
        boolean bl = Class_cB_67aec11c.Vu();
        double d3 = Math.max(this.PTaqi, this.GOtZp);
        double d4 = Math.max(d2, Math.min(d3, d));
        double d5 = this.thjOL;
        if (!bl) {
            if (d5 > 0.0) {
                d4 = (double)Math.round(d4 / this.thjOL) * this.thjOL;
                d4 = Math.max(d2, Math.min(d3, d4));
            }
            d5 = d4;
        }
        return d5;
    }

    public Class_cA_4f409280 UK(double d) {
        long l = ohlej ^ 0x7B13CEEBA3C7L;
        double d2 = this.US(d);
        boolean bl = Class_cB_67aec11c.Vu();
        MutablePair<Double, Double> mutablePair = this.wJgtl;
        if (!bl) {
            if (Double.compare((Double)mutablePair.left, d2) == 0) {
                return this;
            }
            mutablePair = this.wJgtl;
        }
        mutablePair.setLeft((Object)d2);
        this.Vk();
        return this;
    }

    public double UV() {
        return this.thjOL;
    }

    public Class_cA_4f409280 UI(double d, double d2) {
        return this.UJ((MutablePair<Double, Double>)MutablePair.of((Object)d, (Object)d2));
    }

    @Override
    public void SS(JsonElement jsonElement) {
        boolean bl;
        double d;
        double d2;
        block14: {
            CallSite callSite;
            JsonObject jsonObject;
            block16: {
                boolean bl2;
                JsonObject jsonObject2;
                long l;
                block15: {
                    JsonElement jsonElement2;
                    block9: {
                        block10: {
                            block13: {
                                JsonObject jsonObject3;
                                block12: {
                                    int n;
                                    block11: {
                                        l = ohlej ^ 0x35D3349896AAL;
                                        d2 = (Double)this.wJgtl.left;
                                        d = (Double)this.wJgtl.right;
                                        bl = Class_cB_67aec11c.Vu();
                                        jsonElement2 = jsonElement;
                                        if (bl) break block9;
                                        if (!jsonElement2.isJsonArray()) break block10;
                                        jsonObject2 = jsonElement.getAsJsonArray();
                                        n = jsonObject2.isEmpty();
                                        if (bl) break block11;
                                        if (n == 0) {
                                            d2 = jsonObject2.get(0).getAsDouble();
                                        }
                                        jsonObject3 = jsonObject2;
                                        if (bl) break block12;
                                        n = jsonObject3.size();
                                    }
                                    if (n <= 1) break block13;
                                    jsonObject3 = jsonObject2.get(1);
                                }
                                d = jsonObject3.getAsDouble();
                            }
                            if (!bl) break block14;
                        }
                        jsonElement2 = jsonElement;
                    }
                    jsonObject2 = jsonElement2.getAsJsonObject();
                    bl2 = jsonObject2.has((String)((Object)Class_cA_4f409280.Vc("y", (int)19391, (long)(0x5C1B85288CA5568FL ^ l))));
                    if (bl) break block15;
                    if (bl2) {
                        d2 = jsonObject2.get((String)((Object)Class_cA_4f409280.Vc("y", (int)30571, (long)(0x702FAD8ECCA96A58L ^ l)))).getAsDouble();
                    }
                    jsonObject = jsonObject2;
                    callSite = Class_cA_4f409280.Vc("y", (int)26735, (long)(0x686ADAD20D61F55EL ^ l));
                    if (bl) break block16;
                    bl2 = jsonObject.has((String)((Object)callSite));
                }
                if (!bl2) break block14;
                jsonObject = jsonObject2;
                callSite = Class_cA_4f409280.Vc("y", (int)17767, (long)(0x1C6C14CA90165855L ^ l));
            }
            d = jsonObject.get((String)((Object)callSite)).getAsDouble();
        }
        this.UJ((MutablePair<Double, Double>)new MutablePair((Object)d2, (Object)d));
        if (Class_iS_888f260e.bwL() == null) {
            Class_cB_67aec11c.Vs(!bl);
        }
    }

    public MutablePair<Double, Double> UW() {
        return this.wJgtl;
    }

    @Override
    public void SR(Map<String, Object> map) {
        map.put(Arrays.toString(this.NwlSF), MutablePair.of((Object)((Double)this.wJgtl.left), (Object)((Double)this.wJgtl.right)));
    }

    public String UX() {
        return this.pSPRn;
    }

    private static String Va(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x359A;
        if (xcUqQ[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])wtWpm.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    wtWpm.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cA_4f409280", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = hoqLM[n2].getBytes("ISO-8859-1");
            Class_cA_4f409280.xcUqQ[n2] = Class_cA_4f409280.UZ(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return xcUqQ[n2];
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean UM(double d) {
        double d2;
        block5: {
            boolean bl;
            block4: {
                long l = ohlej ^ 0x2B22A7A5B90FL;
                bl = Class_cB_67aec11c.Vt();
                double d3 = d - (Double)this.wJgtl.getLeft();
                d2 = d3 == 0.0 ? 0 : (d3 > 0.0 ? 1 : -1);
                if (!bl) break block4;
                if (d2 < 0) break block5;
                double d4 = d - (Double)this.wJgtl.getRight();
                d2 = d4 == 0.0 ? 0 : (d4 < 0.0 ? -1 : 1);
            }
            if (!bl) return (boolean)d2;
            if (d2 <= 0) {
                d2 = 1.0;
                return (boolean)d2;
            }
        }
        d2 = 0.0;
        return (boolean)d2;
    }

    public long UR(int n) {
        long l = ohlej ^ 0x229F53190B6L;
        return n == 0 ? ((Double)this.wJgtl.getLeft()).longValue() : ((Double)this.wJgtl.getRight()).longValue();
    }

    private static CallSite Vc(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cA_4f409280" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public int UQ(int n) {
        long l = ohlej ^ 0x16929713EB21L;
        boolean bl = Class_cB_67aec11c.Vu();
        int n2 = n;
        if (!bl) {
            n2 = n2 == 0 ? ((Double)this.wJgtl.getLeft()).intValue() : ((Double)this.wJgtl.getRight()).intValue();
        }
        return n2;
    }

    public Number UO() {
        return ((Double)this.wJgtl.getLeft() + (Double)this.wJgtl.getRight()) / 2.0;
    }

    private static Object Vb(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_cA_4f409280.Va(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    public Class_cA_4f409280 UL(double d) {
        long l = ohlej ^ 0x100175B68CE1L;
        double d2 = this.US(d);
        boolean bl = Class_cB_67aec11c.Vu();
        MutablePair<Double, Double> mutablePair = this.wJgtl;
        if (!bl) {
            if (Double.compare((Double)mutablePair.right, d2) == 0) {
                return this;
            }
            mutablePair = this.wJgtl;
        }
        mutablePair.setRight((Object)d2);
        this.Vk();
        return this;
    }

    public double UU() {
        return this.GOtZp;
    }

    private static String UZ(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public Number UN() {
        return Class_mU_1ea4466c.cpR(this);
    }

    private static MatchException UY(MatchException matchException) {
        return matchException;
    }

    /*
     * Unable to fully structure code
     */
    public Class_cA_4f409280 UJ(MutablePair<Double, Double> var1_1) {
        var2_2 = Class_cA_4f409280.ohlej ^ 14676835329887L;
        var5_3 = this.US((Double)var1_1.left);
        var4_4 = Class_cB_67aec11c.Vu();
        var7_5 = this.US((Double)var1_1.right);
        v0 = this.wJgtl;
        if (!var4_4) {
            if (Double.compare((Double)v0.left, var5_3) == 0) {
                v0 = this.wJgtl;
                if (!var4_4) {
                    if (Double.compare((Double)v0.right, var7_5) == 0) {
                        return this;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                this.wJgtl.setLeft((Object)var5_3);
                v0 = this.wJgtl;
            }
        }
        v0.setRight((Object)var7_5);
        this.Vk();
        return this;
    }

    public Class_cA_4f409280 UE(double d) {
        this.PTaqi = d;
        return this.UJ((MutablePair<Double, Double>)MutablePair.of((Object)((Double)this.wJgtl.left), (Object)((Double)this.wJgtl.right)));
    }

    public Class_cA_4f409280 UG(double d) {
        this.thjOL = Math.max(0.0, d);
        return this.UJ((MutablePair<Double, Double>)MutablePair.of((Object)((Double)this.wJgtl.left), (Object)((Double)this.wJgtl.right)));
    }

    public Class_cA_4f409280 UF(double d) {
        this.GOtZp = d;
        return this.UJ((MutablePair<Double, Double>)MutablePair.of((Object)((Double)this.wJgtl.left), (Object)((Double)this.wJgtl.right)));
    }

    public Class_cA_4f409280 UH(String string) {
        long l = ohlej ^ 0x567BC1FA5F4FL;
        boolean bl = Class_cB_67aec11c.Vu();
        String string2 = string;
        if (!bl) {
            string2 = string2 == null ? "" : string;
        }
        this.pSPRn = string2;
        return this;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cA_4f409280.class, "Vb", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

