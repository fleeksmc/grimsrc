/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.joml.Vector4f
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.util.ArrayDeque;
import java.util.Deque;
import org.joml.Vector4f;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;

public final class Class_jF_38b68c76 {
    private static final float[] jJgKH;
    private static final Deque<float[]> WjVUd;
    private static boolean gfICi;
    private static final long uKzlv;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        uKzlv = Class_gb_9d201141.aYR(-5824617674824207052L, -5855478531357891036L, MethodHandles.lookup().lookupClass()).a(25331677279744L);
        jJgKH = new float[]{1.0f, 1.0f, 1.0f, 1.0f};
        Class_jF_38b68c76.bHE(false);
        WjVUd = new ArrayDeque<float[]>();
    }

    public static float bHy() {
        return jJgKH[3];
    }

    public static Vector4f bHx() {
        return new Vector4f(jJgKH[0], jJgKH[1], jJgKH[2], jJgKH[3]);
    }

    public static void bHz(float f, float f2, float f3, float f4) {
        Class_jF_38b68c76.jJgKH[0] = f;
        Class_jF_38b68c76.jJgKH[1] = f2;
        Class_jF_38b68c76.jJgKH[2] = f3;
        Class_jF_38b68c76.jJgKH[3] = f4;
    }

    public static float[] bHw() {
        return jJgKH;
    }

    public static boolean bHG() {
        boolean bl = Class_jF_38b68c76.bHF();
        return !bl;
    }

    public static boolean bHF() {
        return gfICi;
    }

    public static void bHB(float f) {
        Class_jF_38b68c76.bHA(1.0f, 1.0f, 1.0f, f);
    }

    public static void bHA(float f, float f2, float f3, float f4) {
        block0: {
            long l = uKzlv ^ 0x2D3F8E0E3682L;
            boolean bl = Class_jF_38b68c76.bHG();
            WjVUd.push(new float[]{jJgKH[0], jJgKH[1], jJgKH[2], jJgKH[3]});
            boolean bl2 = bl;
            Class_jF_38b68c76.bHz(f, f2, f3, f4);
            if (bl2) break block0;
            Class_iS_888f260e.bwK("CVusTc");
        }
    }

    public static void bHC() {
        boolean bl;
        block6: {
            block5: {
                Object object;
                block4: {
                    long l = uKzlv ^ 0x7D949A6C2C91L;
                    bl = Class_jF_38b68c76.bHF();
                    object = WjVUd;
                    if (bl) break block4;
                    if (object.isEmpty()) break block5;
                    object = WjVUd.pop();
                }
                float[] fArray = (float[])object;
                Class_jF_38b68c76.jJgKH[0] = fArray[0];
                Class_jF_38b68c76.jJgKH[1] = fArray[1];
                Class_jF_38b68c76.jJgKH[2] = fArray[2];
                Class_jF_38b68c76.jJgKH[3] = fArray[3];
                if (!bl) break block6;
            }
            Class_jF_38b68c76.jJgKH[0] = 1.0f;
            Class_jF_38b68c76.jJgKH[1] = 1.0f;
            Class_jF_38b68c76.jJgKH[2] = 1.0f;
            Class_jF_38b68c76.jJgKH[3] = 1.0f;
        }
        if (Class_iS_888f260e.bwL() == null) {
            Class_jF_38b68c76.bHE(!bl);
        }
    }

    private static MatchException bHH(MatchException matchException) {
        return matchException;
    }

    public static void bHE(boolean bl) {
        gfICi = bl;
    }

    public static void bHD() {
        WjVUd.clear();
        Class_jF_38b68c76.jJgKH[0] = 1.0f;
        Class_jF_38b68c76.jJgKH[1] = 1.0f;
        Class_jF_38b68c76.jJgKH[2] = 1.0f;
        Class_jF_38b68c76.jJgKH[3] = 1.0f;
    }
}

