/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_O_5a11f410;
import recovered.internal.Class_U_4dc8f204;
import recovered.internal.Class_aY_e9eaa44d;
import recovered.internal.Class_af_98bd07d0;
import recovered.internal.Class_ak_2ff604c7;
import recovered.internal.Class_ct_fa795250;
import recovered.internal.Class_cu_7306ec45;
import recovered.internal.Class_cy_687dcdb6;
import recovered.internal.Class_iM_910cda2e;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_rk_bf8630d1;

public class Class_aW_20377974
extends Class_aY_e9eaa44d {
    Class_U_4dc8f204 JKERF;
    Class_cy_687dcdb6 xYFlG;
    Class_ct_fa795250 fGsEq;
    Class_cu_7306ec45 DlDbW;
    Class_cu_7306ec45 iIDKD;
    Class_cu_7306ec45 nHtSL;
    Class_ak_2ff604c7<?> qBxsW;
    Class_ak_2ff604c7<?> LjRop;
    Class_O_5a11f410 XNZCi;
    Class_O_5a11f410 aoJBf;
    Class_O_5a11f410 RlfZn;
    Class_O_5a11f410 APjSA;
    Class_af_98bd07d0 fPDzi;
    Class_af_98bd07d0 epryP;
    Class_af_98bd07d0 gxWlU;
    Class_rk_bf8630d1 ygYiH;
    Class_rk_bf8630d1 lRCNz;
    private static long Bekfm;
    private static String[] eFxwa;
    private static String[] JlEgd;
    private static Map HtaLR;
    private static long[] xWjyw;
    private static Integer[] tPqVv;
    private static Map oXzKE;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Exception decompiling
     */
    public Class_aW_20377974(float var1_1, int[] var2_2, Class_iM_910cda2e var3_3) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous, and can't clone.
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:611)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:94)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:517)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    static {
        NativeLoader.doInit(Class_aW_20377974.class);
        Class_aW_20377974._94c9a8fa147204b32928387810571dca();
    }

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    private native /* synthetic */ void zi(Boolean var1);

    private native void zh();

    private static native MatchException zo(MatchException var0);

    @Override
    public native boolean dm(int var1, int var2, int var3);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void sv(Class_lC_5322e8cf var1);

    private static native CallSite zs(MethodHandles.Lookup var0, String var1, MethodType var2);

    @Override
    public native boolean eK(char var1);

    private static native String zq(int var0, long var1);

    private native /* synthetic */ void zn(Class_O_5a11f410 var1);

    private native /* synthetic */ void zk(Class_iM_910cda2e var1);

    private static native int zt(int var0, long var1);

    private static native CallSite zv(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native String zp(byte[] var0);

    private native /* synthetic */ void zm(Class_O_5a11f410 var1);

    private native void zg();

    private static native Object zr(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native /* synthetic */ void zl(Class_U_4dc8f204 var1);

    private native /* synthetic */ void zj(Class_iM_910cda2e var1);

    private static native void _94c9a8fa147204b32928387810571dca();

    private static native int zu(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);
}

