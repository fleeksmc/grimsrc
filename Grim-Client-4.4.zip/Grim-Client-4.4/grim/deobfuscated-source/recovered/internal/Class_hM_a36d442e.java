/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_hK_37a4c9e8;

public final class Class_hM_a36d442e<T>
extends Record {
    private final String name;
    private final boolean required;
    private final boolean vararg;
    private final Class_hK_37a4c9e8 validator;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hM_a36d442e(String string, boolean bl, boolean bl2, Class_hK_37a4c9e8 class_hK_37a4c9e8) {
        this.name = string;
        this.required = bl;
        this.vararg = bl2;
        this.validator = class_hK_37a4c9e8;
    }

    static {
        NativeLoader.doInit(Class_hM_a36d442e.class);
    }

    public native String name();

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    public native boolean required();

    public native Class_hK_37a4c9e8 validator();

    public native boolean vararg();
}

