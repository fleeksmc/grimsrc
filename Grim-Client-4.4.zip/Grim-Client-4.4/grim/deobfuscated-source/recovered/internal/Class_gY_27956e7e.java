/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;

public class Class_gY_27956e7e
extends Class_hH_ae8f8f77 {
    private double Xaiyf;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gY_27956e7e(double d) {
        this.Xaiyf = d;
    }

    public double bcn() {
        return this.Xaiyf;
    }

    public void bco(double d) {
        this.Xaiyf = d;
    }
}

