/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import recovered.internal.Class_aE_a07172c5;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bg_0a91641c;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jG_69891630;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;

public class Class_bi_a63df9c8
extends Class_az_a4990dcf {
    private static final long VEYAp = Class_gb_9d201141.aYR(9139635386457903753L, 1557971589278227743L, MethodHandles.lookup().lookupClass()).a(32253300271458L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    @Override
    public void dl(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        Class_bl_a15fbaa5.Ex().EB().wp().dl(d, d2, class_mA_32d8a5f2);
    }

    @Override
    public boolean dk(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        return Class_bl_a15fbaa5.Ex().EB().wp().dk(d, d2, class_mA_32d8a5f2);
    }

    @Override
    protected void bV(Class_lC_5322e8cf class_lC_5322e8cf) {
        long l = VEYAp ^ 0x5E27D0A0BC07L;
        Class_aE_a07172c5 class_aE_a07172c5 = Class_bl_a15fbaa5.Ex().EB().wp();
        if (class_aE_a07172c5 == null) {
            return;
        }
        float f = this.WjISQ - 0.75f;
        Class_jG_69891630.bHK(class_lC_5322e8cf, this.MCnYt, this.pNyTQ, this.BcpIo, f);
        class_aE_a07172c5.sY(this.MCnYt, this.pNyTQ, this.BcpIo, f);
        class_aE_a07172c5.su(class_lC_5322e8cf);
        Class_jG_69891630.bHN();
    }

    @Override
    public boolean fC(double d, double d2, double d3) {
        long l = VEYAp ^ 0x452E16CAD9C9L;
        int n = Class_bg_0a91641c.De();
        boolean bl = this.tg(d, d2);
        if (n != 0) {
            if (bl) {
                Class_bl_a15fbaa5.Ex().Ez().nJ(d3);
                return true;
            }
            bl = super.fC(d, d2, d3);
        }
        return bl;
    }

    @Override
    public boolean dB(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2, double d3, double d4) {
        return Class_bl_a15fbaa5.Ex().EB().wp().dB(d, d2, class_mA_32d8a5f2, d3, d4);
    }

    public boolean Dv(Class_az_a4990dcf class_az_a4990dcf) {
        return Class_jf_d1c4f950.bAU(this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ, class_az_a4990dcf.tr(), class_az_a4990dcf.ts(), class_az_a4990dcf.kN(), class_az_a4990dcf.dn());
    }

    public boolean Dw(double d, double d2) {
        return Class_jf_d1c4f950.bAX(this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ, d, d2);
    }

    private static MatchException Dx(MatchException matchException) {
        return matchException;
    }
}

