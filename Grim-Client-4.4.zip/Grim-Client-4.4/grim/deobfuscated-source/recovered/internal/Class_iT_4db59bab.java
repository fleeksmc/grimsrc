/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

public class Class_iT_4db59bab {
    private static float kBIoi;
    private static int DpjEu;
    private static long IUuUO;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_iT_4db59bab.class);
        Class_iT_4db59bab._d6ede609aeee50198bb22ae6fa6b962f();
    }

    public static native float bwP();

    public static native void bwN();

    private static native MatchException bwQ(MatchException var0);

    public static native void bwO(float var0, int var1);

    private static native void _d6ede609aeee50198bb22ae6fa6b962f();
}

