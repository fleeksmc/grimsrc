/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import recovered.core.NativeLoader;
import recovered.internal.Class_iE_00f71a81;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ic_fa4de564;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_ij_d7bf2301;
import recovered.internal.Class_iu_bf2db566;

public class Class_ib_b693b5c5
extends Class_iE_00f71a81
implements Class_ic_fa4de564 {
    private static Class_iS_888f260e[] cFbIb;
    private static long rULHc;
    private static String[] GYJov;
    private static String[] IjhxK;
    private static Map NyUUY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_ib_b693b5c5.class);
        Class_ib_b693b5c5._9c5314eb978dce02099338ee8671684d();
    }

    @Override
    public native CompletableFuture<Class_ij_d7bf2301> createTheme(Class_ig_ca326427 var1);

    @Override
    public native CompletableFuture<List<Class_ij_d7bf2301>> fetchThemes();

    @Override
    public native CompletableFuture<Class_iu_bf2db566> deleteTheme(String var1);

    @Override
    public native CompletableFuture<Class_iu_bf2db566> importTheme(String var1);

    private native /* synthetic */ Class_iu_bf2db566 bgT(Throwable var1);

    private native /* synthetic */ Class_ij_d7bf2301 bgU(Throwable var1);

    private native /* synthetic */ Class_ij_d7bf2301 bgV(Throwable var1);

    @Override
    public native CompletableFuture<Class_ij_d7bf2301> fetchTheme(String var1);

    @Override
    public native CompletableFuture<Class_iu_bf2db566> loadTheme(Class_ig_ca326427 var1);

    private native /* synthetic */ Class_iu_bf2db566 bgR(Throwable var1);

    private native /* synthetic */ Class_iu_bf2db566 bgS(Throwable var1);

    private static native String bgZ(byte[] var0);

    private static native Object bhb(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public static native void bgW(Class_iS_888f260e[] var0);

    private static native CallSite bhc(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native MatchException bgY(MatchException var0);

    private static native String bha(int var0, long var1);

    public static native Class_iS_888f260e[] bgX();

    private static native void _9c5314eb978dce02099338ee8671684d();
}

