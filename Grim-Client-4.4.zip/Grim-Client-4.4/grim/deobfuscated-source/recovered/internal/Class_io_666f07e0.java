/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import com.google.gson.JsonObject;
import net.minecraft.util.math.Vec2f;
import recovered.core.NativeLoader;
import recovered.internal.Class_rp_2e61368f;

public class Class_io_666f07e0
implements Class_rp_2e61368f {
    private float rXqlY;
    private float GeupB;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_io_666f07e0() {
    }

    public Class_io_666f07e0(float f, float f2) {
        this.rXqlY = f;
        this.GeupB = f2;
    }

    static {
        NativeLoader.doInit(Class_io_666f07e0.class);
    }

    @Override
    public native void fromJson(JsonObject var1);

    @Override
    public native JsonObject toJson();

    public native float blz();

    public native Class_io_666f07e0 blB(float var1);

    public native Class_io_666f07e0 blx();

    public native float bly();

    public native Class_io_666f07e0 blA(float var1);

    public native Vec2f blw();
}

