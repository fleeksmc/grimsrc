/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import recovered.internal.Class_hG_d70cdb00;
import recovered.internal.Class_hH_ae8f8f77;
import recovered.internal.Class_hI_068ee9a3;

public class Class_hF_7bd1921e {
    private static final Map<Class<? extends Class_hH_ae8f8f77>, List<Class_hI_068ee9a3>> PTGDf = new ConcurrentHashMap<Class<? extends Class_hH_ae8f8f77>, List<Class_hI_068ee9a3>>();
    private static final MethodHandles.Lookup JRwhO = MethodHandles.lookup();
    public static volatile boolean BQuMu = false;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public static void bdI(Object object) {
        Class_hF_7bd1921e.bdJ(object, null);
    }

    public static void bdM(Object object) {
        PTGDf.values().forEach(list -> list.removeIf(class_hI_068ee9a3 -> class_hI_068ee9a3.source().equals(object)));
        Class_hF_7bd1921e.bdN(true);
    }

    public static void bdH() {
        BQuMu = true;
    }

    public static void bdP() {
        BQuMu = false;
        PTGDf.clear();
    }

    private static void bdL(Method method, Object object) {
        Class<?> clazz2 = method.getParameterTypes()[0];
        try {
            MethodHandle methodHandle = JRwhO.unreflect(method);
            Class_hI_068ee9a3 class_hI_068ee9a33 = new Class_hI_068ee9a3(object, methodHandle, method.getAnnotation(Class_hG_d70cdb00.class).priority().cmD());
            List list = PTGDf.computeIfAbsent(clazz2, clazz -> new CopyOnWriteArrayList());
            if (!list.contains(class_hI_068ee9a33)) {
                list.add(class_hI_068ee9a33);
                list.sort((class_hI_068ee9a3, class_hI_068ee9a32) -> Integer.compare(class_hI_068ee9a32.value(), class_hI_068ee9a3.value()));
            }
        }
        catch (IllegalAccessException illegalAccessException) {
            // empty catch block
        }
    }

    public static void bdN(boolean bl) {
        PTGDf.entrySet().removeIf(entry -> bl && ((List)entry.getValue()).isEmpty());
    }

    public static List<Class_hI_068ee9a3> bdO(Class<? extends Class_hH_ae8f8f77> clazz) {
        return PTGDf.getOrDefault(clazz, Collections.emptyList());
    }

    private static boolean bdK(Method method, Class<? extends Class_hH_ae8f8f77> clazz) {
        return method.getParameterCount() == 1 && (clazz == null || method.getParameterTypes()[0].equals(clazz)) && method.isAnnotationPresent(Class_hG_d70cdb00.class) && Modifier.isPublic(method.getModifiers());
    }

    public static void bdJ(Object object, Class<? extends Class_hH_ae8f8f77> clazz) {
        for (Class<?> clazz2 = object.getClass(); clazz2 != null && clazz2 != Object.class; clazz2 = clazz2.getSuperclass()) {
            Method[] methodArray;
            for (Method method : methodArray = clazz2.getDeclaredMethods()) {
                if (!Class_hF_7bd1921e.bdK(method, clazz)) continue;
                Class_hF_7bd1921e.bdL(method, object);
            }
        }
    }
}

