/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 */
package recovered.internal;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iO_e7bfa49a;

public class Class_iN_238b4668 {
    private final String dmpmN;
    private final JsonObject xDpWq;
    private static final long lBagP = Class_gb_9d201141.aYR(8966501344039546894L, -3130552171237775395L, MethodHandles.lookup().lookupClass()).a(238854674416724L);
    private static final String[] KWerv;
    private static final String[] oGkHR;
    private static final Map Fvbad;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static Exception btM(Exception exception) {
        return exception;
    }

    private static String btO(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x3AAA;
        if (oGkHR[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])Fvbad.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    Fvbad.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_iN_238b4668", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = KWerv[n2].getBytes("ISO-8859-1");
            Class_iN_238b4668.oGkHR[n2] = Class_iN_238b4668.btN(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return oGkHR[n2];
    }

    private static JsonObject btJ(String string) {
        block5: {
            long l = lBagP ^ 0x62E53EE5D0D0L;
            String[] stringArray = Class_iO_e7bfa49a.buz();
            try {
                JsonElement jsonElement;
                JsonElement jsonElement2 = jsonElement = JsonParser.parseString((String)string);
                if (stringArray == null) {
                    if (jsonElement2 == null) break block5;
                    jsonElement2 = jsonElement;
                }
                if (stringArray == null) {
                    if (!jsonElement2.isJsonObject()) break block5;
                    jsonElement2 = jsonElement;
                }
                return jsonElement2.getAsJsonObject();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return new JsonObject();
    }

    private static CallSite btQ(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_iN_238b4668" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public JsonObject btH() {
        return this.xDpWq.deepCopy();
    }

    private static Object btP(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_iN_238b4668.btO(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    public String btK() {
        return this.dmpmN;
    }

    public JsonObject btL() {
        return this.xDpWq;
    }

    private static String btN(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public Optional<JsonElement> btI(String string, int[] nArray) {
        Optional<Object> optional;
        JsonElement jsonElement;
        String string2;
        JsonObject jsonObject;
        String[] stringArray;
        block12: {
            JsonObject jsonObject2;
            String string3;
            block13: {
                JsonElement jsonElement2;
                JsonElement jsonElement3;
                long l = lBagP ^ 0x3877FB75BAE4L;
                stringArray = Class_iO_e7bfa49a.buz();
                String string4 = string;
                if (stringArray == null) {
                    if (string4 == null) return Optional.empty();
                    string4 = string;
                }
                if (string4.isBlank()) return Optional.empty();
                if (nArray == null) {
                    return Optional.empty();
                }
                JsonElement jsonElement4 = jsonElement3 = this.xDpWq.get(string);
                if (stringArray == null) {
                    if (jsonElement4 == null) return Optional.empty();
                    jsonElement4 = jsonElement3;
                }
                if (stringArray == null) {
                    if (!jsonElement4.isJsonObject()) {
                        return Optional.empty();
                    }
                    jsonElement4 = jsonElement3;
                }
                JsonObject jsonObject3 = jsonElement4.getAsJsonObject();
                JsonElement jsonElement5 = jsonElement2 = jsonObject3.get((String)((Object)Class_iN_238b4668.btQ("n", (int)32752, (long)(0x4932A385620584DCL ^ l))));
                if (stringArray == null) {
                    if (jsonElement5 == null) return Optional.empty();
                    jsonElement5 = jsonElement2;
                }
                if (!jsonElement5.isJsonArray()) {
                    return Optional.empty();
                }
                string3 = Arrays.toString(nArray);
                JsonArray jsonArray = jsonElement2.getAsJsonArray();
                Iterator iterator = jsonArray.iterator();
                while (iterator.hasNext()) {
                    JsonElement jsonElement6;
                    JsonElement jsonElement7 = jsonElement6 = (JsonElement)iterator.next();
                    if (stringArray == null) {
                        if (!jsonElement7.isJsonObject() && stringArray == null) continue;
                        jsonElement7 = jsonElement6;
                    }
                    jsonObject = jsonObject2 = jsonElement7.getAsJsonObject();
                    string2 = string3;
                    if (stringArray != null) break block12;
                    if (!jsonObject.has(string2) && stringArray == null) {
                        continue;
                    }
                    break block13;
                }
                return Optional.empty();
            }
            jsonObject = jsonObject2;
            string2 = string3;
        }
        JsonElement jsonElement8 = jsonElement = jsonObject.get(string2);
        if (stringArray == null) {
            if (jsonElement8 == null) {
                optional = Optional.empty();
                return optional;
            }
            jsonElement8 = jsonElement.deepCopy();
        }
        optional = Optional.of(jsonElement8);
        return optional;
    }

    public Class_iN_238b4668(String string) {
        long l = lBagP ^ 0x5EEBC230E57BL;
        String[] stringArray = Class_iO_e7bfa49a.buz();
        String[] stringArray2 = stringArray;
        Object object = string;
        if (stringArray2 == null) {
            object = object == null ? Class_iN_238b4668.btQ("n", (int)1278, (long)(0x6CA9C3D4BECEA04CL ^ l)) : string;
        }
        this.dmpmN = object;
        this.xDpWq = Class_iN_238b4668.btJ(this.dmpmN);
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        Fvbad = new HashMap(13);
        long l = lBagP ^ 0xC270E97855FL;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[2];
        int n = 0;
        String string = "l\u0094\u0086Z\u0001\u00f0\u00e8c\r\u00af\u0082\u00e4\u0090\u00a4\u0001\u00b3\u0010\u008d\u000e\u00c1`\u00d2\u00c4\u00e7\u0019\u00cf$\u00ee\u00af\u00c6\u00dd8t";
        int n2 = "l\u0094\u0086Z\u0001\u00f0\u00e8c\r\u00af\u0082\u00e4\u0090\u00a4\u0001\u00b3\u0010\u008d\u000e\u00c1`\u00d2\u00c4\u00e7\u0019\u00cf$\u00ee\u00af\u00c6\u00dd8t".length();
        int n3 = 16;
        int n4 = -1;
        while (true) {
            int n5 = ++n4;
            byte[] byArray3 = cipher.doFinal(string.substring(n5, n5 + n3).getBytes("ISO-8859-1"));
            stringArray[n++] = Class_iN_238b4668.btN(byArray3).intern();
            if ((n4 += n3) >= n2) {
                KWerv = stringArray;
                oGkHR = new String[2];
                return;
            }
            n3 = string.charAt(n4);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_iN_238b4668.class, "btP", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

