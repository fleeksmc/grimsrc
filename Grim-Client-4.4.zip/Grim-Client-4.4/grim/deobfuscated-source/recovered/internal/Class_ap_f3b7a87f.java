/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.ArrayList;
import java.util.List;
import recovered.core.NativeLoader;
import recovered.internal.Class_P_2c9819bb;
import recovered.internal.Class_S_f3cb3437;
import recovered.internal.Class_ac_rM_8a33ea18;
import recovered.internal.Class_ai_36ccd007;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;

public class Class_ap_f3b7a87f
extends Class_aj_95d0a719 {
    private final List<Class_az_a4990dcf> pdPyE = new ArrayList<Class_az_a4990dcf>();
    private Runnable mjUwZ = Class_ap_f3b7a87f::qz;
    private boolean IwVym = true;
    private boolean DfYWQ;
    private boolean hVUFA = false;
    private float LnWsJ;
    private static long RwtlO;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native void _5de6c00e5d605ce0b57385d96b626989();

    public native Class_ap_f3b7a87f qe(int[] var1, String var2, Class_ac_rM_8a33ea18 var3);

    public native Class_ap_f3b7a87f qi(int[] var1, Class_lf_d247d983 var2, Class_ai_36ccd007 var3);

    public Class_ap_f3b7a87f() {
        this(0.0f, 0.0f, 90.0f);
    }

    public Class_ap_f3b7a87f(float f, float f2) {
        this(f, f2, 90.0f);
    }

    public Class_ap_f3b7a87f(float f, float f2, float f3, float f4) {
        this.MCnYt = f;
        this.pNyTQ = f2;
        this.BcpIo = f3;
        this.IzFhM = f4;
        this.FHbTC = true;
    }

    public Class_ap_f3b7a87f(float f, float f2, float f3) {
        this(f, f2, f3, 2.0f);
    }

    static {
        NativeLoader.doInit(Class_ap_f3b7a87f.class);
        Class_ap_f3b7a87f._5de6c00e5d605ce0b57385d96b626989();
    }

    @Override
    public native boolean hc(double var1, double var3);

    public native Class_ap_f3b7a87f qk(String var1, Class_lf_d247d983 var2, Class_ai_36ccd007 var3);

    @Override
    protected native void oa();

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean dm(int var1, int var2, int var3);

    private native /* synthetic */ void qs(Class_ai_36ccd007 var1, Class_P_2c9819bb var2);

    public native Class_ap_f3b7a87f qc(int[] var1);

    private native /* synthetic */ void qt(Class_ai_36ccd007 var1, Class_P_2c9819bb var2);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean fC(double var1, double var3, double var5);

    public native Class_ap_f3b7a87f qb(String var1, String var2, Class_lf_d247d983 var3, float var4, Class_ac_rM_8a33ea18 var5);

    public native Class_ap_f3b7a87f ql(String var1, Class_lf_d247d983 var2, Class_S_f3cb3437 var3, Class_ai_36ccd007 var4);

    public native Class_ap_f3b7a87f qr(float var1);

    @Override
    protected native boolean oe();

    private native /* synthetic */ void qx(Class_lC_5322e8cf var1);

    private native /* synthetic */ void qy(Class_lC_5322e8cf var1);

    private native /* synthetic */ void qw(Class_ai_36ccd007 var1, Class_P_2c9819bb var2);

    private static native /* synthetic */ void qz();

    @Override
    public native boolean dB(double var1, double var3, Class_mA_32d8a5f2 var5, double var6, double var8);

    @Override
    public native boolean eK(char var1);

    @Override
    protected native boolean od();

    @Override
    public native <T extends Class_aj_95d0a719> T oj(boolean var1);

    public native Class_ap_f3b7a87f pV(Class_az_a4990dcf var1);

    public native Class_ap_f3b7a87f pU(Class_cB_67aec11c var1);

    private native float pT(Class_az_a4990dcf var1, boolean var2);

    private native float pS(boolean var1);

    public native Class_ap_f3b7a87f qo(Runnable var1);

    public native Class_ap_f3b7a87f qa(String var1, String var2, Class_lf_d247d983 var3, Class_ac_rM_8a33ea18 var4);

    public native Class_ap_f3b7a87f qh(int[] var1, String var2, Class_lf_d247d983 var3, float var4, Class_ac_rM_8a33ea18 var5);

    public native Class_ap_f3b7a87f qn(String var1, Class_lf_d247d983 var2, Class_mG_52c8d386 var3, Class_mG_52c8d386 var4, Class_ai_36ccd007 var5);

    public native Class_ap_f3b7a87f qg(int[] var1, String var2, Class_lf_d247d983 var3, Class_ac_rM_8a33ea18 var4);

    public native Class_ap_f3b7a87f qj(Class_P_2c9819bb var1);

    public native Class_ap_f3b7a87f qp(boolean var1);

    public native Class_ap_f3b7a87f pZ(String var1, String var2, Class_lf_d247d983 var3);

    public native Class_ap_f3b7a87f qq();

    private static native MatchException qA(MatchException var0);

    private native /* synthetic */ void qu(Class_ai_36ccd007 var1, Class_P_2c9819bb var2);

    public native Class_ap_f3b7a87f qd(int[] var1, String var2);

    public native Class_ap_f3b7a87f pW(String var1);

    public native Class_ap_f3b7a87f qf(int[] var1, String var2, Class_lf_d247d983 var3);

    public native Class_ap_f3b7a87f pX(String var1, String var2);

    public native Class_ap_f3b7a87f qm(String var1, Class_lf_d247d983 var2, Class_S_f3cb3437 var3, Class_mG_52c8d386 var4, Class_ai_36ccd007 var5);

    private native /* synthetic */ void qv(Class_ai_36ccd007 var1, Class_P_2c9819bb var2);

    public native Class_ap_f3b7a87f pY(String var1, String var2, Class_ac_rM_8a33ea18 var3);
}

