/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screen.ChatScreen
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.util.math.MathHelper
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import recovered.core.ClientMain;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_ca_75c833b3;
import recovered.internal.Class_cr_3ba4ae18;
import recovered.internal.Class_ct_fa795250;
import recovered.internal.Class_cu_7306ec45;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.modules.KillAuraModule;
import recovered.modules.MaceAuraModule;
import recovered.modules.NameProtectModule;
import recovered.modules.TargetLockModule;

public class Class_bZ_5682cfc3
extends Class_cr_3ba4ae18 {
    private final Class_cJ_2ae1a557 NCHJZ;
    private final Class_ct_fa795250 nLbAG;
    private final Class_cu_7306ec45 kojYh;
    private final Class_cu_7306ec45 cCJxB;
    private final Class_cu_7306ec45 mBhYD;
    private final Class_rk_bf8630d1[] CCbky;
    private final Class_rk_bf8630d1 pHErH;
    private final Class_rk_bf8630d1 jLjXP;
    private final Class_rk_bf8630d1 sjeIR;
    private final Class_rk_bf8630d1 PquMu;
    private final Class_rk_bf8630d1 dfbld;
    private LivingEntity qcZhQ;
    private static final long yIQrZ;
    private static final long[] wNQMp;
    private static final Integer[] GEMJy;
    private static final Map BwsEB;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bZ_5682cfc3() {
        long l = yIQrZ ^ 0x6BAAE7727777L;
        boolean bl = Class_ca_75c833b3.OY();
        int[] nArray = new int[Class_bZ_5682cfc3.OO("k", (int)23005, (long)(0x64EE44404498FD9FL ^ l))];
        nArray[0] = (int)Class_bZ_5682cfc3.OO("k", (int)30942, (long)(0x46CBD54CDFFA5CB9L ^ l));
        nArray[1] = (int)Class_bZ_5682cfc3.OO("k", (int)12621, (long)(0xCE7D2F941401518L ^ l));
        nArray[2] = (int)Class_bZ_5682cfc3.OO("k", (int)16572, (long)(0x396566BD5B1364DFL ^ l));
        nArray[3] = (int)Class_bZ_5682cfc3.OO("k", (int)10423, (long)(0x35CA47D73C528CDFL ^ l));
        nArray[4] = (int)Class_bZ_5682cfc3.OO("k", (int)16330, (long)(0x5995BCFD7F5C9B8BL ^ l));
        nArray[5] = (int)Class_bZ_5682cfc3.OO("k", (int)16454, (long)(0x41E8DD506886410L ^ l));
        nArray[Class_bZ_5682cfc3.OO("k", (int)31564, (long)(0x3E0BD223A7325F09L ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)9079, (long)(0x42013A1B2E138727L ^ l));
        nArray[Class_bZ_5682cfc3.OO("k", (int)26987, (long)(0x5F766EB1667E4D04L ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)23633, (long)(0x4FA61E322BE7782EL ^ l));
        nArray[Class_bZ_5682cfc3.OO("k", (int)2558, (long)(0x2743A3FDB5DF2DACL ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)6111, (long)(0x49E1AD7A991AB3B5L ^ l));
        nArray[Class_bZ_5682cfc3.OO("k", (int)22698, (long)(0x4973CBD79DA1FCFDL ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)15211, (long)(0x24F9258B67029F25L ^ l));
        super(nArray, Class_lf_d247d983.ENioA);
        this.NCHJZ = new Class_cJ_2ae1a557(this, Class_mr_7eac5189.clS(new int[]{(int)Class_bZ_5682cfc3.OO("k", (int)27347, (long)(0x5F63D24B0A714E93L ^ l)), (int)Class_bZ_5682cfc3.OO("k", (int)24518, (long)(0x3E5D48CC77B0FBB8L ^ l)), (int)Class_bZ_5682cfc3.OO("k", (int)4519, (long)(0x33EEAA6BA8FEB5EDL ^ l)), (int)Class_bZ_5682cfc3.OO("k", (int)1010, (long)(0x2E54C92AAC29A79EL ^ l))})).WE(true);
        int[] nArray2 = new int[Class_bZ_5682cfc3.OO("k", (int)22221, (long)(0x66847DAFBA1C7282L ^ l))];
        nArray2[0] = (int)Class_bZ_5682cfc3.OO("k", (int)23329, (long)(0x3D0F9B3F287F7F7AL ^ l));
        nArray2[1] = (int)Class_bZ_5682cfc3.OO("k", (int)3276, (long)(0x4D61280D000F288AL ^ l));
        nArray2[2] = (int)Class_bZ_5682cfc3.OO("k", (int)2652, (long)(0x43AA39EED1DAAE31L ^ l));
        nArray2[3] = (int)Class_bZ_5682cfc3.OO("k", (int)4519, (long)(0x33EEAA6BA8FEB5EDL ^ l));
        nArray2[4] = (int)Class_bZ_5682cfc3.OO("k", (int)3276, (long)(0x4D61280D000F288AL ^ l));
        nArray2[5] = (int)Class_bZ_5682cfc3.OO("k", (int)16694, (long)(0x4A97822A8133E57FL ^ l));
        nArray2[Class_bZ_5682cfc3.OO("k", (int)24825, (long)(0x5C239557C0A64480L ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)10126, (long)(0x5207C57DD08B03F4L ^ l));
        nArray2[Class_bZ_5682cfc3.OO("k", (int)23687, (long)(0x7CFC556D090678D4L ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)16145, (long)(0x590693FEAACB1B49L ^ l));
        nArray2[Class_bZ_5682cfc3.OO("k", (int)6048, (long)(0x21F1C5EAA73333CEL ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)6515, (long)(0x10C8562615F0BD2EL ^ l));
        nArray2[Class_bZ_5682cfc3.OO("k", (int)23276, (long)(0x71E16C7F04DB7EA1L ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)32346, (long)(0x1B2049503913DA00L ^ l));
        nArray2[Class_bZ_5682cfc3.OO("k", (int)26283, (long)(0x4FDFD68827A042F4L ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)6344, (long)(0x364639305A273C96L ^ l));
        nArray2[Class_bZ_5682cfc3.OO("k", (int)23003, (long)(0xDE18150E3C87DBEL ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)29066, (long)(0x15A16B75FF1CD5CDL ^ l));
        nArray2[Class_bZ_5682cfc3.OO("k", (int)8602, (long)(0x5A6927BC5A9E85FCL ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)23010, (long)(0x7ABDFEFE02507DAAL ^ l));
        nArray2[Class_bZ_5682cfc3.OO("k", (int)10974, (long)(0x77DC128491AB0E92L ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)16694, (long)(0x4A97822A8133E57FL ^ l));
        nArray2[Class_bZ_5682cfc3.OO("k", (int)14087, (long)(0x416481906CF3937FL ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)13371, (long)(0xD16983305679062L ^ l));
        nArray2[Class_bZ_5682cfc3.OO("k", (int)604, (long)(0x7F0EB843AE81A635L ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)4519, (long)(0x33EEAA6BA8FEB5EDL ^ l));
        nArray2[Class_bZ_5682cfc3.OO("k", (int)26930, (long)(0x1755666A60C6CD52L ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)30664, (long)(0x10D817CE5535D38BL ^ l));
        nArray2[Class_bZ_5682cfc3.OO("k", (int)787, (long)(0x3F0EEEF252EEA742L ^ l))] = (int)Class_bZ_5682cfc3.OO("k", (int)2469, (long)(0x22FBDD68AFB12DD9L ^ l));
        this.nLbAG = new Class_ct_fa795250(this, Class_mr_7eac5189.clS(nArray2));
        this.kojYh = new Class_cu_7306ec45(this.nLbAG, Class_mr_7eac5189.clS(new int[]{(int)Class_bZ_5682cfc3.OO("k", (int)15560, (long)(0x568BC2E56BE298A3L ^ l)), (int)Class_bZ_5682cfc3.OO("k", (int)4519, (long)(0x33EEAA6BA8FEB5EDL ^ l)), (int)Class_bZ_5682cfc3.OO("k", (int)7732, (long)(0x12BA8935463BBA7FL ^ l)), (int)Class_bZ_5682cfc3.OO("k", (int)2469, (long)(0x22FBDD68AFB12DD9L ^ l))})).SY();
        this.cCJxB = new Class_cu_7306ec45(this.nLbAG, Class_mr_7eac5189.clS(new int[]{(int)Class_bZ_5682cfc3.OO("k", (int)24710, (long)(0x297FA86EBB07C4D2L ^ l)), (int)Class_bZ_5682cfc3.OO("k", (int)29066, (long)(0x15A16B75FF1CD5CDL ^ l)), (int)Class_bZ_5682cfc3.OO("k", (int)16594, (long)(0x2D9CD80AD447E496L ^ l)), (int)Class_bZ_5682cfc3.OO("k", (int)15478, (long)(0x1532F980A6E59812L ^ l)), (int)Class_bZ_5682cfc3.OO("k", (int)2469, (long)(0x22FBDD68AFB12DD9L ^ l))}));
        this.mBhYD = new Class_cu_7306ec45(this.nLbAG, Class_mr_7eac5189.clS(new int[]{(int)Class_bZ_5682cfc3.OO("k", (int)25765, (long)(0x5A432B4DFE6CC0C7L ^ l)), (int)Class_bZ_5682cfc3.OO("k", (int)2308, (long)(0x9FB4A5220C12D79L ^ l)), (int)Class_bZ_5682cfc3.OO("k", (int)4519, (long)(0x33EEAA6BA8FEB5EDL ^ l)), (int)Class_bZ_5682cfc3.OO("k", (int)25215, (long)(0x738548371197461EL ^ l))}));
        this.CCbky = new Class_rk_bf8630d1[4];
        this.pHErH = new Class_rk_bf8630d1((int)Class_bZ_5682cfc3.OO("k", (int)11673, (long)(0x3BECF2D53BC89C5L ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        boolean bl2 = bl;
        this.jLjXP = new Class_rk_bf8630d1((int)Class_bZ_5682cfc3.OO("k", (int)12884, (long)(0x127D84ACF9C962FL ^ l))).dhs(Class_rj_b691f4f7.XzDkv);
        this.sjeIR = new Class_rk_bf8630d1((int)Class_bZ_5682cfc3.OO("k", (int)12884, (long)(0x127D84ACF9C962FL ^ l))).dhs(Class_rj_b691f4f7.XzDkv);
        this.PquMu = new Class_rk_bf8630d1((int)Class_bZ_5682cfc3.OO("k", (int)12884, (long)(0x127D84ACF9C962FL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.dfbld = new Class_rk_bf8630d1((int)Class_bZ_5682cfc3.OO("k", (int)12884, (long)(0x127D84ACF9C962FL ^ l))).dhs(Class_rj_b691f4f7.XzDkv);
        for (int i = 0; i < this.CCbky.length; ++i) {
            this.CCbky[i] = new Class_rk_bf8630d1((int)Class_bZ_5682cfc3.OO("k", (int)12884, (long)(0x127D84ACF9C962FL ^ l))).dhs(Class_rj_b691f4f7.XzDkv);
            if (bl2) continue;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_bZ_5682cfc3.yIQrZ = Class_gb_9d201141.aYR(3538484401670313874L, -6506673960747853613L, MethodHandles.lookup().lookupClass()).a(209388426308101L);
                Class_bZ_5682cfc3.BwsEB = new HashMap<K, V>(13);
                var0 = Class_bZ_5682cfc3.yIQrZ ^ 100398186049059L;
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[56];
                var5_4 = 0;
                var6_5 = "\u00b2\u00c4\u0098\u0015\u00faVq\u00a6\u00e4.}\u001e_\u0082?w\u001d\u00f3dMA/tDz\u00de\u00c5b\u00e2y\u0082\u0088\u0098\u0087\u00f1\u00b8\u00fb\u00ac\u00c5\u00e9\u008b\u00b6\u00a9)\u00f5\u00f1\u00c4G\u00ab\u0005k}+\u00c5\u00f1\u0012\u00ff\u00f8\u00e64,\u0096\u0001\u00e7\u0081\u0002J\u0088\u00d8\u008cy\u00fe\u00cf;+M\u00b2$#\u0004Qx\u00c9\u00f6M\u0095\u0012\u00f80\t\u00dc\u00e9\u00b5\u00bb\u0006\u00a5*L\u0085\u0005A'C2l\u00ce\u00c7\u00fb\u007fX\u00feG\u0005\u008b##\u00cf\u00a8\u00dc\u00c2\u00bc\u00ec\u00e1b\u0000\u00ab~\u00ef\u009eU\u00d8\u0018\u00c3\u00f3\u0013\u00f6D\u001a\u00e1\u0019\u00db\u00f2\u000e\u00a3|a0.%f\u00e3\u000f\u0092k\u00ed\u00cc\u001f>\u00eb\n\u001b W~\u0018:r\u009anW3\u00f8~\u000f\u0087Yq\u001cl\u00c0\u00aftx\u00db\u00fa\u0007\u00cbl\u007fb\u00a4\u0000m\u00ca\u00d3K\u001e\u00a1\u00f29(\u00ee\u00bc%\u0012\u00b5\u00e9\u00a1<\u00bbS\u0003\u00e2\u00a9\u0083\u0005\u0091\u00c1\u0090\u00e5\u00e1\u00f7B\u00cck\u0012\u0006)k\u00aaOb\u00f0\u00ef\u00af=u\u0091\u00a0\u00c1\u00ba\u0010G4\u00f2\u0010\u0007\u00c9\u00c4\u00c9\u008b\u0094GV0%\u0094;\u001f\u0092i\u0015\n'5m\u00d4\u00b3o\u00fc\u00e9\u00d7\u001c\u0014Q\u009a\u00c5\u00df\u0095s\u00d2H\u00d3\u00b5\u00cd\u00ce\u009cq\u00e6C\u00d0\u00c5\u00da\u00f7\u0014\u00927\u00deA\u0088\u00eb\u0087\u008b\u001e\u00d1\u0092P-\u008c\u0087</c\u008eK\u0088m\u00bfx\u00db\u0082p\u00c0*\u00afo\u00f5\u00b0MXC\u00cbO3\u0003\u00a2\u00e7.\u0091\u0090\u000e;0\u00068\u001e-\u00dd\u00f6\u00f3Y\u0003nb\u00f5/2\u00a2\u00a7&\u00f0K\u00ca9.\u00b9\u00ea\u0012\u00d7\u00b5Fq\u00bf\u0016j\u00de\u00f2A\u0094\u00bb\u0088<\\5V\u008d\u00f6o\u00ca|\u00ba\u0090O k\u00a5\u00f2jN\u00ab\u009aql\u0087\\\u00ffO\u0081\u008eG7y\u009f\ri\u00a6\u00d8a,\u008d\u00c7y\u00c4\u00eeK\u00ad\u0086\u00eb[I\u0005\u00a0";
                var7_6 = "\u00b2\u00c4\u0098\u0015\u00faVq\u00a6\u00e4.}\u001e_\u0082?w\u001d\u00f3dMA/tDz\u00de\u00c5b\u00e2y\u0082\u0088\u0098\u0087\u00f1\u00b8\u00fb\u00ac\u00c5\u00e9\u008b\u00b6\u00a9)\u00f5\u00f1\u00c4G\u00ab\u0005k}+\u00c5\u00f1\u0012\u00ff\u00f8\u00e64,\u0096\u0001\u00e7\u0081\u0002J\u0088\u00d8\u008cy\u00fe\u00cf;+M\u00b2$#\u0004Qx\u00c9\u00f6M\u0095\u0012\u00f80\t\u00dc\u00e9\u00b5\u00bb\u0006\u00a5*L\u0085\u0005A'C2l\u00ce\u00c7\u00fb\u007fX\u00feG\u0005\u008b##\u00cf\u00a8\u00dc\u00c2\u00bc\u00ec\u00e1b\u0000\u00ab~\u00ef\u009eU\u00d8\u0018\u00c3\u00f3\u0013\u00f6D\u001a\u00e1\u0019\u00db\u00f2\u000e\u00a3|a0.%f\u00e3\u000f\u0092k\u00ed\u00cc\u001f>\u00eb\n\u001b W~\u0018:r\u009anW3\u00f8~\u000f\u0087Yq\u001cl\u00c0\u00aftx\u00db\u00fa\u0007\u00cbl\u007fb\u00a4\u0000m\u00ca\u00d3K\u001e\u00a1\u00f29(\u00ee\u00bc%\u0012\u00b5\u00e9\u00a1<\u00bbS\u0003\u00e2\u00a9\u0083\u0005\u0091\u00c1\u0090\u00e5\u00e1\u00f7B\u00cck\u0012\u0006)k\u00aaOb\u00f0\u00ef\u00af=u\u0091\u00a0\u00c1\u00ba\u0010G4\u00f2\u0010\u0007\u00c9\u00c4\u00c9\u008b\u0094GV0%\u0094;\u001f\u0092i\u0015\n'5m\u00d4\u00b3o\u00fc\u00e9\u00d7\u001c\u0014Q\u009a\u00c5\u00df\u0095s\u00d2H\u00d3\u00b5\u00cd\u00ce\u009cq\u00e6C\u00d0\u00c5\u00da\u00f7\u0014\u00927\u00deA\u0088\u00eb\u0087\u008b\u001e\u00d1\u0092P-\u008c\u0087</c\u008eK\u0088m\u00bfx\u00db\u0082p\u00c0*\u00afo\u00f5\u00b0MXC\u00cbO3\u0003\u00a2\u00e7.\u0091\u0090\u000e;0\u00068\u001e-\u00dd\u00f6\u00f3Y\u0003nb\u00f5/2\u00a2\u00a7&\u00f0K\u00ca9.\u00b9\u00ea\u0012\u00d7\u00b5Fq\u00bf\u0016j\u00de\u00f2A\u0094\u00bb\u0088<\\5V\u008d\u00f6o\u00ca|\u00ba\u0090O k\u00a5\u00f2jN\u00ab\u009aql\u0087\\\u00ffO\u0081\u008eG7y\u009f\ri\u00a6\u00d8a,\u008d\u00c7y\u00c4\u00eeK\u00ad\u0086\u00eb[I\u0005\u00a0".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl26:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = "\u00cc\u00c9\u0093\u00d2;i\u00a6\u00df\u0019\u00bc\u00a7&8\u00f5\u00d9\u00b5";
                    var7_6 = "\u00cc\u00c9\u0093\u00d2;i\u00a6\u00df\u0019\u00bc\u00a7&8\u00f5\u00d9\u00b5".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl52:
                // 1 sources

                ** continue;
            }
        }
        Class_bZ_5682cfc3.wNQMp = var8_3;
        Class_bZ_5682cfc3.GEMJy = new Integer[56];
    }

    @Override
    protected void NV(Class_lC_5322e8cf class_lC_5322e8cf) {
        long l = yIQrZ ^ 0x1D07E9902300L;
        LivingEntity livingEntity = this.OK();
        boolean bl = Class_ca_75c833b3.OX();
        LivingEntity livingEntity2 = livingEntity;
        if (!bl) {
            if (livingEntity2 != null) {
                this.qcZhQ = livingEntity;
            }
            livingEntity2 = this.qcZhQ;
        }
        if (livingEntity2 == null) {
            return;
        }
        Class_mG_52c8d386 class_mG_52c8d386 = Class_mG_52c8d386.QHTxQ.cob(0.3f * this.gILqY.dhj());
        class_lC_5322e8cf.ccY(this.toIeR - 5.0f, this.QWaAn - 5.0f, this.jTsqG + 10.0f, this.Xtjvx + 10.0f, 15.0f, Class_ld_bb1690e1.all(6.0f), class_mG_52c8d386);
        class_lC_5322e8cf.ccU(this.toIeR, this.QWaAn, this.jTsqG, this.Xtjvx, this.ormBS.dhj(), this.gILqY.dhj());
        this.OJ(class_lC_5322e8cf);
        this.OG(class_lC_5322e8cf);
        this.OH(class_lC_5322e8cf);
        this.OI(class_lC_5322e8cf);
    }

    @Override
    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        super.LX(class_lC_5322e8cf);
        this.jTsqG = 103.0f;
        this.Xtjvx = 31.0f;
    }

    private static int ON(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bZ_5682cfc3.OM(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private LivingEntity OK() {
        block28: {
            block27: {
                block25: {
                    block26: {
                        block22: {
                            block23: {
                                block24: {
                                    block19: {
                                        block20: {
                                            block21: {
                                                var1_1 = Class_bZ_5682cfc3.yIQrZ ^ 117149597833944L;
                                                var4_2 = ClientMain.dlJ().aZx(TargetLockModule.class);
                                                var3_3 = Class_ca_75c833b3.OY();
                                                v0 = var4_2;
                                                if (var3_3) {
                                                    if (v0.bag()) {
                                                        v0 = var4_2;
                                                        if (var3_3) {
                                                            if (v0.aIU() != null) {
                                                                return var4_2.aIU();
                                                            } else {
                                                                ** GOTO lbl-1000
                                                            }
                                                        }
                                                    } else lbl-1000:
                                                    // 3 sources

                                                    {
                                                        v0 = ClientMain.dlJ().aZx(KillAuraModule.class);
                                                    }
                                                }
                                                var5_4 = (KillAuraModule)v0;
                                                var6_5 = var5_4.aOQ();
                                                v1 /* !! */  = var5_4;
                                                if (!var3_3) break block19;
                                                if (!v1 /* !! */ .bag()) break block20;
                                                v2 = var6_5;
                                                if (!var3_3) break block21;
                                                if (v2 == null) break block20;
                                                v2 = var6_5;
                                            }
                                            return v2;
                                        }
                                        v1 /* !! */  = ClientMain.dlJ().aZx(MaceAuraModule.class);
                                    }
                                    var7_6 = (MaceAuraModule)v1 /* !! */ ;
                                    var6_5 = var7_6.aBS();
                                    v3 = var7_6.bag();
                                    if (!var3_3) break block22;
                                    if (!v3) break block23;
                                    v4 = var6_5;
                                    if (!var3_3) break block24;
                                    if (v4 == null) break block23;
                                    v4 = var6_5;
                                }
                                return v4;
                            }
                            v3 = this.NCHJZ.WF();
                        }
                        if (!var3_3) break block25;
                        if (!v3) break block26;
                        var9_7 = ClientMain.dlmvG.targetedEntity;
                        v3 = var9_7 instanceof LivingEntity;
                        if (var3_3) {
                            if (v3) {
                                var8_8 = (LivingEntity)var9_7;
                                return var8_8;
                            } else {
                                ** GOTO lbl50
                            }
                        }
                        break block25;
                    }
                    v5 = ClientMain.dlmvG;
                    if (!var3_3) break block27;
                    v3 = v5.currentScreen instanceof ChatScreen;
                }
                if (!v3) break block28;
                v5 = ClientMain.dlmvG;
            }
            return v5.player;
        }
        return null;
    }

    @Override
    public boolean Om() {
        long l = yIQrZ ^ 0x1E8A7F10662AL;
        return this.OK() != null;
    }

    private static MatchException OL(MatchException matchException) {
        return matchException;
    }

    /*
     * Exception decompiling
     */
    private void OJ(Class_lC_5322e8cf var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void OG(Class_lC_5322e8cf class_lC_5322e8cf) {
        block2: {
            Class_mG_52c8d386 class_mG_52c8d386;
            block1: {
                LivingEntity livingEntity;
                boolean bl;
                block0: {
                    LivingEntity livingEntity2;
                    long l = yIQrZ ^ 0x4464560B4EE1L;
                    class_mG_52c8d386 = Class_mG_52c8d386.hoGuU.coa(255.0f * this.ormBS.dhj());
                    bl = Class_ca_75c833b3.OX();
                    livingEntity = livingEntity2 = this.qcZhQ;
                    if (bl) break block0;
                    if (!(livingEntity instanceof AbstractClientPlayerEntity)) break block1;
                    livingEntity = livingEntity2;
                }
                AbstractClientPlayerEntity abstractClientPlayerEntity = (AbstractClientPlayerEntity)livingEntity;
                class_lC_5322e8cf.ccZ(abstractClientPlayerEntity, this.toIeR + 6.0f, this.QWaAn + 6.0f, 19.0f, Class_ld_bb1690e1.all(3.0f), class_mG_52c8d386);
                if (!bl) break block2;
            }
            class_lC_5322e8cf.cdb(this.toIeR + 6.0f, this.QWaAn + 6.0f, 19.0f, Class_ld_bb1690e1.all(3.0f), class_mG_52c8d386);
        }
    }

    private void OH(Class_lC_5322e8cf class_lC_5322e8cf) {
        Class_ii_9b427eda class_ii_9b427eda = ClientMain.dlM();
        float f = this.toIeR + 30.0f;
        float f2 = this.QWaAn + this.Xtjvx - 12.0f;
        float f3 = 65.0f;
        float f4 = 3.0f;
        class_lC_5322e8cf.cdg(f, f2, f3, f4, Class_ld_bb1690e1.all(0.7f), Class_mG_52c8d386.QHTxQ.cob(0.3f));
        float f5 = this.qcZhQ.getHealth();
        float f6 = this.qcZhQ.getAbsorptionAmount();
        float f7 = this.qcZhQ.getMaxHealth();
        float f8 = (f5 + f6) / f7;
        float f9 = f6 / Math.max(20.0f, f6);
        this.sjeIR.dhd(f8);
        this.dfbld.dhd(f9);
        this.PquMu.dhd(f5 + f6);
        float f10 = MathHelper.clamp((float)this.sjeIR.dhj(), (float)0.0f, (float)1.0f);
        class_lC_5322e8cf.cdg(f, f2, f3 * f10, f4, Class_ld_bb1690e1.all(0.7f), class_ii_9b427eda.bjf());
        float f11 = MathHelper.clamp((float)this.dfbld.dhj(), (float)0.0f, (float)1.0f);
        class_lC_5322e8cf.cdg(f + f3 - f3 * f11, f2, f3 * f11, f4, Class_ld_bb1690e1.all(0.7f), Class_mG_52c8d386.cnP(255.0f, 220.0f, 81.0f));
    }

    private static int OM(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x19EF;
        if (GEMJy[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = wNQMp[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])BwsEB.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    BwsEB.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bZ_5682cfc3", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bZ_5682cfc3.GEMJy[n2] = n3;
        }
        return GEMJy[n2];
    }

    /*
     * Unable to fully structure code
     */
    private void OI(Class_lC_5322e8cf var1_1) {
        var2_2 = Class_bZ_5682cfc3.yIQrZ ^ 89881241351348L;
        var5_3 = Class_lE_06fbe260.joxgd.bYM(7.0f);
        var4_4 = Class_ca_75c833b3.OX();
        var6_5 = Class_lE_06fbe260.SVnNc.bYM(6.0f);
        var7_6 = ClientMain.dlM();
        var8_7 = var7_6.bjb().coa(255.0f * this.ormBS.dhj());
        var9_8 = var7_6.bjf().coa(255.0f * this.ormBS.dhj());
        v0 = this.PquMu.dhj();
        if (var4_4) ** GOTO lbl14
        if (v0 == 1000.0f) {
            v1 = "?";
        } else {
            v0 = this.PquMu.dhj();
lbl14:
            // 2 sources

            v1 = Class_jf_d1c4f950.bAM(v0);
        }
        var10_9 = v1;
        var11_10 = this.toIeR + 30.0f;
        var12_11 = this.QWaAn + 9.0f;
        var13_12 = this.jTsqG - 40.0f - var6_5.cao(var10_9);
        var14_13 = this.qcZhQ.getName().getString();
        v2 = this;
        if (!var4_4) {
            if (v2.qcZhQ == ClientMain.dlmvG.player) {
                var14_13 = ClientMain.dlJ().aZx(NameProtectModule.class).aWP(var14_13);
            }
            var1_1.ceH(var5_3, var14_13, var11_10, var12_11, var8_7, 0.7f, 1.0f, var13_12);
            v2 = this;
        }
        var15_14 = v2.toIeR + this.jTsqG - 7.0f;
        var16_15 = this.QWaAn + 10.0f;
        var1_1.ceP(var6_5, var10_9, var15_14, var16_15, var9_8);
    }

    private static CallSite OO(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bZ_5682cfc3" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bZ_5682cfc3.class, "ON", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

