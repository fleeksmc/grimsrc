/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_cC_14ef8bb5;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_cy_687dcdb6;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_nd_e33facc7;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bn_2f1533de
extends Class_az_a4990dcf {
    private final Class_nd_e33facc7 oUrRP;
    private final Class_az_a4990dcf CRIaI;
    private final Class_rk_bf8630d1 ThKyW;
    private static long WKWqD;
    private static String[] ZGPGj;
    private static String[] ojBkx;
    private static Map ubJdR;
    private static long[] jzoAa;
    private static Integer[] kwnpJ;
    private static Map uHZms;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bn_2f1533de(Class_nd_e33facc7 class_nd_e33facc7, Class_az_a4990dcf class_az_a4990dcf) {
        long l = WKWqD ^ 0x2F68C2C6DD9L;
        this.ThKyW = new Class_rk_bf8630d1((int)Class_bn_2f1533de.Fv("r", (int)5152, (long)(0x53FFB23390A66F06L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.oUrRP = class_nd_e33facc7;
        this.CRIaI = class_az_a4990dcf;
    }

    static {
        NativeLoader.doInit(Class_bn_2f1533de.class);
        Class_bn_2f1533de._ae95296b69fb76f64e5f8e3764d2f6be();
    }

    @Override
    public native float dn();

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native void dY();

    private static native void _ae95296b69fb76f64e5f8e3764d2f6be();

    private native void Fj(double var1, double var3);

    private static native int Ft(int var0, long var1);

    private static native int Fu(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public native Class_nd_e33facc7 Fk();

    private native /* synthetic */ void Fn(Class_cy_687dcdb6 var1, Class_cJ_2ae1a557 var2, Class_cC_14ef8bb5 var3, Class_aj_95d0a719 var4);

    private static native MatchException Fo(MatchException var0);

    private static native String Fp(byte[] var0);

    private static native CallSite Fs(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native CallSite Fv(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native Class_az_a4990dcf Fl();

    public native Class_rk_bf8630d1 Fm();

    private static native String Fq(int var0, long var1);

    private static native Object Fr(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);
}

