/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.pipeline.RenderPipeline
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.textures.GpuTexture
 *  mixin.accessors.MinecraftAccessor
 *  net.minecraft.client.gl.Framebuffer
 *  net.minecraft.client.gui.screen.ChatScreen
 *  net.minecraft.client.gui.screen.Screen
 */
package recovered.internal;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import mixin.accessors.MinecraftAccessor;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import recovered.core.ClientMain;
import recovered.internal.Class_av_ffcf74a1;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jL_e8aba6a1;
import recovered.internal.Class_jm_b3d8cd6c;
import recovered.internal.Class_jn_35368c94;
import recovered.internal.Class_jp_fe2807d9;
import recovered.internal.Class_kR_e9b8cad1;
import recovered.internal.Class_kV_3456311d;
import recovered.internal.Class_kn_79aeee60;
import recovered.internal.Class_lO_09cf8781;
import recovered.internal.Class_lP_d8fbe071;
import recovered.internal.Class_lQ_4277eb99;
import recovered.internal.Class_lT_411dd062;
import recovered.internal.Class_lt_a3a39a2f;
import recovered.internal.Class_lu_442b747e;
import recovered.internal.Class_rt_3bd7988b;

public final class Class_jo_20314c4b {
    private static final Class_jo_20314c4b fYlIq;
    private static final ThreadLocal<Class_jn_35368c94> wEOIE;
    private static final ThreadLocal<Framebuffer> hdKgo;
    private volatile boolean ifpCk;
    private volatile boolean WZYbo;
    private Class_jp_fe2807d9 vUdoJ;
    private Class_jp_fe2807d9 VZxOZ;
    private Class_jp_fe2807d9 wnqWl;
    private Class_jp_fe2807d9 nBoiY;
    private Class_jp_fe2807d9 eFXCP;
    private Class_jp_fe2807d9 rQpiC;
    private Class_lO_09cf8781 ErHsl;
    private Class_lP_d8fbe071 mauej;
    private static final long SuwYq;
    private static final String[] Jdstx;
    private static final String[] NlbpS;
    private static final Map DoEeQ;
    private static final long[] YKowF;
    private static final Integer[] yOISF;
    private static final Map oVZWQ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public static Framebuffer bEh() {
        long l = SuwYq ^ 0x3D37640E4175L;
        Framebuffer framebuffer = hdKgo.get();
        Class_iS_888f260e[] class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
        Framebuffer framebuffer2 = framebuffer;
        if (class_iS_888f260eArray != null) {
            framebuffer2 = framebuffer2 != null ? framebuffer : ClientMain.dlmvG.getFramebuffer();
        }
        return framebuffer2;
    }

    public static Framebuffer bEk() {
        return fYlIq.bEH(Class_jo_20314c4b.fYlIq.vUdoJ);
    }

    public static Framebuffer bEi() {
        long l = SuwYq ^ 0x39A1CED26880L;
        Class_jn_35368c94 class_jn_35368c94 = wEOIE.get();
        return class_jn_35368c94 == null ? null : fYlIq.bEE(class_jn_35368c94);
    }

    public static Framebuffer bEl() {
        return fYlIq.bEH(Class_jo_20314c4b.fYlIq.wnqWl);
    }

    public static Framebuffer bEj() {
        long l = SuwYq ^ 0x376BF4C4B541L;
        Class_jn_35368c94 class_jn_35368c94 = wEOIE.get();
        return class_jn_35368c94 == null ? null : fYlIq.bEF(class_jn_35368c94);
    }

    /*
     * Unable to fully structure code
     */
    private void bEw() {
        block4: {
            var1_1 = Class_jo_20314c4b.SuwYq ^ 88083106209449L;
            var3_2 = Class_jm_b3d8cd6c.bDZ();
            v0 = this.ifpCk;
            if (var3_2 == null) break block4;
            if (!v0) {
                return;
            }
            this.bEA();
            v1 = this;
            if (var3_2 == null) ** GOTO lbl22
            v0 = v1.bER();
        }
        if (!v0) {
            return;
        }
        try {
            this.bEB();
            this.bEM(this.vUdoJ);
            this.bEM(this.wnqWl);
            this.bEM(this.eFXCP);
            this.bEM(this.VZxOZ);
            this.bEM(this.nBoiY);
            v1 = this;
lbl22:
            // 2 sources

            v1.bEM(this.rQpiC);
        }
        catch (Throwable var4_3) {
            // empty catch block
        }
    }

    private void bEU(int n, int n2) {
        Class_lP_d8fbe071 class_lP_d8fbe071;
        block5: {
            block6: {
                block3: {
                    Class_iS_888f260e[] class_iS_888f260eArray;
                    block4: {
                        Class_jo_20314c4b class_jo_20314c4b;
                        block2: {
                            long l = SuwYq ^ 0x139A4B7CA612L;
                            class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                            class_jo_20314c4b = this;
                            if (class_iS_888f260eArray == null) break block2;
                            if (!class_jo_20314c4b.ifpCk) break block3;
                            class_jo_20314c4b = this;
                        }
                        class_lP_d8fbe071 = class_jo_20314c4b.mauej;
                        if (class_iS_888f260eArray == null) break block4;
                        if (class_lP_d8fbe071 == null) break block3;
                        class_lP_d8fbe071 = this.mauej;
                    }
                    if (class_iS_888f260eArray == null) break block5;
                    if (class_lP_d8fbe071.cgW()) break block6;
                }
                return;
            }
            class_lP_d8fbe071 = this.mauej;
        }
        class_lP_d8fbe071.chf(n, n2);
    }

    private void bEC() {
        block3: {
            block2: {
                long l = SuwYq ^ 0x52099B899D83L;
                Class_iS_888f260e[] class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                Class_jo_20314c4b class_jo_20314c4b = this;
                if (class_iS_888f260eArray == null) break block2;
                if (class_jo_20314c4b.ErHsl != null) break block3;
                class_jo_20314c4b = this;
            }
            class_jo_20314c4b.ErHsl = new Class_lO_09cf8781();
        }
    }

    private void bEN(Class_jp_fe2807d9 class_jp_fe2807d9) {
        long l = SuwYq ^ 0x1C79FF8BB57FL;
        this.bEP(class_jp_fe2807d9, 1, (int)Class_jo_20314c4b.bFi("x", (int)26637, (long)(0x690B34108E039B1EL ^ l)), 1, (int)Class_jo_20314c4b.bFi("x", (int)5820, (long)(0x140FF7B8FF7AE5AEL ^ l)));
    }

    private void bEB() {
        block29: {
            Class_jp_fe2807d9 class_jp_fe2807d9;
            block27: {
                block28: {
                    Class_iS_888f260e[] class_iS_888f260eArray;
                    long l;
                    block26: {
                        Class_jp_fe2807d9 class_jp_fe2807d92;
                        block24: {
                            block25: {
                                block23: {
                                    Class_jp_fe2807d9 class_jp_fe2807d93;
                                    block21: {
                                        block22: {
                                            block20: {
                                                Class_jp_fe2807d9 class_jp_fe2807d94;
                                                block18: {
                                                    block19: {
                                                        block17: {
                                                            Class_jp_fe2807d9 class_jp_fe2807d95;
                                                            block15: {
                                                                block16: {
                                                                    block14: {
                                                                        Class_jp_fe2807d9 class_jp_fe2807d96;
                                                                        block12: {
                                                                            block13: {
                                                                                l = SuwYq ^ 0x38501FC5F242L;
                                                                                class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                                                                                class_jp_fe2807d96 = this.vUdoJ;
                                                                                if (class_iS_888f260eArray == null) break block12;
                                                                                if (class_jp_fe2807d96 != null) break block13;
                                                                                this.vUdoJ = new Class_jp_fe2807d9((String)((Object)Class_jo_20314c4b.bFf("l", (int)15228, (long)(0x72AFADE1A840AADFL ^ l))), true);
                                                                                if (class_iS_888f260eArray != null) break block14;
                                                                            }
                                                                            class_jp_fe2807d96 = this.vUdoJ;
                                                                        }
                                                                        class_jp_fe2807d96.bFj();
                                                                    }
                                                                    class_jp_fe2807d95 = this.wnqWl;
                                                                    if (class_iS_888f260eArray == null) break block15;
                                                                    if (class_jp_fe2807d95 != null) break block16;
                                                                    this.wnqWl = new Class_jp_fe2807d9((String)((Object)Class_jo_20314c4b.bFf("l", (int)13908, (long)(0x1CB0BF5B312E27F8L ^ l))), true);
                                                                    if (class_iS_888f260eArray != null) break block17;
                                                                }
                                                                class_jp_fe2807d95 = this.wnqWl;
                                                            }
                                                            class_jp_fe2807d95.bFj();
                                                        }
                                                        class_jp_fe2807d94 = this.eFXCP;
                                                        if (class_iS_888f260eArray == null) break block18;
                                                        if (class_jp_fe2807d94 != null) break block19;
                                                        this.eFXCP = new Class_jp_fe2807d9((String)((Object)Class_jo_20314c4b.bFf("l", (int)7621, (long)(0x335980C2163E0C63L ^ l))), false);
                                                        if (class_iS_888f260eArray != null) break block20;
                                                    }
                                                    class_jp_fe2807d94 = this.eFXCP;
                                                }
                                                class_jp_fe2807d94.bFj();
                                            }
                                            class_jp_fe2807d93 = this.VZxOZ;
                                            if (class_iS_888f260eArray == null) break block21;
                                            if (class_jp_fe2807d93 != null) break block22;
                                            this.VZxOZ = new Class_jp_fe2807d9((String)((Object)Class_jo_20314c4b.bFf("l", (int)27053, (long)(0x49C4E79922E6F80AL ^ l))), false);
                                            if (class_iS_888f260eArray != null) break block23;
                                        }
                                        class_jp_fe2807d93 = this.VZxOZ;
                                    }
                                    class_jp_fe2807d93.bFj();
                                }
                                class_jp_fe2807d92 = this.nBoiY;
                                if (class_iS_888f260eArray == null) break block24;
                                if (class_jp_fe2807d92 != null) break block25;
                                this.nBoiY = new Class_jp_fe2807d9((String)((Object)Class_jo_20314c4b.bFf("l", (int)15246, (long)(0x1A67CF09E6DC2A2EL ^ l))), false);
                                if (class_iS_888f260eArray != null) break block26;
                            }
                            class_jp_fe2807d92 = this.nBoiY;
                        }
                        class_jp_fe2807d92.bFj();
                    }
                    class_jp_fe2807d9 = this.rQpiC;
                    if (class_iS_888f260eArray == null) break block27;
                    if (class_jp_fe2807d9 != null) break block28;
                    this.rQpiC = new Class_jp_fe2807d9((String)((Object)Class_jo_20314c4b.bFf("l", (int)11727, (long)(0x5E2EF3B7B3F93C6DL ^ l))), false);
                    if (class_iS_888f260eArray != null) break block29;
                }
                class_jp_fe2807d9 = this.rQpiC;
            }
            class_jp_fe2807d9.bFj();
        }
    }

    private static Throwable bFb(Throwable throwable) {
        return throwable;
    }

    private Class_jp_fe2807d9 bEF(Class_jn_35368c94 class_jn_35368c94) {
        long l = SuwYq ^ 0x4325199166DCL;
        return class_jn_35368c94 == Class_jn_35368c94.pWlAK ? this.wnqWl : this.nBoiY;
    }

    public static boolean bEg() {
        long l = SuwYq ^ 0x607F2EF2D2E6L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
        boolean bl = Class_rt_3bd7988b.djy();
        if (class_iS_888f260eArray != null) {
            if (bl) {
                return false;
            }
            bl = true;
        }
        return bl;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean bES() {
        long l = SuwYq ^ 0x1E3994377D97L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
        boolean bl = this.ifpCk;
        if (class_iS_888f260eArray == null) return bl;
        if (!bl) {
            return false;
        }
        Screen screen = ClientMain.dlmvG.currentScreen;
        if (class_iS_888f260eArray != null) {
            if (screen == null) return false;
            screen = ClientMain.dlmvG.currentScreen;
        }
        boolean bl2 = screen instanceof Class_av_ffcf74a1;
        if (class_iS_888f260eArray != null) {
            if (bl2) return false;
            bl2 = ClientMain.dlmvG.currentScreen instanceof ChatScreen;
        }
        if (class_iS_888f260eArray == null) return bl2;
        if (bl2) return false;
        return true;
    }

    private static CallSite bFf(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jo_20314c4b" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private Framebuffer bEI(RenderPipeline renderPipeline, Framebuffer framebuffer) {
        Class_jp_fe2807d9 class_jp_fe2807d9;
        block13: {
            Class_jp_fe2807d9 class_jp_fe2807d92;
            Class_jp_fe2807d9 class_jp_fe2807d93;
            Class_jn_35368c94 class_jn_35368c94;
            block14: {
                Class_jp_fe2807d9 class_jp_fe2807d94;
                block11: {
                    block12: {
                        Class_iS_888f260e[] class_iS_888f260eArray;
                        block10: {
                            Framebuffer framebuffer2;
                            block9: {
                                block8: {
                                    block6: {
                                        boolean bl;
                                        block7: {
                                            long l = SuwYq ^ 0x3BAEE59846D1L;
                                            class_jn_35368c94 = wEOIE.get();
                                            class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                                            if (class_jn_35368c94 == null) break block6;
                                            bl = this.bER();
                                            if (class_iS_888f260eArray == null) break block7;
                                            if (!bl) break block6;
                                            bl = Class_kV_3456311d.bWo(renderPipeline);
                                        }
                                        if (bl) break block8;
                                    }
                                    return framebuffer;
                                }
                                class_jp_fe2807d93 = this.bEE(class_jn_35368c94);
                                framebuffer2 = framebuffer;
                                if (class_iS_888f260eArray == null) break block9;
                                if (framebuffer2 == class_jp_fe2807d93) break block10;
                                framebuffer2 = framebuffer;
                            }
                            return framebuffer2;
                        }
                        class_jp_fe2807d94 = class_jp_fe2807d92 = this.bEF(class_jn_35368c94);
                        if (class_iS_888f260eArray == null) break block11;
                        if (class_jp_fe2807d94 == null) break block12;
                        class_jp_fe2807d9 = class_jp_fe2807d92;
                        if (class_iS_888f260eArray == null) break block13;
                        if (class_jp_fe2807d9.getColorAttachment() != null) break block14;
                    }
                    class_jp_fe2807d94 = framebuffer;
                }
                return class_jp_fe2807d94;
            }
            this.bEJ(class_jn_35368c94, class_jp_fe2807d93, class_jp_fe2807d92);
            class_jp_fe2807d92.LHtaR = true;
            class_jp_fe2807d9 = class_jp_fe2807d92;
        }
        return class_jp_fe2807d9;
    }

    private Class_jp_fe2807d9 bEG(Class_jn_35368c94 class_jn_35368c94) {
        long l = SuwYq ^ 0x4E1B6A1D9CD3L;
        return class_jn_35368c94 == Class_jn_35368c94.pWlAK ? this.eFXCP : this.rQpiC;
    }

    /*
     * Unable to fully structure code
     */
    private void bEz() {
        var1_1 = Class_jo_20314c4b.SuwYq ^ 33196289229748L;
        v0 = Class_jm_b3d8cd6c.bDZ();
        this.bEC();
        var3_2 = v0;
        v1 = this;
        if (var3_2 == null) ** GOTO lbl16
        if (v1.ErHsl == null) {
            return;
        }
        try {
            Class_lQ_4277eb99.chQ();
            Class_lQ_4277eb99.chS();
            this.bEN(this.vUdoJ);
            this.bEO(this.wnqWl, this.eFXCP);
            this.bEN(this.VZxOZ);
            v1 = this;
lbl16:
            // 2 sources

            v1.bEO(this.nBoiY, this.rQpiC);
        }
        finally {
            Class_lQ_4277eb99.chT();
            Class_lQ_4277eb99.chR();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean bER() {
        long l = SuwYq ^ 0x69908BF852D1L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
        Class_jo_20314c4b class_jo_20314c4b = this;
        if (class_iS_888f260eArray != null) {
            if (!class_jo_20314c4b.ifpCk) return false;
            class_jo_20314c4b = this;
        }
        Class_lP_d8fbe071 class_lP_d8fbe071 = class_jo_20314c4b.mauej;
        if (class_iS_888f260eArray != null) {
            if (class_lP_d8fbe071 == null) return false;
            class_lP_d8fbe071 = this.mauej;
        }
        boolean bl = class_lP_d8fbe071.cgW();
        if (class_iS_888f260eArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    private void bEK(Framebuffer framebuffer, Class_jp_fe2807d9 class_jp_fe2807d9) {
        int n;
        int n2;
        block11: {
            block10: {
                int n3;
                block9: {
                    Class_jp_fe2807d9 class_jp_fe2807d92;
                    Class_iS_888f260e[] class_iS_888f260eArray;
                    block7: {
                        block8: {
                            block5: {
                                block6: {
                                    Framebuffer framebuffer2;
                                    block4: {
                                        long l = SuwYq ^ 0x20BA6C29CACCL;
                                        class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                                        framebuffer2 = framebuffer;
                                        if (class_iS_888f260eArray == null) break block4;
                                        if (framebuffer2 == null) break block5;
                                        framebuffer2 = framebuffer;
                                    }
                                    if (framebuffer2.getColorAttachment() == null) break block5;
                                    class_jp_fe2807d92 = class_jp_fe2807d9;
                                    if (class_iS_888f260eArray == null) break block6;
                                    if (class_jp_fe2807d92 == null) break block5;
                                    class_jp_fe2807d92 = class_jp_fe2807d9;
                                }
                                if (class_iS_888f260eArray == null) break block7;
                                if (class_jp_fe2807d92.getColorAttachment() != null) break block8;
                            }
                            return;
                        }
                        class_jp_fe2807d92 = framebuffer;
                    }
                    n2 = Math.min(((Framebuffer)class_jp_fe2807d92).textureWidth, class_jp_fe2807d9.textureWidth);
                    n = Math.min(framebuffer.textureHeight, class_jp_fe2807d9.textureHeight);
                    n3 = n2;
                    if (class_iS_888f260eArray == null) break block9;
                    if (n3 <= 0) break block10;
                    n3 = n;
                }
                if (n3 > 0) break block11;
            }
            return;
        }
        Class_lu_442b747e.cbf(framebuffer.getColorAttachment(), class_jp_fe2807d9.getColorAttachment(), 0, 0, 0, 0, 0, n2, n);
    }

    private void bEL(Framebuffer framebuffer, Class_jp_fe2807d9 class_jp_fe2807d9) {
        block7: {
            block5: {
                Class_jp_fe2807d9 class_jp_fe2807d92;
                block6: {
                    Framebuffer framebuffer2;
                    Class_iS_888f260e[] class_iS_888f260eArray;
                    block4: {
                        long l = SuwYq ^ 0x7C0604711A48L;
                        class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                        framebuffer2 = framebuffer;
                        if (class_iS_888f260eArray == null) break block4;
                        if (framebuffer2 == null) break block5;
                        framebuffer2 = framebuffer;
                    }
                    if (framebuffer2.getColorAttachment() == null) break block5;
                    class_jp_fe2807d92 = class_jp_fe2807d9;
                    if (class_iS_888f260eArray == null) break block6;
                    if (class_jp_fe2807d92 == null) break block5;
                    class_jp_fe2807d92 = class_jp_fe2807d9;
                }
                if (class_jp_fe2807d92.getColorAttachment() != null) break block7;
            }
            return;
        }
        if (Class_kR_e9b8cad1.cSPla == null || Class_jL_e8aba6a1.TruIk == null) {
            return;
        }
        Class_kn_79aeee60.bQq(Class_kR_e9b8cad1.cSPla, (Framebuffer)class_jp_fe2807d9, renderPass -> {
            long l = SuwYq ^ 0x7551D9276827L;
            renderPass.bindTexture((String)((Object)Class_jo_20314c4b.bFf("l", (int)26408, (long)(0x38773BAE874BECE8L ^ l))), framebuffer.getColorAttachmentView(), Class_lt_a3a39a2f.caX());
            Class_jL_e8aba6a1.TruIk.bJl();
        });
    }

    private synchronized void bEu(boolean bl) {
        block6: {
            Class_jo_20314c4b class_jo_20314c4b;
            block5: {
                boolean bl2;
                block4: {
                    long l = SuwYq ^ 0xEEDF1417A63L;
                    Class_iS_888f260e[] class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                    bl2 = this.ifpCk;
                    if (class_iS_888f260eArray == null) break block4;
                    if (bl2 == bl) {
                        return;
                    }
                    class_jo_20314c4b = this;
                    if (class_iS_888f260eArray == null) break block5;
                    class_jo_20314c4b.ifpCk = bl;
                    bl2 = bl;
                }
                if (bl2) break block6;
                class_jo_20314c4b = this;
            }
            class_jo_20314c4b.bEv();
        }
    }

    public static boolean bEf() {
        long l = SuwYq ^ 0x2CCCEC9A1D44L;
        return wEOIE.get() != null;
    }

    private void bEV() {
        block4: {
            long l = SuwYq ^ 0x143DCA2D018BL;
            Class_iS_888f260e[] class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
            try {
                block6: {
                    block5: {
                        if (class_iS_888f260eArray == null) break block5;
                        if (!RenderSystem.isOnRenderThread()) break block6;
                        this.bEW();
                    }
                    if (class_iS_888f260eArray != null) break block4;
                }
                RenderSystem.queueFencedTask(this::bEW);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private void bEA() {
        block6: {
            Class_jo_20314c4b class_jo_20314c4b;
            Class_lP_d8fbe071 class_lP_d8fbe071;
            block5: {
                long l = SuwYq ^ 0x263139094FA7L;
                Class_iS_888f260e[] class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                class_lP_d8fbe071 = this.mauej;
                if (class_iS_888f260eArray == null) break block5;
                if (class_lP_d8fbe071 == null) {
                    this.mauej = new Class_lP_d8fbe071();
                }
                class_jo_20314c4b = this;
                if (class_iS_888f260eArray == null) break block6;
                class_lP_d8fbe071 = class_jo_20314c4b.mauej;
            }
            if (!class_lP_d8fbe071.cgW()) {
                this.mauej.cgX();
            }
            class_jo_20314c4b = this;
        }
        class_jo_20314c4b.WZYbo = this.mauej.cgW();
    }

    public static boolean bEd() {
        return Class_jo_20314c4b.fYlIq.ifpCk;
    }

    private Class_jp_fe2807d9 bEE(Class_jn_35368c94 class_jn_35368c94) {
        long l = SuwYq ^ 0x469C12B82B92L;
        return class_jn_35368c94 == Class_jn_35368c94.pWlAK ? this.vUdoJ : this.VZxOZ;
    }

    private Framebuffer bEH(Class_jp_fe2807d9 class_jp_fe2807d9) {
        Class_jp_fe2807d9 class_jp_fe2807d92;
        block5: {
            block6: {
                block2: {
                    Class_iS_888f260e[] class_iS_888f260eArray;
                    block4: {
                        block3: {
                            long l = SuwYq ^ 0x1E4082FDC85L;
                            class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                            if (!this.ifpCk) break block2;
                            class_jp_fe2807d92 = class_jp_fe2807d9;
                            if (class_iS_888f260eArray == null) break block3;
                            if (class_jp_fe2807d92 == null) break block2;
                            class_jp_fe2807d92 = class_jp_fe2807d9;
                        }
                        if (class_iS_888f260eArray == null) break block4;
                        if (!class_jp_fe2807d92.LHtaR) break block2;
                        class_jp_fe2807d92 = class_jp_fe2807d9;
                    }
                    if (class_iS_888f260eArray == null) break block5;
                    if (class_jp_fe2807d92.getColorAttachment() != null) break block6;
                }
                return null;
            }
            class_jp_fe2807d92 = class_jp_fe2807d9;
        }
        return class_jp_fe2807d92;
    }

    /*
     * Unable to fully structure code
     */
    private void bEx() {
        var1_1 = Class_jo_20314c4b.SuwYq ^ 126333645477197L;
        var3_2 = Class_jm_b3d8cd6c.bDZ();
        v0 = this.ifpCk;
        if (var3_2 == null) ** GOTO lbl9
        if (!v0) {
            return;
        }
        try {
            block11: {
                block10: {
                    v0 = this.bES();
lbl9:
                    // 2 sources

                    if (var3_2 != null) {
                        if (v0) {
                            this.bET();
                            return;
                        }
                        this.bEA();
                        v0 = this.bER();
                    }
                    if (var3_2 == null) break block10;
                    if (!v0) {
                        return;
                    }
                    this.bEB();
                    v1 = this.mauej;
                    if (var3_2 == null) break block11;
                    v0 = v1.cgY();
                }
                if (!v0) {
                    return;
                }
                v1 = this.mauej;
            }
            v1.cgZ((Runnable)LambdaMetafactory.metafactory(null, null, null, ()V, bEz(), ()V)((Class_jo_20314c4b)this));
        }
        catch (Throwable var4_3) {
            // empty catch block
        }
    }

    private void bEO(Class_jp_fe2807d9 class_jp_fe2807d9, Class_jp_fe2807d9 class_jp_fe2807d92) {
        long l = SuwYq ^ 0x15713613FDC3L;
        this.bEQ(class_jp_fe2807d9, class_jp_fe2807d92, 1, (int)Class_jo_20314c4b.bFi("x", (int)5820, (long)(0x140FFEB036E2AD12L ^ l)), 1, (int)Class_jo_20314c4b.bFi("x", (int)5820, (long)(0x140FFEB036E2AD12L ^ l)), 1);
    }

    private void bEJ(Class_jn_35368c94 class_jn_35368c94, Class_jp_fe2807d9 class_jp_fe2807d9, Class_jp_fe2807d9 class_jp_fe2807d92) {
        GpuTexture gpuTexture;
        Class_jp_fe2807d9 class_jp_fe2807d93;
        Class_iS_888f260e[] class_iS_888f260eArray;
        block9: {
            block10: {
                block8: {
                    Class_jp_fe2807d9 class_jp_fe2807d94;
                    block7: {
                        long l = SuwYq ^ 0x4DEB5E554F33L;
                        class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                        Class_jp_fe2807d9 class_jp_fe2807d95 = class_jp_fe2807d92;
                        if (class_iS_888f260eArray != null) {
                            if (class_jp_fe2807d95.LHtaR) {
                                return;
                            }
                            class_jp_fe2807d95 = this.bEG(class_jn_35368c94);
                        }
                        class_jp_fe2807d94 = class_jp_fe2807d93 = class_jp_fe2807d95;
                        if (class_iS_888f260eArray == null) break block7;
                        if (class_jp_fe2807d94 == null) break block8;
                        class_jp_fe2807d94 = class_jp_fe2807d93;
                    }
                    gpuTexture = class_jp_fe2807d94.getColorAttachment();
                    if (class_iS_888f260eArray == null) break block9;
                    if (gpuTexture != null) break block10;
                }
                return;
            }
            gpuTexture = hdKgo.get();
        }
        Framebuffer framebuffer = (Framebuffer)gpuTexture;
        if (class_iS_888f260eArray != null) {
            if (framebuffer == null) {
                framebuffer = ClientMain.dlmvG.getFramebuffer();
            }
            this.bEK(framebuffer, class_jp_fe2807d93);
            this.bEL((Framebuffer)class_jp_fe2807d9, class_jp_fe2807d93);
            this.bEK((Framebuffer)class_jp_fe2807d93, class_jp_fe2807d92);
            class_jp_fe2807d93.LHtaR = true;
        }
    }

    public static void bEn() {
        fYlIq.bEx();
    }

    public static void bEc(boolean bl) {
        fYlIq.bEu(bl);
    }

    public static void bEo(int n, int n2) {
        fYlIq.bEU(n, n2);
    }

    public static boolean bEe() {
        return Class_jo_20314c4b.fYlIq.WZYbo;
    }

    public static void bEm() {
        fYlIq.bEw();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void bEy(Class_jn_35368c94 class_jn_35368c94, Runnable runnable) {
        Class_jp_fe2807d9 class_jp_fe2807d9;
        block22: {
            Class_iS_888f260e[] class_iS_888f260eArray;
            long l;
            block28: {
                block27: {
                    Object object;
                    block26: {
                        boolean bl;
                        block25: {
                            l = SuwYq ^ 0x3395E3988602L;
                            class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                            bl = this.bES();
                            if (class_iS_888f260eArray == null) break block25;
                            if (bl) {
                                return;
                            }
                            object = this;
                            if (class_iS_888f260eArray == null) break block26;
                            bl = ((Class_jo_20314c4b)object).bER();
                        }
                        if (!bl) break block27;
                        object = wEOIE.get();
                    }
                    if (object == null) break block28;
                }
                runnable.run();
                return;
            }
            try {
                Class_jp_fe2807d9 class_jp_fe2807d92;
                Class_jp_fe2807d9 class_jp_fe2807d93;
                block31: {
                    Class_jp_fe2807d9 class_jp_fe2807d94;
                    block32: {
                        block30: {
                            block29: {
                                this.bEB();
                                class_jp_fe2807d93 = this.bEE(class_jn_35368c94);
                                class_jp_fe2807d92 = this.bEF(class_jn_35368c94);
                                class_jp_fe2807d94 = class_jp_fe2807d93;
                                if (class_iS_888f260eArray == null) break block29;
                                if (class_jp_fe2807d94 == null) break block30;
                                class_jp_fe2807d94 = class_jp_fe2807d93;
                            }
                            if (class_iS_888f260eArray == null) break block31;
                            if (class_jp_fe2807d94.getColorAttachment() != null) break block32;
                        }
                        throw new IllegalStateException((String)((Object)Class_jo_20314c4b.bFf("l", (int)30160, (long)(0x4CF8C8E5DC9E903DL ^ l))) + String.valueOf((Object)class_jn_35368c94));
                    }
                    class_jp_fe2807d94 = class_jp_fe2807d9 = ClientMain.dlmvG.getFramebuffer();
                }
                if (class_iS_888f260eArray == null) break block22;
                if (class_jn_35368c94 == Class_jn_35368c94.pWlAK) {
                    this.bED((Framebuffer)class_jp_fe2807d9, class_jp_fe2807d93);
                    if (class_iS_888f260eArray == null) break block22;
                    if (class_jp_fe2807d92 != null) {
                        this.bED((Framebuffer)class_jp_fe2807d9, class_jp_fe2807d92);
                    }
                }
                hdKgo.set((Framebuffer)class_jp_fe2807d9);
                wEOIE.set(class_jn_35368c94);
                ((MinecraftAccessor)ClientMain.dlmvG).setMainRenderTarget((Framebuffer)class_jp_fe2807d93);
            }
            catch (Throwable throwable) {
                hdKgo.remove();
                wEOIE.remove();
                runnable.run();
                return;
            }
        }
        try {
            runnable.run();
        }
        finally {
            try {
                ((MinecraftAccessor)ClientMain.dlmvG).setMainRenderTarget((Framebuffer)class_jp_fe2807d9);
                class_jp_fe2807d93.LHtaR = true;
            }
            finally {
                hdKgo.remove();
                wEOIE.remove();
            }
        }
    }

    private synchronized void bEv() {
        this.WZYbo = false;
        this.bEV();
    }

    private void bEM(Class_jp_fe2807d9 class_jp_fe2807d9) {
        block3: {
            Class_jp_fe2807d9 class_jp_fe2807d92;
            block4: {
                Class_iS_888f260e[] class_iS_888f260eArray;
                block2: {
                    long l = SuwYq ^ 0x11357256C622L;
                    class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                    class_jp_fe2807d92 = class_jp_fe2807d9;
                    if (class_iS_888f260eArray == null) break block2;
                    if (class_jp_fe2807d92 == null) break block3;
                    class_jp_fe2807d92 = class_jp_fe2807d9;
                }
                if (class_iS_888f260eArray == null) break block4;
                if (!class_jp_fe2807d92.LHtaR) break block3;
                class_jp_fe2807d92 = class_jp_fe2807d9;
            }
            class_jp_fe2807d92.bFk();
        }
    }

    private void bET() {
        block3: {
            Class_lP_d8fbe071 class_lP_d8fbe071;
            block2: {
                long l = SuwYq ^ 0x79C16F9C27A1L;
                Class_iS_888f260e[] class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                class_lP_d8fbe071 = this.mauej;
                if (class_iS_888f260eArray == null) break block2;
                if (class_lP_d8fbe071 == null) break block3;
                class_lP_d8fbe071 = this.mauej;
            }
            class_lP_d8fbe071.chl();
        }
    }

    private void bED(Framebuffer framebuffer, Class_jp_fe2807d9 class_jp_fe2807d9) {
        long l = SuwYq ^ 0x19B43FF3DC4EL;
        int n = class_jp_fe2807d9.bFm();
        Class_iS_888f260e[] class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
        if (class_iS_888f260eArray != null) {
            if (n == -1) {
                return;
            }
            Class_lT_411dd062.ciQ().copyDepthTexture(framebuffer.getDepthAttachment(), class_jp_fe2807d9.getDepthAttachment(), class_jp_fe2807d9.textureWidth, class_jp_fe2807d9.textureHeight);
        }
    }

    private static CallSite bFi(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jo_20314c4b" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private void bEW() {
        long l = SuwYq ^ 0x3024142CB62BL;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
        try {
            block9: {
                Class_jo_20314c4b class_jo_20314c4b;
                block8: {
                    block6: {
                        block7: {
                            class_jo_20314c4b = this;
                            if (class_iS_888f260eArray == null) break block6;
                            if (class_jo_20314c4b.mauej == null) break block7;
                            this.mauej.cha(() -> {
                                block3: {
                                    Class_lO_09cf8781 class_lO_09cf8781;
                                    block2: {
                                        long l = SuwYq ^ 0x5D131C63FC96L;
                                        Class_iS_888f260e[] class_iS_888f260eArray = Class_jm_b3d8cd6c.bDZ();
                                        class_lO_09cf8781 = this.ErHsl;
                                        if (class_iS_888f260eArray == null) break block2;
                                        if (class_lO_09cf8781 == null) break block3;
                                        class_lO_09cf8781 = this.ErHsl;
                                    }
                                    class_lO_09cf8781.cgK();
                                    this.ErHsl = null;
                                }
                            });
                            if (class_iS_888f260eArray != null) break block8;
                        }
                        class_jo_20314c4b = this;
                    }
                    if (class_iS_888f260eArray == null) break block9;
                    if (class_jo_20314c4b.ErHsl != null) {
                        this.ErHsl.cgK();
                        this.ErHsl = null;
                    }
                }
                this.mauej = null;
                class_jo_20314c4b = this;
            }
            class_jo_20314c4b.WZYbo = false;
        }
        catch (Throwable throwable) {
            this.mauej = null;
            this.WZYbo = false;
        }
        this.bEX();
    }

    /*
     * Unable to fully structure code
     */
    private void bEY(Class_jp_fe2807d9 var1_1) {
        var2_2 = Class_jo_20314c4b.SuwYq ^ 58633630577549L;
        var4_3 = Class_jm_b3d8cd6c.bDZ();
        v0 = var1_1;
        if (var4_3 == null) ** GOTO lbl9
        if (v0 == null) {
            return;
        }
        try {
            v0 = var1_1;
lbl9:
            // 2 sources

            v0.delete();
        }
        catch (Throwable var5_4) {
            // empty catch block
        }
    }

    private static Object bFe(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_jo_20314c4b.bFd(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static int bFg(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x1007;
        if (yOISF[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = YKowF[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])oVZWQ.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    oVZWQ.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jo_20314c4b", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_jo_20314c4b.yOISF[n2] = n3;
        }
        return yOISF[n2];
    }

    private void bEP(Class_jp_fe2807d9 class_jp_fe2807d9, int n, int n2, int n3, int n4) {
        this.bEQ(class_jp_fe2807d9, null, n, n2, n3, n4, 0);
    }

    private void bEX() {
        this.bEY(this.vUdoJ);
        this.bEY(this.wnqWl);
        this.bEY(this.eFXCP);
        this.bEY(this.VZxOZ);
        this.bEY(this.nBoiY);
        this.bEY(this.rQpiC);
        this.vUdoJ = null;
        this.wnqWl = null;
        this.eFXCP = null;
        this.VZxOZ = null;
        this.nBoiY = null;
        this.rQpiC = null;
    }

    private static String bFc(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static String bFd(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x358D;
        if (NlbpS[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])DoEeQ.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    DoEeQ.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jo_20314c4b", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = Jdstx[n2].getBytes("ISO-8859-1");
            Class_jo_20314c4b.NlbpS[n2] = Class_jo_20314c4b.bFc(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return NlbpS[n2];
    }

    private static int bFh(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_jo_20314c4b.bFg(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    /*
     * Unable to fully structure code
     */
    private void bEQ(Class_jp_fe2807d9 var1_1, Class_jp_fe2807d9 var2_2, int var3_3, int var4_4, int var5_5, int var6_6, int var7_7) {
        block16: {
            block20: {
                block17: {
                    block18: {
                        block19: {
                            block14: {
                                block15: {
                                    block12: {
                                        block13: {
                                            var8_8 = Class_jo_20314c4b.SuwYq ^ 88167924464865L;
                                            var10_9 = Class_jm_b3d8cd6c.bDZ();
                                            v0 = var1_1;
                                            if (var10_9 == null) ** GOTO lbl7
                                            if (v0 != null) {
                                                v0 = var1_1;
lbl7:
                                                // 2 sources

                                                v1 = v0.bFl();
                                            } else {
                                                v1 = var11_10 = -1;
                                            }
                                            if (var1_1 == null) break block12;
                                            v2 = var11_10;
                                            if (var10_9 == null) break block13;
                                            if (v2 == -1) break block12;
                                            v3 = var1_1;
                                            if (var10_9 == null) break block14;
                                            v2 = (int)v3.LHtaR;
                                        }
                                        if (v2 != 0) break block15;
                                    }
                                    return;
                                }
                                v3 = var2_2;
                            }
                            if (var10_9 == null) ** GOTO lbl27
                            if (v3 != null) {
                                v3 = var2_2;
lbl27:
                                // 2 sources

                                v4 = v3.bFl();
                            } else {
                                v4 = -1;
                            }
                            var12_11 = v4;
                            v5 = var7_7;
                            v6 = 1;
                            if (var10_9 == null) break block16;
                            if (v5 != v6) break block17;
                            if (var2_2 == null) break block18;
                            v5 = var12_11;
                            if (var10_9 == null) break block19;
                            if (v5 == -1) break block18;
                            v5 = (int)var2_2.LHtaR;
                        }
                        if (var10_9 == null) break block20;
                        if (v5 != 0) break block17;
                    }
                    return;
                }
                Class_lQ_4277eb99.chK();
                Class_lQ_4277eb99.chO(var3_3, var4_4, var5_5, var6_6);
                Class_lQ_4277eb99.chN();
                this.ErHsl.cgG();
                Class_lQ_4277eb99.chC(0, 0);
                this.ErHsl.cgJ(var7_7);
                this.ErHsl.cgI((String)Class_jo_20314c4b.bFf("l", (int)26632, (long)(4808494369463072522L ^ var8_8)), var11_10, 0);
                v5 = var7_7;
            }
            v6 = 1;
        }
        if (var10_9 != null) {
            if (v5 == v6) {
                Class_lQ_4277eb99.chC(1, 0);
                this.ErHsl.cgI((String)Class_jo_20314c4b.bFf("l", (int)24011, (long)(3602190114215445196L ^ var8_8)), var12_11, 1);
            }
            this.ErHsl.cgH();
            Class_lQ_4277eb99.chB(1, 0);
            v5 = 0;
            v6 = 0;
        }
        Class_lQ_4277eb99.chB(v5, v6);
        Class_lQ_4277eb99.ciq(0);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        Class_jo_20314c4b.SuwYq = Class_gb_9d201141.aYR(-36095552564910604L, -9047621285772579722L, MethodHandles.lookup().lookupClass()).a(165376727831294L);
                        Class_jo_20314c4b.DoEeQ = new HashMap<K, V>(13);
                        var11 = Class_jo_20314c4b.SuwYq ^ 1861293023303L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[10];
                        var18_4 = 0;
                        var17_5 = "\u00a6\u00c0S\u00d8\u0095\u00a2\u00a1Bn\n\n\u00b4O\u0098-\u001e2\u00947\u001e\t\u00f7\u00a9\u00e6\u00a8\u0012\u00f1\u00fc\u00e0_\u001e\u0095 \u007fnG\u00fd\u009f\u009f\u008fl\f\u00b67\u00fe\u00cc\u00c6\u00a6\u00a0\u00ad\u00a6\u00ea/^\u0086\u00f6\u0093\u00d0\u00a3\t\f\u00ce\t\u00cb\u0098\u00100\u00b5o\u00ecx\u009aS\u00ec;\u0007\u008e\u000bQw\u00dc\u00e3(\u009e\u0086\u00b8\u00faH-M\u00e1\u008c\u00f4G\u00b5NhPFm\u00eb\tv\u00f57\u0004\u00dc\u0099\u00e4i\u00bb.\u007f\u00ac\u0084\u008c\u00ef\u00c4+\u000f\u00e8\u0084\" \u00a4@\u00eb\u00abg^)\u00e1Q\u009b\u0086\u0081\u0083F;Q\u00baB\u00c8\u0086\u008eI71,\u00e5\u00e4\u00a6\u00d3\t\u00b6\u00b1 #\u000b-V#,\u0016eh\u001b\u00f8\u00bd\u00c5U\u0081\u0004\u001e\"4'\u0016\u0092\u009f\u0015\u009e\u00f5AY<\u00f7\u00db\u0096\u0010\u001c\u009e\u00df\u0004\u00f6\u00dck\u0018\u00f5\u0089\u00c9\u0003=\u001b\u00c0\u009b(\u0002\u00f9o&\r\u0089\u00d8\u000b\u00da\u0093\u00d6\u00a2\u00bbm=\u00c5\u008c\u00a5\u0097\u0085`\u00e1L\u00e7\u0095\u00de\u001c\u00c0\u00acRp\u00f7\u00bf\u00f2\u00f8\u00ecm\u009a\u001a\u00fd";
                        var19_6 = "\u00a6\u00c0S\u00d8\u0095\u00a2\u00a1Bn\n\n\u00b4O\u0098-\u001e2\u00947\u001e\t\u00f7\u00a9\u00e6\u00a8\u0012\u00f1\u00fc\u00e0_\u001e\u0095 \u007fnG\u00fd\u009f\u009f\u008fl\f\u00b67\u00fe\u00cc\u00c6\u00a6\u00a0\u00ad\u00a6\u00ea/^\u0086\u00f6\u0093\u00d0\u00a3\t\f\u00ce\t\u00cb\u0098\u00100\u00b5o\u00ecx\u009aS\u00ec;\u0007\u008e\u000bQw\u00dc\u00e3(\u009e\u0086\u00b8\u00faH-M\u00e1\u008c\u00f4G\u00b5NhPFm\u00eb\tv\u00f57\u0004\u00dc\u0099\u00e4i\u00bb.\u007f\u00ac\u0084\u008c\u00ef\u00c4+\u000f\u00e8\u0084\" \u00a4@\u00eb\u00abg^)\u00e1Q\u009b\u0086\u0081\u0083F;Q\u00baB\u00c8\u0086\u008eI71,\u00e5\u00e4\u00a6\u00d3\t\u00b6\u00b1 #\u000b-V#,\u0016eh\u001b\u00f8\u00bd\u00c5U\u0081\u0004\u001e\"4'\u0016\u0092\u009f\u0015\u009e\u00f5AY<\u00f7\u00db\u0096\u0010\u001c\u009e\u00df\u0004\u00f6\u00dck\u0018\u00f5\u0089\u00c9\u0003=\u001b\u00c0\u009b(\u0002\u00f9o&\r\u0089\u00d8\u000b\u00da\u0093\u00d6\u00a2\u00bbm=\u00c5\u008c\u00a5\u0097\u0085`\u00e1L\u00e7\u0095\u00de\u001c\u00c0\u00acRp\u00f7\u00bf\u00f2\u00f8\u00ecm\u009a\u001a\u00fd".length();
                        var16_7 = 32;
                        var15_8 = -1;
lbl20:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl25:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Class_jo_20314c4b.bFc(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "mbZ\u00fd\u00c5F3\u0092$\u009f\u001f\u00e7\u0085\u00e4\u008cIM\u00a0\u00ad\u00ed\u001e\u00102\u000bm\tA\u0089\u00f7\u00ef@\u00aa\u0098\u00ce<\u00d8\u0099@\u0019.\u00ba\u00de\u00f8-g\u0019R\u00fc\u0018\u00bf=:K\u0084\b\u007f\u0094Jp\u00bb\u00a5\u00836\u00ee\u00e7\u00d8\u00be\u00a7q)7U\u001b";
                            var19_6 = "mbZ\u00fd\u00c5F3\u0092$\u009f\u001f\u00e7\u0085\u00e4\u008cIM\u00a0\u00ad\u00ed\u001e\u00102\u000bm\tA\u0089\u00f7\u00ef@\u00aa\u0098\u00ce<\u00d8\u0099@\u0019.\u00ba\u00de\u00f8-g\u0019R\u00fc\u0018\u00bf=:K\u0084\b\u007f\u0094Jp\u00bb\u00a5\u00836\u00ee\u00e7\u00d8\u00be\u00a7q)7U\u001b".length();
                            var16_7 = 48;
                            var15_8 = -1;
lbl34:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl39:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Class_jo_20314c4b.bFc(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl51:
                        // 1 sources

                        ** continue;
                    }
                }
                Class_jo_20314c4b.Jdstx = var20_3;
                Class_jo_20314c4b.NlbpS = new String[10];
                Class_jo_20314c4b.oVZWQ = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[2];
                var3_13 = 0;
                var4_14 = "&\u00c8\u00e8+\u0087\u00f4\u001d\n\u0086d\u00ee\u0002\u00f3\u0017,\u00b8";
                var5_15 = "&\u00c8\u00e8+\u0087\u00f4\u001d\n\u0086d\u00ee\u0002\u00f3\u0017,\u00b8".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl73:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        Class_jo_20314c4b.YKowF = var6_12;
        Class_jo_20314c4b.yOISF = new Integer[2];
        Class_jo_20314c4b.fYlIq = new Class_jo_20314c4b();
        Class_jo_20314c4b.wEOIE = new ThreadLocal<T>();
        Class_jo_20314c4b.hdKgo = new ThreadLocal<T>();
    }

    public static void bEt(Runnable runnable) {
        fYlIq.bEy(Class_jn_35368c94.pWlAK, runnable);
    }

    public static void bEs(Runnable runnable) {
        fYlIq.bEy(Class_jn_35368c94.bxePp, runnable);
    }

    public static Framebuffer bEp(RenderPipeline renderPipeline) {
        return fYlIq.bEI(renderPipeline, ClientMain.dlmvG.getFramebuffer());
    }

    public static Framebuffer bEq(RenderPipeline renderPipeline, Framebuffer framebuffer) {
        return fYlIq.bEI(renderPipeline, framebuffer);
    }

    public static RenderPipeline bEr(RenderPipeline renderPipeline) {
        long l = SuwYq ^ 0x41C5E84FF17FL;
        return Class_jo_20314c4b.bEf() ? Class_kV_3456311d.bWp(renderPipeline) : renderPipeline;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jo_20314c4b.class, "bFe", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_jo_20314c4b.class, "bFh", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

