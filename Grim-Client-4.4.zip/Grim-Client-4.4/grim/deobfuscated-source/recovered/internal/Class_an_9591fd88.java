/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.texture.AbstractTexture
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import net.minecraft.client.texture.AbstractTexture;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_ld_bb1690e1;

public class Class_an_9591fd88
extends Class_az_a4990dcf {
    private AbstractTexture nLhhg;
    private Class_ld_bb1690e1 ijNkN = Class_ld_bb1690e1.NONE;
    private static final long hKMkO = Class_gb_9d201141.aYR(-8978404935843101031L, 5007309845702240110L, MethodHandles.lookup().lookupClass()).a(230467291552426L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_an_9591fd88 ph(AbstractTexture abstractTexture) {
        this.nLhhg = abstractTexture;
        return this;
    }

    public AbstractTexture pf() {
        return this.nLhhg;
    }

    @Override
    protected void bV(Class_lC_5322e8cf class_lC_5322e8cf) {
        long l = hKMkO ^ 0x27F1A4909720L;
        String[] stringArray = Class_aj_95d0a719.oA();
        if (stringArray != null) {
            if (this.nLhhg == null) {
                return;
            }
            class_lC_5322e8cf.cee(this.nLhhg, this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ, this.ijNkN);
        }
    }

    public Class_an_9591fd88 pi(Class_ld_bb1690e1 class_ld_bb1690e1) {
        this.ijNkN = class_ld_bb1690e1;
        return this;
    }

    public Class_ld_bb1690e1 pg() {
        return this.ijNkN;
    }

    private static MatchException pj(MatchException matchException) {
        return matchException;
    }
}

