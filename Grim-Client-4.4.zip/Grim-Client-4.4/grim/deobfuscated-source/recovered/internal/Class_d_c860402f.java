/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_cC_14ef8bb5;
import recovered.internal.Class_cH_5b9db066;
import recovered.internal.Class_c_b33cdc52;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_im_0fce3469;
import recovered.internal.Class_mr_7eac5189;

public class Class_d_c860402f
extends Class_iS_888f260e {
    private final Class_cC_14ef8bb5 HGYzf;
    private final Class_cC_14ef8bb5 ilZdU;
    private final Class_cC_14ef8bb5 aLWhm;
    private final Class_cH_5b9db066 qlnHR;
    private final Class_cC_14ef8bb5 ZiKOl;
    private final Class_cC_14ef8bb5 mlyoA;
    private final Class_cC_14ef8bb5 zjzBx;
    private final Class_cH_5b9db066 CEstZ;
    private final Class_cC_14ef8bb5 ZTTTv;
    private final Class_cC_14ef8bb5 VjlZW;
    private final Class_cC_14ef8bb5 cImdk;
    private final Class_cH_5b9db066 bdkXX;
    private static long fgIwi;
    private static long[] rfkHr;
    private static Integer[] XjGFH;
    private static Map fdFbr;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_d_c860402f() {
        long l = fgIwi ^ 0x276151FEE8CFL;
        boolean bl = Class_c_b33cdc52.I();
        int[] nArray = new int[Class_d_c860402f.ai("c", (int)10521, (long)(0x62DF5FDF80B8E67AL ^ l))];
        nArray[0] = (int)Class_d_c860402f.ai("c", (int)20528, (long)(0x3450F1DFC5F79F76L ^ l));
        nArray[1] = (int)Class_d_c860402f.ai("c", (int)26044, (long)(0x6A790DB6853FAAD5L ^ l));
        nArray[2] = (int)Class_d_c860402f.ai("c", (int)30831, (long)(0x7DB324FD14A1B705L ^ l));
        nArray[3] = (int)Class_d_c860402f.ai("c", (int)2507, (long)(0x1B8872E56CFBC694L ^ l));
        nArray[4] = (int)Class_d_c860402f.ai("c", (int)11565, (long)(0x99DF3042776E241L ^ l));
        nArray[5] = (int)Class_d_c860402f.ai("c", (int)6490, (long)(0x490189AF2B52560CL ^ l));
        nArray[Class_d_c860402f.ai("c", (int)27891, (long)(0x1D0DD5B0826A3B6L ^ l))] = (int)Class_d_c860402f.ai("c", (int)29506, (long)(0x2E0CCB1C688B3C20L ^ l));
        nArray[Class_d_c860402f.ai("c", (int)26657, (long)(0x53A947F25303A740L ^ l))] = (int)Class_d_c860402f.ai("c", (int)28951, (long)(0x5825CE9D8827BE57L ^ l));
        nArray[Class_d_c860402f.ai("c", (int)12249, (long)(0x2E61B1A0C499E082L ^ l))] = (int)Class_d_c860402f.ai("c", (int)9458, (long)(0x7E4154775C56B8DL ^ l));
        nArray[Class_d_c860402f.ai("c", (int)11202, (long)(0x5B1E0B938A0DE486L ^ l))] = (int)Class_d_c860402f.ai("c", (int)30832, (long)(0xFF1A1042515B70BL ^ l));
        nArray[Class_d_c860402f.ai("c", (int)2725, (long)(0x1F97171E452AC5F4L ^ l))] = (int)Class_d_c860402f.ai("c", (int)7696, (long)(0x3D43BF7F9386517FL ^ l));
        nArray[Class_d_c860402f.ai("c", (int)10424, (long)(0x5D83C05071BC67CCL ^ l))] = (int)Class_d_c860402f.ai("c", (int)19704, (long)(0x16D4BCCC1B1C03B5L ^ l));
        nArray[Class_d_c860402f.ai("c", (int)8343, (long)(0x170E0FC2CCDEEFFCL ^ l))] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
        nArray[Class_d_c860402f.ai("c", (int)31588, (long)(0x47812D7C4DF6B416L ^ l))] = (int)Class_d_c860402f.ai("c", (int)12250, (long)(0x4F887FCE3A63E08DL ^ l));
        this.HGYzf = new Class_cC_14ef8bb5(Class_mr_7eac5189.clS(nArray)).Vy(0.01f).Vw(-5.0).Vx(5.0).VA(0.0);
        boolean bl2 = bl;
        try {
            int[] nArray2 = new int[Class_d_c860402f.ai("c", (int)8329, (long)(0x29C4F610E729EFFEL ^ l))];
            nArray2[0] = (int)Class_d_c860402f.ai("c", (int)4078, (long)(0x6FB5B44D5303C09DL ^ l));
            nArray2[1] = (int)Class_d_c860402f.ai("c", (int)1444, (long)(0x79E7C227427A4AD4L ^ l));
            nArray2[2] = (int)Class_d_c860402f.ai("c", (int)31460, (long)(0x6B8B136F719135A7L ^ l));
            nArray2[3] = (int)Class_d_c860402f.ai("c", (int)28951, (long)(0x5825CE9D8827BE57L ^ l));
            nArray2[4] = (int)Class_d_c860402f.ai("c", (int)8629, (long)(0x4DCB076045C9EEFFL ^ l));
            nArray2[5] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray2[Class_d_c860402f.ai("c", (int)28638, (long)(0x57820757E687A0BBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)31111, (long)(0x12640E08D47436E9L ^ l));
            nArray2[Class_d_c860402f.ai("c", (int)19901, (long)(0x77B5EA3E2FC082CBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)28951, (long)(0x5825CE9D8827BE57L ^ l));
            nArray2[Class_d_c860402f.ai("c", (int)12348, (long)(0x1E6F3E766EBB7F62L ^ l))] = (int)Class_d_c860402f.ai("c", (int)30873, (long)(0x330F2875F4CFB7F9L ^ l));
            nArray2[Class_d_c860402f.ai("c", (int)1203, (long)(0x288BE6D4E3E9CBF1L ^ l))] = (int)Class_d_c860402f.ai("c", (int)20136, (long)(0x522C0E2A7D6601CEL ^ l));
            nArray2[Class_d_c860402f.ai("c", (int)597, (long)(0x4F6BAF8D976ECD0DL ^ l))] = (int)Class_d_c860402f.ai("c", (int)20097, (long)(0x3C44EEBE58EF81FBL ^ l));
            nArray2[Class_d_c860402f.ai("c", (int)10120, (long)(0xA2FF852868E8F6L ^ l))] = (int)Class_d_c860402f.ai("c", (int)1720, (long)(0x4FEA5FDBE3F549C5L ^ l));
            nArray2[Class_d_c860402f.ai("c", (int)19286, (long)(0x2876B6524FC9841AL ^ l))] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray2[Class_d_c860402f.ai("c", (int)8231, (long)(0x5FFD5238562A6F72L ^ l))] = (int)Class_d_c860402f.ai("c", (int)22332, (long)(0x25B80A57B5C89849L ^ l));
            this.ilZdU = new Class_cC_14ef8bb5(Class_mr_7eac5189.clS(nArray2)).Vy(0.01f).Vw(-5.0).Vx(5.0).VA(0.0);
            int[] nArray3 = new int[Class_d_c860402f.ai("c", (int)8329, (long)(0x29C4F610E729EFFEL ^ l))];
            nArray3[0] = (int)Class_d_c860402f.ai("c", (int)4078, (long)(0x6FB5B44D5303C09DL ^ l));
            nArray3[1] = (int)Class_d_c860402f.ai("c", (int)1444, (long)(0x79E7C227427A4AD4L ^ l));
            nArray3[2] = (int)Class_d_c860402f.ai("c", (int)31460, (long)(0x6B8B136F719135A7L ^ l));
            nArray3[3] = (int)Class_d_c860402f.ai("c", (int)28951, (long)(0x5825CE9D8827BE57L ^ l));
            nArray3[4] = (int)Class_d_c860402f.ai("c", (int)8629, (long)(0x4DCB076045C9EEFFL ^ l));
            nArray3[5] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray3[Class_d_c860402f.ai("c", (int)28638, (long)(0x57820757E687A0BBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)31111, (long)(0x12640E08D47436E9L ^ l));
            nArray3[Class_d_c860402f.ai("c", (int)19901, (long)(0x77B5EA3E2FC082CBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)28951, (long)(0x5825CE9D8827BE57L ^ l));
            nArray3[Class_d_c860402f.ai("c", (int)12348, (long)(0x1E6F3E766EBB7F62L ^ l))] = (int)Class_d_c860402f.ai("c", (int)30873, (long)(0x330F2875F4CFB7F9L ^ l));
            nArray3[Class_d_c860402f.ai("c", (int)1203, (long)(0x288BE6D4E3E9CBF1L ^ l))] = (int)Class_d_c860402f.ai("c", (int)20136, (long)(0x522C0E2A7D6601CEL ^ l));
            nArray3[Class_d_c860402f.ai("c", (int)597, (long)(0x4F6BAF8D976ECD0DL ^ l))] = (int)Class_d_c860402f.ai("c", (int)20097, (long)(0x3C44EEBE58EF81FBL ^ l));
            nArray3[Class_d_c860402f.ai("c", (int)10120, (long)(0xA2FF852868E8F6L ^ l))] = (int)Class_d_c860402f.ai("c", (int)1720, (long)(0x4FEA5FDBE3F549C5L ^ l));
            nArray3[Class_d_c860402f.ai("c", (int)19286, (long)(0x2876B6524FC9841AL ^ l))] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray3[Class_d_c860402f.ai("c", (int)8231, (long)(0x5FFD5238562A6F72L ^ l))] = (int)Class_d_c860402f.ai("c", (int)13708, (long)(0x7AD3BBFA1D9BFAE1L ^ l));
            this.aLWhm = new Class_cC_14ef8bb5(Class_mr_7eac5189.clS(nArray3)).Vy(0.01f).Vw(-5.0).Vx(5.0).VA(0.0);
            int[] nArray4 = new int[Class_d_c860402f.ai("c", (int)28638, (long)(0x57820757E687A0BBL ^ l))];
            nArray4[0] = (int)Class_d_c860402f.ai("c", (int)31111, (long)(0x12640E08D47436E9L ^ l));
            nArray4[1] = (int)Class_d_c860402f.ai("c", (int)28951, (long)(0x5825CE9D8827BE57L ^ l));
            nArray4[2] = (int)Class_d_c860402f.ai("c", (int)30873, (long)(0x330F2875F4CFB7F9L ^ l));
            nArray4[3] = (int)Class_d_c860402f.ai("c", (int)20136, (long)(0x522C0E2A7D6601CEL ^ l));
            nArray4[4] = (int)Class_d_c860402f.ai("c", (int)20097, (long)(0x3C44EEBE58EF81FBL ^ l));
            nArray4[5] = (int)Class_d_c860402f.ai("c", (int)1720, (long)(0x4FEA5FDBE3F549C5L ^ l));
            this.qlnHR = new Class_cH_5b9db066(this, Class_mr_7eac5189.clS(nArray4)).Wu(this.HGYzf, this.ilZdU, this.aLWhm);
            int[] nArray5 = new int[Class_d_c860402f.ai("c", (int)19286, (long)(0x2876B6524FC9841AL ^ l))];
            nArray5[0] = (int)Class_d_c860402f.ai("c", (int)4078, (long)(0x6FB5B44D5303C09DL ^ l));
            nArray5[1] = (int)Class_d_c860402f.ai("c", (int)1444, (long)(0x79E7C227427A4AD4L ^ l));
            nArray5[2] = (int)Class_d_c860402f.ai("c", (int)31460, (long)(0x6B8B136F719135A7L ^ l));
            nArray5[3] = (int)Class_d_c860402f.ai("c", (int)28951, (long)(0x5825CE9D8827BE57L ^ l));
            nArray5[4] = (int)Class_d_c860402f.ai("c", (int)8629, (long)(0x4DCB076045C9EEFFL ^ l));
            nArray5[5] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray5[Class_d_c860402f.ai("c", (int)28638, (long)(0x57820757E687A0BBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)27893, (long)(0x63E0871BBD3C238CL ^ l));
            nArray5[Class_d_c860402f.ai("c", (int)19901, (long)(0x77B5EA3E2FC082CBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)20097, (long)(0x3C44EEBE58EF81FBL ^ l));
            nArray5[Class_d_c860402f.ai("c", (int)12348, (long)(0x1E6F3E766EBB7F62L ^ l))] = (int)Class_d_c860402f.ai("c", (int)20080, (long)(0x3A1F02CF0218139L ^ l));
            nArray5[Class_d_c860402f.ai("c", (int)1203, (long)(0x288BE6D4E3E9CBF1L ^ l))] = (int)Class_d_c860402f.ai("c", (int)24003, (long)(0x2D3F0859D8D4928CL ^ l));
            nArray5[Class_d_c860402f.ai("c", (int)597, (long)(0x4F6BAF8D976ECD0DL ^ l))] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray5[Class_d_c860402f.ai("c", (int)10120, (long)(0xA2FF852868E8F6L ^ l))] = (int)Class_d_c860402f.ai("c", (int)17754, (long)(0x57F859329F0D8A26L ^ l));
            this.ZiKOl = new Class_cC_14ef8bb5(Class_mr_7eac5189.clS(nArray5)).Vy(0.01f).Vw(-5.0).Vx(5.0).VA(0.0);
            int[] nArray6 = new int[Class_d_c860402f.ai("c", (int)19286, (long)(0x2876B6524FC9841AL ^ l))];
            nArray6[0] = (int)Class_d_c860402f.ai("c", (int)4078, (long)(0x6FB5B44D5303C09DL ^ l));
            nArray6[1] = (int)Class_d_c860402f.ai("c", (int)1444, (long)(0x79E7C227427A4AD4L ^ l));
            nArray6[2] = (int)Class_d_c860402f.ai("c", (int)31460, (long)(0x6B8B136F719135A7L ^ l));
            nArray6[3] = (int)Class_d_c860402f.ai("c", (int)28951, (long)(0x5825CE9D8827BE57L ^ l));
            nArray6[4] = (int)Class_d_c860402f.ai("c", (int)8629, (long)(0x4DCB076045C9EEFFL ^ l));
            nArray6[5] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray6[Class_d_c860402f.ai("c", (int)28638, (long)(0x57820757E687A0BBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)5187, (long)(0x4FFA2BD0A2375B1EL ^ l));
            nArray6[Class_d_c860402f.ai("c", (int)19901, (long)(0x77B5EA3E2FC082CBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)20097, (long)(0x3C44EEBE58EF81FBL ^ l));
            nArray6[Class_d_c860402f.ai("c", (int)12348, (long)(0x1E6F3E766EBB7F62L ^ l))] = (int)Class_d_c860402f.ai("c", (int)15893, (long)(0x288AC2A601BD715DL ^ l));
            nArray6[Class_d_c860402f.ai("c", (int)1203, (long)(0x288BE6D4E3E9CBF1L ^ l))] = (int)Class_d_c860402f.ai("c", (int)30335, (long)(0x10BB679D19D43934L ^ l));
            nArray6[Class_d_c860402f.ai("c", (int)597, (long)(0x4F6BAF8D976ECD0DL ^ l))] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray6[Class_d_c860402f.ai("c", (int)10120, (long)(0xA2FF852868E8F6L ^ l))] = (int)Class_d_c860402f.ai("c", (int)4990, (long)(0x1F6E329D060ADC27L ^ l));
            this.mlyoA = new Class_cC_14ef8bb5(Class_mr_7eac5189.clS(nArray6)).Vy(0.01f).Vw(-5.0).Vx(5.0).VA(0.0);
            int[] nArray7 = new int[Class_d_c860402f.ai("c", (int)19286, (long)(0x2876B6524FC9841AL ^ l))];
            nArray7[0] = (int)Class_d_c860402f.ai("c", (int)4078, (long)(0x6FB5B44D5303C09DL ^ l));
            nArray7[1] = (int)Class_d_c860402f.ai("c", (int)1444, (long)(0x79E7C227427A4AD4L ^ l));
            nArray7[2] = (int)Class_d_c860402f.ai("c", (int)31460, (long)(0x6B8B136F719135A7L ^ l));
            nArray7[3] = (int)Class_d_c860402f.ai("c", (int)28951, (long)(0x5825CE9D8827BE57L ^ l));
            nArray7[4] = (int)Class_d_c860402f.ai("c", (int)8629, (long)(0x4DCB076045C9EEFFL ^ l));
            nArray7[5] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray7[Class_d_c860402f.ai("c", (int)28638, (long)(0x57820757E687A0BBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)5187, (long)(0x4FFA2BD0A2375B1EL ^ l));
            nArray7[Class_d_c860402f.ai("c", (int)19901, (long)(0x77B5EA3E2FC082CBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)20097, (long)(0x3C44EEBE58EF81FBL ^ l));
            nArray7[Class_d_c860402f.ai("c", (int)12348, (long)(0x1E6F3E766EBB7F62L ^ l))] = (int)Class_d_c860402f.ai("c", (int)15893, (long)(0x288AC2A601BD715DL ^ l));
            nArray7[Class_d_c860402f.ai("c", (int)1203, (long)(0x288BE6D4E3E9CBF1L ^ l))] = (int)Class_d_c860402f.ai("c", (int)30335, (long)(0x10BB679D19D43934L ^ l));
            nArray7[Class_d_c860402f.ai("c", (int)597, (long)(0x4F6BAF8D976ECD0DL ^ l))] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray7[Class_d_c860402f.ai("c", (int)10120, (long)(0xA2FF852868E8F6L ^ l))] = (int)Class_d_c860402f.ai("c", (int)19365, (long)(0x1F0FC30D3DF504CDL ^ l));
            this.zjzBx = new Class_cC_14ef8bb5(Class_mr_7eac5189.clS(nArray7)).Vy(0.01f).Vw(-3.0).Vx(3.0).VA(0.0);
            int[] nArray8 = new int[Class_d_c860402f.ai("c", (int)28638, (long)(0x57820757E687A0BBL ^ l))];
            nArray8[0] = (int)Class_d_c860402f.ai("c", (int)30171, (long)(0x3BB7BAC92A24BA9AL ^ l));
            nArray8[1] = (int)Class_d_c860402f.ai("c", (int)14743, (long)(0x503DBFAA03BF6CBL ^ l));
            nArray8[2] = (int)Class_d_c860402f.ai("c", (int)29350, (long)(0x4348F21F27DDBDFCL ^ l));
            nArray8[3] = (int)Class_d_c860402f.ai("c", (int)31005, (long)(0x27D86B6937043653L ^ l));
            nArray8[4] = (int)Class_d_c860402f.ai("c", (int)30335, (long)(0x10BB679D19D43934L ^ l));
            nArray8[5] = (int)Class_d_c860402f.ai("c", (int)6973, (long)(0x7450A2F1FC63547AL ^ l));
            this.CEstZ = new Class_cH_5b9db066(this, Class_mr_7eac5189.clS(nArray8)).Wu(this.ZiKOl, this.mlyoA, this.zjzBx);
            int[] nArray9 = new int[Class_d_c860402f.ai("c", (int)8329, (long)(0x29C4F610E729EFFEL ^ l))];
            nArray9[0] = (int)Class_d_c860402f.ai("c", (int)4078, (long)(0x6FB5B44D5303C09DL ^ l));
            nArray9[1] = (int)Class_d_c860402f.ai("c", (int)1444, (long)(0x79E7C227427A4AD4L ^ l));
            nArray9[2] = (int)Class_d_c860402f.ai("c", (int)31460, (long)(0x6B8B136F719135A7L ^ l));
            nArray9[3] = (int)Class_d_c860402f.ai("c", (int)28951, (long)(0x5825CE9D8827BE57L ^ l));
            nArray9[4] = (int)Class_d_c860402f.ai("c", (int)8629, (long)(0x4DCB076045C9EEFFL ^ l));
            nArray9[5] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray9[Class_d_c860402f.ai("c", (int)28638, (long)(0x57820757E687A0BBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)9834, (long)(0x1304FC3AC3C693EL ^ l));
            nArray9[Class_d_c860402f.ai("c", (int)19901, (long)(0x77B5EA3E2FC082CBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)20097, (long)(0x3C44EEBE58EF81FBL ^ l));
            nArray9[Class_d_c860402f.ai("c", (int)12348, (long)(0x1E6F3E766EBB7F62L ^ l))] = (int)Class_d_c860402f.ai("c", (int)6787, (long)(0x3C4E1625835455E4L ^ l));
            nArray9[Class_d_c860402f.ai("c", (int)1203, (long)(0x288BE6D4E3E9CBF1L ^ l))] = (int)Class_d_c860402f.ai("c", (int)2433, (long)(0x276B7B6CDA8546E5L ^ l));
            nArray9[Class_d_c860402f.ai("c", (int)597, (long)(0x4F6BAF8D976ECD0DL ^ l))] = (int)Class_d_c860402f.ai("c", (int)6787, (long)(0x3C4E1625835455E4L ^ l));
            nArray9[Class_d_c860402f.ai("c", (int)10120, (long)(0xA2FF852868E8F6L ^ l))] = (int)Class_d_c860402f.ai("c", (int)30335, (long)(0x10BB679D19D43934L ^ l));
            nArray9[Class_d_c860402f.ai("c", (int)19286, (long)(0x2876B6524FC9841AL ^ l))] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray9[Class_d_c860402f.ai("c", (int)8231, (long)(0x5FFD5238562A6F72L ^ l))] = (int)Class_d_c860402f.ai("c", (int)17754, (long)(0x57F859329F0D8A26L ^ l));
            this.ZTTTv = new Class_cC_14ef8bb5(Class_mr_7eac5189.clS(nArray9)).Vy(5.0).Vw(-360.0).Vx(360.0).VA(0.0);
            int[] nArray10 = new int[Class_d_c860402f.ai("c", (int)8329, (long)(0x29C4F610E729EFFEL ^ l))];
            nArray10[0] = (int)Class_d_c860402f.ai("c", (int)4078, (long)(0x6FB5B44D5303C09DL ^ l));
            nArray10[1] = (int)Class_d_c860402f.ai("c", (int)1444, (long)(0x79E7C227427A4AD4L ^ l));
            nArray10[2] = (int)Class_d_c860402f.ai("c", (int)31460, (long)(0x6B8B136F719135A7L ^ l));
            nArray10[3] = (int)Class_d_c860402f.ai("c", (int)28951, (long)(0x5825CE9D8827BE57L ^ l));
            nArray10[4] = (int)Class_d_c860402f.ai("c", (int)8629, (long)(0x4DCB076045C9EEFFL ^ l));
            nArray10[5] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray10[Class_d_c860402f.ai("c", (int)28638, (long)(0x57820757E687A0BBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)31999, (long)(0x2A07A5E042ED3387L ^ l));
            nArray10[Class_d_c860402f.ai("c", (int)19901, (long)(0x77B5EA3E2FC082CBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)20097, (long)(0x3C44EEBE58EF81FBL ^ l));
            nArray10[Class_d_c860402f.ai("c", (int)12348, (long)(0x1E6F3E766EBB7F62L ^ l))] = (int)Class_d_c860402f.ai("c", (int)6787, (long)(0x3C4E1625835455E4L ^ l));
            nArray10[Class_d_c860402f.ai("c", (int)1203, (long)(0x288BE6D4E3E9CBF1L ^ l))] = (int)Class_d_c860402f.ai("c", (int)15709, (long)(0x559C1482EA7FF22CL ^ l));
            nArray10[Class_d_c860402f.ai("c", (int)597, (long)(0x4F6BAF8D976ECD0DL ^ l))] = (int)Class_d_c860402f.ai("c", (int)6787, (long)(0x3C4E1625835455E4L ^ l));
            nArray10[Class_d_c860402f.ai("c", (int)10120, (long)(0xA2FF852868E8F6L ^ l))] = (int)Class_d_c860402f.ai("c", (int)30335, (long)(0x10BB679D19D43934L ^ l));
            nArray10[Class_d_c860402f.ai("c", (int)19286, (long)(0x2876B6524FC9841AL ^ l))] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray10[Class_d_c860402f.ai("c", (int)8231, (long)(0x5FFD5238562A6F72L ^ l))] = (int)Class_d_c860402f.ai("c", (int)4990, (long)(0x1F6E329D060ADC27L ^ l));
            this.VjlZW = new Class_cC_14ef8bb5(Class_mr_7eac5189.clS(nArray10)).Vy(5.0).Vw(-360.0).Vx(360.0).VA(0.0);
            int[] nArray11 = new int[Class_d_c860402f.ai("c", (int)8329, (long)(0x29C4F610E729EFFEL ^ l))];
            nArray11[0] = (int)Class_d_c860402f.ai("c", (int)4078, (long)(0x6FB5B44D5303C09DL ^ l));
            nArray11[1] = (int)Class_d_c860402f.ai("c", (int)1444, (long)(0x79E7C227427A4AD4L ^ l));
            nArray11[2] = (int)Class_d_c860402f.ai("c", (int)31460, (long)(0x6B8B136F719135A7L ^ l));
            nArray11[3] = (int)Class_d_c860402f.ai("c", (int)28951, (long)(0x5825CE9D8827BE57L ^ l));
            nArray11[4] = (int)Class_d_c860402f.ai("c", (int)8629, (long)(0x4DCB076045C9EEFFL ^ l));
            nArray11[5] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray11[Class_d_c860402f.ai("c", (int)28638, (long)(0x57820757E687A0BBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)31999, (long)(0x2A07A5E042ED3387L ^ l));
            nArray11[Class_d_c860402f.ai("c", (int)19901, (long)(0x77B5EA3E2FC082CBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)20097, (long)(0x3C44EEBE58EF81FBL ^ l));
            nArray11[Class_d_c860402f.ai("c", (int)12348, (long)(0x1E6F3E766EBB7F62L ^ l))] = (int)Class_d_c860402f.ai("c", (int)6787, (long)(0x3C4E1625835455E4L ^ l));
            nArray11[Class_d_c860402f.ai("c", (int)1203, (long)(0x288BE6D4E3E9CBF1L ^ l))] = (int)Class_d_c860402f.ai("c", (int)15709, (long)(0x559C1482EA7FF22CL ^ l));
            nArray11[Class_d_c860402f.ai("c", (int)597, (long)(0x4F6BAF8D976ECD0DL ^ l))] = (int)Class_d_c860402f.ai("c", (int)6787, (long)(0x3C4E1625835455E4L ^ l));
            nArray11[Class_d_c860402f.ai("c", (int)10120, (long)(0xA2FF852868E8F6L ^ l))] = (int)Class_d_c860402f.ai("c", (int)30335, (long)(0x10BB679D19D43934L ^ l));
            nArray11[Class_d_c860402f.ai("c", (int)19286, (long)(0x2876B6524FC9841AL ^ l))] = (int)Class_d_c860402f.ai("c", (int)14899, (long)(0x3C03356EDD71F563L ^ l));
            nArray11[Class_d_c860402f.ai("c", (int)8231, (long)(0x5FFD5238562A6F72L ^ l))] = (int)Class_d_c860402f.ai("c", (int)19365, (long)(0x1F0FC30D3DF504CDL ^ l));
            this.cImdk = new Class_cC_14ef8bb5(Class_mr_7eac5189.clS(nArray11)).Vy(5.0).Vw(-360.0).Vx(360.0).VA(0.0);
            int[] nArray12 = new int[Class_d_c860402f.ai("c", (int)12348, (long)(0x1E6F3E766EBB7F62L ^ l))];
            nArray12[0] = (int)Class_d_c860402f.ai("c", (int)31999, (long)(0x2A07A5E042ED3387L ^ l));
            nArray12[1] = (int)Class_d_c860402f.ai("c", (int)20097, (long)(0x3C44EEBE58EF81FBL ^ l));
            nArray12[2] = (int)Class_d_c860402f.ai("c", (int)6787, (long)(0x3C4E1625835455E4L ^ l));
            nArray12[3] = (int)Class_d_c860402f.ai("c", (int)15709, (long)(0x559C1482EA7FF22CL ^ l));
            nArray12[4] = (int)Class_d_c860402f.ai("c", (int)6787, (long)(0x3C4E1625835455E4L ^ l));
            nArray12[5] = (int)Class_d_c860402f.ai("c", (int)31460, (long)(0x6B8B136F719135A7L ^ l));
            nArray12[Class_d_c860402f.ai("c", (int)28638, (long)(0x57820757E687A0BBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)20097, (long)(0x3C44EEBE58EF81FBL ^ l));
            nArray12[Class_d_c860402f.ai("c", (int)19901, (long)(0x77B5EA3E2FC082CBL ^ l))] = (int)Class_d_c860402f.ai("c", (int)28951, (long)(0x5825CE9D8827BE57L ^ l));
            this.bdkXX = new Class_cH_5b9db066(this, Class_mr_7eac5189.clS(nArray12)).Wu(this.ZTTTv, this.VjlZW, this.cImdk);
            if (!bl2) {
                Class_iS_888f260e.bwK("hLdgC");
            }
        }
        catch (MatchException matchException) {
            throw Class_d_c860402f.af(matchException);
        }
    }

    static {
        NativeLoader.doInit(Class_d_c860402f.class);
        Class_d_c860402f._365c9537c0a9353d1e26f03d16447cfb();
    }

    public native Class_im_0fce3469 S();

    public native Class_cC_14ef8bb5 Z();

    public native Class_cC_14ef8bb5 V();

    public native Class_cC_14ef8bb5 ad();

    public native Class_cH_5b9db066 ae();

    public native Class_cC_14ef8bb5 U();

    private static native MatchException af(MatchException var0);

    public native Class_cC_14ef8bb5 Y();

    public native Class_cC_14ef8bb5 X();

    public native Class_cC_14ef8bb5 ac();

    public native Class_cH_5b9db066 W();

    public native Class_cC_14ef8bb5 T();

    public native void R(Class_im_0fce3469 var1);

    private static native CallSite ai(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native Class_cC_14ef8bb5 ab();

    public native Class_cH_5b9db066 aa();

    private static native int ah(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native int ag(int var0, long var1);

    private static native void _365c9537c0a9353d1e26f03d16447cfb();
}

