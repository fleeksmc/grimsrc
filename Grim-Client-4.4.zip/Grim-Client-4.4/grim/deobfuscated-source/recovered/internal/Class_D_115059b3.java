/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import net.minecraft.util.math.Vec2f;
import recovered.core.NativeLoader;
import recovered.internal.Class_ak_2ff604c7;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_cL_ccb21d14;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_D_115059b3
extends Class_ak_2ff604c7<Class_cL_ccb21d14> {
    private static float wROpY = 14.0f;
    private final Class_rk_bf8630d1 eRMSo;
    private final Class_rk_bf8630d1 CpJYd;
    private final Class_rk_bf8630d1 WlUSf;
    private final Class_rk_bf8630d1 gOcCu;
    private final Class_rk_bf8630d1 doXNy;
    private final Class_rk_bf8630d1 iYaup;
    private boolean QNUBB;
    private boolean kIOqP;
    private static long VGdtl;
    private static long[] WiuaB;
    private static Integer[] fyVLy;
    private static Map IzEFY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_D_115059b3(Class_cL_ccb21d14 class_cL_ccb21d14, Class_az_a4990dcf class_az_a4990dcf) {
        long l = VGdtl ^ 0x6A18AACCB97CL;
        super(class_cL_ccb21d14, class_az_a4990dcf);
        this.eRMSo = new Class_rk_bf8630d1((int)Class_D_115059b3.fA("e", (int)18108, (long)(0x1F2DBD1A2D9C6C91L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.CpJYd = new Class_rk_bf8630d1((int)Class_D_115059b3.fA("e", (int)3137, (long)(0x3F0E25AA0BCF266DL ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.WlUSf = new Class_rk_bf8630d1((int)Class_D_115059b3.fA("e", (int)3137, (long)(0x3F0E25AA0BCF266DL ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.gOcCu = new Class_rk_bf8630d1((int)Class_D_115059b3.fA("e", (int)3137, (long)(0x3F0E25AA0BCF266DL ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.doXNy = new Class_rk_bf8630d1((int)Class_D_115059b3.fA("e", (int)27623, (long)(0x2365CC8BE22DC1C8L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.iYaup = new Class_rk_bf8630d1((int)Class_D_115059b3.fA("e", (int)5202, (long)(0x19AC0329A62BE7CL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.eRMSo.dhe(class_cL_ccb21d14.Xt().x);
        this.CpJYd.dhe(class_cL_ccb21d14.Xt().y);
        this.WlUSf.dhe(class_cL_ccb21d14.Xu().x);
        this.gOcCu.dhe(class_cL_ccb21d14.Xu().y);
    }

    static {
        NativeLoader.doInit(Class_D_115059b3.class);
        Class_D_115059b3._9cd2f71414855ceb2d07a0f8decaf2e6();
    }

    private native void fp(Class_lC_5322e8cf var1, float var2, float var3, float var4);

    @Override
    public native float dn();

    private native float fw(Class_rk_bf8630d1 var1, float var2, boolean var3);

    private native float ft(float var1, float var2, float var3, float var4, float var5);

    private native float fv(float var1, float var2, float var3, float var4);

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    private native Vec2f fs(float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private native Vec2f fr(Class_lC_5322e8cf var1, float var2, float var3, float var4, float var5, float var6, float var7);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private static native CallSite fA(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native int fz(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    @Override
    public native boolean dB(double var1, double var3, Class_mA_32d8a5f2 var5, double var6, double var8);

    private native void fq(Class_lC_5322e8cf var1, float var2, float var3, float var4, float var5, float var6, float var7);

    private static native int fy(int var0, long var1);

    private native float fu(float var1, float var2, float var3, float var4, float var5);

    private static native MatchException fx(MatchException var0);

    private static native void _9cd2f71414855ceb2d07a0f8decaf2e6();
}

