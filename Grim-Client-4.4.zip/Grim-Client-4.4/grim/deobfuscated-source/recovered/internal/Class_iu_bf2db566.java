/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package recovered.internal;

import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import recovered.core.NativeLoader;
import recovered.internal.Class_iO_e7bfa49a;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_iy_c88c0f4f;
import recovered.internal.Class_rp_2e61368f;

public class Class_iu_bf2db566
implements Class_rp_2e61368f {
    private String WuTCb;
    private String gfSDY;
    private String mEXOF;
    private String VGCuV;
    private String tQHDh;
    private List<String> uozsm;
    private List<String> pjvIl;
    private List<String> vPrne;
    private List<String> AxOms;
    private List<String> GtoZc;
    private List<String> ouiSY;
    private List<String> wDcOh;
    private List<String> ClTFw;
    private List<String> FBtIM;
    private List<String> KpRyc;
    private List<String> PrsMv;
    private static boolean aGtbS;
    private static long rbToX;
    private static String[] EvhNi;
    private static String[] bjFbF;
    private static Map JOgCf;
    private static long[] PkoJk;
    private static Integer[] clbro;
    private static Map QKrcf;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public native List<String> bmW();

    public native String bmR();

    public native List<String> bne();

    public native List<String> bnf();

    public native List<String> bmV();

    public native List<String> bmX();

    private static native int bnF(int var0, long var1);

    public native List<String> bna();

    public native Class_iu_bf2db566 bnm(List<String> var1);

    private static native String bnC(int var0, long var1);

    public native Class_iu_bf2db566 bnp(List<String> var1);

    public native Class_iu_bf2db566 bnk(String var1);

    public static native boolean bny();

    public native List<String> bmZ();

    public static native boolean bnz();

    public native Optional<Class_ig_ca326427> bmO();

    private static native MatchException bnA(MatchException var0);

    public native Class_iu_bf2db566 bni(String var1);

    public native Class_iu_bf2db566 bnu(List<String> var1);

    public native Optional<Class_iO_e7bfa49a> bmN();

    public native Class_iu_bf2db566 bnl(List<String> var1);

    private static native String bnB(byte[] var0);

    public native List<String> bnb();

    public native Class_iu_bf2db566 bnh(String var1);

    public native Class_iu_bf2db566 bns(List<String> var1);

    private static native Object bnD(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite bnE(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native int bnG(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public native Class_iu_bf2db566 bnj(String var1);

    public native List<String> bnc();

    public native String bmS();

    public native String bmT();

    public native String bmU();

    public native List<String> bmY();

    public native List<String> bnd();

    public native Class_iu_bf2db566 bno(List<String> var1);

    public native Class_iu_bf2db566 bng(String var1);

    public native Class_iu_bf2db566 bnq(List<String> var1);

    public native String bmQ();

    public native Class_iu_bf2db566 bnr(List<String> var1);

    public native Class_iu_bf2db566 bnt(List<String> var1);

    public native Class_iu_bf2db566 bnv(List<String> var1);

    protected native boolean bnw(Object var1);

    public static native void bnx(boolean var0);

    private static native CallSite bnH(MethodHandles.Lookup var0, String var1, MethodType var2);

    static {
        NativeLoader.doInit(Class_iu_bf2db566.class);
        Class_iu_bf2db566._36df3eeca17650f7448f0d948480f6a5();
    }

    public native boolean equals(Object var1);

    public native String toString();

    public native int hashCode();

    public native Class_iu_bf2db566 bnn(List<String> var1);

    @Override
    public native void fromJson(JsonObject var1);

    @Override
    public native JsonObject toJson();

    private static native void _36df3eeca17650f7448f0d948480f6a5();

    public native Optional<Class_iy_c88c0f4f> bmP();
}

