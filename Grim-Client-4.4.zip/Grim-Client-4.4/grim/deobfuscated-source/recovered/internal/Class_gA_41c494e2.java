/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.input.KeyInput
 *  net.minecraft.client.input.MouseInput
 */
package recovered.internal;

import net.minecraft.client.input.KeyInput;
import net.minecraft.client.input.MouseInput;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gA_41c494e2
extends Class_hH_ae8f8f77 {
    private MouseInput cfYNO;
    private KeyInput mcpAc;
    private int eZWeT;
    private int BZQxa;
    private int nctbO;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gA_41c494e2(MouseInput mouseInput, KeyInput keyInput, int n, int n2, int n3) {
        this.cfYNO = mouseInput;
        this.mcpAc = keyInput;
        this.eZWeT = n;
        this.BZQxa = n2;
        this.nctbO = n3;
    }

    public MouseInput bbN() {
        return this.cfYNO;
    }

    public KeyInput bbO() {
        return this.mcpAc;
    }

    public int bbR() {
        return this.nctbO;
    }

    public int bbQ() {
        return this.BZQxa;
    }

    public int bbP() {
        return this.eZWeT;
    }
}

