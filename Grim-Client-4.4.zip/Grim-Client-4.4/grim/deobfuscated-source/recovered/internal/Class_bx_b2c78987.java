/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_aA_8076b584;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mG_52c8d386;

public class Class_bx_b2c78987
extends Class_aA_8076b584 {
    private Class_mG_52c8d386 gJoVo = Class_mG_52c8d386.UhgnI;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bx_b2c78987() {
        this.BcpIo = 20.0f;
        this.WjISQ = 20.0f;
        this.tI(false);
    }

    static {
        NativeLoader.doInit(Class_bx_b2c78987.class);
    }

    public native Class_mG_52c8d386 IT();

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    public native Class_bx_b2c78987 IS(Class_mG_52c8d386 var1);
}

