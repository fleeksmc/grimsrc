/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.joml.Matrix4f
 */
package recovered.internal;

import org.joml.Matrix4f;

public final class Class_jK_8ad0bed0 {
    public static final float qAijK = 0.05f;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public static Matrix4f bIF(float f, float f2, float f3) {
        return new Matrix4f().setPerspective((float)Math.toRadians(f), f2, 0.05f, f3);
    }
}

