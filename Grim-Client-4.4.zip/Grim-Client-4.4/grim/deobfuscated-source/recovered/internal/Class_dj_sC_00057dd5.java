/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;

final class Class_dj_sC_00057dd5
extends Enum<Class_dj_sC_00057dd5> {
    public static final /* enum */ Class_dj_sC_00057dd5 iiJny;
    public static final /* enum */ Class_dj_sC_00057dd5 XksfN;
    public static final /* enum */ Class_dj_sC_00057dd5 vzSwM;
    public static final /* enum */ Class_dj_sC_00057dd5 WdDaI;
    private static final Class_dj_sC_00057dd5[] nRxbT;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                var9 = Class_gb_9d201141.aYR(651909763914831484L, 803236130106764977L, MethodHandles.lookup().lookupClass()).a(216211222552836L) ^ 67702014275273L;
                var1_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var9 >>> 56);
                for (var2_2 = 1; var2_2 < 8; ++var2_2) {
                    v2 = v2;
                    v2[var2_2] = (byte)(var9 << var2_2 * 8 >>> 56);
                }
                var1_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var0_3 = new String[4];
                var6_4 = 0;
                var5_5 = "\u00104\u0019\u00f9 \u00d0PS\b\u0018\u008f\u00b8\u00dcM\"\u00f5\u00f0";
                var7_6 = "\u00104\u0019\u00f9 \u00d0PS\b\u0018\u008f\u00b8\u00dcM\"\u00f5\u00f0".length();
                var4_7 = 8;
                var3_8 = -1;
lbl18:
                // 2 sources

                while (true) {
                    v3 = ++var3_8;
                    v4 = var5_5.substring(v3, v3 + var4_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl23:
                // 1 sources

                while (true) {
                    var0_3[var6_4++] = Class_dj_sC_00057dd5.doG(var8_9).intern();
                    if ((var3_8 += var4_7) < var7_6) {
                        var4_7 = var5_5.charAt(var3_8);
                        ** continue;
                    }
                    var5_5 = "`\f\f\u00d5\u00a2\\\u00b8+\u00da\u001am_\u0007\u000bju\b\u000f\u00c9\u00f5i\u0082\u00bf\u0018\"";
                    var7_6 = "`\f\f\u00d5\u00a2\\\u00b8+\u00da\u001am_\u0007\u000bju\b\u000f\u00c9\u00f5i\u0082\u00bf\u0018\"".length();
                    var4_7 = 16;
                    var3_8 = -1;
lbl32:
                    // 2 sources

                    while (true) {
                        v6 = ++var3_8;
                        v4 = var5_5.substring(v6, v6 + var4_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl37:
                // 1 sources

                while (true) {
                    var0_3[var6_4++] = Class_dj_sC_00057dd5.doG(var8_9).intern();
                    if ((var3_8 += var4_7) < var7_6) {
                        var4_7 = var5_5.charAt(var3_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var8_9 = var1_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl49:
                // 1 sources

                ** continue;
            }
        }
        Class_dj_sC_00057dd5.iiJny = new Class_dj_sC_00057dd5();
        Class_dj_sC_00057dd5.XksfN = new Class_dj_sC_00057dd5();
        Class_dj_sC_00057dd5.vzSwM = new Class_dj_sC_00057dd5();
        Class_dj_sC_00057dd5.WdDaI = new Class_dj_sC_00057dd5();
        Class_dj_sC_00057dd5.nRxbT = Class_dj_sC_00057dd5.doF();
    }

    public static Class_dj_sC_00057dd5[] values() {
        return (Class_dj_sC_00057dd5[])nRxbT.clone();
    }

    public static Class_dj_sC_00057dd5 valueOf(String string) {
        return Enum.valueOf(Class_dj_sC_00057dd5.class, string);
    }

    private static Class_dj_sC_00057dd5[] doF() {
        return new Class_dj_sC_00057dd5[]{iiJny, XksfN, vzSwM, WdDaI};
    }

    private static String doG(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }
}

