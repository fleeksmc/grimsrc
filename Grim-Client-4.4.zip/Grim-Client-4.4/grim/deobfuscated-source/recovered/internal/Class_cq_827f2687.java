/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screen.ChatScreen
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.client.gui.screen.ChatScreen;
import recovered.core.ClientMain;
import recovered.core.NativeLoader;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_ap_f3b7a87f;
import recovered.internal.Class_bU_714b1dad;
import recovered.internal.Class_bX_66e572fb;
import recovered.internal.Class_bY_d6d3ef36;
import recovered.internal.Class_cb_d55bce0b;
import recovered.internal.Class_ci_cdd1c45c;
import recovered.internal.Class_cm_25af7b08;
import recovered.internal.Class_cr_3ba4ae18;
import recovered.internal.Class_gk_d35e15dd;
import recovered.internal.Class_hA_4f0c4656;
import recovered.internal.Class_hC_bfce1e55;
import recovered.internal.Class_hD_08709cfc;
import recovered.internal.Class_hE_c0b4b57e;
import recovered.internal.Class_hF_7bd1921e;
import recovered.internal.Class_hG_d70cdb00;
import recovered.internal.Class_hx_d641fb49;
import recovered.internal.Class_hy_a98e9ba6;
import recovered.internal.Class_hz_5cba7134;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_lA_428877cb;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mw_6a6543f5;

public class Class_cq_827f2687
implements Class_lA_428877cb {
    private final List<Class_cr_3ba4ae18> vzihI = new ArrayList<Class_cr_3ba4ae18>();
    private final List<Class_ap_f3b7a87f> QcobS = new ArrayList<Class_ap_f3b7a87f>();
    private final List<Class_aj_95d0a719> awKdp = new ArrayList<Class_aj_95d0a719>();
    private final Class_cm_25af7b08 uSTRJ = new Class_cm_25af7b08();
    private Class_bU_714b1dad WYTsE;
    private Class_bY_d6d3ef36 EWerh;
    private Class_bX_66e572fb FUAur;
    private static long eLNhX;
    private static String[] uVCNi;
    private static String[] ERnPb;
    private static Map orwtF;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cq_827f2687() {
        Class_hF_7bd1921e.bdI(this);
    }

    static {
        NativeLoader.doInit(Class_cq_827f2687.class);
        Class_cq_827f2687._c98c0cbfc2ed8848e8b9749fe985ab6c();
    }

    public native Class_cm_25af7b08 RB();

    public native void Rs(Class_ap_f3b7a87f var1);

    private static native /* synthetic */ boolean RG(Class_cr_3ba4ae18 var0);

    private static native /* synthetic */ boolean RF(Class_cr_3ba4ae18 var0);

    public native void Rx();

    public List<Class_cr_3ba4ae18> Rv() {
        return this.vzihI.stream().filter(Class_cq_827f2687::RG).toList();
    }

    public native List<Class_aj_95d0a719> RA();

    private static native String RJ(byte[] var0);

    private static native String RK(int var0, long var1);

    private static native CallSite RM(MethodHandles.Lookup var0, String var1, MethodType var2);

    /*
     * Unable to fully structure code
     */
    @Class_hG_d70cdb00(priority=Class_mw_6a6543f5.LOWEST)
    public void Rk(Class_gk_d35e15dd var1_1) {
        block63: {
            block62: {
                block60: {
                    var2_2 = Class_cq_827f2687.eLNhX ^ 128337433618904L;
                    var5_3 = var1_1.baT();
                    this.uSTRJ.QN(var5_3);
                    v0 = Class_cr_3ba4ae18.SC();
                    this.uSTRJ.QO();
                    var6_4 = var5_3.cfe();
                    var4_5 = v0;
                    var7_6 = this.vzihI.iterator();
                    while (var7_6.hasNext()) {
                        block58: {
                            block59: {
                                block56: {
                                    block57: {
                                        block54: {
                                            block55: {
                                                block64: {
                                                    block53: {
                                                        block52: {
                                                            block51: {
                                                                block49: {
                                                                    block50: {
                                                                        var8_7 = var7_6.next();
                                                                        try {
                                                                            try {
                                                                                try {
                                                                                    var8_7.Ph(var5_3);
                                                                                    v1 = var8_7 instanceof Class_ci_cdd1c45c;
                                                                                    if (var4_5 != null) {
                                                                                        if (var4_5 == null) break block49;
                                                                                    }
                                                                                    ** GOTO lbl124
                                                                                }
                                                                                catch (MatchException v2) {
                                                                                    throw Class_cq_827f2687.RI(v2);
                                                                                }
                                                                                if (!v1) break block50;
                                                                            }
                                                                            catch (MatchException v3) {
                                                                                throw Class_cq_827f2687.RI(v3);
                                                                            }
                                                                            if (var4_5 != null) continue;
                                                                        }
                                                                        catch (MatchException v4) {
                                                                            throw Class_cq_827f2687.RI(v4);
                                                                        }
                                                                    }
                                                                    try {
                                                                        v5 = var8_7.OsbYH.dhj();
                                                                        if (var4_5 == null) break block51;
                                                                        cfr_temp_0 = v5 - 0.0f;
                                                                        v6 = cfr_temp_0 == 0.0f ? 0 : (cfr_temp_0 > 0.0f ? 1 : -1);
                                                                    }
                                                                    catch (MatchException v7) {
                                                                        throw Class_cq_827f2687.RI(v7);
                                                                    }
                                                                }
                                                                try {
                                                                    if (v6 == false && var4_5 != null) continue;
                                                                }
                                                                catch (MatchException v8) {
                                                                    throw Class_cq_827f2687.RI(v8);
                                                                }
                                                                v5 = var8_7.OsbYH.dhj();
                                                            }
                                                            var9_8 = v5;
                                                            var10_9 = var8_7.ormBS.dhj() * var8_7.KgDVz.dhj();
                                                            try {
                                                                try {
                                                                    v9 = var8_7;
                                                                    if (var4_5 == null) break block52;
                                                                    if (!(v9 instanceof Class_cb_d55bce0b)) break block53;
                                                                }
                                                                catch (MatchException v10) {
                                                                    throw Class_cq_827f2687.RI(v10);
                                                                }
                                                                v9 = var8_7;
                                                            }
                                                            catch (MatchException v11) {
                                                                throw Class_cq_827f2687.RI(v11);
                                                            }
                                                        }
                                                        var12_12 = (Class_cb_d55bce0b)v9;
                                                        var11_10 = var12_12.Pi();
                                                        if (var4_5 != null) break block64;
                                                    }
                                                    var11_10 = 0.5f + var10_9 * 0.5f - 0.05f * var9_8;
                                                }
                                                try {
                                                    try {
                                                        var8_7.AyAnj.dhd(1.0f);
                                                        v12 = var8_7.AyAnj.dhj();
                                                        if (var4_5 == null) break block54;
                                                        if (v12 != 1.0f) break block55;
                                                    }
                                                    catch (MatchException v13) {
                                                        throw Class_cq_827f2687.RI(v13);
                                                    }
                                                    var8_7.AyAnj.dhg();
                                                }
                                                catch (MatchException v14) {
                                                    throw Class_cq_827f2687.RI(v14);
                                                }
                                            }
                                            v12 = var8_7.RT();
                                        }
                                        var12_11 = v12;
                                        try {
                                            try {
                                                Class_jH_c1172273.bIe(var6_4.getMatrices(), var8_7.toIeR + var8_7.RU() / 2.0f, var8_7.QWaAn + var8_7.RV() / 2.0f, var11_10);
                                                v15 = var12_11;
                                                v16 = 1.0f;
                                                if (var4_5 == null) break block56;
                                                if (v15 == v16) break block57;
                                            }
                                            catch (MatchException v17) {
                                                throw Class_cq_827f2687.RI(v17);
                                            }
                                            Class_jH_c1172273.bIe(var6_4.getMatrices(), var8_7.toIeR, var8_7.QWaAn, var12_11);
                                        }
                                        catch (MatchException v18) {
                                            throw Class_cq_827f2687.RI(v18);
                                        }
                                    }
                                    v15 = var8_7.AyAnj.dhj() * 2.2f;
                                    v16 = 0.5f;
                                }
                                var13_13 = v15 - v16;
                                try {
                                    try {
                                        var5_3.ceh(var8_7.toIeR, var8_7.QWaAn, var8_7.jTsqG, var8_7.Xtjvx, Class_mG_52c8d386.hoGuU.coa(100.0f * var9_8), var13_13, 7.0f, Class_ld_bb1690e1.all(7.0f));
                                        if (var4_5 == null) break block58;
                                        if (var12_11 == 1.0f) break block59;
                                    }
                                    catch (MatchException v19) {
                                        throw Class_cq_827f2687.RI(v19);
                                    }
                                    Class_jH_c1172273.bIf();
                                }
                                catch (MatchException v20) {
                                    throw Class_cq_827f2687.RI(v20);
                                }
                            }
                            Class_jH_c1172273.bIf();
                        }
                        if (var4_5 != null) continue;
                    }
                    var7_6 = this.QcobS.iterator();
                    do lbl-1000:
                    // 3 sources

                    {
                        block61: {
                            v1 = var7_6.hasNext();
lbl124:
                            // 2 sources

                            if (!v1) break;
                            var8_7 = (Class_ap_f3b7a87f)var7_6.next();
                            try {
                                try {
                                    try {
                                        if (var4_5 == null) continue;
                                        v21 = ClientMain.dlmvG.currentScreen instanceof ChatScreen;
                                        if (var4_5 == null) break block60;
                                    }
                                    catch (MatchException v22) {
                                        throw Class_cq_827f2687.RI(v22);
                                    }
                                    if (!v21) break block61;
                                }
                                catch (MatchException v23) {
                                    throw Class_cq_827f2687.RI(v23);
                                }
                                if (var4_5 != null) ** GOTO lbl-1000
                            }
                            catch (MatchException v24) {
                                throw Class_cq_827f2687.RI(v24);
                            }
                        }
                        var8_7.oj(false);
                    } while (var4_5 != null);
                    this.QcobS.removeIf((Predicate<Class_ap_f3b7a87f>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, oi(), (Lrecovered/internal/Class_ap_f3b7a87f;)Z)());
                    v21 = this.awKdp.removeIf((Predicate<Class_aj_95d0a719>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, oi(), (Lrecovered/internal/Class_aj_95d0a719;)Z)());
                }
                var5_3.ceV();
                var7_6 = this.QcobS.iterator();
                while (var7_6.hasNext()) {
                    var8_7 = (Class_ap_f3b7a87f)var7_6.next();
                    try {
                        var8_7.su(var5_3);
                        if (var4_5 != null) {
                            if (var4_5 != null) continue;
                            break;
                        }
                        break block62;
                    }
                    catch (MatchException v25) {
                        throw Class_cq_827f2687.RI(v25);
                    }
                }
                var7_6 = this.awKdp.iterator();
            }
            while (var7_6.hasNext()) {
                var8_7 = (Class_aj_95d0a719)var7_6.next();
                try {
                    var8_7.su(var5_3);
                    if (var4_5 != null) {
                        if (var4_5 != null) continue;
                        break;
                    }
                    break block63;
                }
                catch (MatchException v26) {
                    throw Class_cq_827f2687.RI(v26);
                }
            }
            var5_3.ceW();
        }
    }

    public native void Ru(float var1, float var2);

    public native List<Class_cr_3ba4ae18> Ry();

    public native Class_bU_714b1dad RC();

    private static native MatchException RI(MatchException var0);

    private static native /* synthetic */ void RH(Class_cr_3ba4ae18 var0, Class_aj_95d0a719 var1);

    @Class_hG_d70cdb00
    public native void Rn(Class_hy_a98e9ba6 var1);

    public native void Rt(Class_aj_95d0a719 var1);

    public native List<Class_ap_f3b7a87f> Rz();

    public native void Rj();

    @Class_hG_d70cdb00
    public native void Ro(Class_hC_bfce1e55 var1);

    public List<Class_cr_3ba4ae18> Rw() {
        return this.vzihI.stream().filter(Class_cq_827f2687::RF).toList();
    }

    private static native Object RL(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    @Class_hG_d70cdb00
    public native void Rm(Class_hz_5cba7134 var1);

    @Class_hG_d70cdb00
    public native void Rp(Class_hE_c0b4b57e var1);

    @Class_hG_d70cdb00
    public native void Rq(Class_hx_d641fb49 var1);

    @Class_hG_d70cdb00
    public native void Rl(Class_hA_4f0c4656 var1);

    @Class_hG_d70cdb00
    public native void Rr(Class_hD_08709cfc var1);

    public native Class_bX_66e572fb RE();

    public native Class_bY_d6d3ef36 RD();

    private static native void _c98c0cbfc2ed8848e8b9749fe985ab6c();
}

