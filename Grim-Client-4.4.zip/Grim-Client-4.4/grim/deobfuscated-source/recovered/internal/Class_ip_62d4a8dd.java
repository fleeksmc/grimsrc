/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import recovered.core.NativeLoader;
import recovered.internal.Class_in_57efefb0;
import recovered.internal.Class_ir_8e0d90e0;

public class Class_ip_62d4a8dd {
    private final Map<String, Class_in_57efefb0> FlCme = new ConcurrentHashMap<String, Class_in_57efefb0>();
    private final List<Class_in_57efefb0> ZuBuJ = List.of(Class_in_57efefb0.FBjZE, Class_in_57efefb0.eiOnG, Class_in_57efefb0.lTmAi, Class_in_57efefb0.mYAkW);
    private static long jsoEm;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_ip_62d4a8dd.class);
        Class_ip_62d4a8dd._d8868ff4e2dd8e5a978546520563325a();
    }

    public native Class_ir_8e0d90e0 blC(String var1);

    public native List<Class_in_57efefb0> blE();

    public native Map<String, Class_in_57efefb0> blD();

    private static native MatchException blF(MatchException var0);

    private static native void _d8868ff4e2dd8e5a978546520563325a();
}

