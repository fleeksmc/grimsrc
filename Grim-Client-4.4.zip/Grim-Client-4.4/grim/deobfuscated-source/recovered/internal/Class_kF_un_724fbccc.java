/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_kF_cb1e3cd6;
import recovered.internal.Class_mG_52c8d386;

public class Class_kF_un_724fbccc {
    private MatrixStack tvbZE;
    private Vec3d KONNl;
    private Vec3d EFiQK;
    private Class_mG_52c8d386 FeAsi;
    private boolean YVlcU;
    private float zDZwd;
    private static final long kmaNw;
    private static final String[] pkrlR;
    private static final String[] oAHiB;
    private static final Map ebMsx;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_kF_un_724fbccc() {
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_kF_un_724fbccc.kmaNw = Class_gb_9d201141.aYR(8609377615685431963L, 6536453900990879170L, MethodHandles.lookup().lookupClass()).a(147037262473897L);
                Class_kF_un_724fbccc.ebMsx = new HashMap<K, V>(13);
                var0 = Class_kF_un_724fbccc.kmaNw ^ 136329274872285L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[5];
                var7_4 = 0;
                var6_5 = "\u00ff<\u0010\u00cd%\u00fd3\u00ef~K\u0091`\u00a2X\u00dd\u001f(\f\u0094\u0094\u00f8\u0080}g3\u009c\u00e7\u00cff\u00ce\u0015\u00bf\u0004\u00ef\"\u008b\u001bW\f\u00e5\u0086\u0016\u00ff\u0002\u0099a\u00e3\u00c9I\u00f2\u00c2l\u00f9\u008f\u00e9\u00c7\u00b6\u0010\u008cof\u00be\u00dcM\u00a9|$\u00a2\u0098\nf\u00bfnQ";
                var8_6 = "\u00ff<\u0010\u00cd%\u00fd3\u00ef~K\u0091`\u00a2X\u00dd\u001f(\f\u0094\u0094\u00f8\u0080}g3\u009c\u00e7\u00cff\u00ce\u0015\u00bf\u0004\u00ef\"\u008b\u001bW\f\u00e5\u0086\u0016\u00ff\u0002\u0099a\u00e3\u00c9I\u00f2\u00c2l\u00f9\u008f\u00e9\u00c7\u00b6\u0010\u008cof\u00be\u00dcM\u00a9|$\u00a2\u0098\nf\u00bfnQ".length();
                var5_7 = 16;
                var4_8 = -1;
lbl20:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl25:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_kF_un_724fbccc.dtu(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "P`\t\u00b7\u0088B@\u0000\u007f\u009e\u00ec\u00ec\u00f0W\u00ae\u0080\u0001\u00d6f\u00865\u008b2l1\u00cb\u00abD-\\\u00e0W,2\u00b9\u00ecy\u009c\u00b3\u00c57e\u00b4N@\u00d8\u00f2/\u00c2\u00f1\u00de\u00f0\u00e3\u00f8\u00c1\u00a8\u00c5p\u0016\u00c3\u00f2\u0012\u00f7\u00e5q\u00af\u00ad\u00a5\u00dbv=\u00df\u000f[Q\u00ba|ra\u008eL\u00ee|QpL`\u0019\u00f2\u00e8uC\u0014\u00fb\u00b4\u0095\u0018\u00c3\u00a2S)p\u00a8\u00ae\u00dc\u00b5\u000bOhMYC\u008e\u00ea\u000eP\u00e4\r\u000bG\u0080";
                    var8_6 = "P`\t\u00b7\u0088B@\u0000\u007f\u009e\u00ec\u00ec\u00f0W\u00ae\u0080\u0001\u00d6f\u00865\u008b2l1\u00cb\u00abD-\\\u00e0W,2\u00b9\u00ecy\u009c\u00b3\u00c57e\u00b4N@\u00d8\u00f2/\u00c2\u00f1\u00de\u00f0\u00e3\u00f8\u00c1\u00a8\u00c5p\u0016\u00c3\u00f2\u0012\u00f7\u00e5q\u00af\u00ad\u00a5\u00dbv=\u00df\u000f[Q\u00ba|ra\u008eL\u00ee|QpL`\u0019\u00f2\u00e8uC\u0014\u00fb\u00b4\u0095\u0018\u00c3\u00a2S)p\u00a8\u00ae\u00dc\u00b5\u000bOhMYC\u008e\u00ea\u000eP\u00e4\r\u000bG\u0080".length();
                    var5_7 = 96;
                    var4_8 = -1;
lbl34:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_kF_un_724fbccc.dtu(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl51:
                // 1 sources

                ** continue;
            }
        }
        Class_kF_un_724fbccc.pkrlR = var9_3;
        Class_kF_un_724fbccc.oAHiB = new String[5];
    }

    public String toString() {
        long l = kmaNw ^ 0x1D5AC8F57053L;
        float f = this.zDZwd;
        String string = String.valueOf(this.FeAsi);
        String string2 = String.valueOf(this.EFiQK);
        String string3 = String.valueOf(this.KONNl);
        String string4 = String.valueOf(this.tvbZE);
        return (String)((Object)Class_kF_un_724fbccc.dtx("x", (int)244, (long)(0x756DAB70E10113DCL ^ l))) + string4 + (String)((Object)Class_kF_un_724fbccc.dtx("x", (int)18475, (long)(0x1230FDDF17ADB00L ^ l))) + string3 + (String)((Object)Class_kF_un_724fbccc.dtx("x", (int)16496, (long)(0x5529844009A25359L ^ l))) + string2 + (String)((Object)Class_kF_un_724fbccc.dtx("x", (int)15406, (long)(0x729D1624D7972F01L ^ l))) + string + (String)((Object)Class_kF_un_724fbccc.dtx("x", (int)16743, (long)(0x24BFD56839BED24DL ^ l))) + f + ")";
    }

    public Class_kF_un_724fbccc dtp(Vec3d vec3d) {
        this.KONNl = vec3d;
        return this;
    }

    public Class_kF_un_724fbccc dtr(Class_mG_52c8d386 class_mG_52c8d386) {
        this.FeAsi = class_mG_52c8d386;
        return this;
    }

    private static Object dtw(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_kF_un_724fbccc.dtv(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    public Class_kF_un_724fbccc dtq(Vec3d vec3d) {
        this.EFiQK = vec3d;
        return this;
    }

    public Class_kF_un_724fbccc dto(MatrixStack matrixStack) {
        this.tvbZE = matrixStack;
        return this;
    }

    private static String dtu(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static String dtv(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x4E87;
        if (oAHiB[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])ebMsx.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    ebMsx.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_kF_un_724fbccc", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = pkrlR[n2].getBytes("ISO-8859-1");
            Class_kF_un_724fbccc.oAHiB[n2] = Class_kF_un_724fbccc.dtu(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return oAHiB[n2];
    }

    private static CallSite dtx(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_kF_un_724fbccc" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public Class_kF_cb1e3cd6 dtt() {
        long l = kmaNw ^ 0x20AB587104EL;
        float f = this.zDZwd;
        if (!this.YVlcU) {
            f = Class_kF_cb1e3cd6.bTo();
        }
        return new Class_kF_cb1e3cd6(this.tvbZE, this.KONNl, this.EFiQK, this.FeAsi, f);
    }

    public Class_kF_un_724fbccc dts(float f) {
        this.zDZwd = f;
        this.YVlcU = true;
        return this;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_kF_un_724fbccc.class, "dtw", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

