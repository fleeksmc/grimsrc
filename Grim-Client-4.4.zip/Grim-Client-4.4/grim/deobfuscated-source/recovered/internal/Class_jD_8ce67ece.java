/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.render.RenderLayers
 *  net.minecraft.client.render.VertexConsumer
 *  net.minecraft.client.render.VertexConsumerProvider$Immediate
 *  net.minecraft.client.render.command.OrderedRenderCommandQueue
 *  net.minecraft.client.render.entity.model.ShieldEntityModel
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.ItemDisplayContext
 *  net.minecraft.util.Identifier
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.jspecify.annotations.Nullable
 */
package recovered.internal;

import com.mojang.blaze3d.systems.RenderSystem;
import java.lang.invoke.MethodHandles;
import java.security.Key;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.model.ShieldEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.jspecify.annotations.Nullable;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jC_6c1c779b;
import recovered.internal.Class_jD_tV_d967f43f;
import recovered.internal.Class_ki_df085586;
import recovered.internal.Class_kn_79aeee60;
import recovered.internal.Class_mG_52c8d386;
import recovered.modules.ShieldStatusModule;

public final class Class_jD_8ce67ece {
    private static final Identifier rPixL;
    private static final List<Class_jD_tV_d967f43f> zbxcJ;
    private static @Nullable PlayerEntity KGTBV;
    private static @Nullable ItemDisplayContext euveQ;
    private static @Nullable Class_jC_6c1c779b OHnhj;
    private static final long BioyZ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    static {
        BioyZ = Class_gb_9d201141.aYR(5961469359657005583L, -2655715135983645903L, MethodHandles.lookup().lookupClass()).a(145425912808576L);
        long l = BioyZ ^ 0x2B4736FE3E37L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                byte[] byArray3 = cipher.doFinal("\u0088\u00a13\u0010\u0000\u008b\u0013\u00a9\u00beZ!\u008c8\u00a77\u00f6e\u00eb\u00d5Z*\\L>\u0013\u00d8\u00b1\u00ceY\u00f4t\u00bb\u00a7\u008d\u00a5\u00f5h\u00c2)~;\u007fQ\u00e1\u00aaz\u0085\u00d8'g[\u001d3Ba\u008f".getBytes("ISO-8859-1"));
                String string = Class_jD_8ce67ece.bHt(byArray3).intern();
                rPixL = Identifier.ofVanilla((String)string);
                zbxcJ = new ArrayList<Class_jD_tV_d967f43f>();
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    private static MatchException bHs(MatchException matchException) {
        return matchException;
    }

    private static @Nullable PlayerEntity bHn() {
        block8: {
            block7: {
                ItemDisplayContext itemDisplayContext;
                block6: {
                    ItemDisplayContext itemDisplayContext2;
                    long l = BioyZ ^ 0x132400CA4300L;
                    int n = Class_jC_6c1c779b.bHb();
                    if (ClientMain.dlmvG.player == null) {
                        return null;
                    }
                    itemDisplayContext = itemDisplayContext2 = euveQ;
                    if (n != 0) {
                        if (itemDisplayContext == null) {
                            return KGTBV;
                        }
                        itemDisplayContext = itemDisplayContext2;
                    }
                    if (n == 0) break block6;
                    if (itemDisplayContext.isFirstPerson()) break block7;
                    itemDisplayContext = itemDisplayContext2;
                }
                if (itemDisplayContext != ItemDisplayContext.GUI) break block8;
            }
            return ClientMain.dlmvG.player;
        }
        return KGTBV;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void bHo(ShieldEntityModel shieldEntityModel, MatrixStack matrixStack, Matrix4f matrix4f, int n, int n2) {
        Class_jC_6c1c779b class_jC_6c1c779b = Class_jD_8ce67ece.bHp();
        VertexConsumerProvider.Immediate immediate = class_jC_6c1c779b.bGU();
        RenderSystem.getModelViewStack().pushMatrix().identity().mul((Matrix4fc)matrix4f);
        matrixStack.push();
        try {
            VertexConsumer vertexConsumer = immediate.getBuffer(RenderLayers.entityTranslucent((Identifier)rPixL));
            shieldEntityModel.render(matrixStack, vertexConsumer, n, n2, Class_mG_52c8d386.hoGuU.coh());
        }
        finally {
            try {
                class_jC_6c1c779b.bGY();
            }
            finally {
                matrixStack.pop();
                RenderSystem.getModelViewStack().popMatrix();
            }
        }
    }

    private static String bHt(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static Class_jC_6c1c779b bHp() {
        long l = BioyZ ^ 0x773041F689B1L;
        int n = Class_jC_6c1c779b.bHb();
        Class_jC_6c1c779b class_jC_6c1c779b = OHnhj;
        if (n != 0) {
            if (class_jC_6c1c779b == null) {
                OHnhj = new Class_jC_6c1c779b();
            }
            class_jC_6c1c779b = OHnhj;
        }
        return class_jC_6c1c779b;
    }

    public static void bHh(@Nullable PlayerEntity playerEntity) {
        KGTBV = playerEntity;
    }

    public static void bHl() {
        long l = BioyZ ^ 0x79036C82CBC2L;
        int n = Class_jC_6c1c779b.bHc();
        if (zbxcJ.isEmpty()) {
            return;
        }
        ArrayList<Class_jD_tV_d967f43f> arrayList = new ArrayList<Class_jD_tV_d967f43f>(zbxcJ);
        zbxcJ.clear();
        for (Class_jD_tV_d967f43f class_jD_tV_d967f43f : arrayList) {
            Class_ki_df085586.bPj(() -> Class_jD_8ce67ece.bHo(class_jD_tV_d967f43f.model(), class_jD_tV_d967f43f.poseStack(), class_jD_tV_d967f43f.modelViewMatrix(), class_jD_tV_d967f43f.lightCoords(), class_jD_tV_d967f43f.overlayCoords()), class_jD_tV_d967f43f.color(), class_jD_tV_d967f43f.color(), 0, 4, 2.5f, 1.0f, 1.0f, 0.0f, 1.0f, 1.0f);
            if (n == 0) continue;
        }
    }

    public static void bHm() {
        zbxcJ.clear();
    }

    public static void bHj() {
        euveQ = null;
    }

    public static void bHi(@Nullable ItemDisplayContext itemDisplayContext) {
        euveQ = itemDisplayContext;
    }

    public static void bHk(ShieldEntityModel shieldEntityModel, MatrixStack matrixStack, OrderedRenderCommandQueue orderedRenderCommandQueue, int n, int n2, ShieldStatusModule shieldStatusModule) {
        long l = BioyZ ^ 0x6B7061D76D42L;
        int n3 = Class_jC_6c1c779b.bHc();
        if (Class_kn_79aeee60.bQp()) {
            return;
        }
        PlayerEntity playerEntity = Class_jD_8ce67ece.bHn();
        Class_mG_52c8d386 class_mG_52c8d386 = shieldStatusModule.aaK(playerEntity);
        if (n3 == 0) {
            if (class_mG_52c8d386.cnW()) {
                return;
            }
            orderedRenderCommandQueue.submitCustom(matrixStack, RenderLayers.entityTranslucent((Identifier)rPixL), (entry, vertexConsumer) -> {
                MatrixStack matrixStack = new MatrixStack();
                matrixStack.peek().copy(entry);
                Matrix4f matrix4f = new Matrix4f((Matrix4fc)RenderSystem.getModelViewMatrix());
                zbxcJ.add(new Class_jD_tV_d967f43f(shieldEntityModel, matrixStack, matrix4f, n, n2, class_mG_52c8d386));
            });
        }
    }
}

