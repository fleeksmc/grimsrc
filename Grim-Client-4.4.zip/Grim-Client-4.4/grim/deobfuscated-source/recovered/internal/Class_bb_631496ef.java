/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_ba_2644396b;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bb_631496ef<T extends Class_ig_ca326427>
extends Class_az_a4990dcf {
    private final T Hzehq;
    private boolean wdYkr;
    private Class_ba_2644396b yPGPg;
    private Class_ba_2644396b mVfOV;
    private final Class_rk_bf8630d1 ENBAX;
    private final Class_rk_bf8630d1 TExFB;
    private final Class_rk_bf8630d1 SBrVn;
    private static long bEhCo;
    private static long[] qBphK;
    private static Integer[] EUMNl;
    private static Map vsPex;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bb_631496ef(T t) {
        long l = bEhCo ^ 0x45A82AC0E3A4L;
        this.wdYkr = true;
        this.ENBAX = new Class_rk_bf8630d1((int)Class_bb_631496ef.Bq("v", (int)30884, (long)(0x336DB35E67287748L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.TExFB = new Class_rk_bf8630d1((int)Class_bb_631496ef.Bq("v", (int)25046, (long)(0x37A7EB18B569EE39L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.SBrVn = new Class_rk_bf8630d1((int)Class_bb_631496ef.Bq("v", (int)14887, (long)(0x2FB715D6D0CF35C9L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.Hzehq = t;
        this.BcpIo = 9.0f;
        this.WjISQ = 9.0f;
    }

    static {
        NativeLoader.doInit(Class_bb_631496ef.class);
        Class_bb_631496ef._82fbfebd99153c333724c02ed202703f();
    }

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private static native int Bo(int var0, long var1);

    public native Class_bb_631496ef<T> Be(Class_ba_2644396b var1);

    public native Class_bb_631496ef<T> Bf(Class_ba_2644396b var1);

    public native boolean Bh();

    public native Class_bb_631496ef<T> Bd(boolean var1);

    public native Class_ba_2644396b Bi();

    public native Class_ba_2644396b Bj();

    public native Class_rk_bf8630d1 Bm();

    public native T Bg();

    private static native MatchException Bn(MatchException var0);

    private static native int Bp(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public native Class_rk_bf8630d1 Bk();

    private static native CallSite Bq(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native Class_rk_bf8630d1 Bl();

    private static native void _82fbfebd99153c333724c02ed202703f();
}

