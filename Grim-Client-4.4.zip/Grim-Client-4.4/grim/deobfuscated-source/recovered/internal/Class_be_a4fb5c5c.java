/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_P_2c9819bb;
import recovered.internal.Class_ad_d4e95a2c;
import recovered.internal.Class_ag_8130246f;
import recovered.internal.Class_ag_rR_5deaebc6;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mT_db06bea0;

public class Class_be_a4fb5c5c
extends Class_aj_95d0a719 {
    private final String dBkfw;
    private final Class_ad_d4e95a2c whlUn;
    private final Class_ag_8130246f jSGrk;
    private String HWjtp;
    private String UbxXC;
    private final Class_mT_db06bea0 SGppE;
    private final Class_P_2c9819bb WqZWe;
    private static long ukNDG;
    private static String[] IRMpT;
    private static String[] ZbaeG;
    private static Map Cpuuq;
    private static long[] naAAL;
    private static Integer[] ibjaS;
    private static Map yDulb;
    private static long bIldw;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_be_a4fb5c5c(float f, float f2, float f3, String string) {
        long l = ukNDG ^ 0x3FA7745E654EL;
        super(f, f2, 110.0f, 155.0f);
        this.HWjtp = "";
        this.UbxXC = "";
        this.SGppE = Class_mT_db06bea0.cpz();
        this.IzFhM = f3;
        this.dBkfw = string;
        this.whlUn = new Class_ad_d4e95a2c(Class_lE_06fbe260.joxgd.bYM(7.0f));
        this.whlUn.lZ((String)((Object)Class_be_a4fb5c5c.Cy("s", (int)8591, (long)(0x5F345ECD94291566L ^ l))));
        this.whlUn.me((int)Class_be_a4fb5c5c.CB("r", (int)22149, (long)(0x3B07F7D018F8633DL ^ l)));
        this.jSGrk = new Class_ag_8130246f("", Class_ag_rR_5deaebc6.VdGoA);
        this.jSGrk.sX(25.0f, 75.0f);
        this.jSGrk.dY();
        this.whlUn.mg(this::Cr);
        this.WqZWe = new Class_P_2c9819bb((Class_aj_95d0a719)this, (String)((Object)Class_be_a4fb5c5c.Cy("s", (int)31028, (long)(0x2282D58697964DDBL ^ l))), Class_lf_d247d983.gamnD);
        this.WqZWe.jb(this::Ct);
        this.WqZWe.tn(this.BcpIo);
        this.FHbTC = true;
    }

    static {
        NativeLoader.doInit(Class_be_a4fb5c5c.class);
        Class_be_a4fb5c5c._c58d6e7f14e64e674356b8505b28b354();
    }

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean dm(int var1, int var2, int var3);

    private native /* synthetic */ void Cs(Class_lC_5322e8cf var1, float var2);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private static native int CA(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean dB(double var1, double var3, Class_mA_32d8a5f2 var5, double var6, double var8);

    @Override
    public native boolean eK(char var1);

    private native void Cr();

    private static native void _c58d6e7f14e64e674356b8505b28b354();

    private static native CallSite Cy(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native CallSite CB(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native String Cw(int var0, long var1);

    private static native Object Cx(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native MatchException Cu(MatchException var0);

    private static native String Cv(byte[] var0);

    private native /* synthetic */ void Ct(Class_P_2c9819bb var1);

    private static native int Cz(int var0, long var1);
}

