/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_gC_1f010b94;

public class Class_gC_tb_7100cbc2
extends Class_gC_1f010b94 {
    private final int LENXb;
    private final int bmahp;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gC_tb_7100cbc2(int n, int n2) {
        this.LENXb = n;
        this.bmahp = n2;
    }

    public int dpe() {
        return this.bmahp;
    }

    public int dpd() {
        return this.LENXb;
    }
}

