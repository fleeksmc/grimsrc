/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockState
 *  net.minecraft.util.math.BlockPos
 */
package recovered.internal;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gS_4ef360bc
extends Class_hH_ae8f8f77 {
    private BlockState XpgmN;
    private BlockPos dxjVh;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gS_4ef360bc(BlockState blockState, BlockPos blockPos) {
        this.XpgmN = blockState;
        this.dxjVh = blockPos;
    }

    public void bci(BlockState blockState) {
        this.XpgmN = blockState;
    }

    public BlockState bcg() {
        return this.XpgmN;
    }

    public BlockPos bch() {
        return this.dxjVh;
    }
}

