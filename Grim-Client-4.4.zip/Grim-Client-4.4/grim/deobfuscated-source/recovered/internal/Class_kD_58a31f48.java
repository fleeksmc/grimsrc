/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.joml.Matrix3x2fStack
 *  org.joml.Matrix4f
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix4f;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_kD_ul_11f82661;
import recovered.internal.Class_kG_82f650e3;
import recovered.internal.Class_mG_52c8d386;

public class Class_kD_58a31f48 {
    private Matrix3x2fStack vLXCt;
    private Matrix4f LTgfz;
    private float qcXxG;
    private float QkzCs;
    private float lpFYB;
    private float SCber;
    private int[] bDgdv;
    private Class_mG_52c8d386 uePHf;
    private static final long PeEVb = Class_gb_9d201141.aYR(8725412669369813506L, 2727400911256207010L, MethodHandles.lookup().lookupClass()).a(85921129537519L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static MatchException bTe(MatchException matchException) {
        return matchException;
    }

    public static Class_kD_ul_11f82661 bSU(Matrix4f matrix4f, double d, double d2, double d3, double d4, int[] nArray) {
        return Class_kD_58a31f48.bSV().dsR(matrix4f).dsS((float)d).dsT((float)d2).dsU((float)d3).dsV((float)d4).dsW(nArray);
    }

    public static Class_kD_ul_11f82661 bSV() {
        return new Class_kD_ul_11f82661();
    }

    Class_kD_58a31f48(Matrix3x2fStack matrix3x2fStack, Matrix4f matrix4f, float f, float f2, float f3, float f4, int[] nArray, Class_mG_52c8d386 class_mG_52c8d386) {
        block0: {
            long l = PeEVb ^ 0x51B9A1A9C66AL;
            Class_iS_888f260e[] class_iS_888f260eArray = Class_kG_82f650e3.bTH();
            this.vLXCt = matrix3x2fStack;
            this.LTgfz = matrix4f;
            this.qcXxG = f;
            Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
            this.QkzCs = f2;
            this.lpFYB = f3;
            this.SCber = f4;
            this.bDgdv = nArray;
            this.uePHf = class_mG_52c8d386;
            if (class_iS_888f260eArray2 == null) break block0;
            Class_iS_888f260e.bwK("ZgrXCc");
        }
    }

    public int[] bTc() {
        return this.bDgdv;
    }

    public Matrix4f bSX() {
        return this.LTgfz;
    }

    public float bTb() {
        return this.SCber;
    }

    public Class_mG_52c8d386 bTd() {
        return this.uePHf;
    }

    public float bSY() {
        return this.qcXxG;
    }

    public float bSZ() {
        return this.QkzCs;
    }

    public float bTa() {
        return this.lpFYB;
    }

    public Matrix3x2fStack bSW() {
        return this.vLXCt;
    }

    public static Class_kD_ul_11f82661 bST(Matrix3x2fStack matrix3x2fStack, double d, double d2, double d3, double d4, int[] nArray) {
        return Class_kD_58a31f48.bSV().dsQ(matrix3x2fStack).dsS((float)d).dsT((float)d2).dsU((float)d3).dsV((float)d4).dsW(nArray);
    }
}

