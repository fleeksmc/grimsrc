/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.core.ClientMain;
import recovered.internal.Class_bH_2433d459;
import recovered.internal.Class_cn_4308f1f5;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iX_8d826c07;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bG_4add376c
extends Class_cn_4308f1f5 {
    private final Class_bH_2433d459 jEFqT;
    private final Class_bH_2433d459 KRQEY;
    private final Class_rk_bf8630d1 pePjV;
    private final Class_rk_bf8630d1 aaKXr;
    private static final long xeDNj;
    private static final String[] EWhLc;
    private static final String[] SLNuF;
    private static final Map RGkOd;
    private static final long[] dmiyD;
    private static final Integer[] jIRWP;
    private static final Map XDQAr;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bG_4add376c() {
        long l = xeDNj ^ 0x2E4E17ECA9C5L;
        int[] nArray = new int[Class_bG_4add376c.Mn("k", (int)14490, (long)(0x48E2E3E41B7D9F8AL ^ l))];
        nArray[0] = (int)Class_bG_4add376c.Mn("k", (int)16264, (long)(0x4BF76EE6733A1899L ^ l));
        nArray[1] = (int)Class_bG_4add376c.Mn("k", (int)11171, (long)(0x217B95EC630F8CB8L ^ l));
        nArray[2] = (int)Class_bG_4add376c.Mn("k", (int)20011, (long)(0x17609526D145693CL ^ l));
        nArray[3] = (int)Class_bG_4add376c.Mn("k", (int)4243, (long)(0x42C887E21818378FL ^ l));
        nArray[4] = (int)Class_bG_4add376c.Mn("k", (int)1048, (long)(0x7B0D431301232301L ^ l));
        nArray[5] = (int)Class_bG_4add376c.Mn("k", (int)30326, (long)(0x1B28759051F8D16EL ^ l));
        super(nArray, Class_lf_d247d983.PWkZi);
        this.jEFqT = new Class_bH_2433d459(this.ZpVra, Class_mr_7eac5189.clS(new int[]{(int)Class_bG_4add376c.Mn("k", (int)21247, (long)(0x281CE154D3FF5E9L ^ l)), (int)Class_bG_4add376c.Mn("k", (int)32670, (long)(0x435D6E6AD67C588CL ^ l)), (int)Class_bG_4add376c.Mn("k", (int)8553, (long)(0x1FAF6B7039E5067AL ^ l))}), (String)((Object)Class_bG_4add376c.Mk("y", (int)31360, (long)(0x5EFED64F205746A6L ^ l))));
        this.KRQEY = new Class_bH_2433d459(this.ZpVra, Class_mr_7eac5189.clS(new int[]{(int)Class_bG_4add376c.Mn("k", (int)2769, (long)(0x1F31EBC1A522DC4L ^ l)), (int)Class_bG_4add376c.Mn("k", (int)32670, (long)(0x435D6E6AD67C588CL ^ l)), (int)Class_bG_4add376c.Mn("k", (int)5810, (long)(0x41D9CBADCB6B1A8L ^ l))}), (String)((Object)Class_bG_4add376c.Mk("y", (int)1652, (long)(0x26D81610734BA53L ^ l))));
        this.pePjV = new Class_rk_bf8630d1((int)Class_bG_4add376c.Mn("k", (int)4066, (long)(0x3E47EA18F40FA8F6L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.aaKXr = new Class_rk_bf8630d1((int)Class_bG_4add376c.Mn("k", (int)5544, (long)(0x409BB1D60247B2B5L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block14: {
            block13: {
                block12: {
                    Class_bG_4add376c.xeDNj = Class_gb_9d201141.aYR(-8832293978279949331L, -8353497630788713414L, MethodHandles.lookup().lookupClass()).a(159406309179691L);
                    Class_bG_4add376c.RGkOd = new HashMap<K, V>(13);
                    var11 = Class_bG_4add376c.xeDNj ^ 103388287698353L;
                    var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                    v0 = SecretKeyFactory.getInstance("DES");
                    v1 = new byte[8];
                    v2 = v1;
                    v1[0] = (byte)(var11 >>> 56);
                    for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                        v2 = v2;
                        v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                    }
                    var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                    var20_3 = new String[2];
                    var18_4 = 0;
                    var17_5 = "\u00a3\u00dc\u00c7\r\u0094P*\u00d0\u008a\u0011\u00d9U\u001c\u00abWO\u0010#;\u0094\u00e4Z`_$\u001b\u00ff\u00den\u007f\u00f1\u00cb\u0086";
                    var19_6 = "\u00a3\u00dc\u00c7\r\u0094P*\u00d0\u008a\u0011\u00d9U\u001c\u00abWO\u0010#;\u0094\u00e4Z`_$\u001b\u00ff\u00den\u007f\u00f1\u00cb\u0086".length();
                    var16_7 = 16;
                    var15_8 = -1;
lbl20:
                    // 2 sources

                    while (true) {
                        continue;
                        break;
                    }
lbl22:
                    // 1 sources

                    while (true) {
                        var20_3[var18_4++] = Class_bG_4add376c.Mh(var21_9).intern();
                        if ((var15_8 += var16_7) < var19_6) {
                            var16_7 = var17_5.charAt(var15_8);
                            ** continue;
                        }
                        break block12;
                        break;
                    }
                    v3 = ++var15_8;
                    var21_9 = var13_1.doFinal(var17_5.substring(v3, v3 + var16_7).getBytes("ISO-8859-1"));
                    ** while (true)
                }
                Class_bG_4add376c.EWhLc = var20_3;
                Class_bG_4add376c.SLNuF = new String[2];
                Class_bG_4add376c.XDQAr = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v4 = SecretKeyFactory.getInstance("DES");
                v5 = new byte[8];
                v6 = v5;
                v5[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v6 = v6;
                    v6[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v4.generateSecret(new DESKeySpec(v6)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[14];
                var3_13 = 0;
                var4_14 = "\u00f0{1U\u0013S\u0092\u0089\u0093ki\u009d\u00d1\"\u00f36)\u00e2i\u00c4\u00ec\u00fc<U\u000e\u00f9~k\u00a6\"\u0085\u00fd\u001f\u00f4\u00d7`r\t\u00f5\f\u0081\u000eK\u00acx\u0084pq\u00d6\b\u0007\u0085X\u00c7\u00e2ge\u00e9\u001e\u0080\u001b\u00d3s\u00e8\u0081\u00b3h\u001f\u000b\u00b5K\u0099\u0096\u00c6\u0004\u00ba\u00e1Kci\u00c0\u00f3`\u007f9\u00cb\u00aa\u0006&\u0086\u00ddx\u00c6\u00c2\u00ad\u0007";
                var5_15 = "\u00f0{1U\u0013S\u0092\u0089\u0093ki\u009d\u00d1\"\u00f36)\u00e2i\u00c4\u00ec\u00fc<U\u000e\u00f9~k\u00a6\"\u0085\u00fd\u001f\u00f4\u00d7`r\t\u00f5\f\u0081\u000eK\u00acx\u0084pq\u00d6\b\u0007\u0085X\u00c7\u00e2ge\u00e9\u001e\u0080\u001b\u00d3s\u00e8\u0081\u00b3h\u001f\u000b\u00b5K\u0099\u0096\u00c6\u0004\u00ba\u00e1Kci\u00c0\u00f3`\u007f9\u00cb\u00aa\u0006&\u0086\u00ddx\u00c6\u00c2\u00ad\u0007".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v7 = var6_12;
                    v8 = var3_13++;
                    v9 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v10 = -1;
                    break block13;
                    break;
                }
lbl58:
                // 1 sources

                while (true) {
                    v7[v8] = v11;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u0090\u00b7\u008cz\u00c3\u009c%;\u0099\u00c2\u0096#AS\u00b3\u00a5";
                    var5_15 = "\u0090\u00b7\u008cz\u00c3\u009c%;\u0099\u00c2\u0096#AS\u00b3\u00a5".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v7 = var6_12;
                        v8 = var3_13++;
                        v9 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v10 = 0;
                        break block13;
                        break;
                    }
                    break;
                }
lbl71:
                // 1 sources

                while (true) {
                    v7[v8] = v11;
                    if (var2_16 < var5_15) ** continue;
                    break block14;
                    break;
                }
            }
            var8_18 = v9;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v11 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v10) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl84:
                // 1 sources

                ** continue;
            }
        }
        Class_bG_4add376c.dmiyD = var6_12;
        Class_bG_4add376c.jIRWP = new Integer[14];
    }

    private static CallSite Mn(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bG_4add376c" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    @Override
    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        super.LX(class_lC_5322e8cf);
        this.pePjV.dhd(ClientMain.dlmvG.getCurrentFps());
        this.aaKXr.dhd(Class_iX_8d826c07.bxS());
        this.jEFqT.Mo(String.valueOf((int)this.pePjV.dhj()));
        this.KRQEY.Mo(Class_jf_d1c4f950.bAM(this.aaKXr.dhj()));
    }

    private static Object Mj(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_bG_4add376c.Mi(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static String Mh(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static int Ml(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x6C67;
        if (jIRWP[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = dmiyD[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])XDQAr.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    XDQAr.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bG_4add376c", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bG_4add376c.jIRWP[n2] = n3;
        }
        return jIRWP[n2];
    }

    private static CallSite Mk(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bG_4add376c" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int Mm(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bG_4add376c.Ml(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static String Mi(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x7750;
        if (SLNuF[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])RGkOd.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    RGkOd.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bG_4add376c", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = EWhLc[n2].getBytes("ISO-8859-1");
            Class_bG_4add376c.SLNuF[n2] = Class_bG_4add376c.Mh(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return SLNuF[n2];
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bG_4add376c.class, "Mm", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_bG_4add376c.class, "Mj", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

