/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import recovered.core.ClientMain;
import recovered.internal.Class_ap_f3b7a87f;
import recovered.internal.Class_bU_714b1dad;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_cC_14ef8bb5;
import recovered.internal.Class_ck_d3c7acd5;
import recovered.internal.Class_cl_0655ee76;
import recovered.internal.Class_cs_f7c4d6b1;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_lA_428877cb;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lG_79349165;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.internal.Class_rm_d861be3b;
import recovered.internal.Class_rr_be159084;

public abstract class Class_cr_3ba4ae18
extends Class_iS_888f260e
implements Class_cs_f7c4d6b1,
Class_lA_428877cb,
Class_lG_79349165 {
    protected float toIeR;
    protected float QWaAn;
    protected float jTsqG;
    protected float Xtjvx;
    protected final Class_rk_bf8630d1 ormBS;
    protected final Class_rk_bf8630d1 KgDVz;
    protected final Class_rk_bf8630d1 gILqY;
    protected final Class_rk_bf8630d1 OsbYH;
    protected final Class_rk_bf8630d1 AyAnj;
    protected final Class_rk_bf8630d1 iArvU;
    protected boolean LkpAS;
    protected boolean vCMYc;
    protected boolean pAjuu;
    protected float lGacw;
    protected float WjFpo;
    protected float TSvLw;
    protected float VngMS;
    protected int[] eqWHC;
    protected Class_lf_d247d983 jAncU;
    protected final Class_cC_14ef8bb5 WUOUc;
    private static Class_iS_888f260e[] vFBld;
    private static final long yIaJZ;
    private static final String[] tsSMY;
    private static final String[] FmiwT;
    private static final Map cSkUg;
    private static final long[] pSShx;
    private static final Integer[] pIOSJ;
    private static final Map wWYME;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cr_3ba4ae18(int[] nArray, Class_lf_d247d983 class_lf_d247d983) {
        long l = yIaJZ ^ 0x7488EF839935L;
        this.ormBS = new Class_rk_bf8630d1((int)Class_cr_3ba4ae18.SK("h", (int)1477, (long)(0x7776480BED7ACECFL ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        this.KgDVz = new Class_rk_bf8630d1((int)Class_cr_3ba4ae18.SK("h", (int)18508, (long)(0x45295B730BE50345L ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        this.gILqY = new Class_rk_bf8630d1((int)Class_cr_3ba4ae18.SK("h", (int)18508, (long)(0x45295B730BE50345L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.OsbYH = new Class_rk_bf8630d1((int)Class_cr_3ba4ae18.SK("h", (int)18508, (long)(0x45295B730BE50345L ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        this.AyAnj = new Class_rk_bf8630d1((int)Class_cr_3ba4ae18.SK("h", (int)24503, (long)(0x5BDFDF71336614B8L ^ l))).dhs(Class_rj_b691f4f7.yiIHY);
        this.iArvU = new Class_rk_bf8630d1((int)Class_cr_3ba4ae18.SK("h", (int)18508, (long)(0x45295B730BE50345L ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        this.WUOUc = new Class_cC_14ef8bb5(Class_mr_7eac5189.clS(new int[]{(int)Class_cr_3ba4ae18.SK("h", (int)16150, (long)(0x94135F2E6CE7418L ^ l)), (int)Class_cr_3ba4ae18.SK("h", (int)30109, (long)(0x51F7E794577BE91L ^ l)), (int)Class_cr_3ba4ae18.SK("h", (int)32371, (long)(0x4107EDADA07DB57EL ^ l)), (int)Class_cr_3ba4ae18.SK("h", (int)6674, (long)(0x25706542A67B511AL ^ l))})).Vy(1.0).Vw(50.0).Vx(200.0).VA(100.0).Vz("%");
        this.eqWHC = nArray;
        this.jAncU = class_lf_d247d983;
        this.oZllQ.add(this.WUOUc);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block14: {
            block13: {
                block12: {
                    Class_cr_3ba4ae18.yIaJZ = Class_gb_9d201141.aYR(-5607814429691454069L, 3264665966983370356L, MethodHandles.lookup().lookupClass()).a(110351274464627L);
                    Class_cr_3ba4ae18.cSkUg = new HashMap<K, V>(13);
                    Class_cr_3ba4ae18.SB(new Class_iS_888f260e[3]);
                    var11 = Class_cr_3ba4ae18.yIaJZ ^ 46570476029976L;
                    var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                    v0 = SecretKeyFactory.getInstance("DES");
                    v1 = new byte[8];
                    v2 = v1;
                    v1[0] = (byte)(var11 >>> 56);
                    for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                        v2 = v2;
                        v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                    }
                    var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                    var20_3 = new String[3];
                    var18_4 = 0;
                    var17_5 = "f|\u0098\u00d4\u0091\u001e\u0014x\u00d4\u00ae0.\u00d5\u00c1YX1\u0096,\u0012\u00df\u0019-C\u00b8\u00c8\u00c3\f\u00e8\u0093\u0087O\u0010\u0081\u0016\u00b3\u00f9GRS\u00d5\u0083\u00c9\u00a1\u0095\u00abZ\u00a6R\u0010\u009a\u0006\u00ed\u0018\u00b3\u007fm3\u00d9\u00bei\u00ff7\u009c\u00d1\u0007";
                    var19_6 = "f|\u0098\u00d4\u0091\u001e\u0014x\u00d4\u00ae0.\u00d5\u00c1YX1\u0096,\u0012\u00df\u0019-C\u00b8\u00c8\u00c3\f\u00e8\u0093\u0087O\u0010\u0081\u0016\u00b3\u00f9GRS\u00d5\u0083\u00c9\u00a1\u0095\u00abZ\u00a6R\u0010\u009a\u0006\u00ed\u0018\u00b3\u007fm3\u00d9\u00bei\u00ff7\u009c\u00d1\u0007".length();
                    var16_7 = 32;
                    var15_8 = -1;
lbl21:
                    // 2 sources

                    while (true) {
                        continue;
                        break;
                    }
lbl23:
                    // 1 sources

                    while (true) {
                        var20_3[var18_4++] = Class_cr_3ba4ae18.SE(var21_9).intern();
                        if ((var15_8 += var16_7) < var19_6) {
                            var16_7 = var17_5.charAt(var15_8);
                            ** continue;
                        }
                        break block12;
                        break;
                    }
                    v3 = ++var15_8;
                    var21_9 = var13_1.doFinal(var17_5.substring(v3, v3 + var16_7).getBytes("ISO-8859-1"));
                    ** while (true)
                }
                Class_cr_3ba4ae18.tsSMY = var20_3;
                Class_cr_3ba4ae18.FmiwT = new String[3];
                Class_cr_3ba4ae18.wWYME = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v4 = SecretKeyFactory.getInstance("DES");
                v5 = new byte[8];
                v6 = v5;
                v5[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v6 = v6;
                    v6[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v4.generateSecret(new DESKeySpec(v6)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[8];
                var3_13 = 0;
                var4_14 = "\u00a1s\u00c7E\u00a4\u00b8\u00c7\u0003\u0013\u00fa\u00ec\u00f3M\u00ae\u00a0ya\u001f\u00aaU.\"\u00bb\u00a6\u0091P,\u0014Z\u00f2\fH\u0088\u00dc\u00dc\u00ac\u00c3f\u00fa\u00ae\u0095\u00cb\u00ae\fcR\u00c6\u00bf";
                var5_15 = "\u00a1s\u00c7E\u00a4\u00b8\u00c7\u0003\u0013\u00fa\u00ec\u00f3M\u00ae\u00a0ya\u001f\u00aaU.\"\u00bb\u00a6\u0091P,\u0014Z\u00f2\fH\u0088\u00dc\u00dc\u00ac\u00c3f\u00fa\u00ae\u0095\u00cb\u00ae\fcR\u00c6\u00bf".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v7 = var6_12;
                    v8 = var3_13++;
                    v9 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v10 = -1;
                    break block13;
                    break;
                }
lbl59:
                // 1 sources

                while (true) {
                    v7[v8] = v11;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00adpGB\u00dag\u009ed\u00d9\u00e6[\u00ae\u00fc7\u00f1\u00ad";
                    var5_15 = "\u00adpGB\u00dag\u009ed\u00d9\u00e6[\u00ae\u00fc7\u00f1\u00ad".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v7 = var6_12;
                        v8 = var3_13++;
                        v9 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v10 = 0;
                        break block13;
                        break;
                    }
                    break;
                }
lbl72:
                // 1 sources

                while (true) {
                    v7[v8] = v11;
                    if (var2_16 < var5_15) ** continue;
                    break block14;
                    break;
                }
            }
            var8_18 = v9;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v11 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v10) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl85:
                // 1 sources

                ** continue;
            }
        }
        Class_cr_3ba4ae18.pSShx = var6_12;
        Class_cr_3ba4ae18.pIOSJ = new Integer[8];
    }

    private static Object SG(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_cr_3ba4ae18.SF(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    public Class_lf_d247d983 Sm() {
        return this.jAncU;
    }

    public Class_rk_bf8630d1 Sc() {
        return this.AyAnj;
    }

    public float Sk() {
        return this.VngMS;
    }

    public Class_cr_3ba4ae18 So(float f) {
        this.toIeR = f;
        return this;
    }

    private static CallSite SH(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cr_3ba4ae18" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public float Si() {
        return this.WjFpo;
    }

    public float Sj() {
        return this.TSvLw;
    }

    public void Ph(Class_lC_5322e8cf class_lC_5322e8cf) {
        float f;
        float f2;
        block8: {
            float f3;
            block7: {
                long l = yIaJZ ^ 0x5C675520520BL;
                Class_iS_888f260e[] class_iS_888f260eArray = Class_cr_3ba4ae18.SC();
                this.LX(class_lC_5322e8cf);
                float f4 = this.ormBS.dhj() * this.KgDVz.dhj();
                Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
                float f5 = f4;
                float f6 = 0.0f;
                if (class_iS_888f260eArray2 != null) {
                    if (f5 == f6) {
                        return;
                    }
                    Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, Math.min(1.0f, f4));
                    f5 = 0.5f + f4 * 0.5f;
                    f6 = 0.05f * this.OsbYH.dhj();
                }
                float f7 = f5 - f6;
                float f8 = this.RT();
                Class_jH_c1172273.bId(class_lC_5322e8cf, this.toIeR + this.RU() / 2.0f, this.QWaAn + this.RV() / 2.0f, f7);
                float f9 = f8 - 1.0f;
                f3 = f9 == 0.0f ? 0 : (f9 > 0.0f ? 1 : -1);
                if (class_iS_888f260eArray2 == null) break block7;
                if (f3 != false) {
                    Class_jH_c1172273.bId(class_lC_5322e8cf, this.toIeR, this.QWaAn, f8);
                }
                this.NV(class_lC_5322e8cf);
                f2 = f8;
                f = 1.0f;
                if (class_iS_888f260eArray2 == null) break block8;
                float f10 = f2 - f;
                f3 = f10 == 0.0f ? 0 : (f10 > 0.0f ? 1 : -1);
            }
            if (f3 != false) {
                Class_jH_c1172273.bIf();
            }
            Class_jH_c1172273.bIf();
            f2 = 1.0f;
            f = 1.0f;
        }
        Class_jF_38b68c76.bHz(f2, f, 1.0f, 1.0f);
    }

    public float RT() {
        return this.WUOUc.VB() / 100.0f;
    }

    public static Class_iS_888f260e[] SC() {
        return vFBld;
    }

    public Class_cr_3ba4ae18 Sz(int[] nArray) {
        this.eqWHC = nArray;
        return this;
    }

    private static CallSite SK(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cr_3ba4ae18" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public static void SB(Class_iS_888f260e[] class_iS_888f260eArray) {
        vFBld = class_iS_888f260eArray;
    }

    private static String SE(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public Class_cr_3ba4ae18 SA(Class_lf_d247d983 class_lf_d247d983) {
        this.jAncU = class_lf_d247d983;
        return this;
    }

    private static String SF(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x38F7;
        if (FmiwT[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])cSkUg.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    cSkUg.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cr_3ba4ae18", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = tsSMY[n2].getBytes("ISO-8859-1");
            Class_cr_3ba4ae18.FmiwT[n2] = Class_cr_3ba4ae18.SE(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return FmiwT[n2];
    }

    private static int SI(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x158D;
        if (pIOSJ[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = pSShx[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])wWYME.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    wWYME.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cr_3ba4ae18", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_cr_3ba4ae18.pIOSJ[n2] = n3;
        }
        return pIOSJ[n2];
    }

    private float RN(Class_ck_d3c7acd5 class_ck_d3c7acd5, float f, List<Float> list, List<Float> list2) {
        float f2;
        block5: {
            long l = yIaJZ ^ 0x296186338E9FL;
            Class_iS_888f260e[] class_iS_888f260eArray = Class_cr_3ba4ae18.SC();
            for (int i = 0; i < list.size(); ++i) {
                float f3;
                float f4;
                block7: {
                    float f5;
                    block6: {
                        float f6;
                        f2 = f6 = Math.abs(f + list.get(i).floatValue() - class_ck_d3c7acd5.QG());
                        if (class_iS_888f260eArray == null) break block5;
                        float f7 = f2 - 25.0f;
                        f5 = f7 == 0.0f ? 0 : (f7 < 0.0f ? -1 : 1);
                        if (class_iS_888f260eArray == null) break block6;
                        if (f5 < 0) {
                            class_ck_d3c7acd5.QI(true);
                        }
                        f4 = f6;
                        f3 = 5.0f;
                        if (class_iS_888f260eArray == null) break block7;
                        float f8 = f4 - f3;
                        f5 = f8 == 0.0f ? 0 : (f8 < 0.0f ? -1 : 1);
                    }
                    if (f5 >= 0) continue;
                    f4 = class_ck_d3c7acd5.QG();
                    f3 = list2.get(i).floatValue();
                }
                f = f4 + f3;
                if (class_iS_888f260eArray != null) continue;
            }
            f2 = f;
        }
        return f2;
    }

    public Class_rk_bf8630d1 Sb() {
        return this.OsbYH;
    }

    public float RW() {
        return this.toIeR;
    }

    public double RR(double d) {
        return (double)this.toIeR + (d - (double)this.toIeR) / (double)this.RT();
    }

    public boolean RP(double d, double d2) {
        return Class_jf_d1c4f950.bAE(d, d2, this.toIeR, this.QWaAn, this.jTsqG, this.Xtjvx);
    }

    public Class_rk_bf8630d1 RY() {
        return this.ormBS;
    }

    public Class_rk_bf8630d1 RZ() {
        return this.KgDVz;
    }

    public boolean Sf() {
        return this.vCMYc;
    }

    public float Sh() {
        return this.lGacw;
    }

    public Class_cC_14ef8bb5 Sn() {
        return this.WUOUc;
    }

    public Class_cr_3ba4ae18 Sp(float f) {
        this.QWaAn = f;
        return this;
    }

    public Class_cr_3ba4ae18 Sq(float f) {
        this.jTsqG = f;
        return this;
    }

    protected abstract void NV(Class_lC_5322e8cf var1);

    public boolean RQ(Class_lC_5322e8cf class_lC_5322e8cf) {
        return this.RP(this.RR(class_lC_5322e8cf.cff()), this.RS(class_lC_5322e8cf.cfg()));
    }

    public Class_rk_bf8630d1 Sa() {
        return this.gILqY;
    }

    public double RS(double d) {
        return (double)this.QWaAn + (d - (double)this.QWaAn) / (double)this.RT();
    }

    public Class_rk_bf8630d1 Sd() {
        return this.iArvU;
    }

    public int[] Sl() {
        return this.eqWHC;
    }

    public Class_cr_3ba4ae18 Sr(float f) {
        this.Xtjvx = f;
        return this;
    }

    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        block9: {
            boolean bl;
            float f;
            float f2;
            Class_iS_888f260e[] class_iS_888f260eArray;
            block8: {
                long l = yIaJZ ^ 0x60D2A8E341A7L;
                Vec2f vec2f = Class_rm_d861be3b.dip();
                class_iS_888f260eArray = Class_cr_3ba4ae18.SC();
                float f3 = this.iArvU.dhd(this.jTsqG);
                float f4 = this.RT();
                f2 = f3 * f4;
                f = this.Xtjvx * f4;
                this.jTsqG = f3;
                this.gILqY.dhc(this.pAjuu);
                this.ormBS.dhs(this.LkpAS ? Class_rj_b691f4f7.XzDkv : Class_rj_b691f4f7.AYqck);
                this.ormBS.dhc(this.LkpAS);
                this.KgDVz.dhs(this.Om() ? Class_rj_b691f4f7.XzDkv : Class_rj_b691f4f7.AYqck);
                this.KgDVz.dhc(this.Om());
                this.OsbYH.dhc(this.vCMYc);
                bl = this.pAjuu;
                if (class_iS_888f260eArray == null) break block8;
                if (!bl) break block9;
                this.toIeR = MathHelper.clamp((float)((float)class_lC_5322e8cf.cff() - this.lGacw), (float)0.0f, (float)(vec2f.x - f2));
                this.QWaAn = MathHelper.clamp((float)((float)class_lC_5322e8cf.cfg() - this.WjFpo), (float)0.0f, (float)(vec2f.y - f));
                bl = Class_rr_be159084.diY((int)Class_cr_3ba4ae18.SK("h", (int)5942, (long)(0x72125F24498A04AFL ^ l)));
            }
            boolean bl2 = bl;
            Class_rk_bf8630d1 class_rk_bf8630d1 = ClientMain.dlK().RB().QQ();
            boolean bl3 = bl2;
            if (class_iS_888f260eArray != null) {
                bl3 = !bl3;
            }
            class_rk_bf8630d1.dhc(bl3);
            if (bl2) {
                return;
            }
            for (Class_ck_d3c7acd5 class_ck_d3c7acd5 : ClientMain.dlK().RB().QP()) {
                if (class_iS_888f260eArray != null) {
                    if (class_ck_d3c7acd5.QF() == Class_cl_0655ee76.zjBim) {
                        this.toIeR = this.RN(class_ck_d3c7acd5, this.toIeR, List.of(Float.valueOf(0.0f), Float.valueOf(f2), Float.valueOf(f2 / 2.0f)), List.of(Float.valueOf(0.0f), Float.valueOf(-f2), Float.valueOf(-f2 / 2.0f)));
                        if (class_iS_888f260eArray != null) continue;
                    }
                    this.QWaAn = this.RN(class_ck_d3c7acd5, this.QWaAn, List.of(Float.valueOf(0.0f), Float.valueOf(f)), List.of(Float.valueOf(0.0f), Float.valueOf(-f)));
                }
                if (class_iS_888f260eArray != null) continue;
            }
        }
    }

    public Class_cr_3ba4ae18 RO(float f, float f2) {
        this.toIeR = f;
        this.QWaAn = f2;
        return this;
    }

    private static MatchException SD(MatchException matchException) {
        return matchException;
    }

    public Class_cr_3ba4ae18 Ss(boolean bl) {
        this.LkpAS = bl;
        return this;
    }

    public Class_cr_3ba4ae18 St(boolean bl) {
        this.vCMYc = bl;
        return this;
    }

    public Class_cr_3ba4ae18 Su(boolean bl) {
        this.pAjuu = bl;
        return this;
    }

    public boolean Sg() {
        return this.pAjuu;
    }

    public Class_cr_3ba4ae18 Sv(float f) {
        this.lGacw = f;
        return this;
    }

    public Class_cr_3ba4ae18 Sw(float f) {
        this.WjFpo = f;
        return this;
    }

    public Class_cr_3ba4ae18 Sx(float f) {
        this.TSvLw = f;
        return this;
    }

    public Class_cr_3ba4ae18 Sy(float f) {
        this.VngMS = f;
        return this;
    }

    public float RX() {
        return this.QWaAn;
    }

    private static int SJ(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_cr_3ba4ae18.SI(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public float RU() {
        return this.jTsqG * this.RT();
    }

    public boolean Om() {
        return true;
    }

    public boolean Se() {
        return this.LkpAS;
    }

    public float RV() {
        return this.Xtjvx * this.RT();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean onMouseClicked(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        long l = yIaJZ ^ 0x7F1AB2301C4FL;
        boolean bl = this.RP(d, d2);
        Class_iS_888f260e[] class_iS_888f260eArray = Class_cr_3ba4ae18.SC();
        boolean bl2 = bl;
        if (class_iS_888f260eArray == null) return bl2;
        if (!bl2) return false;
        bl2 = this.LkpAS;
        if (class_iS_888f260eArray == null) return bl2;
        if (!bl2) return false;
        Class_mA_32d8a5f2 class_mA_32d8a5f22 = class_mA_32d8a5f2;
        Class_mA_32d8a5f2 class_mA_32d8a5f23 = Class_mA_32d8a5f2.sCBUa;
        if (class_iS_888f260eArray != null) {
            if (class_mA_32d8a5f22 == class_mA_32d8a5f23) {
                Class_cr_3ba4ae18 class_cr_3ba4ae18 = this;
                if (class_iS_888f260eArray != null) {
                    if (class_cr_3ba4ae18 instanceof Class_bU_714b1dad) {
                        return false;
                    }
                    this.pAjuu = true;
                    class_cr_3ba4ae18 = this;
                }
                float f = class_cr_3ba4ae18.RT();
                this.lGacw = (float)(d - (double)this.toIeR) * f;
                this.WjFpo = (float)(d2 - (double)this.QWaAn) * f;
                this.TSvLw = this.toIeR;
                this.VngMS = this.QWaAn;
                return true;
            }
            class_mA_32d8a5f22 = class_mA_32d8a5f2;
            class_mA_32d8a5f23 = Class_mA_32d8a5f2.frWTZ;
        }
        if (class_mA_32d8a5f22 != class_mA_32d8a5f23) return false;
        this.pAjuu = false;
        this.vCMYc = true;
        this.AyAnj.dhg();
        float f = this.toIeR + (float)(d - (double)this.toIeR) * this.RT();
        float f2 = this.QWaAn + (float)(d2 - (double)this.QWaAn) * this.RT();
        Class_ap_f3b7a87f class_ap_f3b7a87f = new Class_ap_f3b7a87f(f, f2, 110.0f, 6.0f).pW((String)((Object)(this.oZllQ.isEmpty() ? Class_cr_3ba4ae18.SH("u", (int)31643, (long)(0x5F4E0899FF911891L ^ l)) : Class_cr_3ba4ae18.SH("u", (int)3802, (long)(0x2CE150DF83CEEDD1L ^ l))))).qq();
        for (Class_cB_67aec11c class_cB_67aec11c : this.oZllQ) {
            class_ap_f3b7a87f.pU(class_cB_67aec11c);
            if (class_iS_888f260eArray == null) return true;
            if (class_iS_888f260eArray != null) continue;
        }
        class_ap_f3b7a87f.qn((String)((Object)Class_cr_3ba4ae18.SH("u", (int)6072, (long)(0x59099E596AC2F4B1L ^ l))), Class_lf_d247d983.JHGge, Class_jk_a0800133.mPXGi, Class_jk_a0800133.mPXGi, class_aj_95d0a719 -> {
            this.LkpAS = false;
            class_aj_95d0a719.oj(false);
        }).qo(() -> {
            this.vCMYc = false;
        });
        ClientMain.dlK().Rs(class_ap_f3b7a87f);
        return true;
    }

    @Override
    public boolean onMouseReleased(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        long l = yIaJZ ^ 0x16737CF5A1E2L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_cr_3ba4ae18.SC();
        boolean bl = this.pAjuu;
        if (class_iS_888f260eArray != null) {
            if (bl && class_mA_32d8a5f2 == Class_mA_32d8a5f2.sCBUa) {
                this.pAjuu = false;
            }
            bl = false;
        }
        return bl;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cr_3ba4ae18.class, "SG", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_cr_3ba4ae18.class, "SJ", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

