/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bz_8cac7329;
import recovered.internal.Class_f_2512a74f;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;

class Class_bz_sh_3463383a
extends Class_az_a4990dcf {
    final Class_bz_8cac7329 nIiHX;
    private static long lEAqJ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native void _64228e79e0c8f9e7d25bb01595af0630();

    Class_bz_sh_3463383a(Class_bz_8cac7329 class_bz_8cac7329) {
        this.nIiHX = class_bz_8cac7329;
    }

    static {
        NativeLoader.doInit(Class_bz_sh_3463383a.class);
        Class_bz_sh_3463383a._64228e79e0c8f9e7d25bb01595af0630();
    }

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean dm(int var1, int var2, int var3);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean fC(double var1, double var3, double var5);

    @Override
    public native void sA(Class_f_2512a74f var1);

    @Override
    protected native boolean nZ();

    private static native MatchException dnv(MatchException var0);
}

