/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderPass
 *  com.mojang.blaze3d.textures.GpuTextureView
 *  com.mojang.blaze3d.vertex.VertexFormat$DrawMode
 *  net.minecraft.client.gl.GpuSampler
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.texture.AbstractTexture
 *  net.minecraft.client.util.BufferAllocator
 */
package recovered.internal;

import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.util.BufferAllocator;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jL_e8aba6a1;
import recovered.internal.Class_jN_f0c1545a;
import recovered.internal.Class_jS_9dae0bf7;
import recovered.internal.Class_jT_87816f30;
import recovered.internal.Class_kR_e9b8cad1;
import recovered.internal.Class_ke_512fbaf0;
import recovered.internal.Class_kh_19daf527;
import recovered.internal.Class_lF_27593463;
import recovered.internal.Class_la_8f67ae40;
import recovered.internal.Class_lt_a3a39a2f;

public class Class_ka_729da68f
implements Class_kh_19daf527<Class_jS_9dae0bf7> {
    private static final long Svclk;
    private static final String[] KqBiZ;
    private static final String[] nkwQm;
    private static final Map FWlbV;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_ka_729da68f.Svclk = Class_gb_9d201141.aYR(800389536625626810L, -8325731754206593775L, MethodHandles.lookup().lookupClass()).a(229622370642876L);
                Class_ka_729da68f.FWlbV = new HashMap<K, V>(13);
                var0 = Class_ka_729da68f.Svclk ^ 23220963582867L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[13];
                var7_4 = 0;
                var6_5 = "v\u0099Y7w\u0099\u00ca\u001b~B2\u00cf>k\u00be\u009d\u0096\u00e1\u00e9\u0013\u00f2Kg\u00e3\u00c0U\u00a5\u008e7\u0096v\u0003\u0018\u00d7\u00b9\u00bc\u00e5\u0005X\n\u00ae\u00b8\u00f1m)01\u0085e\u001d6zd\u00d2\u00ff\u0019\u0090 \u00bea\u00ba\u009ch\u00ffS\u00f5\u00de\u00fe\u00c7Ny~r\u00f8(\u0099\u00a8=\u001a\u00b3\u009cg\u0014\u0010T\f|A\u008b\u0086\u00185l\u00fa\u00b6\u00c0-\u00ddH\u000bx5\u0000C\u00fbD\u0082\u00ac\b\u00b2\u00a1\u00d0\u00a8\u00927 \u00ce\"\u00800&\u0016\u00b9\u0092\u00aa\u00f4\u00fe\u00acV\u00c3b[\u00cd\u00f8\u00ee\u00e2\u0098Z\u0090\u00cf\n\u0016\u008dT\u0083\u00e5\u008ci \u001a\u00cd\u00ba\u00d6\u00a3\u00f0\\\u00a7F\u00bank\u0088\u00e8\u0089\u000e\u0091\u00a5$\r\u0091\u00f2\u00c8\"Y\u00b4F\u0012K\u00e1\u00a9r \u00day\u0011\u00c5q\u0086\u0018\u000fI\u001c\"\u00b3[$\u00cd\u00b4(\u00fc\u00a3\u00ac\u0006\u00a6\u00f8\u00c0\u00ff\u0095\u00c4\u007f\u0084\u009f\u00f66\u0018\u00d2oh\u0017c{\u00ab\u00c5\u00fd]\u00d0\u00de\u009c\u009236#\u00d4j\u00ab\u008e\u00f3\u0001e `m\u009f\t\u0014$\u0012\u0084G\u00bc\\9\u0010f\u00b1\u00fd\u0094677\u0087\u00d37\u0007\u0094h\u008f\u000f\u00c2\b\u00b4\u00ae\u0018YLJ[@\u00ed\u0094\tI5\u00b3\u0013\u00dfi\u00f2\u00ad\u00f3-C_\u00e4g\u00d9\u0091 \u0013M\u00d7\u00c5+\u008f,\u0001\u00b0X\u00e1\u00c5\u00a3\u0085\u0086(\u00ef\u00eb\u00ee\u00cf\u00ca$Gt?\u00dbu\u0081J.\u0093\\";
                var8_6 = "v\u0099Y7w\u0099\u00ca\u001b~B2\u00cf>k\u00be\u009d\u0096\u00e1\u00e9\u0013\u00f2Kg\u00e3\u00c0U\u00a5\u008e7\u0096v\u0003\u0018\u00d7\u00b9\u00bc\u00e5\u0005X\n\u00ae\u00b8\u00f1m)01\u0085e\u001d6zd\u00d2\u00ff\u0019\u0090 \u00bea\u00ba\u009ch\u00ffS\u00f5\u00de\u00fe\u00c7Ny~r\u00f8(\u0099\u00a8=\u001a\u00b3\u009cg\u0014\u0010T\f|A\u008b\u0086\u00185l\u00fa\u00b6\u00c0-\u00ddH\u000bx5\u0000C\u00fbD\u0082\u00ac\b\u00b2\u00a1\u00d0\u00a8\u00927 \u00ce\"\u00800&\u0016\u00b9\u0092\u00aa\u00f4\u00fe\u00acV\u00c3b[\u00cd\u00f8\u00ee\u00e2\u0098Z\u0090\u00cf\n\u0016\u008dT\u0083\u00e5\u008ci \u001a\u00cd\u00ba\u00d6\u00a3\u00f0\\\u00a7F\u00bank\u0088\u00e8\u0089\u000e\u0091\u00a5$\r\u0091\u00f2\u00c8\"Y\u00b4F\u0012K\u00e1\u00a9r \u00day\u0011\u00c5q\u0086\u0018\u000fI\u001c\"\u00b3[$\u00cd\u00b4(\u00fc\u00a3\u00ac\u0006\u00a6\u00f8\u00c0\u00ff\u0095\u00c4\u007f\u0084\u009f\u00f66\u0018\u00d2oh\u0017c{\u00ab\u00c5\u00fd]\u00d0\u00de\u009c\u009236#\u00d4j\u00ab\u008e\u00f3\u0001e `m\u009f\t\u0014$\u0012\u0084G\u00bc\\9\u0010f\u00b1\u00fd\u0094677\u0087\u00d37\u0007\u0094h\u008f\u000f\u00c2\b\u00b4\u00ae\u0018YLJ[@\u00ed\u0094\tI5\u00b3\u0013\u00dfi\u00f2\u00ad\u00f3-C_\u00e4g\u00d9\u0091 \u0013M\u00d7\u00c5+\u008f,\u0001\u00b0X\u00e1\u00c5\u00a3\u0085\u0086(\u00ef\u00eb\u00ee\u00cf\u00ca$Gt?\u00dbu\u0081J.\u0093\\".length();
                var5_7 = 32;
                var4_8 = -1;
lbl20:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl25:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_ka_729da68f.bNW(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "\u00a5\u009a\u00e9a\u0080\u00c1\u009d>\u009c\u00ba@\u00fa\u00c49\u0007;\u00bd\u00fd~{\u00d7\u00f4\u008b\u00a7\u0012\u009f\bsK\u001b*\u0087\u0010}\u00ab\u00f7\u00a9i&\u001f\u00eb\u00b2\u0018\u00fc\u00d6-0*2";
                    var8_6 = "\u00a5\u009a\u00e9a\u0080\u00c1\u009d>\u009c\u00ba@\u00fa\u00c49\u0007;\u00bd\u00fd~{\u00d7\u00f4\u008b\u00a7\u0012\u009f\bsK\u001b*\u0087\u0010}\u00ab\u00f7\u00a9i&\u001f\u00eb\u00b2\u0018\u00fc\u00d6-0*2".length();
                    var5_7 = 32;
                    var4_8 = -1;
lbl34:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_ka_729da68f.bNW(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl51:
                // 1 sources

                ** continue;
            }
        }
        Class_ka_729da68f.KqBiZ = var9_3;
        Class_ka_729da68f.nkwQm = new String[13];
    }

    /*
     * Unable to fully structure code
     */
    public void bNR(Class_jS_9dae0bf7 var1_1) {
        block17: {
            var2_2 = Class_ka_729da68f.Svclk ^ 22889794249675L;
            var5_3 = var1_1.bMB();
            var4_4 = Class_jT_87816f30.bMQ();
            var6_5 = var1_1.bMx();
            v0 = var5_3.cnW();
            if (var4_4) {
                if (v0 && var6_5 == null) {
                    return;
                }
                v0 = var1_1.bMb();
            }
            var7_6 = v0;
            var8_7 = this.bNS(var1_1);
            var9_8 = this.bNT(var1_1);
            if (var7_6 && var8_7 == null) {
                return;
            }
            var10_9 = new BufferAllocator(VertexFormats.POSITION_TEXTURE_COLOR.getVertexSize() * 4);
            try {
                var11_10 = new BufferBuilder(var10_9, VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
                Class_ka_729da68f.FroVm.uv_quad_region_color(var11_10, var1_1.bMo(), var1_1.bMp(), var1_1.bMq(), var1_1.bMr(), var1_1.bMs(), var1_1.bMH(), var1_1.bMI(), var1_1.bMJ(), var1_1.bMK(), var5_3);
                var12_12 = var11_10.end();
                try {
                    Class_lF_27593463.cfB(var7_6 != false ? Class_kR_e9b8cad1.cdFxE : Class_kR_e9b8cad1.cHZhA, var12_12, (Consumer<RenderPass>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, bNU(boolean com.mojang.blaze3d.textures.GpuTextureView net.minecraft.client.gl.GpuSampler recovered.internal.Class_jS_9dae0bf7 recovered.internal.Class_la_8f67ae40 com.mojang.blaze3d.systems.RenderPass ), (Lcom/mojang/blaze3d/systems/RenderPass;)V)((boolean)var7_6, (GpuTextureView)var8_7, (GpuSampler)var9_8, (Class_jS_9dae0bf7)var1_1, (Class_la_8f67ae40)var6_5));
                    if (!var4_4) break block17;
                    ** if (var12_12 == null) goto lbl-1000
                }
                catch (Throwable var13_14) {
                    block18: {
                        v1 = var12_12;
                        if (!var4_4) ** GOTO lbl32
                        if (v1 == null) break block18;
                        try {
                            v1 = var12_12;
lbl32:
                            // 2 sources

                            v1.close();
                        }
                        catch (Throwable var14_15) {
                            var13_14.addSuppressed(var14_15);
                        }
                    }
                    throw var13_14;
                }
lbl-1000:
                // 1 sources

                {
                    var12_12.close();
                }
lbl-1000:
                // 2 sources

                {
                }
            }
            catch (Throwable var11_11) {
                try {
                    var10_9.close();
                }
                catch (Throwable var12_13) {
                    var11_11.addSuppressed(var12_13);
                }
                throw var11_11;
            }
            var10_9.close();
        }
        if (Class_iS_888f260e.bwL() == null) {
            Class_jT_87816f30.bMP(var4_4 == false);
        }
    }

    private static CallSite bNZ(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_ka_729da68f" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static Throwable bNV(Throwable throwable) {
        return throwable;
    }

    private GpuSampler bNT(Class_jS_9dae0bf7 class_jS_9dae0bf7) {
        GpuSampler gpuSampler;
        boolean bl;
        block5: {
            AbstractTexture abstractTexture;
            block4: {
                long l = Svclk ^ 0x6EBE1EC93500L;
                AbstractTexture abstractTexture2 = class_jS_9dae0bf7.bMy();
                bl = Class_jT_87816f30.bMQ();
                abstractTexture = abstractTexture2;
                if (!bl) break block4;
                if (abstractTexture == null) break block5;
                abstractTexture = abstractTexture2;
            }
            return abstractTexture.getSampler();
        }
        GpuSampler gpuSampler2 = gpuSampler = class_jS_9dae0bf7.bMA();
        if (bl) {
            gpuSampler2 = gpuSampler2 == null ? Class_lt_a3a39a2f.caX() : gpuSampler;
        }
        return gpuSampler2;
    }

    private static /* synthetic */ void bNU(boolean bl, GpuTextureView gpuTextureView, GpuSampler gpuSampler, Class_jS_9dae0bf7 class_jS_9dae0bf7, Class_la_8f67ae40 class_la_8f67ae40, RenderPass renderPass) {
        block9: {
            Class_jN_f0c1545a class_jN_f0c1545a;
            block8: {
                long l = Svclk ^ 0x21D49BC6B0D5L;
                boolean bl2 = Class_jT_87816f30.bMQ();
                if (bl2) {
                    if (bl) {
                        renderPass.bindTexture((String)((Object)Class_ka_729da68f.bNZ("z", (int)4993, (long)(0x1279ECC582BB07A6L ^ l))), gpuTextureView, gpuSampler);
                    }
                    Class_jL_e8aba6a1.OHwYv.bJl();
                    Class_jL_e8aba6a1.OHwYv.bJr((String)((Object)Class_ka_729da68f.bNZ("z", (int)1144, (long)(0x5AF911C60C0B9053L ^ l))), class_jS_9dae0bf7.bMr(), class_jS_9dae0bf7.bMs());
                    Class_jL_e8aba6a1.OHwYv.bJq((String)((Object)Class_ka_729da68f.bNZ("z", (int)29971, (long)(0x64DCB0732F27613EL ^ l))), class_jS_9dae0bf7.bMt());
                    Class_jL_e8aba6a1.OHwYv.bJq((String)((Object)Class_ka_729da68f.bNZ("z", (int)12115, (long)(0x3C19BB6A93863B7FL ^ l))), class_jS_9dae0bf7.bMu());
                    Class_jL_e8aba6a1.OHwYv.bJq((String)((Object)Class_ka_729da68f.bNZ("z", (int)22567, (long)(0x3C1E529555864C07L ^ l))), class_jS_9dae0bf7.bMv());
                    Class_jL_e8aba6a1.OHwYv.bJq((String)((Object)Class_ka_729da68f.bNZ("z", (int)23864, (long)(0x739E61961E3E4919L ^ l))), class_jS_9dae0bf7.bMw());
                    Class_jL_e8aba6a1.OHwYv.bJq((String)((Object)Class_ka_729da68f.bNZ("z", (int)30207, (long)(0x3BE6EBEF6161DDL ^ l))), class_jS_9dae0bf7.bMC());
                }
                CallSite callSite = Class_ka_729da68f.bNZ("z", (int)17933, (long)(0xCFF01FB50A55223L ^ l));
                int n = bl;
                if (bl2) {
                    n = n != 0 ? 1 : 0;
                }
                Class_jL_e8aba6a1.OHwYv.bJx((String)((Object)callSite), n);
                CallSite callSite2 = Class_ka_729da68f.bNZ("z", (int)13737, (long)(0x25A6C2992002A18AL ^ l));
                int n2 = class_jS_9dae0bf7.bME();
                if (bl2) {
                    n2 = n2 != 0 ? 1 : 0;
                }
                Class_jL_e8aba6a1.OHwYv.bJx((String)((Object)callSite2), n2);
                Class_jL_e8aba6a1.OHwYv.bJx((String)((Object)Class_ka_729da68f.bNZ("z", (int)9366, (long)(0x2F2EBFCDBD5F30B2L ^ l))), class_la_8f67ae40 == null ? 0 : 1);
                CallSite callSite3 = Class_ka_729da68f.bNZ("z", (int)4822, (long)(0x1B1974F83B7086F0L ^ l));
                int n3 = class_jS_9dae0bf7.bMD();
                if (bl2) {
                    n3 = n3 != 0 ? 1 : 0;
                }
                Class_jL_e8aba6a1.OHwYv.bJx((String)((Object)callSite3), n3);
                Class_jL_e8aba6a1.OHwYv.bJr((String)((Object)Class_ka_729da68f.bNZ("z", (int)32567, (long)(0xD4D1CCAF03B6B18L ^ l))), class_jS_9dae0bf7.bMF(), class_jS_9dae0bf7.bMG());
                class_jN_f0c1545a = Class_jL_e8aba6a1.OHwYv;
                if (!bl2) break block8;
                class_jN_f0c1545a.bJu((String)((Object)Class_ka_729da68f.bNZ("z", (int)29146, (long)(0x5AA3B778777FE5FFL ^ l))), Class_jF_38b68c76.bHw());
                if (class_la_8f67ae40 == null) break block9;
                class_jN_f0c1545a = Class_jL_e8aba6a1.OHwYv;
            }
            Class_ke_512fbaf0.bOl(class_jN_f0c1545a, class_la_8f67ae40);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private GpuTextureView bNS(Class_jS_9dae0bf7 class_jS_9dae0bf7) {
        GpuTextureView gpuTextureView;
        long l = Svclk ^ 0x3FA6A5E10C2CL;
        AbstractTexture abstractTexture = class_jS_9dae0bf7.bMy();
        boolean bl = Class_jT_87816f30.bMQ();
        AbstractTexture abstractTexture2 = abstractTexture;
        if (bl) {
            if (abstractTexture2 == null) {
                gpuTextureView = class_jS_9dae0bf7.bMz();
                return gpuTextureView;
            }
            abstractTexture2 = abstractTexture;
        }
        gpuTextureView = abstractTexture2.getGlTextureView();
        return gpuTextureView;
    }

    private static String bNW(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static String bNX(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x1FB5;
        if (nkwQm[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])FWlbV.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    FWlbV.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_ka_729da68f", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = KqBiZ[n2].getBytes("ISO-8859-1");
            Class_ka_729da68f.nkwQm[n2] = Class_ka_729da68f.bNW(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return nkwQm[n2];
    }

    private static Object bNY(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_ka_729da68f.bNX(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_ka_729da68f.class, "bNY", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

