/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderPass
 *  com.mojang.blaze3d.vertex.VertexFormat$DrawMode
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.util.BufferAllocator
 */
package recovered.internal;

import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jL_e8aba6a1;
import recovered.internal.Class_jO_1924117a;
import recovered.internal.Class_jT_87816f30;
import recovered.internal.Class_kR_e9b8cad1;
import recovered.internal.Class_ke_512fbaf0;
import recovered.internal.Class_kh_19daf527;
import recovered.internal.Class_lF_27593463;
import recovered.internal.Class_la_8f67ae40;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mG_52c8d386;

public class Class_jW_18c0e1dc
implements Class_kh_19daf527<Class_jO_1924117a> {
    private static final long LJoTc;
    private static final String[] xudpm;
    private static final String[] zqpdo;
    private static final Map GcFSr;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_jW_18c0e1dc.LJoTc = Class_gb_9d201141.aYR(-4751435363820668798L, 5791048156308862445L, MethodHandles.lookup().lookupClass()).a(184724111238064L);
                Class_jW_18c0e1dc.GcFSr = new HashMap<K, V>(13);
                var0 = Class_jW_18c0e1dc.LJoTc ^ 100620001438449L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[6];
                var7_4 = 0;
                var6_5 = "j\u0086'\u0080+V\u0018z\u00a0\u0018\u00b4P\u009d\u0092\u00cf\u00a9 w\u001e\r\u0089}EQ6kt\u0005\u00fdb\u00cf\u0014\u00f8\u0000J\u00a5\t-SB\u0015\u00ca\u00d5\u00bb}\u00f2\u00a2k\u0091\u0010\u00d1\u00e17\u00cc3wN\u00a7 \u0002[fc!pt \u001d\u0081MF\u0092H\u00e4\u008b\u009e\u0097\u007f\u008b\f\u00a7s\u00b4m\u00f7\u00b5\u00e0\u00ed,d_>Z\u00ff\u00d4\u0091\u00c1w\u00e9";
                var8_6 = "j\u0086'\u0080+V\u0018z\u00a0\u0018\u00b4P\u009d\u0092\u00cf\u00a9 w\u001e\r\u0089}EQ6kt\u0005\u00fdb\u00cf\u0014\u00f8\u0000J\u00a5\t-SB\u0015\u00ca\u00d5\u00bb}\u00f2\u00a2k\u0091\u0010\u00d1\u00e17\u00cc3wN\u00a7 \u0002[fc!pt \u001d\u0081MF\u0092H\u00e4\u008b\u009e\u0097\u007f\u008b\f\u00a7s\u00b4m\u00f7\u00b5\u00e0\u00ed,d_>Z\u00ff\u00d4\u0091\u00c1w\u00e9".length();
                var5_7 = 16;
                var4_8 = -1;
lbl20:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl25:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jW_18c0e1dc.bNv(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "B\u008es\u00de\u001b\u00fc\u0003\u00a4\u00f7.5\u00aa\u0017\u009a\u00a8\t\u0084I9\u001b\u000b\u0097\u00ef\u008e\u00ab\u00ce\u00c6\u00fe\\\u001d\u00e3U C*\bw\u008b\u0012\u00cf\u00a9\u00801\u00b2\u00c1Pc5I\u00cb\u009a\u0085N\u00a4\u0098\u0093\u00fej\u00b2\u0090\u00b7\u00cf$\f\u00c6";
                    var8_6 = "B\u008es\u00de\u001b\u00fc\u0003\u00a4\u00f7.5\u00aa\u0017\u009a\u00a8\t\u0084I9\u001b\u000b\u0097\u00ef\u008e\u00ab\u00ce\u00c6\u00fe\\\u001d\u00e3U C*\bw\u008b\u0012\u00cf\u00a9\u00801\u00b2\u00c1Pc5I\u00cb\u009a\u0085N\u00a4\u0098\u0093\u00fej\u00b2\u0090\u00b7\u00cf$\f\u00c6".length();
                    var5_7 = 32;
                    var4_8 = -1;
lbl34:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jW_18c0e1dc.bNv(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl51:
                // 1 sources

                ** continue;
            }
        }
        Class_jW_18c0e1dc.xudpm = var9_3;
        Class_jW_18c0e1dc.zqpdo = new String[6];
    }

    public void bNn(Class_jO_1924117a class_jO_1924117a) {
        long l = LJoTc ^ 0x6FCC7400F5CAL;
        boolean bl = Class_jT_87816f30.bMQ();
        Class_jW_18c0e1dc class_jW_18c0e1dc = this;
        Class_jO_1924117a class_jO_1924117a2 = class_jO_1924117a;
        if (bl) {
            if (class_jW_18c0e1dc.bNr(class_jO_1924117a2)) {
                this.bNo(class_jO_1924117a);
            }
            class_jW_18c0e1dc = this;
            class_jO_1924117a2 = class_jO_1924117a;
        }
        class_jW_18c0e1dc.bNp(class_jO_1924117a2);
    }

    /*
     * Unable to fully structure code
     */
    private void bNp(Class_jO_1924117a var1_1) {
        var2_2 = Class_jW_18c0e1dc.LJoTc ^ 118026128184716L;
        var5_3 = new BufferAllocator(VertexFormats.POSITION_TEXTURE_COLOR.getVertexSize() * 4);
        var4_4 = Class_jT_87816f30.bMQ();
        try {
            var6_5 = new BufferBuilder(var5_3, VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            this.bNq(var6_5, var1_1, var1_1.bKi());
            var7_7 = var6_5.end();
            try {
                Class_lF_27593463.cfB(Class_kR_e9b8cad1.cbSJp, var7_7, (Consumer<RenderPass>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, bNs(recovered.internal.Class_jO_1924117a com.mojang.blaze3d.systems.RenderPass ), (Lcom/mojang/blaze3d/systems/RenderPass;)V)((Class_jO_1924117a)var1_1));
                ** if (!var4_4 || var7_7 == null) goto lbl-1000
            }
            catch (Throwable var8_9) {
                block15: {
                    v0 = var7_7;
                    if (!var4_4) ** GOTO lbl19
                    if (v0 == null) break block15;
                    try {
                        v0 = var7_7;
lbl19:
                        // 2 sources

                        v0.close();
                    }
                    catch (Throwable var9_10) {
                        var8_9.addSuppressed(var9_10);
                    }
                }
                throw var8_9;
            }
lbl-1000:
            // 1 sources

            {
                var7_7.close();
            }
lbl-1000:
            // 2 sources

            {
            }
        }
        finally {
            var5_3.close();
        }
    }

    private static Object bNx(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_jW_18c0e1dc.bNw(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    /*
     * Unable to fully structure code
     */
    private void bNo(Class_jO_1924117a var1_1) {
        var2_2 = Class_jW_18c0e1dc.LJoTc ^ 97484327513161L;
        var5_3 = new BufferAllocator(VertexFormats.POSITION_TEXTURE_COLOR.getVertexSize() * 4);
        var4_4 = Class_jT_87816f30.bMQ();
        try {
            var6_5 = new BufferBuilder(var5_3, VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            this.bNq(var6_5, var1_1, Class_mG_52c8d386.hoGuU);
            var7_7 = var6_5.end();
            try {
                Class_lF_27593463.cfB(Class_kR_e9b8cad1.ippae, var7_7, (Consumer<RenderPass>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, bNt(recovered.internal.Class_jO_1924117a com.mojang.blaze3d.systems.RenderPass ), (Lcom/mojang/blaze3d/systems/RenderPass;)V)((Class_jO_1924117a)var1_1));
                ** if (!var4_4 || var7_7 == null) goto lbl-1000
            }
            catch (Throwable var8_9) {
                block15: {
                    v0 = var7_7;
                    if (!var4_4) ** GOTO lbl19
                    if (v0 == null) break block15;
                    try {
                        v0 = var7_7;
lbl19:
                        // 2 sources

                        v0.close();
                    }
                    catch (Throwable var9_10) {
                        var8_9.addSuppressed(var9_10);
                    }
                }
                throw var8_9;
            }
lbl-1000:
            // 1 sources

            {
                var7_7.close();
            }
lbl-1000:
            // 2 sources

            {
            }
        }
        finally {
            var5_3.close();
        }
    }

    private static String bNw(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x3D81;
        if (zqpdo[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])GcFSr.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    GcFSr.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jW_18c0e1dc", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = xudpm[n2].getBytes("ISO-8859-1");
            Class_jW_18c0e1dc.zqpdo[n2] = Class_jW_18c0e1dc.bNv(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return zqpdo[n2];
    }

    private static Throwable bNu(Throwable throwable) {
        return throwable;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean bNr(Class_jO_1924117a class_jO_1924117a) {
        long l = LJoTc ^ 0x207DF696277EL;
        boolean bl = Class_jT_87816f30.bMQ();
        Class_jO_1924117a class_jO_1924117a2 = class_jO_1924117a;
        if (bl) {
            if (!class_jO_1924117a2.bJG()) {
                return class_jO_1924117a.bKi().cnW();
            }
            class_jO_1924117a2 = class_jO_1924117a;
        }
        Class_la_8f67ae40 class_la_8f67ae40 = class_jO_1924117a2.bKj();
        int n = class_la_8f67ae40.bWQ();
        if (bl) {
            if (n == 0) {
                boolean bl2 = class_la_8f67ae40.bXe().cnW();
                if (!bl) return bl2;
                if (bl2) return true;
                bl2 = class_la_8f67ae40.bXf().cnW();
                if (!bl) return bl2;
                if (bl2) return true;
                bl2 = class_la_8f67ae40.bXg().cnW();
                if (!bl) return bl2;
                if (bl2) return true;
                bl2 = class_la_8f67ae40.bXh().cnW();
                if (!bl) return bl2;
                if (!bl2) return false;
                return true;
            }
            n = 0;
        }
        int n2 = n;
        do {
            if (n2 >= class_la_8f67ae40.bWR()) return false;
            boolean bl3 = class_la_8f67ae40.bWS(n2).cnW();
            if (!bl) return bl3;
            if (!bl) boolean bl4;
            return bl4;
            if (bl3) {
                return true;
            }
            ++n2;
        } while (bl);
        return false;
    }

    private void bNq(BufferBuilder bufferBuilder, Class_jO_1924117a class_jO_1924117a, Class_mG_52c8d386 class_mG_52c8d386) {
        float f = class_jO_1924117a.bKb();
        float f2 = class_jO_1924117a.bKc();
        float f3 = class_jO_1924117a.bKd();
        float f4 = class_jO_1924117a.bKe();
        float f5 = Math.max(1.0f, class_jO_1924117a.bKm());
        float f6 = class_jO_1924117a.bKt() - f5 / f3;
        float f7 = class_jO_1924117a.bKu() - f5 / f4;
        float f8 = class_jO_1924117a.bKv() + f5 / f3;
        float f9 = class_jO_1924117a.bKw() + f5 / f4;
        FroVm.uv_quad_region_color(bufferBuilder, class_jO_1924117a.bKa(), f - f5, f2 - f5, f3 + f5 * 2.0f, f4 + f5 * 2.0f, f6, f7, f8, f9, class_mG_52c8d386);
    }

    private static String bNv(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static /* synthetic */ void bNt(Class_jO_1924117a class_jO_1924117a, RenderPass renderPass) {
        long l = LJoTc ^ 0x7769C016A13BL;
        Class_ld_bb1690e1 class_ld_bb1690e1 = class_jO_1924117a.bKh();
        Class_jL_e8aba6a1.cazyD.bJl();
        Class_jL_e8aba6a1.cazyD.bJr((String)((Object)Class_jW_18c0e1dc.bNy("k", (int)15476, (long)(0x7887241C762E17D9L ^ l))), class_jO_1924117a.bKd(), class_jO_1924117a.bKe());
        Class_jL_e8aba6a1.cazyD.bJt((String)((Object)Class_jW_18c0e1dc.bNy("k", (int)18233, (long)(0x78F5D7903DA3EC96L ^ l))), class_ld_bb1690e1.topLeft(), class_ld_bb1690e1.bottomLeft(), class_ld_bb1690e1.topRight(), class_ld_bb1690e1.bottomRight());
        Class_jL_e8aba6a1.cazyD.bJq((String)((Object)Class_jW_18c0e1dc.bNy("k", (int)14152, (long)(0x60DB7C88B5BC1CE6L ^ l))), class_jO_1924117a.bKm());
        Class_jL_e8aba6a1.cazyD.bJq((String)((Object)Class_jW_18c0e1dc.bNy("k", (int)17731, (long)(0x76432C990F66EEE9L ^ l))), class_jO_1924117a.bKe() / 3.0f);
        Class_jL_e8aba6a1.cazyD.bJu((String)((Object)Class_jW_18c0e1dc.bNy("k", (int)30929, (long)(0x5785B3E9FDDBD37AL ^ l))), Class_jF_38b68c76.bHw());
    }

    private static /* synthetic */ void bNs(Class_jO_1924117a class_jO_1924117a, RenderPass renderPass) {
        long l = LJoTc ^ 0x32B31EC2016FL;
        boolean bl = Class_jT_87816f30.bMQ();
        int n = class_jO_1924117a.bJG();
        if (bl) {
            n = n != 0 ? 1 : 0;
        }
        int n2 = n;
        Class_ke_512fbaf0.bOi(Class_jL_e8aba6a1.VBAOv, class_jO_1924117a, n2);
        Class_jL_e8aba6a1.VBAOv.bJr((String)((Object)Class_jW_18c0e1dc.bNy("k", (int)31390, (long)(0x32F567A5637CF166L ^ l))), 0.0f, 0.0f);
    }

    private static CallSite bNy(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jW_18c0e1dc" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jW_18c0e1dc.class, "bNx", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

