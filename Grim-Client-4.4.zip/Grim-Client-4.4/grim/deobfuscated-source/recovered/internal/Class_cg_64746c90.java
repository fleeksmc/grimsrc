/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.hud.InGameHud
 *  net.minecraft.client.gui.screen.ChatScreen
 *  net.minecraft.entity.effect.StatusEffect
 *  net.minecraft.entity.effect.StatusEffectCategory
 *  net.minecraft.entity.effect.StatusEffectInstance
 *  net.minecraft.registry.entry.RegistryEntry
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.registry.entry.RegistryEntry;
import recovered.core.ClientMain;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_cN_30b69d20;
import recovered.internal.Class_ca_75c833b3;
import recovered.internal.Class_co_c10d0572;
import recovered.internal.Class_gM_0706a5f6;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_hF_7bd1921e;
import recovered.internal.Class_hG_d70cdb00;
import recovered.internal.Class_iW_8b6e535d;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mM_57b5ebea;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_rj_b691f4f7;

public class Class_cg_64746c90
extends Class_co_c10d0572 {
    private final Class_cJ_2ae1a557 KsSMf;
    private final Map<String, StatusEffectInstance> lkRFs;
    private final Map<StatusEffect, Boolean> XXdvi;
    private static final long kjqzv;
    private static final String[] GQfMq;
    private static final String[] XMEkj;
    private static final Map ysebq;
    private static final long[] QgNXY;
    private static final Integer[] yyYQj;
    private static final Map phUmR;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cg_64746c90() {
        long l = kjqzv ^ 0x488275A41265L;
        int[] nArray = new int[Class_cg_64746c90.Qj("f", (int)26790, (long)(0x57DB8164524B70F1L ^ l))];
        nArray[0] = (int)Class_cg_64746c90.Qj("f", (int)401, (long)(0x12B091BA8ECB99C3L ^ l));
        nArray[1] = (int)Class_cg_64746c90.Qj("f", (int)24151, (long)(0x29CF34070B58460DL ^ l));
        nArray[2] = (int)Class_cg_64746c90.Qj("f", (int)8527, (long)(0x2CF346EBEB1CB903L ^ l));
        nArray[3] = (int)Class_cg_64746c90.Qj("f", (int)17782, (long)(0x12E03AAC98B5DD39L ^ l));
        nArray[4] = (int)Class_cg_64746c90.Qj("f", (int)835, (long)(0x7F412C99EBB79B16L ^ l));
        nArray[5] = (int)Class_cg_64746c90.Qj("f", (int)6567, (long)(0x46B6BF1D629181FEL ^ l));
        nArray[Class_cg_64746c90.Qj("f", (int)11237, (long)(0x14A94FBB364533B9L ^ l))] = (int)Class_cg_64746c90.Qj("f", (int)12840, (long)(0x408AD3A04D68AA76L ^ l));
        super(nArray, Class_lf_d247d983.DyMwJ);
        this.KsSMf = new Class_cJ_2ae1a557(this, Class_mr_7eac5189.clS(new int[]{(int)Class_cg_64746c90.Qj("f", (int)22745, (long)(0x5DA3FB48660B4086L ^ l)), (int)Class_cg_64746c90.Qj("f", (int)12734, (long)(0x3DBC2A8F30D9A9F0L ^ l)), (int)Class_cg_64746c90.Qj("f", (int)15718, (long)(0x40A5D407D5F1A53EL ^ l)), (int)Class_cg_64746c90.Qj("f", (int)9778, (long)(0x397E3DE3C354BE61L ^ l)), (int)Class_cg_64746c90.Qj("f", (int)6986, (long)(0x4D94730DFAE0831BL ^ l))})).WE(false);
        this.lkRFs = new TreeMap<String, StatusEffectInstance>();
        this.XXdvi = new HashMap<StatusEffect, Boolean>();
        Class_hF_7bd1921e.bdI(this);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Class_cg_64746c90.kjqzv = Class_gb_9d201141.aYR(24728271087640463L, 2606469178279783025L, MethodHandles.lookup().lookupClass()).a(62859203139507L);
                        Class_cg_64746c90.ysebq = new HashMap<K, V>(13);
                        var11 = Class_cg_64746c90.kjqzv ^ 127414406724590L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[8];
                        var18_4 = 0;
                        var17_5 = "2\u00da#\u00a9\u0083d\u00fd\u00cfd\u00dcc\u0084\u00c7\u0087 \u00a4\u0010\u0093v\u00df\r\u00fb\u00c5\u009a\u0080m\u00ce`S\u00ecKO\u0099\u0010\u0006<\u00ce<\u00a6\u00a81\u00cc=\u00b3|M3r\u00ab\u0096(\u0084\u00c5.\u00e0\u00c3\u00a9\u00d5\u0095^!\u000f\u001f\u00f2\u00b1:\u00a1\u009e\u00ca\u00ddX\u00e2\u00cf\u00d98\u00f8\u0098\u0088\u0088\u00f3&\u00ae[\u00db\u001e\u008cu\u00f1\u0092\u00df\u0084 9\u00b1\u00a5\u0016\u000fd\u00a7?\u0084\u00a2C\u0019\u00bd\u00af\u0003\u00e0\u00f6\f\u0004\u001a;\u0003\u0004K\u001a\u00ed\u00a6\u00c6\u001dO}\u0089 \u0002\u00a5\u00d8'\u00a10\u00f65\u0098V\u0010\u00f4\u0087\u0086\u00e3\u00dbh\u00cb\u009a\u00ad#\u0086C \u00fe\u00173\u00cb_3\u00a5\u008c";
                        var19_6 = "2\u00da#\u00a9\u0083d\u00fd\u00cfd\u00dcc\u0084\u00c7\u0087 \u00a4\u0010\u0093v\u00df\r\u00fb\u00c5\u009a\u0080m\u00ce`S\u00ecKO\u0099\u0010\u0006<\u00ce<\u00a6\u00a81\u00cc=\u00b3|M3r\u00ab\u0096(\u0084\u00c5.\u00e0\u00c3\u00a9\u00d5\u0095^!\u000f\u001f\u00f2\u00b1:\u00a1\u009e\u00ca\u00ddX\u00e2\u00cf\u00d98\u00f8\u0098\u0088\u0088\u00f3&\u00ae[\u00db\u001e\u008cu\u00f1\u0092\u00df\u0084 9\u00b1\u00a5\u0016\u000fd\u00a7?\u0084\u00a2C\u0019\u00bd\u00af\u0003\u00e0\u00f6\f\u0004\u001a;\u0003\u0004K\u001a\u00ed\u00a6\u00c6\u001dO}\u0089 \u0002\u00a5\u00d8'\u00a10\u00f65\u0098V\u0010\u00f4\u0087\u0086\u00e3\u00dbh\u00cb\u009a\u00ad#\u0086C \u00fe\u00173\u00cb_3\u00a5\u008c".length();
                        var16_7 = 16;
                        var15_8 = -1;
lbl20:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl25:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Class_cg_64746c90.Qd(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00b31\u0086V\u00ee\u0014\u0004\u0088\u0083\u0001\u001dq\u001b\u0095\u0004pG\u00c6\u00b3Ws\u0015\u00cfI\u0010v\u00e6\u00a9\u00af2\u00de\u00f2@\u009d\u00c9\u008c\u00bb4\u00ca\u0084\u000f";
                            var19_6 = "\u00b31\u0086V\u00ee\u0014\u0004\u0088\u0083\u0001\u001dq\u001b\u0095\u0004pG\u00c6\u00b3Ws\u0015\u00cfI\u0010v\u00e6\u00a9\u00af2\u00de\u00f2@\u009d\u00c9\u008c\u00bb4\u00ca\u0084\u000f".length();
                            var16_7 = 24;
                            var15_8 = -1;
lbl34:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl39:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Class_cg_64746c90.Qd(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl51:
                        // 1 sources

                        ** continue;
                    }
                }
                Class_cg_64746c90.GQfMq = var20_3;
                Class_cg_64746c90.XMEkj = new String[8];
                Class_cg_64746c90.phUmR = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[20];
                var3_13 = 0;
                var4_14 = "B}\u00f4\u00d8\u00fd\u00c7%5^\u00afz\u00a5N>\u0015i}X8\f\u008dC\u00a6\u0084\u00b0\u0096\u00f5g\u00e6Y\u0081@[\u00eb\u0004\u00d0\u0098\u00a7\u00b4\u0094g\u0016_\u00ad\u0090bt:I\u00dd\u0010\u00df)\u009b6\u00e5\u009djv\u00f5\u00e1\u00ba\u0015C\u00e7\u000e\u00a9\u00a4\u007fhZ\u00e4\u00b6IR\u0002\u00fc\u00a50\u008a \u00db\u00edB\u00e2\u00b3\u0006\u00ddo4)\u0090\u009e\u00fe\u009a\u000b\u00bdV_\u00c2\u0017\u00e5j\u0004!\u00efbx\u00e0N\u00909\u00d0\u00e1-J\u00aa\u00dd\u008d\u001e\u0096\u00de\u00fap\u0097\u00d3\u00e4n`\u00ccn\u00000\u0012\u00e5\u000b\u00f4\u009a\u0010\u00de\u0089\u0082\u0093\u0001";
                var5_15 = "B}\u00f4\u00d8\u00fd\u00c7%5^\u00afz\u00a5N>\u0015i}X8\f\u008dC\u00a6\u0084\u00b0\u0096\u00f5g\u00e6Y\u0081@[\u00eb\u0004\u00d0\u0098\u00a7\u00b4\u0094g\u0016_\u00ad\u0090bt:I\u00dd\u0010\u00df)\u009b6\u00e5\u009djv\u00f5\u00e1\u00ba\u0015C\u00e7\u000e\u00a9\u00a4\u007fhZ\u00e4\u00b6IR\u0002\u00fc\u00a50\u008a \u00db\u00edB\u00e2\u00b3\u0006\u00ddo4)\u0090\u009e\u00fe\u009a\u000b\u00bdV_\u00c2\u0017\u00e5j\u0004!\u00efbx\u00e0N\u00909\u00d0\u00e1-J\u00aa\u00dd\u008d\u001e\u0096\u00de\u00fap\u0097\u00d3\u00e4n`\u00ccn\u00000\u0012\u00e5\u000b\u00f4\u009a\u0010\u00de\u0089\u0082\u0093\u0001".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl78:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "|oqcy\u0010ee\u0084\u00f5\u009f\u00c1<\u0006\u00ef\u00b9";
                    var5_15 = "|oqcy\u0010ee\u0084\u00f5\u009f\u00c1<\u0006\u00ef\u00b9".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl91:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl104:
                // 1 sources

                ** continue;
            }
        }
        Class_cg_64746c90.QgNXY = var6_12;
        Class_cg_64746c90.yyYQj = new Integer[20];
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    @Override
    protected void NV(Class_lC_5322e8cf var1_1) {
        block22: {
            block15: {
                var2_2 = Class_cg_64746c90.kjqzv ^ 17096044552792L;
                super.NV(var1_1);
                var5_3 = Class_lE_06fbe260.joxgd.bYM(7.0f);
                var6_4 = ClientMain.dlM();
                var7_5 = 22.0f;
                var4_6 = Class_ca_75c833b3.OY();
                var8_7 = null;
                var9_8 = this.lkRFs.values().iterator();
                while (var9_8.hasNext()) {
                    block16: {
                        var10_9 = var9_8.next();
                        var11_10 = ((Class_mM_57b5ebea)var10_9).getFadeAnimation();
                        v0 = var11_10.dhj();
                        v1 = 0.0f;
                        if (!var4_6) break block16;
                        cfr_temp_0 = v0 - v1;
                        v2 = cfr_temp_0 == 0.0f ? 0 : (cfr_temp_0 > 0.0f ? 1 : -1);
                        if (!var4_6) ** GOTO lbl35
                        if (!v2) {
                            var8_7 = var10_9;
                            if (var4_6) continue;
                        }
                        v0 = 4.5f;
                        v1 = var11_10.dhj() - 1.0f;
                    }
                    var12_11 = v0 * v1;
                    var13_13 = ClientMain.dlmvG.getAtlasManager().getAtlasTexture(Class_iW_8b6e535d.HaVqD).getSprite(InGameHud.getEffectTexture((RegistryEntry)var10_9.getEffectType()));
                    var1_1.cdY(var13_13.getAtlasId(), this.toIeR + 7.0f * var11_10.dhj(), this.QWaAn + var7_5 + var12_11 + Class_jf_d1c4f950.bAH(8.0f, 18.0f), 8.0f, 8.0f, var13_13.getMinU(), var13_13.getMinV(), var13_13.getMaxU(), var13_13.getMaxV(), Class_mG_52c8d386.hoGuU.coa(255.0f * var11_10.dhj()));
                    var7_5 += 18.0f * var11_10.dhj();
                    if (var4_6) continue;
                }
                var7_5 = 22.0f;
                Class_cg_64746c90.zXCXX.bUa(var5_3);
                var9_8 = this.lkRFs.values().iterator();
                while (true) {
                    block21: {
                        block19: {
                            block20: {
                                block18: {
                                    block17: {
                                        v2 = var9_8.hasNext();
lbl35:
                                        // 2 sources

                                        if (!v2) break;
                                        var10_9 = var9_8.next();
                                        var11_10 = (StatusEffect)var10_9.getEffectType().comp_349();
                                        var12_12 = ((Class_mM_57b5ebea)var10_9).getFadeAnimation();
                                        var13_13 = ((Class_mM_57b5ebea)var10_9).getTimerAnimation();
                                        v3 = var12_12;
                                        if (!var4_6) break block15;
                                        if (v3.dhj() == 0.0f && var4_6) continue;
                                        var14_14 = var6_4.bjb().coa(255.0f * var12_12.dhj());
                                        v4 = var11_10.getName().getString();
                                        v5 = var10_9.getAmplifier();
                                        if (!var4_6) ** GOTO lbl49
                                        if (v5 > 0) {
                                            v5 = var10_9.getAmplifier() + 1;
lbl49:
                                            // 2 sources

                                            v6 = String.valueOf(v5);
                                        } else {
                                            v6 = "";
                                        }
                                        var15_15 = v4 + " " + v6;
                                        var16_16 = -4.5f + 4.5f * var12_12.dhj();
                                        var17_17 = this.toIeR + 13.0f + 7.0f * var12_12.dhj();
                                        var18_18 = this.QWaAn + var7_5 + var16_16 + Class_jf_d1c4f950.bAH(var5_3.cat(), 18.0f);
                                        var1_1.cer(var5_3, var15_15, var17_17, var18_18, var14_14);
                                        var19_19 = this.toIeR + this.jTsqG - 7.0f * var12_12.dhj();
                                        v7 = var10_9.isInfinite();
                                        if (!var4_6) break block17;
                                        if (v7 != 0) break block18;
                                        v7 = var10_9.getDuration();
                                    }
                                    v8 = Class_cg_64746c90.Qj("f", (int)22088, (long)(7195861460517715493L ^ var2_2));
                                    if (!var4_6) break block19;
                                    if (v7 < v8) break block20;
                                }
                                var20_20 = Class_cg_64746c90.Qg("g", (int)31904, (long)(4802436344857664317L ^ var2_2));
                                var1_1.cev(var5_3, (String)Class_cg_64746c90.Qg("g", (int)31904, (long)(4802436344857664317L ^ var2_2)), var19_19, var18_18, var14_14);
                                if (var4_6) break block21;
                            }
                            v7 = var10_9.getDuration();
                            v8 = Class_cg_64746c90.Qj("f", (int)30520, (long)(1375935685821259603L ^ var2_2));
                        }
                        var20_21 = v7 / v8;
                        var21_22 = var20_21 / Class_cg_64746c90.Qj("f", (int)2430, (long)(8900718079139553566L ^ var2_2));
                        var22_23 = var20_21 % Class_cg_64746c90.Qj("f", (int)2430, (long)(8900718079139553566L ^ var2_2));
                        var23_24 = String.format((String)Class_cg_64746c90.Qg("g", (int)13655, (long)(6103395322653364940L ^ var2_2)), new Object[]{var21_22});
                        var24_25 = String.format((String)Class_cg_64746c90.Qg("g", (int)7099, (long)(6140833719285709859L ^ var2_2)), new Object[]{var21_22, var22_23});
                        var25_26 = var5_3.cao(var23_24);
                        var26_27 = var5_3.cao(var24_25);
                        var1_1.cer(var5_3, var23_24, var19_19 - var26_27, var18_18, var14_14);
                        var27_28 = var19_19 - var26_27 + var25_26;
                        var13_13.kS(true, var14_14);
                        var13_13.kO(var22_23);
                        var13_13.sW(var27_28, var18_18);
                        var13_13.su(var1_1);
                    }
                    var7_5 += 18.0f * var12_12.dhj();
                    if (!var4_6) break;
                }
                Class_cg_64746c90.zXCXX.endBatch();
                v3 = var8_7;
                if (!var4_6) break block15;
                if (v3 == null) break block22;
                v3 = var8_7.getEffectType().comp_349();
            }
            var9_8 = (StatusEffect)v3;
            this.lkRFs.remove(var9_8.getName().getString(), var8_7);
        }
    }

    /*
     * Could not resolve type clashes
     * Unable to fully structure code
     */
    @Override
    public void LX(Class_lC_5322e8cf var1_1) {
        block22: {
            block30: {
                block29: {
                    block21: {
                        var2_2 = Class_cg_64746c90.kjqzv ^ 29925481139608L;
                        this.jTsqG = 92.0f;
                        this.Xtjvx = 20.0f;
                        var5_3 = ClientMain.dlmvG.player.getStatusEffects();
                        var4_4 = Class_ca_75c833b3.OX();
                        for (Object var7_6 : var5_3) {
                            block28: {
                                block24: {
                                    block25: {
                                        block27: {
                                            block26: {
                                                block23: {
                                                    var8_7 = (StatusEffect)var7_6.getEffectType().comp_349();
                                                    var9_8 = var8_7.getName().getString();
                                                    v0 = var9_8.isBlank();
                                                    if (var4_4) break block21;
                                                    if (var4_4) break block23;
                                                    if (v0 && !var4_4) continue;
                                                    v1 = this.lkRFs;
                                                    v2 = var9_8;
                                                    if (var4_4) break block24;
                                                    v3 = v1.containsKey(v2);
                                                }
                                                if (!v3) break block25;
                                                this.lkRFs.replace((String)var9_8, (StatusEffectInstance)var7_6);
                                                v4 = var10_9 = ((Class_mM_57b5ebea)var7_6).getFadeAnimation();
                                                if (var4_4) break block26;
                                                if (v4.dhj() != 0.0f) break block27;
                                                v4 = var10_9;
                                            }
                                            v4.dhe(1.0f);
                                        }
                                        if (!var4_4) break block28;
                                    }
                                    v1 = this.lkRFs;
                                    v2 = var9_8;
                                }
                                v1.put(v2, (StatusEffectInstance)var7_6);
                            }
                            if (!var4_4) continue;
                        }
                        v5 = this;
                        if (var4_4) break block29;
                        v0 = v5.lkRFs.isEmpty();
                    }
                    if (v0) break block30;
                    v5 = this;
                }
                v5.Xtjvx += 5.0f;
            }
            var6_5 = Class_lE_06fbe260.joxgd.bYM(7.0f);
            for (StatusEffect var8_7 : this.lkRFs.values()) {
                block40: {
                    block38: {
                        block39: {
                            block37: {
                                block36: {
                                    block35: {
                                        block31: {
                                            block32: {
                                                block33: {
                                                    block34: {
                                                        var9_8 = ((Class_mM_57b5ebea)var8_7).getFadeAnimation();
                                                        var10_9 = (StatusEffect)var8_7.getEffectType().comp_349();
                                                        if (var4_4) break block31;
                                                        v6 = this;
                                                        if (var4_4) break block22;
                                                        if (!v6.KsSMf.WF()) break block32;
                                                        v7 = var10_9.getName().getString();
                                                        v8 = var8_7.getAmplifier();
                                                        if (var4_4) ** GOTO lbl59
                                                        if (v8 > 0) {
                                                            v8 = var8_7.getAmplifier() + 1;
lbl59:
                                                            // 2 sources

                                                            v9 = v8;
                                                        } else {
                                                            v9 = "";
                                                        }
                                                        var11_10 = v7 + " " + String.valueOf(v9);
                                                        v10 /* !! */  = ClientMain.dlmvG.player;
                                                        if (var4_4) break block32;
                                                        if (v10 /* !! */ .hasStatusEffect(var8_7.getEffectType())) break block33;
                                                        v11 = this.XXdvi.getOrDefault(var10_9, false);
                                                        if (var4_4) break block34;
                                                        if (v11) break block32;
                                                        v12 = var10_9;
                                                        if (var4_4) break block35;
                                                        v11 = v12.getCategory().equals((Object)StatusEffectCategory.HARMFUL);
                                                    }
                                                    if (v11) break block32;
                                                    Class_cN_30b69d20.XQ((String)Class_cg_64746c90.Qg("g", (int)31255, (long)(8860898950464860745L ^ var2_2)) + (String)var11_10 + (String)Class_cg_64746c90.Qg("g", (int)10882, (long)(3499432574078264027L ^ var2_2)), (String)Class_cg_64746c90.Qg("g", (int)7359, (long)(8031778270325839072L ^ var2_2)));
                                                    this.XXdvi.put((StatusEffect)var10_9, true);
                                                    if (!var4_4) break block32;
                                                }
                                                v10 /* !! */  = this.XXdvi.put((StatusEffect)var10_9, false);
                                            }
                                            var9_8.dhc(var5_3.contains(var8_7));
                                            var9_8.dhs(Class_rj_b691f4f7.XzDkv);
                                        }
                                        v12 = var10_9;
                                    }
                                    v13 = v12.getName().getString();
                                    v14 = var8_7.getAmplifier();
                                    if (var4_4) ** GOTO lbl92
                                    if (v14 > 0) {
                                        v14 = var8_7.getAmplifier() + 1;
lbl92:
                                        // 2 sources

                                        v15 = v14;
                                    } else {
                                        v15 = "";
                                    }
                                    var11_10 = v13 + " " + String.valueOf(v15);
                                    var12_11 = var6_5.cao(var11_10);
                                    v16 = var8_7.isInfinite();
                                    if (var4_4) break block36;
                                    if (v16 != 0) break block37;
                                    v16 = var8_7.getDuration();
                                }
                                v17 = Class_cg_64746c90.Qj("f", (int)22872, (long)(7285557963839413992L ^ var2_2));
                                if (var4_4) break block38;
                                if (v16 < v17) break block39;
                            }
                            var13_12 = Class_cg_64746c90.Qg("g", (int)25873, (long)(6279610284547665229L ^ var2_2));
                            if (!var4_4) break block40;
                        }
                        v16 = var8_7.getDuration();
                        v17 = Class_cg_64746c90.Qj("f", (int)27560, (long)(44593545406196737L ^ var2_2));
                    }
                    var14_14 = v16 / v17;
                    var15_16 = var14_14 / Class_cg_64746c90.Qj("f", (int)22640, (long)(5650285629085065174L ^ var2_2));
                    var16_18 = var14_14 % Class_cg_64746c90.Qj("f", (int)2430, (long)(8900704220790345438L ^ var2_2));
                    var13_12 = String.format((String)Class_cg_64746c90.Qg("g", (int)25358, (long)(841274481665010516L ^ var2_2)), new Object[]{var15_16, var16_18});
                }
                var14_13 = var6_5.cao((String)var13_12);
                var15_15 = 7.0f;
                var16_17 = 8.0f;
                var17_19 = var15_15 + var16_17 + var12_11 + 14.0f + var14_13 + var15_15;
                this.jTsqG = Math.max(var17_19, this.jTsqG);
                this.Xtjvx += 18.0f * var9_8.dhj();
                if (!var4_4) continue;
            }
            v6 = this;
        }
        super.LX(var1_1);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean Om() {
        long l = kjqzv ^ 0xC01ED29E772L;
        boolean bl = Class_ca_75c833b3.OX();
        boolean bl2 = this.lkRFs.isEmpty();
        if (!bl) {
            bl2 = !bl2;
        }
        boolean bl3 = bl2;
        boolean bl4 = ClientMain.dlmvG.currentScreen instanceof ChatScreen;
        boolean bl5 = bl3;
        if (bl) return bl5;
        if (bl5) return true;
        bl5 = bl4;
        if (bl) return bl5;
        if (!bl5) return false;
        return true;
    }

    private static String Qe(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0xE48;
        if (XMEkj[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])ysebq.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    ysebq.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cg_64746c90", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = GQfMq[n2].getBytes("ISO-8859-1");
            Class_cg_64746c90.XMEkj[n2] = Class_cg_64746c90.Qd(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return XMEkj[n2];
    }

    @Class_hG_d70cdb00
    public void Qb(Class_gM_0706a5f6 class_gM_0706a5f6) {
        this.lkRFs.clear();
        this.XXdvi.clear();
    }

    private static MatchException Qc(MatchException matchException) {
        return matchException;
    }

    private static CallSite Qj(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cg_64746c90" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static CallSite Qg(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cg_64746c90" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static String Qd(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static Object Qf(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_cg_64746c90.Qe(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static int Qh(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x41B4;
        if (yyYQj[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = QgNXY[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])phUmR.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    phUmR.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cg_64746c90", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_cg_64746c90.yyYQj[n2] = n3;
        }
        return yyYQj[n2];
    }

    private static int Qi(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_cg_64746c90.Qh(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cg_64746c90.class, "Qi", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_cg_64746c90.class, "Qf", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

