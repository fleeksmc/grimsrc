/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import recovered.core.ClientMain;
import recovered.core.NativeLoader;
import recovered.internal.Class_O_5a11f410;
import recovered.internal.Class_ah_02444db4;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bs_8800d93f;
import recovered.internal.Class_bz_8cac7329;
import recovered.internal.Class_cC_14ef8bb5;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_cy_687dcdb6;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_iy_c88c0f4f;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bt_551ea435
extends Class_aj_95d0a719 {
    private static Pattern xTVZM;
    private final Class_rk_bf8630d1 bFTNj;
    private final List<Class_az_a4990dcf> UlztO;
    private final Class_ah_02444db4 uyARm;
    private final Class_iy_c88c0f4f FmXmt;
    private final Class_O_5a11f410 KKEPY;
    private static Class_cy_687dcdb6 AaYbn;
    private static Class_cy_687dcdb6 NcLix;
    private static Class_cC_14ef8bb5 mJDgD;
    private static Class_cC_14ef8bb5 yMNoI;
    private static Class_cy_687dcdb6 XbZzs;
    private static Class_cy_687dcdb6 gCJzz;
    private static Class_cJ_2ae1a557 wdJaU;
    private static Class_cJ_2ae1a557 HGeKS;
    private static Class_cJ_2ae1a557 xewZE;
    private static Class_cC_14ef8bb5 jAdum;
    private static Class_cJ_2ae1a557 XLbVI;
    private static Class_cJ_2ae1a557 UuLNK;
    private static Class_cy_687dcdb6 JNSMX;
    private static Class_cC_14ef8bb5 BdyXl;
    private static Class_cC_14ef8bb5 EQmot;
    private static Class_cC_14ef8bb5 zeYXW;
    private static Class_cC_14ef8bb5 STxMh;
    private float gURWm;
    private static long QedcP;
    private static String[] snfIh;
    private static String[] MFsQY;
    private static Map oeiZn;
    private static long[] KBLUT;
    private static Integer[] MMCfZ;
    private static Map pkphh;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native void _5290428a703cbcba4987191105fc62ce();

    public Class_bt_551ea435(Class_iy_c88c0f4f class_iy_c88c0f4f) {
        long l = QedcP ^ 0x25DCECC705FAL;
        this.bFTNj = new Class_rk_bf8630d1((int)Class_bt_551ea435.HZ("v", (int)28603, (long)(0x39F8B8FC6A39D487L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.UlztO = new ArrayList<Class_az_a4990dcf>();
        Class_bz_8cac7329 class_bz_8cac7329 = Class_bz_8cac7329.KH();
        Class_lc_b8480f87 class_lc_b8480f87 = class_bz_8cac7329.KI();
        this.FmXmt = class_iy_c88c0f4f;
        this.uyARm = new Class_ah_02444db4();
        this.gURWm = class_lc_b8480f87.bXz() + 10.0f;
        this.MCnYt = this.gURWm + 24.0f;
        this.pNyTQ = class_lc_b8480f87.bXG();
        this.BcpIo = 140.0f;
        this.WjISQ = class_lc_b8480f87.bXI() + 10.0f + class_bz_8cac7329.KJ().bXI();
        this.bFTNj.dhe(this.MCnYt);
        this.IzFhM = 2.0f;
        this.HH();
        Class_ig_ca326427 class_ig_ca326427 = ClientMain.dlM().bjG();
        this.KKEPY = Class_O_5a11f410.hE((String)((Object)Class_bt_551ea435.HW("f", (int)995, (long)(0x7883D0B2C3EC8B7BL ^ l)))).je(true).jf(Class_ld_bb1690e1.M).jk(class_ig_ca326427.bio().coe(0.9f)).jq(class_ig_ca326427.bis()).jr(class_ig_ca326427.bis().cog(0.85f)).jb(this::HR);
        this.FHbTC = true;
    }

    public Class_bt_551ea435() {
        long l = QedcP ^ 0x1D85CAE47DE7L;
        this.bFTNj = new Class_rk_bf8630d1((int)Class_bt_551ea435.HZ("v", (int)5503, (long)(0x5C24461A5922561EL ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.UlztO = new ArrayList<Class_az_a4990dcf>();
        Class_bz_8cac7329 class_bz_8cac7329 = Class_bz_8cac7329.KH();
        Class_lc_b8480f87 class_lc_b8480f87 = class_bz_8cac7329.KI();
        this.FmXmt = null;
        this.uyARm = new Class_ah_02444db4();
        this.gURWm = class_lc_b8480f87.bXz() + 10.0f;
        int[] nArray = Class_bs_8800d93f.Hv();
        this.MCnYt = this.gURWm + 24.0f;
        this.pNyTQ = class_lc_b8480f87.bXG();
        this.BcpIo = 140.0f;
        this.WjISQ = class_lc_b8480f87.bXI() + 10.0f + class_bz_8cac7329.KJ().bXI();
        this.bFTNj.dhe(this.MCnYt);
        this.IzFhM = 2.0f;
        this.HH();
        Class_ig_ca326427 class_ig_ca326427 = ClientMain.dlM().bjG();
        try {
            this.KKEPY = Class_O_5a11f410.hE((String)((Object)Class_bt_551ea435.HW("f", (int)17283, (long)(0x553A948DE4E9B312L ^ l)))).je(true).jf(Class_ld_bb1690e1.M).jk(class_ig_ca326427.bio().coe(0.9f)).jq(class_ig_ca326427.bis()).jr(class_ig_ca326427.bis().cog(0.85f)).jb(this::HQ);
            this.FHbTC = true;
            if (Class_iS_888f260e.bwL() == null) {
                Class_bs_8800d93f.Hu(new int[5]);
            }
        }
        catch (MatchException matchException) {
            throw Class_bt_551ea435.HS(matchException);
        }
    }

    static {
        NativeLoader.doInit(Class_bt_551ea435.class);
        Class_bt_551ea435._5290428a703cbcba4987191105fc62ce();
    }

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    private native void HK();

    @Override
    public native boolean dm(int var1, int var2, int var3);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private native void HH();

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean fC(double var1, double var3, double var5);

    @Override
    protected native float gb();

    private static native CallSite HZ(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native String HT(byte[] var0);

    @Override
    public native boolean dB(double var1, double var3, Class_mA_32d8a5f2 var5, double var6, double var8);

    @Override
    public native boolean eK(char var1);

    @Override
    protected native boolean od();

    public native void HB(float var1, float var2, float var3);

    private native void HG(float var1);

    private static native MatchException HS(MatchException var0);

    private native float HC();

    private native /* synthetic */ void HL(Class_iy_c88c0f4f var1);

    private native /* synthetic */ void HO(Class_lC_5322e8cf var1);

    private native /* synthetic */ void HP(Class_lC_5322e8cf var1);

    private static native int HX(int var0, long var1);

    private static native int HY(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native /* synthetic */ void HM(Class_iy_c88c0f4f var1);

    private native /* synthetic */ void HN(Class_iy_c88c0f4f var1);

    private static native Object HV(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native float HD();

    private native float HF();

    private native float HE();

    private native void HI();

    private static native String HU(int var0, long var1);

    private static native CallSite HW(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native /* synthetic */ void HR(Class_O_5a11f410 var1);

    private native /* synthetic */ void HQ(Class_O_5a11f410 var1);

    private native void HJ();
}

