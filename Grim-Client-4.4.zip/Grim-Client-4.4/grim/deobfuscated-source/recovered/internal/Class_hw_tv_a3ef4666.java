/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 */
package recovered.internal;

import net.minecraft.entity.Entity;
import recovered.internal.Class_hw_ffa47777;
import recovered.internal.Class_oX_4486ae98;

public class Class_hw_tv_a3ef4666
extends Class_hw_ffa47777 {
    private boolean VibZH = Class_oX_4486ae98.cLK();
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hw_tv_a3ef4666(Entity entity) {
        super(entity);
    }

    public boolean dps() {
        return this.VibZH;
    }

    public void dpt() {
        this.VibZH = true;
    }
}

