/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.MovementType
 */
package recovered.internal;

import net.minecraft.entity.MovementType;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_hi_834b65e6
extends Class_hH_ae8f8f77 {
    private MovementType ioDCS;
    private double TtyvP;
    private double HJOdl;
    private double xjPbi;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public void bcF(double d) {
        this.TtyvP = d;
    }

    public void bcG(double d) {
        this.HJOdl = d;
    }

    public Class_hi_834b65e6(MovementType movementType, double d, double d2, double d3) {
        this.ioDCS = movementType;
        this.TtyvP = d;
        this.HJOdl = d2;
        this.xjPbi = d3;
    }

    public double bcD() {
        return this.HJOdl;
    }

    public MovementType bcB() {
        return this.ioDCS;
    }

    public double bcC() {
        return this.TtyvP;
    }

    public double bcE() {
        return this.xjPbi;
    }

    public void bcH(double d) {
        this.xjPbi = d;
    }
}

