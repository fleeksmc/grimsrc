/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.sound.SoundInstance
 */
package recovered.internal;

import net.minecraft.client.sound.SoundInstance;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gI_1ed505bf
extends Class_hH_ae8f8f77 {
    private SoundInstance Wpqlj;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gI_1ed505bf(SoundInstance soundInstance) {
        this.Wpqlj = soundInstance;
    }

    public SoundInstance bcc() {
        return this.Wpqlj;
    }
}

