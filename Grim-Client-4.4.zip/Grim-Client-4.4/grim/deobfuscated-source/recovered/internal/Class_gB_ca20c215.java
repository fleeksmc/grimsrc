/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.screen.slot.SlotActionType
 */
package recovered.internal;

import net.minecraft.screen.slot.SlotActionType;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gB_ca20c215
extends Class_hH_ae8f8f77 {
    private SlotActionType vomyn;
    private int SMlZR;
    private int KZhqs;
    private int PlWth;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gB_ca20c215(SlotActionType slotActionType, int n, int n2, int n3) {
        this.vomyn = slotActionType;
        this.SMlZR = n;
        this.KZhqs = n2;
        this.PlWth = n3;
    }

    public SlotActionType bbS() {
        return this.vomyn;
    }

    public int bbU() {
        return this.KZhqs;
    }

    public int bbV() {
        return this.PlWth;
    }

    public int bbT() {
        return this.SMlZR;
    }
}

