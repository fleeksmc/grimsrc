/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.reflect.TypeToken
 */
package recovered.internal;

import com.google.common.reflect.TypeToken;
import java.util.List;
import recovered.internal.Class_jL_e8aba6a1;
import recovered.internal.Class_mz_7ef7b67c;

class Class_jL_tX_11278a59
extends TypeToken<List<Class_mz_7ef7b67c<int[], int[]>>> {
    final Class_jL_e8aba6a1 NwKVU;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_jL_tX_11278a59(Class_jL_e8aba6a1 class_jL_e8aba6a1) {
        this.NwKVU = class_jL_e8aba6a1;
    }
}

