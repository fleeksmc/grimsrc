/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  net.minecraft.util.math.MathHelper
 */
package recovered.internal;

import com.google.gson.JsonElement;
import java.lang.invoke.MethodHandles;
import java.util.Arrays;
import java.util.Map;
import net.minecraft.util.math.MathHelper;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mr_7eac5189;

public class Class_cC_14ef8bb5
extends Class_cB_67aec11c {
    protected double bYxsv = -1.7976931348623157E308;
    protected double WhuQX = Double.MAX_VALUE;
    protected double HqniU;
    protected double LYVpX = 0.0;
    private String VnJkN = "";
    private static int[] iwtYu;
    private static final long JJQla;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cC_14ef8bb5(Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_mr_7eac5189);
    }

    public Class_cC_14ef8bb5(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    static {
        JJQla = Class_gb_9d201141.aYR(-1585309316230611833L, -5126282417768967594L, MethodHandles.lookup().lookupClass()).a(258852658179006L);
        if (Class_cC_14ef8bb5.VL() == null) {
            Class_cC_14ef8bb5.VK(new int[5]);
        }
    }

    @Override
    public void SS(JsonElement jsonElement) {
        this.VA(jsonElement.getAsDouble());
    }

    @Override
    public void SR(Map<String, Object> map) {
        map.put(Arrays.toString(this.NwlSF), this.LYVpX);
    }

    public double VI() {
        return this.LYVpX;
    }

    public long VD() {
        return (long)this.LYVpX;
    }

    public double VG() {
        return this.WhuQX;
    }

    private static MatchException VM(MatchException matchException) {
        return matchException;
    }

    public static int[] VL() {
        return iwtYu;
    }

    public double VF() {
        return this.bYxsv;
    }

    private double VE(double d) {
        long l = JJQla ^ 0x3F78622DDA2FL;
        double d2 = Math.min(this.bYxsv, this.WhuQX);
        double d3 = Math.max(this.bYxsv, this.WhuQX);
        double d4 = MathHelper.clamp((double)d, (double)d2, (double)d3);
        boolean bl = Class_cB_67aec11c.Vu();
        double d5 = this.HqniU;
        if (!bl) {
            if (d5 > 0.0) {
                d4 = (double)Math.round(d4 / this.HqniU) * this.HqniU;
                d4 = MathHelper.clamp((double)d4, (double)d2, (double)d3);
            }
            d5 = d4;
        }
        return d5;
    }

    public static void VK(int[] nArray) {
        iwtYu = nArray;
    }

    public double VH() {
        return this.HqniU;
    }

    public String VJ() {
        return this.VnJkN;
    }

    public float VB() {
        return (float)this.LYVpX;
    }

    public int VC() {
        return (int)this.LYVpX;
    }

    public Class_cC_14ef8bb5 Vz(String string) {
        long l = JJQla ^ 0x378D504CBE06L;
        boolean bl = Class_cB_67aec11c.Vu();
        String string2 = string;
        if (!bl) {
            string2 = string2 == null ? "" : string;
        }
        this.VnJkN = string2;
        return this;
    }

    public Class_cC_14ef8bb5 VA(double d) {
        long l = JJQla ^ 0x2618B115C4FDL;
        double d2 = this.VE(d);
        boolean bl = Class_cB_67aec11c.Vt();
        Class_cC_14ef8bb5 class_cC_14ef8bb5 = this;
        if (bl) {
            if (Double.compare(class_cC_14ef8bb5.LYVpX, d2) == 0) {
                return this;
            }
            this.LYVpX = d2;
            this.Vk();
            class_cC_14ef8bb5 = this;
        }
        return class_cC_14ef8bb5;
    }

    public Class_cC_14ef8bb5 Vy(double d) {
        this.HqniU = Math.max(0.0, d);
        return this.VA(this.LYVpX);
    }

    public Class_cC_14ef8bb5 Vx(double d) {
        this.WhuQX = d;
        return this.VA(this.LYVpX);
    }

    public Class_cC_14ef8bb5 Vw(double d) {
        this.bYxsv = d;
        return this.VA(this.LYVpX);
    }
}

