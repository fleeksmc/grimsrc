/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mixin.accessors.MultiPlayerGameModeAccessor
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockState
 *  net.minecraft.client.network.ClientPlayerInteractionManager
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.math.MathHelper
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import mixin.accessors.MultiPlayerGameModeAccessor;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import recovered.core.ClientMain;
import recovered.internal.Class_bS_979bca5c;
import recovered.internal.Class_bU_714b1dad;
import recovered.internal.Class_cv_f4b0140a;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mB_991638fe;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mr_7eac5189;
import recovered.modules.NukerModule;

public class Class_bJ_24f874fc
extends Class_bS_979bca5c {
    private static boolean iJFTz;
    private static final long WXZJW;
    private static final long[] qGJPS;
    private static final Integer[] NuZfs;
    private static final Map tHMUD;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bJ_24f874fc(Class_cv_f4b0140a class_cv_f4b0140a) {
        long l = WXZJW ^ 0x4A6764947C84L;
        int[] nArray = new int[Class_bJ_24f874fc.MR("z", (int)30279, (long)(0x33F9FC76F42DBEE7L ^ l))];
        nArray[0] = (int)Class_bJ_24f874fc.MR("z", (int)5532, (long)(0x2394BDB5F26F5D3FL ^ l));
        nArray[1] = (int)Class_bJ_24f874fc.MR("z", (int)14897, (long)(0x5752FC8581B97295L ^ l));
        nArray[2] = (int)Class_bJ_24f874fc.MR("z", (int)18524, (long)(0x4F30CE426ACF80F5L ^ l));
        nArray[3] = (int)Class_bJ_24f874fc.MR("z", (int)16354, (long)(0x1BD6971FFFFF774CL ^ l));
        nArray[4] = (int)Class_bJ_24f874fc.MR("z", (int)17196, (long)(0x48EBA42046248B8DL ^ l));
        nArray[5] = (int)Class_bJ_24f874fc.MR("z", (int)17577, (long)(0x6D9767DB07A70C0EL ^ l));
        nArray[Class_bJ_24f874fc.MR("z", (int)11775, (long)(0x6265242C0AAEE554L ^ l))] = (int)Class_bJ_24f874fc.MR("z", (int)22658, (long)(0x235C5EA7A7991020L ^ l));
        nArray[Class_bJ_24f874fc.MR("z", (int)7521, (long)(0x691242D41CA955C4L ^ l))] = (int)Class_bJ_24f874fc.MR("z", (int)18517, (long)(0x69799E431C1880E7L ^ l));
        nArray[Class_bJ_24f874fc.MR("z", (int)20934, (long)(0x3B1C30407BC1975L ^ l))] = (int)Class_bJ_24f874fc.MR("z", (int)11477, (long)(0x13C36626D103647AL ^ l));
        nArray[Class_bJ_24f874fc.MR("z", (int)792, (long)(0x41186088A3E4BA9L ^ l))] = (int)Class_bJ_24f874fc.MR("z", (int)6559, (long)(0x4AEF3D2EB374D135L ^ l));
        nArray[Class_bJ_24f874fc.MR("z", (int)8234, (long)(0x44694868E239E88CL ^ l))] = (int)Class_bJ_24f874fc.MR("z", (int)7001, (long)(0x60DED689C4853F4L ^ l));
        nArray[Class_bJ_24f874fc.MR("z", (int)13444, (long)(0x6FB723ECB3D6FC28L ^ l))] = (int)Class_bJ_24f874fc.MR("z", (int)615, (long)(0x1B2727C364CCACFL ^ l));
        super(class_cv_f4b0140a, Class_mr_7eac5189.clS(nArray));
    }

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_bJ_24f874fc.WXZJW = Class_gb_9d201141.aYR(6643231901512878892L, 9161461381816758708L, MethodHandles.lookup().lookupClass()).a(273006904077945L);
                Class_bJ_24f874fc.tHMUD = new HashMap<K, V>(13);
                var0 = Class_bJ_24f874fc.WXZJW ^ 40200051608194L;
                Class_bJ_24f874fc.ML(true);
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[19];
                var5_4 = 0;
                var6_5 = "\u00be\u00fa\u00d4\u00f2\u00fb\u00d3\u00bc\u008d\u0087\u00893-\u00f3q1\u00c6\u00ea\u00f0d\u0095\u00d2-\u00f8\u00b7\u0004\u0019\u0015\u00f4\u008b\u008f&\u00e8\u0085o\u00eaZ0\u00b79\u00a4\u0096\u0007\u00d1\u00f80\u00f5\u0090O#\u00ee:\u00c1b\u00c6\u00bfN\u00ad\u00c7\u00dbV\u008e\u00bd$B\u00a9\u00a2:\u00c8\u00ecjk\u00b4\u00b6?\u00f2R\u00997\u00c9\u0084\u0007\u00d9\u0099wc|\u009b\"\u0013\u00c5#\t\u00d3\u009f%Gg\u00b4\u00f6\u00c7\u00d7\u00e2\u0086%\u00cd(7x\u0081\u00ed\u008b<\u00c2\u00c5\u00ee#\u0007\u00f0\u00ff\u0084~\u0097\u00d6S\u0091\u00d5\u007f\u00fa\u0091\u00bb\u00b9\u00bf\u00c4\u00c5\u000f\u00da";
                var7_6 = "\u00be\u00fa\u00d4\u00f2\u00fb\u00d3\u00bc\u008d\u0087\u00893-\u00f3q1\u00c6\u00ea\u00f0d\u0095\u00d2-\u00f8\u00b7\u0004\u0019\u0015\u00f4\u008b\u008f&\u00e8\u0085o\u00eaZ0\u00b79\u00a4\u0096\u0007\u00d1\u00f80\u00f5\u0090O#\u00ee:\u00c1b\u00c6\u00bfN\u00ad\u00c7\u00dbV\u008e\u00bd$B\u00a9\u00a2:\u00c8\u00ecjk\u00b4\u00b6?\u00f2R\u00997\u00c9\u0084\u0007\u00d9\u0099wc|\u009b\"\u0013\u00c5#\t\u00d3\u009f%Gg\u00b4\u00f6\u00c7\u00d7\u00e2\u0086%\u00cd(7x\u0081\u00ed\u008b<\u00c2\u00c5\u00ee#\u0007\u00f0\u00ff\u0084~\u0097\u00d6S\u0091\u00d5\u007f\u00fa\u0091\u00bb\u00b9\u00bf\u00c4\u00c5\u000f\u00da".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl27:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = "\u001f*\u00f1\u0014+S+,2r\u0099]RIM\u008a";
                    var7_6 = "\u001f*\u00f1\u0014+S+,2r\u0099]RIM\u008a".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl40:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl53:
                // 1 sources

                ** continue;
            }
        }
        Class_bJ_24f874fc.qGJPS = var8_3;
        Class_bJ_24f874fc.NuZfs = new Integer[19];
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean MH() {
        NukerModule nukerModule;
        NukerModule nukerModule2;
        block5: {
            boolean bl;
            block4: {
                long l = WXZJW ^ 0x2D7AD8D27266L;
                boolean bl2 = Class_bJ_24f874fc.MN();
                if (ClientMain.dlmvG.world == null) {
                    return false;
                }
                nukerModule2 = ClientMain.dlJ().aZx(NukerModule.class);
                bl = nukerModule2.bag();
                if (bl2) break block4;
                if (!bl) return false;
                nukerModule = nukerModule2;
                if (bl2) break block5;
                bl = nukerModule.alW().SQ(2);
            }
            if (bl) return false;
            nukerModule = nukerModule2;
        }
        if (nukerModule.amm() == null) return false;
        if (this.MK(nukerModule2) == null) return false;
        return true;
    }

    private static MatchException MO(MatchException matchException) {
        return matchException;
    }

    @Override
    public void MG(Class_lC_5322e8cf class_lC_5322e8cf, Class_ii_9b427eda class_ii_9b427eda) {
        float f;
        float f2;
        long l = WXZJW ^ 0x227AF0C848A9L;
        NukerModule nukerModule = ClientMain.dlJ().aZx(NukerModule.class);
        Block block = this.MK(nukerModule);
        if (block == null) {
            return;
        }
        Class_bU_714b1dad class_bU_714b1dad = ClientMain.dlK().RC();
        float f3 = class_bU_714b1dad.RW();
        float f4 = class_bU_714b1dad.RX();
        Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
        Class_lq_87a74641 class_lq_87a746412 = Class_lE_06fbe260.SVnNc.bYM(6.0f);
        Class_mG_52c8d386 class_mG_52c8d386 = class_ii_9b427eda.bjf();
        String string = block.getName().getString();
        String string2 = this.MJ() + "%";
        float f5 = 255.0f * this.dExGi.dhj();
        float f6 = 20.0f * this.dExGi.dhj();
        float f7 = 4.0f;
        float f8 = 4.0f;
        float f9 = 10.0f;
        float f10 = f3 - 16.0f + f6;
        float f11 = f4 + 2.5f;
        float f12 = f10 + f9 + f8;
        float f13 = class_lq_87a74641.cao(string);
        float f14 = class_lq_87a746412.cao(string2);
        this.fGWTH.NU(f9 + f13 + f14 + f8 * 2.0f + f7 * 2.0f, 15.0f);
        class_lC_5322e8cf.cdg(f10, f11, f9, f9, Class_ld_bb1690e1.all(3.5f), class_mG_52c8d386.coa(90.0f * this.dExGi.dhj()));
        ItemStack itemStack = block.asItem().getDefaultStack();
        if (!itemStack.isEmpty()) {
            f2 = 0.45f;
            f = 16.0f * f2;
            float f15 = f10 + (f9 - f) * 0.5f;
            float f16 = f11 + (f9 - f) * 0.5f;
            class_lC_5322e8cf.cea(itemStack, f15, f16, f2).bGv();
        }
        f2 = f4 + 5.0f;
        class_lC_5322e8cf.cez(class_lq_87a74641, string, f12, f2, class_ii_9b427eda.bjb().coa(f5));
        f = f4 + Class_jf_d1c4f950.bAH(class_lq_87a746412.cat(), 15.0f);
        class_lC_5322e8cf.cez(class_lq_87a746412, string2, f12 + f13 + f8, f, class_mG_52c8d386.coa(f5));
    }

    @Override
    public Class_mG_52c8d386 MI() {
        return ClientMain.dlM().bjf();
    }

    public static void ML(boolean bl) {
        iJFTz = bl;
    }

    public static boolean MN() {
        boolean bl = Class_bJ_24f874fc.MM();
        return !bl;
    }

    public static boolean MM() {
        return iJFTz;
    }

    private static CallSite MR(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bJ_24f874fc" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private Block MK(NukerModule nukerModule) {
        block6: {
            BlockState blockState;
            block5: {
                BlockState blockState2;
                long l = WXZJW ^ 0x5D2623577D54L;
                boolean bl = Class_bJ_24f874fc.MN();
                if (ClientMain.dlmvG.world == null) {
                    return null;
                }
                Class_mB_991638fe class_mB_991638fe = nukerModule.amm();
                if (class_mB_991638fe == null) {
                    return null;
                }
                blockState = blockState2 = ClientMain.dlmvG.world.getBlockState(class_mB_991638fe.cnb());
                if (bl) break block5;
                if (blockState.isAir()) break block6;
                blockState = blockState2;
            }
            return blockState.getBlock();
        }
        return nukerModule.aml();
    }

    private static int MQ(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bJ_24f874fc.MP(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static int MP(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5E46;
        if (NuZfs[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = qGJPS[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])tHMUD.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    tHMUD.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bJ_24f874fc", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bJ_24f874fc.NuZfs[n2] = n3;
        }
        return NuZfs[n2];
    }

    private int MJ() {
        float f;
        block3: {
            ClientPlayerInteractionManager clientPlayerInteractionManager;
            block2: {
                long l = WXZJW ^ 0xE150A128AB4L;
                f = 0.0f;
                boolean bl = Class_bJ_24f874fc.MN();
                clientPlayerInteractionManager = ClientMain.dlmvG.interactionManager;
                if (bl) break block2;
                if (clientPlayerInteractionManager == null) break block3;
                clientPlayerInteractionManager = ClientMain.dlmvG.interactionManager;
            }
            f = ((MultiPlayerGameModeAccessor)clientPlayerInteractionManager).getDestroyProgress();
        }
        return Math.round(MathHelper.clamp((float)f, (float)0.0f, (float)1.0f) * 100.0f);
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bJ_24f874fc.class, "MQ", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

