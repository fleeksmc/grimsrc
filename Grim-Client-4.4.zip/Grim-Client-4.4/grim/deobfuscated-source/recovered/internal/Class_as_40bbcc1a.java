/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_ri_288534d5;

public class Class_as_40bbcc1a
extends Class_az_a4990dcf {
    private Class_lf_d247d983 IMYwx;
    private float roFDy;
    private String eUwLB;
    private Class_lq_87a74641 Dbxwi;
    private Class_ld_bb1690e1 hXIIw;
    private Class_mG_52c8d386 bqrOL;
    private Class_mG_52c8d386 ZNkPs;
    private Class_mG_52c8d386 zaHDb;
    private Class_mG_52c8d386 RUvmV;
    private Class_mG_52c8d386 SVUiL;
    private Class_mG_52c8d386 TgwOQ;
    private boolean OcHac;
    private final Class_ri_288534d5 PDMmP;
    private final Class_ri_288534d5 nWGSH;
    private final Class_ri_288534d5 tTyYq;
    private static final long vmyiF = Class_gb_9d201141.aYR(-2646341689623667932L, -9019365439646895507L, MethodHandles.lookup().lookupClass()).a(233193405348572L);
    private static final long[] rxBGn;
    private static final Integer[] HTRFc;
    private static final Map sYRBY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_as_40bbcc1a() {
        long l = vmyiF ^ 0x5749A1474546L;
        this.hXIIw = Class_ld_bb1690e1.all(2.0f);
        this.bqrOL = Class_mG_52c8d386.hoGuU;
        this.ZNkPs = Class_mG_52c8d386.hoGuU;
        this.zaHDb = Class_mG_52c8d386.hoGuU;
        this.RUvmV = null;
        this.SVUiL = null;
        this.TgwOQ = null;
        this.OcHac = false;
        this.PDMmP = new Class_ri_288534d5((int)Class_as_40bbcc1a.rT("w", (int)1907, (long)(0x63B2DD280CB7D025L ^ l)));
        this.nWGSH = new Class_ri_288534d5((int)Class_as_40bbcc1a.rT("w", (int)22994, (long)(0x68A5BB3B8CA68E85L ^ l)));
        this.tTyYq = new Class_ri_288534d5((int)Class_as_40bbcc1a.rT("w", (int)22994, (long)(0x68A5BB3B8CA68E85L ^ l)));
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        sYRBY = new HashMap(13);
        long l = vmyiF ^ 0x37897FB9046FL;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "\u00ec][M\u0017\u00c9\u00a5az\u00d1my\u00e6 \u00b9\u0003";
        int n2 = "\u00ec][M\u0017\u00c9\u00a5az\u00d1my\u00e6 \u00b9\u0003".length();
        int n3 = 0;
        do {
            byte[] byArray3 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
            byte[] byArray4 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray4[0] & 0xFFL) << 56 | ((long)byArray4[1] & 0xFFL) << 48 | ((long)byArray4[2] & 0xFFL) << 40 | ((long)byArray4[3] & 0xFFL) << 32 | ((long)byArray4[4] & 0xFFL) << 24 | ((long)byArray4[5] & 0xFFL) << 16 | ((long)byArray4[6] & 0xFFL) << 8 | (long)byArray4[7] & 0xFFL;
        } while (n3 < n2);
        rxBGn = lArray;
        HTRFc = new Integer[2];
    }

    @Override
    public float dn() {
        this.rp();
        return this.WjISQ;
    }

    public Class_mG_52c8d386 rv() {
        return this.bqrOL;
    }

    public String rs() {
        return this.eUwLB;
    }

    /*
     * Unable to fully structure code
     */
    private void rp() {
        block11: {
            block10: {
                block9: {
                    block8: {
                        block7: {
                            var1_1 = Class_as_40bbcc1a.vmyiF ^ 102748456605598L;
                            var4_2 = 10.0f;
                            var3_3 = Class_aj_95d0a719.oA();
                            v0 = this.eUwLB;
                            if (var3_3 == null) break block7;
                            if (v0 == null) ** GOTO lbl-1000
                            v1 = this;
                            if (var3_3 == null) break block8;
                            v0 = v1.eUwLB;
                        }
                        if (v0.isBlank()) ** GOTO lbl-1000
                        v1 = this;
                    }
                    if (v1.Dbxwi != null) {
                        v2 = true;
                    } else lbl-1000:
                    // 3 sources

                    {
                        v2 = var5_4 = false;
                    }
                    if (var3_3 == null) break block9;
                    if (this.IMYwx == null) break block10;
                    var4_2 += Class_lE_06fbe260.WxpHL.bYM(this.roFDy).caq(this.IMYwx.bXR());
                }
                v3 = var5_4;
                if (var3_3 == null) break block11;
                if (v3) {
                    var4_2 += 3.0f;
                }
            }
            v3 = var5_4;
        }
        if (v3) {
            var4_2 += this.Dbxwi.cao(this.eUwLB);
        }
        this.BcpIo = var4_2;
    }

    public Class_ld_bb1690e1 ru() {
        return this.hXIIw;
    }

    public Class_mG_52c8d386 rw() {
        return this.ZNkPs;
    }

    public Class_lq_87a74641 rt() {
        return this.Dbxwi;
    }

    public Class_mG_52c8d386 rx() {
        return this.zaHDb;
    }

    public Class_as_40bbcc1a ro(Class_lq_87a74641 class_lq_87a74641) {
        this.Dbxwi = class_lq_87a74641;
        this.rp();
        return this;
    }

    public Class_lf_d247d983 rq() {
        return this.IMYwx;
    }

    public float rr() {
        return this.roFDy;
    }

    public Class_mG_52c8d386 ry() {
        return this.RUvmV;
    }

    public Class_mG_52c8d386 rz() {
        return this.SVUiL;
    }

    public Class_ri_288534d5 rD() {
        return this.nWGSH;
    }

    private static int rR(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5A00;
        if (HTRFc[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = rxBGn[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])sYRBY.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    sYRBY.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_as_40bbcc1a", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_as_40bbcc1a.HTRFc[n2] = n3;
        }
        return HTRFc[n2];
    }

    public Class_as_40bbcc1a rI(Class_ld_bb1690e1 class_ld_bb1690e1) {
        this.hXIIw = class_ld_bb1690e1;
        return this;
    }

    public boolean rB() {
        return this.OcHac;
    }

    public Class_ri_288534d5 rC() {
        return this.PDMmP;
    }

    public Class_as_40bbcc1a rK(Class_mG_52c8d386 class_mG_52c8d386) {
        this.ZNkPs = class_mG_52c8d386;
        return this;
    }

    public Class_as_40bbcc1a rM(Class_mG_52c8d386 class_mG_52c8d386) {
        this.RUvmV = class_mG_52c8d386;
        return this;
    }

    public Class_ri_288534d5 rE() {
        return this.tTyYq;
    }

    private static CallSite rT(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_as_40bbcc1a" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public Class_as_40bbcc1a rN(Class_mG_52c8d386 class_mG_52c8d386) {
        this.SVUiL = class_mG_52c8d386;
        return this;
    }

    public Class_as_40bbcc1a rP(boolean bl) {
        this.OcHac = bl;
        return this;
    }

    private static int rS(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_as_40bbcc1a.rR(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static MatchException rQ(MatchException matchException) {
        return matchException;
    }

    public Class_mG_52c8d386 rA() {
        return this.TgwOQ;
    }

    public Class_as_40bbcc1a rJ(Class_mG_52c8d386 class_mG_52c8d386) {
        this.bqrOL = class_mG_52c8d386;
        return this;
    }

    public Class_as_40bbcc1a rL(Class_mG_52c8d386 class_mG_52c8d386) {
        this.zaHDb = class_mG_52c8d386;
        return this;
    }

    public Class_as_40bbcc1a rO(Class_mG_52c8d386 class_mG_52c8d386) {
        this.TgwOQ = class_mG_52c8d386;
        return this;
    }

    @Override
    public float kN() {
        this.rp();
        return this.BcpIo;
    }

    @Override
    protected void bV(Class_lC_5322e8cf class_lC_5322e8cf) {
        block24: {
            Class_as_40bbcc1a class_as_40bbcc1a;
            float f;
            float f2;
            block26: {
                String string;
                block25: {
                    Class_as_40bbcc1a class_as_40bbcc1a2;
                    String[] stringArray;
                    block23: {
                        Class_mG_52c8d386 class_mG_52c8d386;
                        Class_mG_52c8d386 class_mG_52c8d3862;
                        Class_mG_52c8d386 class_mG_52c8d3863;
                        block22: {
                            Class_mG_52c8d386 class_mG_52c8d3864;
                            block20: {
                                block21: {
                                    boolean bl;
                                    block19: {
                                        Class_mG_52c8d386 class_mG_52c8d3865;
                                        block17: {
                                            block18: {
                                                block16: {
                                                    Class_mG_52c8d386 class_mG_52c8d3866;
                                                    block14: {
                                                        block15: {
                                                            long l = vmyiF ^ 0x6E5C324F7A2DL;
                                                            String[] stringArray2 = Class_aj_95d0a719.oA();
                                                            this.rp();
                                                            bl = this.ti(class_lC_5322e8cf);
                                                            stringArray = stringArray2;
                                                            class_mG_52c8d3866 = this.RUvmV;
                                                            if (stringArray == null) break block14;
                                                            if (class_mG_52c8d3866 == null) break block15;
                                                            Class_mG_52c8d386 class_mG_52c8d3867 = class_mG_52c8d3863 = bl ? this.RUvmV : this.bqrOL;
                                                            if (stringArray != null) break block16;
                                                        }
                                                        class_mG_52c8d3866 = this.bqrOL;
                                                    }
                                                    class_mG_52c8d3863 = class_mG_52c8d3866;
                                                }
                                                class_mG_52c8d3865 = this.SVUiL;
                                                if (stringArray == null) break block17;
                                                if (class_mG_52c8d3865 == null) break block18;
                                                Class_mG_52c8d386 class_mG_52c8d3868 = class_mG_52c8d3862 = bl ? this.SVUiL : this.ZNkPs;
                                                if (stringArray != null) break block19;
                                            }
                                            class_mG_52c8d3865 = this.ZNkPs;
                                        }
                                        class_mG_52c8d3862 = class_mG_52c8d3865;
                                    }
                                    class_mG_52c8d3864 = this.TgwOQ;
                                    if (stringArray == null) break block20;
                                    if (class_mG_52c8d3864 == null) break block21;
                                    Class_mG_52c8d386 class_mG_52c8d3869 = class_mG_52c8d386 = bl ? this.TgwOQ : this.zaHDb;
                                    if (stringArray != null) break block22;
                                }
                                class_mG_52c8d3864 = this.zaHDb;
                            }
                            class_mG_52c8d386 = class_mG_52c8d3864;
                        }
                        this.PDMmP.dfT(class_mG_52c8d3863);
                        this.nWGSH.dfT(class_mG_52c8d3862);
                        this.tTyYq.dfT(class_mG_52c8d386);
                        class_lC_5322e8cf.cdg(this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ, this.hXIIw, this.tTyYq.dfU());
                        f2 = this.MCnYt + 5.0f;
                        class_as_40bbcc1a2 = this;
                        if (stringArray != null) {
                            if (class_as_40bbcc1a2.IMYwx != null) {
                                f = this.MCnYt + 5.0f;
                                float f3 = this.pNyTQ + Class_jf_d1c4f950.bAH(this.roFDy, this.WjISQ);
                                class_lC_5322e8cf.cem(this.IMYwx, f, f3, this.roFDy, this.PDMmP.dfU());
                                f2 = f + this.roFDy + 3.0f;
                            }
                            class_as_40bbcc1a2 = this;
                        }
                        if (stringArray == null) break block23;
                        if (class_as_40bbcc1a2.Dbxwi == null) break block24;
                        class_as_40bbcc1a2 = this;
                    }
                    string = class_as_40bbcc1a2.eUwLB;
                    if (stringArray == null) break block25;
                    if (string == null) break block24;
                    class_as_40bbcc1a = this;
                    if (stringArray == null) break block26;
                    string = class_as_40bbcc1a.eUwLB;
                }
                if (string.isBlank()) break block24;
                class_as_40bbcc1a = this;
            }
            f = class_as_40bbcc1a.pNyTQ + Class_jf_d1c4f950.bAH(this.Dbxwi.cat(), this.WjISQ);
            class_lC_5322e8cf.cez(this.Dbxwi, this.eUwLB, f2, f, this.nWGSH.dfU());
        }
    }

    public Class_as_40bbcc1a rG(float f) {
        this.roFDy = f;
        return this;
    }

    public Class_as_40bbcc1a rH(String string) {
        this.eUwLB = string;
        return this;
    }

    public Class_as_40bbcc1a rF(Class_lf_d247d983 class_lf_d247d983) {
        this.IMYwx = class_lf_d247d983;
        return this;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_as_40bbcc1a.class, "rS", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

