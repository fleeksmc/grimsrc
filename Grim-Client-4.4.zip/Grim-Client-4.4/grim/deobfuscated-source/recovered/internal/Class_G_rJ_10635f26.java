/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

final class Class_G_rJ_10635f26
extends Record {
    private final float listX;
    private final float listY;
    private final float listWidth;
    private final float listHeight;
    private final float footerX;
    private final float footerY;
    private final float footerWidth;
    private final float footerHeight;
    private final float rowsStartY;
    private final float addIconY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_G_rJ_10635f26(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10) {
        this.listX = f;
        this.listY = f2;
        this.listWidth = f3;
        this.listHeight = f4;
        this.footerX = f5;
        this.footerY = f6;
        this.footerWidth = f7;
        this.footerHeight = f8;
        this.rowsStartY = f9;
        this.addIconY = f10;
    }

    static {
        NativeLoader.doInit(Class_G_rJ_10635f26.class);
    }

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    public native float listWidth();

    public native float rowsStartY();

    public native float addIconY();

    native float addIconX();

    public native float footerX();

    public native float footerY();

    public native float listX();

    public native float listY();

    public native float listHeight();

    public native float footerWidth();

    public native float footerHeight();
}

