/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_bc_f7ef99a1;
import recovered.internal.Class_cB_67aec11c;

class Class_bc_sa_c60341ff {
    private final Object YauLb;
    private final Class_cB_67aec11c WygRB;
    private final int VIjzs;
    private final int[] qScLI;
    private final int[] JJlyC;
    private final int[] oEOCs;
    private static long JMlDh;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bc_sa_c60341ff(Class_bc_f7ef99a1 class_bc_f7ef99a1, Object object, Class_cB_67aec11c class_cB_67aec11c, int n, int[] nArray, int[] nArray2, int[] nArray3) {
        this.YauLb = object;
        this.WygRB = class_cB_67aec11c;
        this.VIjzs = n;
        this.qScLI = nArray;
        this.JJlyC = nArray2;
        this.oEOCs = nArray3;
    }

    static {
        NativeLoader.doInit(Class_bc_sa_c60341ff.class);
        Class_bc_sa_c60341ff._7df91a5543007a73dde1415504f358fe();
    }

    private static native void _7df91a5543007a73dde1415504f358fe();

    private static native MatchException dne(MatchException var0);

    private native boolean dnd();
}

