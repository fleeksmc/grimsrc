/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import recovered.core.ClientMain;
import recovered.internal.Class_cr_3ba4ae18;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jG_69891630;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;

public abstract class Class_co_c10d0572
extends Class_cr_3ba4ae18 {
    private static final long pzAXQ = Class_gb_9d201141.aYR(-3922662000648132649L, -4878582657813872057L, MethodHandles.lookup().lookupClass()).a(154218339454509L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_co_c10d0572(int[] nArray, Class_lf_d247d983 class_lf_d247d983) {
        super(nArray, class_lf_d247d983);
    }

    @Override
    public void Ph(Class_lC_5322e8cf class_lC_5322e8cf) {
        float f;
        float f2;
        block7: {
            float f3;
            block6: {
                long l = pzAXQ ^ 0x3B656CA4AA40L;
                Class_iS_888f260e[] class_iS_888f260eArray = Class_cr_3ba4ae18.SC();
                this.LX(class_lC_5322e8cf);
                Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
                float f4 = this.ormBS.dhj() * this.KgDVz.dhj();
                if (f4 == 0.0f) {
                    return;
                }
                Class_mG_52c8d386 class_mG_52c8d386 = Class_mG_52c8d386.QHTxQ.cob(0.3f * this.gILqY.dhj());
                Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, Math.min(1.0f, f4));
                float f5 = 0.5f + f4 * 0.5f - 0.05f * this.OsbYH.dhj();
                float f6 = this.RT();
                Class_jH_c1172273.bId(class_lC_5322e8cf, this.toIeR + this.RU() / 2.0f, this.QWaAn + this.RV() / 2.0f, f5);
                float f7 = f6 - 1.0f;
                f3 = f7 == 0.0f ? 0 : (f7 > 0.0f ? 1 : -1);
                if (class_iS_888f260eArray2 == null) break block6;
                if (f3 != false) {
                    Class_jH_c1172273.bId(class_lC_5322e8cf, this.toIeR, this.QWaAn, f6);
                }
                class_lC_5322e8cf.ccY(this.toIeR - 5.0f, this.QWaAn - 5.0f, this.jTsqG + 10.0f, this.Xtjvx + 10.0f, 15.0f, Class_ld_bb1690e1.all(6.0f), class_mG_52c8d386);
                Class_jG_69891630.bHK(class_lC_5322e8cf, this.toIeR, this.QWaAn, this.jTsqG, Math.max(20.0f, this.Xtjvx));
                this.NV(class_lC_5322e8cf);
                Class_jG_69891630.bHN();
                f2 = f6;
                f = 1.0f;
                if (class_iS_888f260eArray2 == null) break block7;
                float f8 = f2 - f;
                f3 = f8 == 0.0f ? 0 : (f8 > 0.0f ? 1 : -1);
            }
            if (f3 != false) {
                Class_jH_c1172273.bIf();
            }
            Class_jH_c1172273.bIf();
            f2 = 1.0f;
            f = 1.0f;
        }
        Class_jF_38b68c76.bHz(f2, f, 1.0f, 1.0f);
    }

    @Override
    protected void NV(Class_lC_5322e8cf class_lC_5322e8cf) {
        Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
        Class_ii_9b427eda class_ii_9b427eda = ClientMain.dlM();
        float f = this.ormBS.dhj();
        float f2 = this.gILqY.dhj();
        Class_mG_52c8d386 class_mG_52c8d386 = class_ii_9b427eda.bjb().coa(255.0f * f);
        Class_mG_52c8d386 class_mG_52c8d3862 = class_ii_9b427eda.bjc().coa(255.0f * f);
        float f3 = 20.0f;
        float f4 = Math.max(f3, this.Xtjvx);
        class_lC_5322e8cf.ccU(this.toIeR, this.QWaAn, this.jTsqG, f4, f, f2);
        float f5 = this.toIeR + 7.0f;
        float f6 = this.QWaAn + Class_jf_d1c4f950.bAH(class_lq_87a74641.cat(), f3);
        class_lC_5322e8cf.ceA(class_lq_87a74641, this.eqWHC, f5, f6, class_mG_52c8d386);
        float f7 = 8.0f;
        float f8 = this.toIeR + this.jTsqG - f7 - 7.0f;
        float f9 = this.QWaAn + 6.0f;
        class_lC_5322e8cf.cem(this.jAncU, f8, f9, f7, class_mG_52c8d3862);
    }

    private static MatchException QW(MatchException matchException) {
        return matchException;
    }
}

