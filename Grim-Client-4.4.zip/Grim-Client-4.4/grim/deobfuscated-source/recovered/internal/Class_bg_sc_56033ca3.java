/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

class Class_bg_sc_56033ca3 {
    static int[] gbAZn;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_bg_sc_56033ca3.class);
        Class_bg_sc_56033ca3._24b91673e83bbd509eaef3399b56ed93();
    }

    private static native void _24b91673e83bbd509eaef3399b56ed93();
}

