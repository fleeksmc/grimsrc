/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_gX_511309ce;

public class Class_gX_tr_05a195e5
extends Class_gX_511309ce {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

