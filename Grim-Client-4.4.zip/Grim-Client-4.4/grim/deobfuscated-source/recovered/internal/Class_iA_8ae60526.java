/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import recovered.core.NativeLoader;
import recovered.internal.Class_iy_c88c0f4f;
import recovered.internal.Class_mu_a94f6370;

public class Class_iA_8ae60526 {
    private final Class_mu_a94f6370<Class_iy_c88c0f4f> mWcuI = new Class_mu_a94f6370();
    private static long QruPQ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_iA_8ae60526.class);
        Class_iA_8ae60526._fc55fdbf12e352490a0fce49ce34f109();
    }

    private static native MatchException bpT(MatchException var0);

    public native void bpO(Class_iy_c88c0f4f var1);

    public native Class_iy_c88c0f4f bpQ(String var1);

    public native Class_mu_a94f6370<Class_iy_c88c0f4f> bpR();

    public native void bpP(String var1);

    public native void bpN(List<Class_iy_c88c0f4f> var1);

    private static native /* synthetic */ boolean bpS(String var0, Class_iy_c88c0f4f var1);

    private static native void _fc55fdbf12e352490a0fce49ce34f109();
}

