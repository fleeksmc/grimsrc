/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_ar_rT_99a3d414;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_ar_511d46e6
extends Class_az_a4990dcf {
    public static float PlhLL = 95.0f;
    public static float XUVbp = 65.0f;
    public static float UUhbc = 10.0f;
    private static float rKrUJ = 72.5f;
    private static float hDMsk = 30.0f;
    private static float FEKcs = 5.0f;
    private static float Zdkyt = 25.0f;
    private static float jpflI = 9.0f;
    private static float pABir = 14.0f;
    private static float WBuuz = 15.0f;
    private static float mbaYO = 8.0f;
    private static float xiWEV = 1.0f;
    private final boolean klgAN;
    private final boolean bvQbu;
    private final Map<Integer, Class_ar_rT_99a3d414> BWfDJ;
    private final Class_ri_288534d5 cHtGL;
    private final Class_ri_288534d5 TZUuw;
    private final Class_rk_bf8630d1 wWScb;
    private final Class_rk_bf8630d1 RnGbo;
    private final Class_rk_bf8630d1 yfvEk;
    private final Class_rk_bf8630d1 iSnTn;
    private final Class_rk_bf8630d1 uVLZj;
    private final Class_rk_bf8630d1 KhklX;
    private boolean wRdLT;
    private boolean YZuVT;
    private boolean jOVQz;
    private float imcLz;
    private float ulqwb;
    private float JLHJd;
    private float mFvOG;
    private boolean ItrsY;
    private Class_mG_52c8d386 JvOAZ;
    private Runnable nEQMA;
    private static long UwIwA;
    private static String[] uBvLb;
    private static String[] ZbVBN;
    private static Map ERPUB;
    private static long[] YbRaZ;
    private static Integer[] Qpluh;
    private static Map qwVjG;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native String ri(int var0, long var1);

    public Class_ar_511d46e6(boolean bl, boolean bl2) {
        long l = UwIwA ^ 0x1C47EF57659AL;
        super(0.0f, 0.0f, 95.0f, Class_ar_511d46e6.rc(bl, bl2));
        this.BWfDJ = new LinkedHashMap<Integer, Class_ar_rT_99a3d414>();
        this.cHtGL = new Class_ri_288534d5((int)Class_ar_511d46e6.rn("c", (int)19406, (long)(0x611C3664876AEC29L ^ l)));
        this.TZUuw = new Class_ri_288534d5((int)Class_ar_511d46e6.rn("c", (int)20914, (long)(0x16331214BD537652L ^ l)));
        this.wWScb = new Class_rk_bf8630d1((int)Class_ar_511d46e6.rn("c", (int)11441, (long)(0x474F2E5BE5820B55L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.RnGbo = new Class_rk_bf8630d1((int)Class_ar_511d46e6.rn("c", (int)25706, (long)(0x66E6476C9429C38BL ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.yfvEk = new Class_rk_bf8630d1((int)Class_ar_511d46e6.rn("c", (int)25706, (long)(0x66E6476C9429C38BL ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.iSnTn = new Class_rk_bf8630d1((int)Class_ar_511d46e6.rn("c", (int)25706, (long)(0x66E6476C9429C38BL ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.uVLZj = new Class_rk_bf8630d1((int)Class_ar_511d46e6.rn("c", (int)13044, (long)(0x5B463A81761D1511L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.KhklX = new Class_rk_bf8630d1((int)Class_ar_511d46e6.rn("c", (int)7341, (long)(0x1C145B0477AF3B4BL ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.JvOAZ = Class_mG_52c8d386.hoGuU;
        this.nEQMA = Class_ar_511d46e6::rf;
        this.klgAN = bl;
        this.bvQbu = bl2;
    }

    static {
        NativeLoader.doInit(Class_ar_511d46e6.class);
        Class_ar_511d46e6._b444f5f277c0077159632a5e6f930aee();
    }

    private static native /* synthetic */ boolean rd(Class_ar_rT_99a3d414 var0);

    private static native Class_lq_87a74641 rb();

    private static native CallSite rn(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native /* synthetic */ void rf();

    private static native int rl(int var0, long var1);

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    private static native int rm(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native MatchException rg(MatchException var0);

    private static native float rc(boolean var0, boolean var1);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private static native String rh(byte[] var0);

    private static native /* synthetic */ void re();

    private static native void _b444f5f277c0077159632a5e6f930aee();

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private native float ra();

    public native Class_ar_511d46e6 qH(Runnable var1);

    public static native float qF(boolean var0, boolean var1);

    private native boolean qQ(double var1, double var3, Class_mA_32d8a5f2 var5);

    public native void qI(Class_mG_52c8d386 var1);

    private native Class_mG_52c8d386 qK();

    public native void qG(Class_lC_5322e8cf var1, Class_mG_52c8d386 var2);

    public native boolean qM(Class_mG_52c8d386 var1, float var2);

    public native Class_mG_52c8d386 qL();

    public native float qN();

    public native Class_mG_52c8d386 qJ();

    private native void qP(Class_lC_5322e8cf var1, List<Class_ar_rT_99a3d414> var2);

    public native float qO();

    private native List<Class_ar_rT_99a3d414> qR();

    private native Class_lc_b8480f87 qS();

    private native Class_lc_b8480f87 qT();

    private native Class_lc_b8480f87 qU();

    private native void qV(Class_lC_5322e8cf var1, float var2, float var3);

    private native float qW();

    private native float qX();

    private native float qY();

    private native float qZ();

    private static native CallSite rk(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native Object rj(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);
}

