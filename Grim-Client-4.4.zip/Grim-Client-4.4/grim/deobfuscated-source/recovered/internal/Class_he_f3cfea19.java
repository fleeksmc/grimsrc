/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 */
package recovered.internal;

import net.minecraft.entity.Entity;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_he_f3cfea19
extends Class_hH_ae8f8f77 {
    private Entity djrlD;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_he_f3cfea19(Entity entity) {
        this.djrlD = entity;
    }

    public Entity bcx() {
        return this.djrlD;
    }
}

