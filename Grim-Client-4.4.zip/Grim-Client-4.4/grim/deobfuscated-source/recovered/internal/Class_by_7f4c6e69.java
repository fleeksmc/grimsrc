/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import recovered.core.ClientMain;
import recovered.core.NativeLoader;
import recovered.internal.Class_P_2c9819bb;
import recovered.internal.Class_S_f3cb3437;
import recovered.internal.Class_Z_a19ce218;
import recovered.internal.Class_aA_8076b584;
import recovered.internal.Class_ab_035d8734;
import recovered.internal.Class_as_40bbcc1a;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bw_21f72edc;
import recovered.internal.Class_by_sf_14d666cb;
import recovered.internal.Class_by_sg_9b1a6ca5;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_iy_c88c0f4f;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_l_9f9f1a50;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_nd_e33facc7;
import recovered.internal.Class_nf_8f40fc48;
import recovered.internal.Class_ng_91317468;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_by_7f4c6e69
extends Class_aA_8076b584 {
    private static Class_mG_52c8d386 KCPRy;
    private Class_iy_c88c0f4f cyJzR;
    private Class_nf_8f40fc48 MPHDO;
    private final Class_ab_035d8734 Vldqu;
    private final Class_lq_87a74641 AUvqD;
    private final Class_as_40bbcc1a oZmkb;
    private final Class_as_40bbcc1a OMsnK;
    private final Class_as_40bbcc1a xwVXG;
    private final Class_as_40bbcc1a QTCKH;
    private final Class_l_9f9f1a50 jGHQn;
    private final Class_l_9f9f1a50 xUJUF;
    private final Class_l_9f9f1a50 fHSrA;
    private Class_mG_52c8d386 QKlpg;
    private Class_mG_52c8d386 LwbUH;
    private Class_mG_52c8d386 EEeXl;
    private Class_mG_52c8d386 iUDgS;
    private List<Class_as_40bbcc1a> nZzYS;
    private List<Class_as_40bbcc1a> eiayC;
    private List<Class_l_9f9f1a50> QAVAK;
    private final Class_P_2c9819bb cJZCT;
    private final Class_P_2c9819bb YwyKS;
    private final Class_Z_a19ce218 LoViH;
    private boolean KXDuV;
    private boolean cMiHK;
    private final Class_rk_bf8630d1 Qgzvc;
    private final Class_rk_bf8630d1 XnthW;
    private final Class_rk_bf8630d1 afExC;
    private final Class_rk_bf8630d1 AmKbT;
    private static long ziXVK;
    private static String[] cdfzx;
    private static String[] ZekGs;
    private static Map nWZwm;
    private static long[] nnWKW;
    private static Integer[] lqWIa;
    private static Map DSvvZ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_by_7f4c6e69(Class_iy_c88c0f4f class_iy_c88c0f4f, Class_nf_8f40fc48 class_nf_8f40fc48) {
        long l = ziXVK ^ 0x3D2F9DF592BBL;
        this.QKlpg = Class_mG_52c8d386.hoGuU;
        this.LwbUH = Class_mG_52c8d386.hoGuU;
        int[] nArray = Class_bw_21f72edc.IJ();
        this.EEeXl = Class_mG_52c8d386.hoGuU;
        this.iUDgS = Class_mG_52c8d386.hoGuU;
        this.nZzYS = new ArrayList<Class_as_40bbcc1a>();
        this.eiayC = new ArrayList<Class_as_40bbcc1a>();
        this.QAVAK = new ArrayList<Class_l_9f9f1a50>();
        this.cMiHK = false;
        this.Qgzvc = new Class_rk_bf8630d1((int)Class_by_7f4c6e69.Km("u", (int)2270, (long)(0x5CAB8D430AE8288DL ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        this.XnthW = new Class_rk_bf8630d1((int)Class_by_7f4c6e69.Km("u", (int)28098, (long)(0x490D4C744E834D92L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.afExC = new Class_rk_bf8630d1((int)Class_by_7f4c6e69.Km("u", (int)28098, (long)(0x490D4C744E834D92L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.AmKbT = new Class_rk_bf8630d1((int)Class_by_7f4c6e69.Km("u", (int)28098, (long)(0x490D4C744E834D92L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.cyJzR = class_iy_c88c0f4f;
        this.MPHDO = class_nf_8f40fc48;
        this.tJ(true);
        Class_ig_ca326427 class_ig_ca326427 = ClientMain.dlM().bjG();
        this.AUvqD = Class_lE_06fbe260.WTzbi.bYM(6.0f);
        this.oZmkb = (Class_as_40bbcc1a)new Class_as_40bbcc1a().ro(this.AUvqD).rH((String)((Object)Class_by_7f4c6e69.Kj("e", (int)29678, (long)(0x246ECC6FE6FC6E7AL ^ l)))).rF(Class_lf_d247d983.kRmbJ).rG(7.0f).to(10.0f);
        this.jGHQn = new Class_l_9f9f1a50((Class_az_a4990dcf)this.oZmkb, true).cP((String)((Object)Class_by_7f4c6e69.Kj("e", (int)10539, (long)(0x21AA16980634B4A2L ^ l)))).cQ(Class_lE_06fbe260.WTzbi.bYM(6.0f)).cT(Class_ld_bb1690e1.all(3.0f));
        this.OMsnK = (Class_as_40bbcc1a)new Class_as_40bbcc1a().ro(this.AUvqD).rH((String)((Object)Class_by_7f4c6e69.Kj("e", (int)29394, (long)(0x5BCB6B10B484EF5AL ^ l)))).rF(Class_lf_d247d983.EqCfG).rG(7.0f).to(10.0f);
        this.xUJUF = new Class_l_9f9f1a50((Class_az_a4990dcf)this.OMsnK, true).cP((String)((Object)Class_by_7f4c6e69.Kj("e", (int)18447, (long)(0x5A8B3890E983D582L ^ l)))).cQ(Class_lE_06fbe260.WTzbi.bYM(6.0f)).cT(Class_ld_bb1690e1.all(3.0f));
        int[] nArray2 = nArray;
        try {
            this.xwVXG = (Class_as_40bbcc1a)new Class_as_40bbcc1a().ro(this.AUvqD).rH((String)((Object)Class_by_7f4c6e69.Kj("e", (int)12565, (long)(0x67EA6D8F22EA2CA4L ^ l)))).rF(Class_lf_d247d983.EqCfG).rG(7.0f).to(10.0f);
            this.fHSrA = new Class_l_9f9f1a50((Class_az_a4990dcf)this.xwVXG, true).cP((String)((Object)Class_by_7f4c6e69.Kj("e", (int)8580, (long)(0x6A9F03501D9FBC1EL ^ l)))).cQ(Class_lE_06fbe260.WTzbi.bYM(6.0f)).cT(Class_ld_bb1690e1.all(3.0f));
            this.QTCKH = (Class_as_40bbcc1a)new Class_as_40bbcc1a().ro(this.AUvqD).to(15.0f);
            this.cJZCT = ((Class_P_2c9819bb)new Class_P_2c9819bb(null, (String)((Object)Class_by_7f4c6e69.Kj("e", (int)17822, (long)(0x19B69FF9746CD807L ^ l))), Class_lf_d247d983.cuxpa).ja(class_ig_ca326427.biw().bhF())).hO(Class_S_f3cb3437.CLgKH);
            this.YwyKS = ((Class_P_2c9819bb)((Class_P_2c9819bb)new Class_P_2c9819bb(null, (String)((Object)Class_by_7f4c6e69.Kj("e", (int)14237, (long)(0x519EAA2BCCDA2A1AL ^ l))), Class_lf_d247d983.JHGge).ja(Class_jk_a0800133.mPXGi)).iY(Class_jk_a0800133.mPXGi)).hO(Class_S_f3cb3437.CLgKH);
            this.Vldqu = new Class_ab_035d8734(class_nf_8f40fc48.ctS()).lg(class_ig_ca326427.biq()).li(this::Ke);
            this.LoViH = new Class_Z_a19ce218().kJ(Class_lE_06fbe260.WTzbi.bYM(6.0f)).kK(3.0f).kL((int)Class_by_7f4c6e69.Km("u", (int)31340, (long)(0x36516539635ADA38L ^ l))).kM(Class_rj_b691f4f7.MBpuQ).kP((String)((Object)Class_by_7f4c6e69.Kj("e", (int)25212, (long)(0x6BA25A20C603FFCCL ^ l))));
            this.LoViH.kO(this.Jb());
            if (nArray2 != null) {
                Class_iS_888f260e.bwK("KuC8Mb");
            }
        }
        catch (MatchException matchException) {
            throw Class_by_7f4c6e69.Kf(matchException);
        }
    }

    static {
        NativeLoader.doInit(Class_by_7f4c6e69.class);
        Class_by_7f4c6e69._97df465657bfe5f2e6c05dff9ae6d725();
    }

    @Override
    public native float dn();

    public native Class_rk_bf8630d1 JP();

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private native /* synthetic */ void Ke(Class_ab_035d8734 var1);

    private native /* synthetic */ void Kd(Class_P_2c9819bb var1);

    private native void IV(Class_lC_5322e8cf var1);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    public native Class_by_7f4c6e69 JS(Class_iy_c88c0f4f var1);

    public native Class_by_7f4c6e69 IU(Class_nf_8f40fc48 var1);

    public native Class_nf_8f40fc48 Js();

    public native boolean JN();

    public native Class_iy_c88c0f4f Jr();

    private static native void _97df465657bfe5f2e6c05dff9ae6d725();

    private native Class_l_9f9f1a50 Ja(int var1, Class_ng_91317468 var2, Class_as_40bbcc1a var3);

    private native float Jg();

    private native float Jh(List<Class_ng_91317468> var1, float var2, float var3);

    private native float Ji(Class_nd_e33facc7 var1, List<Class_nd_e33facc7> var2, float var3, float var4);

    private static native MatchException Kf(MatchException var0);

    private static native CallSite Km(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native CallSite Kj(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native Class_as_40bbcc1a IX(int var1, Class_ng_91317468 var2);

    private native float IY(Class_lC_5322e8cf var1, List<Class_nd_e33facc7> var2, float var3, float var4, float var5, float var6, int[] var7);

    private native Class_as_40bbcc1a IZ(int var1, Class_nd_e33facc7 var2);

    private native void Jc(Class_mG_52c8d386 var1, Class_mG_52c8d386 var2);

    private native float IW(Class_lC_5322e8cf var1, List<Class_ng_91317468> var2, boolean var3, float var4, float var5, float var6, float var7, int[] var8);

    private native Class_lc_b8480f87 Jd(float var1);

    private native int Jb();

    private native Class_lc_b8480f87 Je(float var1);

    private native void Jf(double var1, double var3);

    public native Class_l_9f9f1a50 JB();

    public native Class_mG_52c8d386 JF();

    public native Class_rk_bf8630d1 JQ();

    public native List<Class_l_9f9f1a50> JI();

    private native String Jp(long var1);

    public native Class_rk_bf8630d1 JR();

    public native Class_mG_52c8d386 JD();

    public native Class_P_2c9819bb JJ();

    public native Class_by_7f4c6e69 JT(Class_mG_52c8d386 var1);

    public native Class_by_7f4c6e69 JV(Class_mG_52c8d386 var1);

    public native Class_l_9f9f1a50 JA();

    public native Class_by_7f4c6e69 JW(Class_mG_52c8d386 var1);

    public native Class_by_7f4c6e69 JY(List<Class_as_40bbcc1a> var1);

    private native Class_by_sf_14d666cb Jo(List<Class_nd_e33facc7> var1, float var2, float var3);

    public native Class_by_7f4c6e69 JX(List<Class_as_40bbcc1a> var1);

    private static native String Kh(int var0, long var1);

    private native boolean Jk(Class_nd_e33facc7 var1);

    public native Class_mG_52c8d386 JC();

    public native Class_as_40bbcc1a Jw();

    public native boolean JM();

    public native Class_rk_bf8630d1 JO();

    public native Class_mG_52c8d386 JE();

    public native Class_P_2c9819bb JK();

    public native Class_by_7f4c6e69 JZ(List<Class_l_9f9f1a50> var1);

    public native Class_by_7f4c6e69 Ka(boolean var1);

    public native Class_by_7f4c6e69 Kb(boolean var1);

    private static native Object Ki(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native int Kk(int var0, long var1);

    private native boolean Jl(Class_nd_e33facc7 var1);

    private static native int Kl(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native List<Class_nd_e33facc7> Jq();

    public native Class_ab_035d8734 Jt();

    private native /* synthetic */ void Kc(Class_P_2c9819bb var1);

    public native Class_lq_87a74641 Ju();

    public native Class_as_40bbcc1a Jx();

    public native Class_Z_a19ce218 JL();

    public native Class_by_7f4c6e69 JU(Class_mG_52c8d386 var1);

    public native List<Class_as_40bbcc1a> JG();

    public native List<Class_as_40bbcc1a> JH();

    public native Class_as_40bbcc1a Jy();

    private native Class_by_sg_9b1a6ca5 Jn(List<Class_ng_91317468> var1, boolean var2, float var3, float var4);

    public native Class_l_9f9f1a50 Jz();

    private static native String Kg(byte[] var0);

    public native Class_as_40bbcc1a Jv();

    private native Class_as_40bbcc1a Jj(Class_nd_e33facc7 var1);

    private native float Jm(Class_by_sg_9b1a6ca5 var1, float var2);
}

