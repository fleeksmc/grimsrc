/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.OutlineVertexConsumerProvider
 *  net.minecraft.client.render.VertexConsumerProvider$Immediate
 *  net.minecraft.client.render.command.OrderedRenderCommandQueueImpl
 *  net.minecraft.client.render.command.RenderDispatcher
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import net.minecraft.client.render.OutlineVertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.command.OrderedRenderCommandQueueImpl;
import net.minecraft.client.render.command.RenderDispatcher;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ju_e398051e;
import recovered.internal.Class_kJ_a7cdce3d;

public record Class_jx_3a49ff3b(OrderedRenderCommandQueueImpl submitNodeStorage, VertexConsumerProvider.Immediate bufferSource, OutlineVertexConsumerProvider outlineBufferSource, VertexConsumerProvider.Immediate crumblingBufferSource, RenderDispatcher featureRenderDispatcher, Class_kJ_a7cdce3d textBatch) {
    private static final long a = Class_gb_9d201141.aYR(4057888368728632929L, 4351856996389973477L, MethodHandles.lookup().lookupClass()).a(241857473023105L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_jx_3a49ff3b(OrderedRenderCommandQueueImpl orderedRenderCommandQueueImpl, VertexConsumerProvider.Immediate immediate, OutlineVertexConsumerProvider outlineVertexConsumerProvider, VertexConsumerProvider.Immediate immediate2, RenderDispatcher renderDispatcher, Class_kJ_a7cdce3d class_kJ_a7cdce3d) {
        block0: {
            long l = a ^ 0x6ADA9D168C7FL;
            this.submitNodeStorage = orderedRenderCommandQueueImpl;
            this.bufferSource = immediate;
            String string = Class_ju_e398051e.bGn();
            this.outlineBufferSource = outlineVertexConsumerProvider;
            this.crumblingBufferSource = immediate2;
            this.featureRenderDispatcher = renderDispatcher;
            this.textBatch = class_kJ_a7cdce3d;
            if (Class_iS_888f260e.bwL() != null) break block0;
            Class_ju_e398051e.bGm("o0ip8");
        }
    }

    private static MatchException a(MatchException matchException) {
        return matchException;
    }
}

