/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  net.minecraft.entity.player.PlayerEntity
 */
package recovered.internal;

import com.google.gson.JsonElement;
import java.lang.invoke.MethodHandles;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.entity.player.PlayerEntity;
import recovered.core.ClientMain;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mr_7eac5189;

public class Class_cz_c738b74f
extends Class_cB_67aec11c {
    private Set<Integer> vTMHw = new HashSet<Integer>();
    private static final long akFDW = Class_gb_9d201141.aYR(-9107030281486293025L, 2831443964350399896L, MethodHandles.lookup().lookupClass()).a(31398750213229L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cz_c738b74f(Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_mr_7eac5189);
    }

    public Class_cz_c738b74f(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    public Class_cz_c738b74f UA(Integer n) {
        long l = akFDW ^ 0x4C47D8703B43L;
        boolean bl = Class_cB_67aec11c.Vt();
        Class_cz_c738b74f class_cz_c738b74f = this;
        if (bl) {
            if (class_cz_c738b74f.vTMHw.add(n)) {
                this.Vk();
            }
            class_cz_c738b74f = this;
        }
        return class_cz_c738b74f;
    }

    public boolean Uy() {
        return this.vTMHw.contains(ClientMain.dlmvG.player.getInventory().getSelectedSlot());
    }

    public Class_cz_c738b74f UC(Set<Integer> hashSet) {
        long l = akFDW ^ 0x1B83393EAC8L;
        boolean bl = Class_cB_67aec11c.Vt();
        HashSet<Integer> hashSet2 = hashSet == null ? new HashSet<Integer>() : hashSet;
        Class_cz_c738b74f class_cz_c738b74f = this;
        if (bl) {
            if (Objects.equals(class_cz_c738b74f.vTMHw, hashSet2)) {
                return this;
            }
            this.vTMHw = hashSet2;
            this.Vk();
            class_cz_c738b74f = this;
        }
        return class_cz_c738b74f;
    }

    public Class_cz_c738b74f Uw(int ... nArray) {
        long l = akFDW ^ 0x3D5B5DFA7D3CL;
        HashSet<Integer> hashSet = new HashSet<Integer>();
        int[] nArray2 = nArray;
        int n = nArray2.length;
        boolean bl = Class_cB_67aec11c.Vt();
        for (int i = 0; i < n; ++i) {
            int n2 = nArray2[i];
            hashSet.add(n2);
            if (bl) continue;
        }
        return this.UC(hashSet);
    }

    private static MatchException UD(MatchException matchException) {
        return matchException;
    }

    @Override
    public void SS(JsonElement jsonElement) {
        block2: {
            long l = akFDW ^ 0x36991C2321DL;
            HashSet<Integer> hashSet = new HashSet<Integer>();
            boolean bl = Class_cB_67aec11c.Vu();
            for (JsonElement jsonElement2 : jsonElement.getAsJsonArray()) {
                hashSet.add(jsonElement2.getAsInt());
                if (!bl) {
                    if (!bl) continue;
                }
                break block2;
            }
            this.UC(hashSet);
        }
    }

    public boolean Uz(PlayerEntity playerEntity) {
        return this.vTMHw.contains(playerEntity.getInventory().getSelectedSlot());
    }

    public Set<Integer> Ux() {
        return this.vTMHw;
    }

    public Class_cz_c738b74f UB(Integer n) {
        long l = akFDW ^ 0x337A9A0ADED1L;
        boolean bl = Class_cB_67aec11c.Vt();
        Class_cz_c738b74f class_cz_c738b74f = this;
        if (bl) {
            if (class_cz_c738b74f.vTMHw.remove(n)) {
                this.Vk();
            }
            class_cz_c738b74f = this;
        }
        return class_cz_c738b74f;
    }

    @Override
    public void SR(Map<String, Object> map) {
        map.put(Arrays.toString(this.NwlSF), this.vTMHw);
    }
}

