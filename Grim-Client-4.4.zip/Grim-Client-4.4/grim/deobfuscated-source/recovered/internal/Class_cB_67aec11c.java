/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 */
package recovered.internal;

import com.google.gson.JsonElement;
import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import recovered.internal.Class_cB_sm_89194ec0;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mr_7eac5189;

public abstract class Class_cB_67aec11c {
    private static final ThreadLocal<Class_cB_sm_89194ec0> BgpvM;
    private static final ThreadLocal<Boolean> qrjFk;
    protected final int[] NwlSF;
    protected final List<Runnable> PMSMO = new ArrayList<Runnable>();
    protected final List<Runnable> aFqYe = new ArrayList<Runnable>();
    protected Supplier<Boolean> uexTC = () -> true;
    private static boolean WVYkD;
    private static final long LcOyM;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cB_67aec11c(Class_mr_7eac5189 class_mr_7eac5189) {
        this.NwlSF = class_mr_7eac5189.clT();
    }

    public Class_cB_67aec11c(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    static {
        LcOyM = Class_gb_9d201141.aYR(3762902164579098143L, 1918968295152562278L, MethodHandles.lookup().lookupClass()).a(202678185734377L);
        BgpvM = new ThreadLocal();
        qrjFk = new ThreadLocal();
        Class_cB_67aec11c.Vs(true);
    }

    public int[] Vm() {
        return this.NwlSF;
    }

    public <T extends Class_cB_67aec11c> T Vd(Runnable runnable) {
        this.PMSMO.add(runnable);
        return (T)this;
    }

    public static void Vi(Runnable runnable) {
        Class_cB_67aec11c.Vj(runnable, true);
    }

    public static void Vh(Runnable runnable) {
        Class_cB_67aec11c.Vj(runnable, false);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void Vj(Runnable runnable, boolean bl) {
        long l = LcOyM ^ 0x3E521F2C5956L;
        Class_cB_sm_89194ec0 class_cB_sm_89194ec02 = BgpvM.get();
        boolean bl2 = Class_cB_67aec11c.Vu();
        Class_cB_sm_89194ec0 class_cB_sm_89194ec0 = class_cB_sm_89194ec02;
        if (!bl2) {
            if (class_cB_sm_89194ec0 == null) {
                class_cB_sm_89194ec02 = new Class_cB_sm_89194ec0();
                BgpvM.set(class_cB_sm_89194ec02);
            }
            class_cB_sm_89194ec02.oTCWD |= bl;
            ++class_cB_sm_89194ec02.Gkoov;
            try {
                runnable.run();
                --class_cB_sm_89194ec02.Gkoov;
                class_cB_sm_89194ec0 = class_cB_sm_89194ec02;
            }
            catch (Throwable throwable) {
                --class_cB_sm_89194ec02.Gkoov;
                Class_cB_sm_89194ec0 class_cB_sm_89194ec03 = class_cB_sm_89194ec02;
                if (!bl2) {
                    if (class_cB_sm_89194ec03.Gkoov != 0) throw throwable;
                    class_cB_sm_89194ec03 = class_cB_sm_89194ec02;
                }
                List<Class_cB_67aec11c> list2 = List.copyOf(class_cB_sm_89194ec03.vzghL);
                BgpvM.remove();
                Iterator<Class_cB_67aec11c> iterator = list2.iterator();
                do {
                    if (!iterator.hasNext()) throw throwable;
                    Class_cB_67aec11c class_cB_67aec11c = iterator.next();
                    class_cB_67aec11c.Vl(class_cB_sm_89194ec02.oTCWD);
                } while (!bl2);
                throw throwable;
            }
        }
        if (!bl2) {
            if (class_cB_sm_89194ec0.Gkoov != 0) return;
            class_cB_sm_89194ec0 = class_cB_sm_89194ec02;
        }
        List<Class_cB_67aec11c> list = List.copyOf(class_cB_sm_89194ec0.vzghL);
        BgpvM.remove();
        Iterator<Class_cB_67aec11c> iterator = list.iterator();
        do {
            if (!iterator.hasNext()) return;
            Class_cB_67aec11c class_cB_67aec11c = iterator.next();
            class_cB_67aec11c.Vl(class_cB_sm_89194ec02.oTCWD);
            if (bl2) return;
        } while (!bl2);
    }

    public <T extends Class_cB_67aec11c> T Ve(Runnable runnable) {
        this.aFqYe.add(runnable);
        return (T)this;
    }

    private static MatchException Vv(MatchException matchException) {
        return matchException;
    }

    public void Vg(Class_iS_888f260e class_iS_888f260e) {
        block3: {
            Class_iS_888f260e class_iS_888f260e2;
            block2: {
                long l = LcOyM ^ 0x196A68BFD708L;
                boolean bl = Class_cB_67aec11c.Vt();
                class_iS_888f260e2 = class_iS_888f260e;
                if (!bl) break block2;
                if (class_iS_888f260e2 == null) break block3;
                class_iS_888f260e2 = class_iS_888f260e;
            }
            class_iS_888f260e2.bwH(this);
        }
    }

    public static boolean Vu() {
        boolean bl = Class_cB_67aec11c.Vt();
        return !bl;
    }

    public abstract void SS(JsonElement var1);

    public Supplier<Boolean> Vp() {
        return this.uexTC;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void Vl(boolean bl) {
        block16: {
            long l = LcOyM ^ 0x246DEF19D34AL;
            Boolean bl2 = qrjFk.get();
            boolean bl3 = Class_cB_67aec11c.Vt();
            if (bl) {
                qrjFk.set(true);
            }
            try {
                block15: {
                    for (Runnable runnable : this.PMSMO) {
                        runnable.run();
                        if (bl3) {
                            if (bl3) continue;
                        }
                        break block15;
                    }
                    if (!bl) {
                        for (Runnable runnable : this.aFqYe) {
                            runnable.run();
                            if (bl3) {
                                if (bl3) continue;
                            }
                            break block16;
                        }
                    }
                }
                if (bl2 == null) {
                    qrjFk.remove();
                    if (bl3) break block16;
                }
                qrjFk.set(bl2);
            }
            catch (Throwable throwable) {
                block19: {
                    block18: {
                        block17: {
                            if (!bl3) break block17;
                            if (bl2 != null) break block18;
                            qrjFk.remove();
                        }
                        if (bl3) break block19;
                    }
                    qrjFk.set(bl2);
                }
                throw throwable;
            }
        }
    }

    public List<Runnable> Vn() {
        return this.PMSMO;
    }

    public static void Vs(boolean bl) {
        WVYkD = bl;
    }

    public static boolean Vt() {
        return WVYkD;
    }

    public List<Runnable> Vo() {
        return this.aFqYe;
    }

    protected void Vk() {
        long l = LcOyM ^ 0x4AB527BD44A3L;
        Class_cB_sm_89194ec0 class_cB_sm_89194ec0 = BgpvM.get();
        boolean bl = Class_cB_67aec11c.Vu();
        if (!bl) {
            if (class_cB_sm_89194ec0 != null) {
                class_cB_sm_89194ec0.vzghL.add(this);
                return;
            }
            this.Vl(Boolean.TRUE.equals(qrjFk.get()));
        }
    }

    public abstract void SR(Map<String, Object> var1);

    public <T extends Class_cB_67aec11c> T Vf(Supplier<Boolean> supplier) {
        long l = LcOyM ^ 0x767A4A59DA92L;
        boolean bl = Class_cB_67aec11c.Vt();
        Supplier<Boolean> supplier2 = supplier;
        if (bl) {
            supplier2 = supplier2 != null ? supplier : () -> true;
        }
        this.uexTC = supplier2;
        return (T)this;
    }
}

