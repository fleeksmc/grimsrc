/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import recovered.core.ClientMain;
import recovered.core.NativeLoader;
import recovered.internal.Class_P_2c9819bb;
import recovered.internal.Class_S_f3cb3437;
import recovered.internal.Class_ac_79a43a3e;
import recovered.internal.Class_ah_02444db4;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_ap_f3b7a87f;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bb_631496ef;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_cC_14ef8bb5;
import recovered.internal.Class_cG_6e1ba021;
import recovered.internal.Class_cy_687dcdb6;
import recovered.internal.Class_id_3eb7ad7a;
import recovered.internal.Class_ie_4a6d16b6;
import recovered.internal.Class_if_dd7ae04e;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_ih_ba1deb13;
import recovered.internal.Class_ij_d7bf2301;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_aZ_2406f66f
extends Class_aj_95d0a719 {
    private static int Bntgy;
    private final List<Class_az_a4990dcf> IkudM;
    private final List<Class_aj_95d0a719> ODKnU;
    private final Class_ah_02444db4 GGNlF;
    private Class_ac_79a43a3e epPDf;
    private Class_ac_79a43a3e iBZhf;
    private Class_ac_79a43a3e chGPO;
    private final Class_P_2c9819bb MKuzJ;
    private final Class_P_2c9819bb zQIvK;
    private final Class_P_2c9819bb yiyEl;
    private final Class_P_2c9819bb YWarX;
    private static Class_cG_6e1ba021 yAejq;
    private static Class_cG_6e1ba021 ERseG;
    private static Class_cG_6e1ba021 YtBwS;
    private static Class_cG_6e1ba021 gipIr;
    private static Class_cG_6e1ba021 klcWm;
    private static Class_cC_14ef8bb5 PqAQr;
    private static Class_cC_14ef8bb5 KKBtz;
    private static Class_cC_14ef8bb5 Wklho;
    private static Class_cC_14ef8bb5 hkeHc;
    private static Class_cC_14ef8bb5 jkJBT;
    private static Class_cC_14ef8bb5 waETu;
    private static Class_cC_14ef8bb5 QPFQS;
    private static Class_cG_6e1ba021 cnpgV;
    private static Class_cG_6e1ba021 hiZZI;
    private static boolean VeSmn;
    private int cMafA;
    private int vylxx;
    private int XDEoP;
    private int YYAes;
    private boolean GUOUm;
    private final List<Class_ri_288534d5> VKbkM;
    private final Class_rk_bf8630d1 ltNwj;
    private final Class_rk_bf8630d1 HgcQO;
    private final Class_rk_bf8630d1 TkQJN;
    private static long lVKmB;
    private static String[] MhSRE;
    private static String[] qslyP;
    private static Map qhReV;
    private static long[] ClfhO;
    private static Integer[] waiDL;
    private static Map uNytp;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aZ_2406f66f(float f) {
        long l = lVKmB ^ 0x5CF0B18B9F20L;
        this.IkudM = new ArrayList<Class_az_a4990dcf>();
        this.ODKnU = new ArrayList<Class_aj_95d0a719>();
        this.cMafA = 0;
        this.vylxx = 0;
        this.XDEoP = -1;
        this.YYAes = 1;
        this.GUOUm = false;
        this.VKbkM = new ArrayList<Class_ri_288534d5>();
        this.ltNwj = new Class_rk_bf8630d1((int)Class_aZ_2406f66f.Bc("m", (int)7219, (long)(0x3CBA76E76E0C83A6L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.HgcQO = new Class_rk_bf8630d1((int)Class_aZ_2406f66f.Bc("m", (int)19427, (long)(0x2410B789C8B1540CL ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.TkQJN = new Class_rk_bf8630d1((int)Class_aZ_2406f66f.Bc("m", (int)18025, (long)(0x191BFB83AC35D9C9L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.BcpIo = 127.0f;
        this.WjISQ = 170.0f;
        this.IzFhM = f;
        this.GGNlF = new Class_ah_02444db4();
        Class_ig_ca326427 class_ig_ca326427 = ClientMain.dlM().bjG();
        this.MKuzJ = ((Class_P_2c9819bb)new Class_P_2c9819bb(null, (String)((Object)Class_aZ_2406f66f.AZ("f", (int)10033, (long)(0x31E19FF59F873DF7L ^ l))), Class_lf_d247d983.NCCOy).ja(class_ig_ca326427.biw().bhF())).hO(Class_S_f3cb3437.CLgKH);
        this.zQIvK = ((Class_P_2c9819bb)((Class_P_2c9819bb)new Class_P_2c9819bb(null, (String)((Object)Class_aZ_2406f66f.AZ("f", (int)31575, (long)(0x1853CE22CDFA6194L ^ l))), Class_lf_d247d983.JHGge).ja(Class_jk_a0800133.mPXGi)).iY(Class_jk_a0800133.mPXGi)).hO(Class_S_f3cb3437.CLgKH);
        this.yiyEl = ((Class_P_2c9819bb)new Class_P_2c9819bb(null, (String)((Object)Class_aZ_2406f66f.AZ("f", (int)14637, (long)(0xEEF92E24A90A3F1L ^ l))), Class_lf_d247d983.ucWHb).ja(class_ig_ca326427.biw().bhF())).hO(Class_S_f3cb3437.CLgKH).jb(this::AU);
        this.YWarX = ((Class_P_2c9819bb)new Class_P_2c9819bb(null, (String)((Object)Class_aZ_2406f66f.AZ("f", (int)13369, (long)(0x699351DE97E32EEEL ^ l))), Class_lf_d247d983.blMVg).ja(class_ig_ca326427.biw().bhF())).hO(Class_S_f3cb3437.CLgKH).jb(this::AT);
        this.Az(class_ig_ca326427);
        this.AA(class_ig_ca326427);
        this.AB(class_ig_ca326427);
        this.FHbTC = true;
    }

    static {
        NativeLoader.doInit(Class_aZ_2406f66f.class);
        Class_aZ_2406f66f._9e6362dc46ed1b1e0e02573f56dfb361();
    }

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    private static native /* synthetic */ void AM(Class_ap_f3b7a87f var0, Boolean var1);

    private native Class_ie_4a6d16b6 AD();

    @Override
    public native boolean dm(int var1, int var2, int var3);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private static native /* synthetic */ void AH(Class_cy_687dcdb6 var0, Class_aj_95d0a719 var1);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean fC(double var1, double var3, double var5);

    private native void AA(Class_ig_ca326427 var1);

    private static native /* synthetic */ void AN(Class_ap_f3b7a87f var0, Class_ij_d7bf2301 var1, Class_P_2c9819bb var2);

    @Override
    public native boolean dB(double var1, double var3, Class_mA_32d8a5f2 var5, double var6, double var8);

    private native Class_if_dd7ae04e AE();

    private native void Ao(float var1);

    private native /* synthetic */ void AO(Class_bb_631496ef var1);

    private static native String AX(int var0, long var1);

    private static native CallSite AZ(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native Object AY(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native MatchException AV(MatchException var0);

    @Override
    public native boolean eK(char var1);

    private static native /* synthetic */ void AL(Class_ij_d7bf2301 var0, Class_ap_f3b7a87f var1, Class_P_2c9819bb var2);

    private native void AB(Class_ig_ca326427 var1);

    private native float Am();

    private native float An();

    private native int Ap(int var1);

    private static native CallSite Bc(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native /* synthetic */ void AT(Class_P_2c9819bb var1);

    private native void Aj();

    private native void Ai(Class_lC_5322e8cf var1, List<Class_bb_631496ef<Class_ig_ca326427>> var2, int var3, float var4);

    private native void Ak();

    private native void Ah(Class_lC_5322e8cf var1, float var2, float var3);

    private native float Al();

    private native /* synthetic */ void AU(Class_P_2c9819bb var1);

    private native void Az(Class_ig_ca326427 var1);

    private native void Aq();

    private native void Av(Class_aj_95d0a719 var1);

    private native /* synthetic */ void AG(Class_ap_f3b7a87f var1);

    private native /* synthetic */ void AP(Boolean var1);

    private native void Aw(Class_ap_f3b7a87f var1);

    private native /* synthetic */ void AK(Class_bb_631496ef var1, Class_bb_631496ef var2);

    private native boolean Ax(double var1, double var3);

    private static native int Bb(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native /* synthetic */ void AR(Class_lC_5322e8cf var1);

    private native void Ay();

    private static native int Ba(int var0, long var1);

    private native boolean As(int var1);

    private native void AC(Class_cB_67aec11c var1);

    private static native /* synthetic */ boolean AS(Class_bb_631496ef var0);

    private native void Au(Class_aj_95d0a719 var1);

    private native /* synthetic */ void AJ(Class_cy_687dcdb6 var1, Class_aj_95d0a719 var2);

    private native void Ar();

    private static native String AW(byte[] var0);

    private static native /* synthetic */ void AI(Class_aj_95d0a719 var0, Boolean var1);

    private native Class_id_3eb7ad7a AF();

    private native /* synthetic */ void AQ(Class_lC_5322e8cf var1, Class_ih_ba1deb13 var2);

    private static native void _9e6362dc46ed1b1e0e02573f56dfb361();

    @Override
    protected native boolean od();

    @Override
    public native <T extends Class_aj_95d0a719> T oj(boolean var1);

    private native void At(Class_bb_631496ef<Class_ig_ca326427> var1);
}

