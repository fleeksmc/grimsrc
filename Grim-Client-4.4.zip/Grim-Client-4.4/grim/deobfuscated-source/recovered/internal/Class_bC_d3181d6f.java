/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.client.network.ClientPlayerEntity
 *  net.minecraft.client.render.entity.state.EntityRenderState
 *  net.minecraft.client.render.entity.state.PlayerEntityRenderState
 *  net.minecraft.entity.PlayerLikeEntity
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.PlayerLikeEntity;
import recovered.core.ClientMain;
import recovered.internal.Class_bB_f304b0cf;
import recovered.internal.Class_bC_si_86276f1b;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mS_4d666094;
import recovered.internal.Class_mZ_07f59a29;
import recovered.internal.Class_pX_3bcb504f;
import recovered.internal.Class_pY_4f9ecc6b;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bC_d3181d6f {
    private final Class_pY_4f9ecc6b imthM;
    private final String neETJ;
    private final Class_pX_3bcb504f VRAiw;
    private Class_pX_3bcb504f ouKLq;
    private final Class_rk_bf8630d1 XclRQ;
    private static final long ZpdFS = Class_gb_9d201141.aYR(-3195232151852259922L, 3105695006094609560L, MethodHandles.lookup().lookupClass()).a(190578593781542L);
    private static final long LMIZW;
    private static final long FEhqQ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bC_d3181d6f(Class_pY_4f9ecc6b class_pY_4f9ecc6b) {
        long l = ZpdFS ^ 0x54C86D9152E2L;
        this.XclRQ = new Class_rk_bf8630d1((int)LMIZW).dhs(Class_rj_b691f4f7.XzDkv);
        this.imthM = class_pY_4f9ecc6b;
        this.neETJ = class_pY_4f9ecc6b.label();
        this.VRAiw = new Class_bC_si_86276f1b(class_pY_4f9ecc6b);
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = ZpdFS ^ 0x7A21A187C06AL;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        long l2 = 1611812430527484127L;
        byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
        LMIZW = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
        Cipher cipher2 = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory2 = SecretKeyFactory.getInstance("DES");
        byte[] byArray4 = new byte[8];
        byte[] byArray5 = byArray4;
        byArray4[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher2.init(2, (Key)secretKeyFactory2.generateSecret(new DESKeySpec(byArray5)), new IvParameterSpec(new byte[8]));
                long l3 = -7248963263439970520L;
                byte[] byArray6 = cipher2.doFinal(new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3});
                FEhqQ = ((long)byArray6[0] & 0xFFL) << 56 | ((long)byArray6[1] & 0xFFL) << 48 | ((long)byArray6[2] & 0xFFL) << 40 | ((long)byArray6[3] & 0xFFL) << 32 | ((long)byArray6[4] & 0xFFL) << 24 | ((long)byArray6[5] & 0xFFL) << 16 | ((long)byArray6[6] & 0xFFL) << 8 | (long)byArray6[7] & 0xFFL;
                return;
            }
            byArray5 = byArray5;
            byArray5[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    private void Lu(Class_lC_5322e8cf class_lC_5322e8cf, float f, float f2, boolean bl, float f3) {
        ClientPlayerEntity clientPlayerEntity;
        ClientPlayerEntity clientPlayerEntity2;
        block4: {
            block3: {
                int[] nArray;
                block2: {
                    long l = ZpdFS ^ 0x72E15F44FD3FL;
                    clientPlayerEntity2 = ClientMain.dlmvG.player;
                    nArray = Class_bB_f304b0cf.b();
                    ClientPlayerEntity clientPlayerEntity3 = clientPlayerEntity2;
                    if (nArray != null) break block2;
                    if (!(clientPlayerEntity3 instanceof AbstractClientPlayerEntity)) break block3;
                    clientPlayerEntity3 = clientPlayerEntity = clientPlayerEntity2;
                }
                if (nArray == null) break block4;
            }
            return;
        }
        clientPlayerEntity2 = ClientMain.dlmvG.getEntityRenderDispatcher().getPlayerRenderer((AbstractClientPlayerEntity)clientPlayerEntity);
        PlayerEntityRenderState playerEntityRenderState = new PlayerEntityRenderState();
        clientPlayerEntity2.updateRenderState((PlayerLikeEntity)clientPlayerEntity, playerEntityRenderState, class_lC_5322e8cf.cfh());
        this.Lw(playerEntityRenderState, bl);
        ((Class_mS_4d666094)playerEntityRenderState).setEmoteInstance(this.Lr(bl));
        float f4 = this.Lv(f3);
        float f5 = Class_mZ_07f59a29.csl(14.5, 16.5, f3);
        class_lC_5322e8cf.ced((EntityRenderState)playerEntityRenderState, f - f4 * 0.5f, f2 - f4 * 0.5f, f4, f4).bFH(f5).bFJ(0.0f, 0.45f, 0.0f).bFM();
    }

    /*
     * Unable to fully structure code
     */
    private float Lt(Class_bB_f304b0cf var1_1) {
        var2_2 = Class_bC_d3181d6f.ZpdFS ^ 20549726561789L;
        var5_3 = var1_1.innerRadius();
        var6_4 = var1_1.outerRadius();
        var7_5 = Math.abs((float)Math.toRadians(var1_1.segmentEnd() - var1_1.segmentStart()));
        var4_6 = Class_bB_f304b0cf.b();
        v0 = var7_5;
        v1 = 6.282185f;
        if (var4_6 == null) {
            if (v0 >= v1) {
                return (var5_3 + var6_4) * 0.5f;
            }
            v0 = var7_5;
            v1 = 0.5f;
        }
        var8_7 = v0 * v1;
        var9_8 = 0.6666667f * (var6_4 * var6_4 * var6_4 - var5_3 * var5_3 * var5_3) / (var6_4 * var6_4 - var5_3 * var5_3);
        v2 = var8_7;
        v3 = 0.0f;
        if (var4_6 != null) ** GOTO lbl23
        if (v2 == v3) {
            v4 = 1.0f;
        } else {
            v2 = (float)Math.sin(var8_7);
            v3 = var8_7;
lbl23:
            // 2 sources

            v4 = v2 / v3;
        }
        var10_9 = v4;
        return var9_8 * var10_9;
    }

    private static MatchException LC(MatchException matchException) {
        return matchException;
    }

    public Class_pX_3bcb504f LA() {
        return this.ouKLq;
    }

    public Class_rk_bf8630d1 LB() {
        return this.XclRQ;
    }

    public String Ly() {
        return this.neETJ;
    }

    public Class_pY_4f9ecc6b Lx() {
        return this.imthM;
    }

    public void Ls() {
        this.ouKLq = null;
    }

    public void Lq(Class_lC_5322e8cf class_lC_5322e8cf, Class_bB_f304b0cf class_bB_f304b0cf) {
        block0: {
            long l = ZpdFS ^ 0x30ECC3E61F1FL;
            int[] nArray = Class_bB_f304b0cf.b();
            this.XclRQ.dhs(class_bB_f304b0cf.selected() ? Class_rj_b691f4f7.XzDkv : Class_rj_b691f4f7.UPXqT);
            this.XclRQ.dhc(class_bB_f304b0cf.selected());
            Class_ii_9b427eda class_ii_9b427eda = ClientMain.dlM();
            float f = this.XclRQ.dhj();
            float f2 = (float)Math.toRadians(class_bB_f304b0cf.segmentMiddleAngle());
            float f3 = this.Lt(class_bB_f304b0cf) + 3.0f * f;
            float f4 = class_bB_f304b0cf.centerX() + (float)Math.cos(f2) * f3;
            float f5 = class_bB_f304b0cf.centerY() + (float)Math.sin(f2) * f3;
            Class_mG_52c8d386 class_mG_52c8d386 = class_ii_9b427eda.bjb().cob(0.5f).coc(class_ii_9b427eda.bjb(), f);
            Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(Class_mZ_07f59a29.csl(5.5, 6.0, f));
            float f6 = this.Lv(f);
            float f7 = f5 - (f6 + class_lq_87a74641.cat()) * 0.5f;
            float f8 = f7 + f6 * 0.5f + 3.0f;
            float f9 = f7 + f6;
            this.Lu(class_lC_5322e8cf, f4, f8, class_bB_f304b0cf.selected(), f);
            float f10 = f4 - class_lq_87a74641.cao(this.neETJ) * 0.5f;
            class_lC_5322e8cf.cez(class_lq_87a74641, this.neETJ, f10, f9, class_mG_52c8d386);
            if (nArray == null) break block0;
            Class_iS_888f260e.bwK("Kujvoc");
        }
    }

    private float Lv(float f) {
        return Class_mZ_07f59a29.csl(30.0, 34.0, f);
    }

    public Class_pX_3bcb504f Lz() {
        return this.VRAiw;
    }

    /*
     * Unable to fully structure code
     */
    public Class_pX_3bcb504f Lr(boolean var1_1) {
        block5: {
            block6: {
                block3: {
                    block4: {
                        var2_2 = Class_bC_d3181d6f.ZpdFS ^ 5870922892468L;
                        var4_3 = Class_bB_f304b0cf.b();
                        if (!var1_1) {
                            return this.VRAiw;
                        }
                        v0 = this;
                        if (var4_3 != null) break block3;
                        if (v0.ouKLq == null) break block4;
                        v1 = this.ouKLq;
                        if (var4_3 != null) break block5;
                        if (!v1.finished()) break block6;
                    }
                    v0 = this;
                }
                v2 = this.imthM;
                if (var4_3 != null) ** GOTO lbl20
                if (v2 == null) {
                    v3 = this.VRAiw;
                } else {
                    v2 = this.imthM;
lbl20:
                    // 2 sources

                    v3 = v2.createInstance();
                }
                v0.ouKLq = v3;
            }
            v1 = this.ouKLq;
        }
        return v1;
    }

    private void Lw(PlayerEntityRenderState playerEntityRenderState, boolean bl) {
        long l = ZpdFS ^ 0x5A61B18CB559L;
        playerEntityRenderState.displayName = null;
        playerEntityRenderState.bodyYaw = 180.0f;
        playerEntityRenderState.relativeHeadYaw = 0.0f;
        playerEntityRenderState.pitch = 0.0f;
        playerEntityRenderState.limbSwingAmplitude = 0.0f;
        int[] nArray = Class_bB_f304b0cf.b();
        playerEntityRenderState.limbSwingAnimationProgress = 0.0f;
        playerEntityRenderState.leaningPitch = 0.0f;
        playerEntityRenderState.isInSneakingPose = false;
        playerEntityRenderState.isGliding = false;
        playerEntityRenderState.isSwimming = false;
        playerEntityRenderState.hasVehicle = false;
        playerEntityRenderState.glidingTicks = 0.0f;
        playerEntityRenderState.applyFlyingRotation = false;
        PlayerEntityRenderState playerEntityRenderState2 = playerEntityRenderState;
        float f = 0.0f;
        if (nArray == null) {
            playerEntityRenderState2.flyingRotation = f;
            playerEntityRenderState.flipUpsideDown = false;
            playerEntityRenderState2 = playerEntityRenderState;
            f = bl ? (float)(System.currentTimeMillis() % FEhqQ) / 50.0f : 0.0f;
        }
        playerEntityRenderState2.age = f;
    }
}

