/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  sixtwo.at
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.core.ClientMain;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_ob_77a6de24;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import sixtwo.at;

public class Class_au_d40f6177
extends Class_az_a4990dcf {
    private final Class_rk_bf8630d1 HxBzM;
    private final Class_ri_288534d5 pNvvb;
    private at VhaVC;
    private boolean qSAqB;
    private static final long vzfUG = Class_gb_9d201141.aYR(3384193007651451487L, -2449311745717754863L, MethodHandles.lookup().lookupClass()).a(260161488895751L);
    private static final String kheUW;
    private static final long[] hlCPm;
    private static final Integer[] adMRv;
    private static final Map safNd;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_au_d40f6177(float f) {
        long l = vzfUG ^ 0x4BAE19083E83L;
        this.HxBzM = new Class_rk_bf8630d1((int)Class_au_d40f6177.se("n", (int)19508, (long)(0x4ABFA29ADA7D4296L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.BcpIo = f;
        this.WjISQ = f;
        Class_ig_ca326427 class_ig_ca326427 = ClientMain.dlM().bjG();
        this.pNvvb = new Class_ri_288534d5((int)Class_au_d40f6177.se("n", (int)32661, (long)(0x2149166B45E0F136L ^ l)), this.qSAqB ? class_ig_ca326427.bis() : class_ig_ca326427.bir());
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = vzfUG ^ 0x18EF48C7230AL;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        byte[] byArray3 = cipher.doFinal("\u0007\t\u0089\u0006G\u00c4\u00a1\u00c5\u00fcwFbvS\u00ce\u0000".getBytes("ISO-8859-1"));
        kheUW = Class_au_d40f6177.sb(byArray3).intern();
        safNd = new HashMap(13);
        Cipher cipher2 = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory2 = SecretKeyFactory.getInstance("DES");
        byte[] byArray4 = new byte[8];
        byte[] byArray5 = byArray4;
        byArray4[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray5 = byArray5;
            byArray5[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher2.init(2, (Key)secretKeyFactory2.generateSecret(new DESKeySpec(byArray5)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "`\u0080\u00f2v\u0087\u00a2\u00cfn\t\b\u000e\u00ff\u00c1\u00bdj\u00de";
        int n2 = "`\u0080\u00f2v\u0087\u00a2\u00cfn\t\b\u000e\u00ff\u00c1\u00bdj\u00de".length();
        int n3 = 0;
        do {
            byte[] byArray6 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray6[0] & 0xFFL) << 56 | ((long)byArray6[1] & 0xFFL) << 48 | ((long)byArray6[2] & 0xFFL) << 40 | ((long)byArray6[3] & 0xFFL) << 32 | ((long)byArray6[4] & 0xFFL) << 24 | ((long)byArray6[5] & 0xFFL) << 16 | ((long)byArray6[6] & 0xFFL) << 8 | (long)byArray6[7] & 0xFFL;
            byte[] byArray7 = cipher2.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray7[0] & 0xFFL) << 56 | ((long)byArray7[1] & 0xFFL) << 48 | ((long)byArray7[2] & 0xFFL) << 40 | ((long)byArray7[3] & 0xFFL) << 32 | ((long)byArray7[4] & 0xFFL) << 24 | ((long)byArray7[5] & 0xFFL) << 16 | ((long)byArray7[6] & 0xFFL) << 8 | (long)byArray7[7] & 0xFFL;
        } while (n3 < n2);
        hlCPm = lArray;
        adMRv = new Integer[2];
    }

    private static MatchException sa(MatchException matchException) {
        return matchException;
    }

    private static String sb(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static int sc(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x4196;
        if (adMRv[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = hlCPm[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])safNd.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    safNd.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_au_d40f6177", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_au_d40f6177.adMRv[n2] = n3;
        }
        return adMRv[n2];
    }

    private static CallSite se(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_au_d40f6177" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int sd(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_au_d40f6177.sc(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    @Override
    public boolean dk(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        boolean bl;
        block4: {
            block5: {
                block7: {
                    at at2;
                    block6: {
                        long l = vzfUG ^ 0x25E36435174EL;
                        String[] stringArray = Class_aj_95d0a719.oA();
                        bl = this.tg(d, d2);
                        if (stringArray == null) break block4;
                        if (!bl || class_mA_32d8a5f2 != Class_mA_32d8a5f2.sCBUa) break block5;
                        boolean bl2 = this.qSAqB;
                        if (stringArray != null) {
                            bl2 = !bl2;
                        }
                        this.qSAqB = bl2;
                        at2 = this.VhaVC;
                        if (stringArray == null) break block6;
                        if (at2 == null) break block7;
                        at2 = this.VhaVC;
                    }
                    at2.run(this);
                }
                return true;
            }
            bl = super.dk(d, d2, class_mA_32d8a5f2);
        }
        return bl;
    }

    public Class_au_d40f6177 rV(boolean bl) {
        this.qSAqB = bl;
        return this;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    protected void bV(Class_lC_5322e8cf var1_1) {
        var2_2 = Class_au_d40f6177.vzfUG ^ 132451097428874L;
        var4_3 = Class_aj_95d0a719.oA();
        v0 = this;
        if (var4_3 == null) ** GOTO lbl9
        if (v0.qSAqB) {
            v1 = this.CtPwV.bjf();
        } else {
            v0 = this;
lbl9:
            // 2 sources

            v1 = v0.CtPwV.bje();
        }
        this.pNvvb.dfT(v1);
        this.HxBzM.dhc(this.qSAqB);
        var5_4 = this.pNvvb.dfU().coa(this.qSAqB != false ? 255.0f : 155.0f);
        var1_1.cdg(this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ, Class_ld_bb1690e1.all(1.5f), var5_4);
        var6_5 = this.HxBzM.dhj();
        var7_6 = this.CtPwV.bjb().coa(255.0f * var6_5);
        var8_7 = 6.0f;
        var9_8 = this.MCnYt + Class_jf_d1c4f950.bAH(var8_7, this.BcpIo);
        var10_9 = this.pNyTQ + Class_jf_d1c4f950.bAH(var8_7, this.WjISQ);
        Class_jH_c1172273.bId(var1_1, this.MCnYt + this.BcpIo * 0.5f, this.pNyTQ + this.WjISQ * 0.5f, var6_5);
        var1_1.cdW(Class_ob_77a6de24.cBv(Class_au_d40f6177.kheUW), var9_8, var10_9, var8_7, var8_7, var7_6);
        Class_jH_c1172273.bIf();
    }

    public Class_au_d40f6177 rU(at at2) {
        this.VhaVC = at2;
        return this;
    }

    public boolean rZ() {
        return this.qSAqB;
    }

    public Class_rk_bf8630d1 rW() {
        return this.HxBzM;
    }

    public Class_ri_288534d5 rX() {
        return this.pNvvb;
    }

    public at rY() {
        return this.VhaVC;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_au_d40f6177.class, "sd", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

