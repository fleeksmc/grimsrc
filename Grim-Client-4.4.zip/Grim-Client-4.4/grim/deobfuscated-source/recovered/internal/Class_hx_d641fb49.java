/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;

public class Class_hx_d641fb49
extends Class_hH_ae8f8f77 {
    private final double NDtKB;
    private final double QaiYp;
    private final double hGfBe;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hx_d641fb49(double d, double d2, double d3) {
        this.NDtKB = d;
        this.QaiYp = d2;
        this.hGfBe = d3;
    }

    public double bdp() {
        return this.hGfBe;
    }

    public double bdo() {
        return this.QaiYp;
    }

    public double bdn() {
        return this.NDtKB;
    }
}

