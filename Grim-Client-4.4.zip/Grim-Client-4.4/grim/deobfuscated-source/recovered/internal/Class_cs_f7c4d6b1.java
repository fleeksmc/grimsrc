/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_mA_32d8a5f2;

public interface Class_cs_f7c4d6b1 {
    default public boolean onMouseDragged(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2, double d3, double d4) {
        return false;
    }

    default public boolean onCharTyped(char c) {
        return false;
    }

    default public boolean onMouseClicked(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        return false;
    }

    default public boolean onKeyPressed(int n, int n2, int n3) {
        return false;
    }

    default public boolean onMouseReleased(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        return false;
    }

    default public boolean onMouseScrolled(double d, double d2, double d3) {
        return false;
    }
}

