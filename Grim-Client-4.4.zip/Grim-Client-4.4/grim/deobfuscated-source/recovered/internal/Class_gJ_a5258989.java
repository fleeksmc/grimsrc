/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screen.Screen
 */
package recovered.internal;

import net.minecraft.client.gui.screen.Screen;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gJ_a5258989
extends Class_hH_ae8f8f77 {
    private Screen olkZq;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gJ_a5258989(Screen screen) {
        this.olkZq = screen;
    }

    public Screen bcd() {
        return this.olkZq;
    }
}

