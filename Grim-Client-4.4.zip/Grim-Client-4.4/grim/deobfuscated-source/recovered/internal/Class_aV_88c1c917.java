/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  sixtwo.aS
 */
package recovered.internal;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_aU_b708ac4e;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_py_edabaa53;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import sixtwo.aS;

public class Class_aV_88c1c917
extends Class_az_a4990dcf {
    private static float oDtke = 6.0f;
    private final List<aS> TBGre;
    private final Map<Class_py_edabaa53, aS> cxvQr;
    private final Class_rk_bf8630d1 fwoMR;
    private Class_aU_b708ac4e jFVar;
    private static long dTZIw;
    private static long OgGNH;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aV_88c1c917() {
        long l = dTZIw ^ 0x2F1A39F87F28L;
        this.TBGre = new ArrayList<aS>();
        this.cxvQr = new IdentityHashMap<Class_py_edabaa53, aS>();
        this.fwoMR = new Class_rk_bf8630d1((int)OgGNH).dhs(Class_rj_b691f4f7.MBpuQ);
    }

    static {
        NativeLoader.doInit(Class_aV_88c1c917.class);
        Class_aV_88c1c917._974846e1551efaed4a484217fd409839();
    }

    @Override
    public native float dn();

    private static native /* synthetic */ boolean ze(List var0, Map.Entry var1);

    public native Class_aV_88c1c917 zc(Class_aU_b708ac4e var1);

    private static native MatchException zf(MatchException var0);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private native void zd(List<Class_py_edabaa53> var1);

    private static native void _974846e1551efaed4a484217fd409839();

    public native Class_aV_88c1c917 zb(List<Class_py_edabaa53> var1);
}

