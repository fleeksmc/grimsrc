/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import net.minecraft.item.Item;
import recovered.core.NativeLoader;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bs_8800d93f;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

class Class_bs_se_6fe98b85
extends Class_az_a4990dcf {
    private final Class_bs_8800d93f mAGlG;
    private final Item zVisd;
    private final Class_rk_bf8630d1 XIdWx;
    private final Class_rk_bf8630d1 PlZba;
    private boolean rjcuK;
    private static long jnWEe;
    private static String gUvvz;
    private static long[] NEAZe;
    private static Integer[] ZJgLS;
    private static Map xVRty;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bs_se_6fe98b85(Class_bs_8800d93f class_bs_8800d93f, Item item) {
        long l = jnWEe ^ 0x7DBD1451FEBDL;
        this.XIdWx = new Class_rk_bf8630d1((int)Class_bs_se_6fe98b85.dnu("e", (int)20016, (long)(0x19C0E793981D4F38L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.PlZba = new Class_rk_bf8630d1((int)Class_bs_se_6fe98b85.dnu("e", (int)27095, (long)(0xB1A8E741F4A68DEL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.mAGlG = class_bs_8800d93f;
        this.zVisd = item;
    }

    static {
        NativeLoader.doInit(Class_bs_se_6fe98b85.class);
        Class_bs_se_6fe98b85._02c8e32375e80bbbd9a400eee85b58d8();
    }

    private static native void _02c8e32375e80bbbd9a400eee85b58d8();

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private static native MatchException dnq(MatchException var0);

    public native void dnk(boolean var1);

    public native boolean dnp();

    public native Class_rk_bf8630d1 dno();

    public native Class_bs_8800d93f dnl();

    public native Item dnm();

    private static native CallSite dnu(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native Class_rk_bf8630d1 dnn();

    private static native String dnr(byte[] var0);

    private static native int dns(int var0, long var1);

    private static native int dnt(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);
}

