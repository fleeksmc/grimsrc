/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.RenderTickCounter
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.Arm
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.Vec2f;
import recovered.core.ClientMain;
import recovered.internal.Class_bX_66e572fb;
import recovered.internal.Class_cp_ba0fd449;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_ju_e398051e;
import recovered.internal.Class_jv_4c1871b8;
import recovered.internal.Class_jw_a460984a;
import recovered.internal.Class_jy_33e84da2;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_rm_d861be3b;
import recovered.modules.InterfaceModule;

public class Class_bY_d6d3ef36
extends Class_cp_ba0fd449 {
    private static final float WCYGX = 0.8f;
    private static final float AzaIL = 12.8f;
    private static final long FwqDO;
    private static final long[] MujRV;
    private static final Integer[] VtGWK;
    private static final Map kIeWJ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bY_d6d3ef36() {
        long l = FwqDO ^ 0x36E9668D601DL;
        boolean bl = Class_bX_66e572fb.Ov();
        int[] nArray = new int[Class_bY_d6d3ef36.OF("u", (int)3968, (long)(0x5AACAD8582A11E60L ^ l))];
        nArray[0] = (int)Class_bY_d6d3ef36.OF("u", (int)3390, (long)(0x6C6F4609E2FD1CDDL ^ l));
        nArray[1] = (int)Class_bY_d6d3ef36.OF("u", (int)24795, (long)(0x5FB8A0D59C4DF139L ^ l));
        nArray[2] = (int)Class_bY_d6d3ef36.OF("u", (int)8307, (long)(0x67670488C17B3194L ^ l));
        nArray[3] = (int)Class_bY_d6d3ef36.OF("u", (int)5724, (long)(0x77F0EC4DFEE787B9L ^ l));
        nArray[4] = (int)Class_bY_d6d3ef36.OF("u", (int)12419, (long)(0x5189000700E4A167L ^ l));
        nArray[5] = (int)Class_bY_d6d3ef36.OF("u", (int)30012, (long)(0x39AACDC6356264DAL ^ l));
        super(nArray, Class_lf_d247d983.OxOQo);
        boolean bl2 = bl;
        if (Class_iS_888f260e.bwL() == null) {
            Class_bX_66e572fb.Ot(!bl2);
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_bY_d6d3ef36.FwqDO = Class_gb_9d201141.aYR(2925985723345337069L, -3629615129369220686L, MethodHandles.lookup().lookupClass()).a(269555676370922L);
                Class_bY_d6d3ef36.kIeWJ = new HashMap<K, V>(13);
                var0 = Class_bY_d6d3ef36.FwqDO ^ 110017288961692L;
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[9];
                var5_4 = 0;
                var6_5 = "M\u0092\u0010+\n\u0005\u00fa\u00f5ZLb \u00ec\u00dbJ\u00d7\u0081\u00e8\u00b1%\u00ac\u009f\u00c5\u00d6 \u00c6\u00a2\u00a51l\u00b1\u0096\u0010\u0080\u00d8\u00cex\u00aa\u00a4\u0007\u00aed\u00c8{\u00c8\u00f1\u00c1:\u0081T\u0096\u008e\n#7\u000b";
                var7_6 = "M\u0092\u0010+\n\u0005\u00fa\u00f5ZLb \u00ec\u00dbJ\u00d7\u0081\u00e8\u00b1%\u00ac\u009f\u00c5\u00d6 \u00c6\u00a2\u00a51l\u00b1\u0096\u0010\u0080\u00d8\u00cex\u00aa\u00a4\u0007\u00aed\u00c8{\u00c8\u00f1\u00c1:\u0081T\u0096\u008e\n#7\u000b".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl26:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = "\u00e4\u00a3\u00e2\u00ad\u008e\u0081T\u0019F]\u0099\u0088\u00ab\u0019\u00a3\u0019";
                    var7_6 = "\u00e4\u00a3\u00e2\u00ad\u008e\u0081T\u0019F]\u0099\u0088\u00ab\u0019\u00a3\u0019".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl52:
                // 1 sources

                ** continue;
            }
        }
        Class_bY_d6d3ef36.MujRV = var8_3;
        Class_bY_d6d3ef36.VtGWK = new Integer[9];
    }

    @Override
    protected void NV(Class_lC_5322e8cf class_lC_5322e8cf) {
        block18: {
            block19: {
                float f;
                ItemStack itemStack;
                float f2;
                float f3;
                RenderTickCounter renderTickCounter;
                float f4;
                float f5;
                float f6;
                block21: {
                    block20: {
                        long l = FwqDO ^ 0x7A9B0A8C708EL;
                        boolean bl = Class_bX_66e572fb.Ov();
                        if (ClientMain.dlmvG.world == null) {
                            return;
                        }
                        Class_ii_9b427eda class_ii_9b427eda = ClientMain.dlM();
                        boolean bl2 = InterfaceModule.aYe();
                        f6 = this.ormBS.dhj();
                        f5 = this.gILqY.dhj();
                        float f7 = 7.0f;
                        Class_mG_52c8d386 class_mG_52c8d386 = class_ii_9b427eda.bjd().coc(Class_mG_52c8d386.hoGuU, 0.25f).cob(f6);
                        Class_mG_52c8d386 class_mG_52c8d3862 = class_ii_9b427eda.bjf().cob(0.25f);
                        class_lC_5322e8cf.ccU(this.toIeR, this.QWaAn, this.jTsqG, this.Xtjvx, f6, f5);
                        f4 = this.QWaAn + Class_jf_d1c4f950.bAH(12.8f, this.Xtjvx);
                        renderTickCounter = ClientMain.dlmvG.getRenderTickCounter();
                        int n = 0;
                        while (n < Class_bY_d6d3ef36.OF("u", (int)18475, (long)(0xE81828A14EEC954L ^ l))) {
                            block17: {
                                int n2;
                                block12: {
                                    block13: {
                                        block16: {
                                            int n3;
                                            block14: {
                                                block15: {
                                                    f3 = this.toIeR + (float)n * 20.0f;
                                                    f2 = f3 + Class_jf_d1c4f950.bAH(12.8f, 21.0f);
                                                    n2 = n;
                                                    if (bl) break block12;
                                                    if (n2 != ClientMain.dlZ().dbr()) break block13;
                                                    n3 = n;
                                                    if (bl) break block14;
                                                    if (n3 != 0) break block15;
                                                    class_lC_5322e8cf.cdm(f3, this.QWaAn, 21.0f, 22.0f, 7.0f, Class_ld_bb1690e1.left(f7, f7), class_mG_52c8d3862);
                                                    if (!bl) break block13;
                                                }
                                                n3 = n;
                                            }
                                            if (n3 != Class_bY_d6d3ef36.OF("u", (int)10835, (long)(0x7BF2ACECA26DAB21L ^ l))) break block16;
                                            class_lC_5322e8cf.cdm(f3, this.QWaAn, 22.0f, 22.0f, 7.0f, Class_ld_bb1690e1.right(f7, f7), class_mG_52c8d3862);
                                            if (!bl) break block13;
                                        }
                                        class_lC_5322e8cf.cdi(f3, this.QWaAn, 21.0f, 22.0f, class_mG_52c8d3862);
                                    }
                                    this.OB(class_lC_5322e8cf, f2, f4, renderTickCounter, ClientMain.dlmvG.player.getInventory().getStack(n));
                                    if (bl) break block17;
                                    n2 = n;
                                }
                                if (n2 != 0 && !bl2) {
                                    float f8 = this.toIeR + (float)n * 20.0f;
                                    class_lC_5322e8cf.cdh(f8, this.QWaAn + 2.0f, 1.0f, this.Xtjvx - 4.0f, Class_ld_bb1690e1.all(0.25f), class_mG_52c8d386, 0.5f);
                                }
                                ++n;
                            }
                            if (!bl) continue;
                        }
                        itemStack = ClientMain.dlmvG.player.getOffHandStack();
                        if (bl) break block18;
                        if (itemStack.isEmpty()) break block19;
                        Arm arm = ClientMain.dlmvG.player.getMainArm().getOpposite();
                        f = 22.0f;
                        if (arm != Arm.LEFT) break block20;
                        f3 = this.toIeR - f - 8.0f;
                        if (!bl) break block21;
                    }
                    f3 = this.toIeR + this.jTsqG + 8.0f;
                }
                f2 = f3 + Class_jf_d1c4f950.bAH(12.8f, f);
                class_lC_5322e8cf.ccU(f3, this.QWaAn, f, this.Xtjvx, f6, f5);
                this.OB(class_lC_5322e8cf, f2, f4, renderTickCounter, itemStack);
            }
            Class_ju_e398051e.bFV();
        }
    }

    @Override
    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        this.jTsqG = 182.0f;
        this.Xtjvx = 22.0f;
        super.LX(class_lC_5322e8cf);
    }

    private static CallSite OF(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bY_d6d3ef36" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int OD(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x68A3;
        if (VtGWK[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = MujRV[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])kIeWJ.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    kIeWJ.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bY_d6d3ef36", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bY_d6d3ef36.VtGWK[n2] = n3;
        }
        return VtGWK[n2];
    }

    private void OB(Class_lC_5322e8cf class_lC_5322e8cf, float f, float f2, RenderTickCounter renderTickCounter, ItemStack itemStack) {
        block6: {
            Class_jy_33e84da2 class_jy_33e84da2;
            float f3;
            block7: {
                int n;
                boolean bl;
                block5: {
                    long l = FwqDO ^ 0x32E97AA3A40CL;
                    bl = Class_bX_66e572fb.Ou();
                    n = itemStack.isEmpty();
                    if (!bl) break block5;
                    if (n != 0) break block6;
                    n = itemStack.getBobbingAnimationTime();
                }
                float f4 = (float)n - renderTickCounter.getTickProgress(false);
                float f5 = f4 - 0.0f;
                f3 = f5 == 0.0f ? 0 : (f5 > 0.0f ? 1 : -1);
                if (!bl) break block7;
                if (f3 > 0) {
                    float f6 = 1.0f + f4 / 5.0f;
                    float f7 = f + 6.4f;
                    float f8 = f2 + 6.4f;
                    class_lC_5322e8cf.ceV();
                    class_lC_5322e8cf.ceX(f7, f8);
                    class_lC_5322e8cf.ceY(1.0f / f6, (f6 + 1.0f) / 2.0f);
                    class_lC_5322e8cf.ceX(-f7, -f8);
                }
                class_jy_33e84da2 = ((Class_jv_4c1871b8)class_lC_5322e8cf.cea(itemStack, f, f2, 0.8f).bGw()).bGv();
                if (!bl) break block6;
                float f9 = f4 - 0.0f;
                f3 = f9 == 0.0f ? 0 : (f9 > 0.0f ? 1 : -1);
            }
            if (f3 > 0) {
                class_lC_5322e8cf.ceW();
            }
            class_jy_33e84da2 = ((Class_jw_a460984a)class_lC_5322e8cf.ceb(itemStack, f, f2, 0.8f).bGw()).bGv();
        }
    }

    private static int OE(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bY_d6d3ef36.OD(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    @Override
    protected void Ol() {
        long l = FwqDO ^ 0x5453682DD3ADL;
        if (this.mZZzJ.WF()) {
            Vec2f vec2f = Class_rm_d861be3b.dip();
            this.toIeR = Class_jf_d1c4f950.bAH(this.RU(), vec2f.x);
            this.QWaAn = vec2f.y - this.RV();
        }
    }

    private static MatchException OC(MatchException matchException) {
        return matchException;
    }

    @Override
    public boolean Om() {
        long l = FwqDO ^ 0x79169C0C35A4L;
        return ClientMain.dlmvG.world != null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bY_d6d3ef36.class, "OE", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

