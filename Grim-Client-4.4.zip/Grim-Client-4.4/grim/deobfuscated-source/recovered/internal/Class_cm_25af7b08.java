/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.util.math.Vec2f;
import recovered.core.ClientMain;
import recovered.core.NativeLoader;
import recovered.internal.Class_ck_d3c7acd5;
import recovered.internal.Class_cl_0655ee76;
import recovered.internal.Class_cr_3ba4ae18;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.internal.Class_rm_d861be3b;

public class Class_cm_25af7b08 {
    private final List<Class_ck_d3c7acd5> MENPa;
    protected final Class_rk_bf8630d1 ybtAZ;
    private static long LwpdX;
    private static long iYuFd;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cm_25af7b08() {
        long l = LwpdX ^ 0x35CED3973FA8L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_ck_d3c7acd5.QK();
        Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
        try {
            this.MENPa = new ArrayList<Class_ck_d3c7acd5>();
            this.ybtAZ = new Class_rk_bf8630d1((int)iYuFd).dhs(Class_rj_b691f4f7.yiIHY);
            if (Class_iS_888f260e.bwL() == null) {
                Class_ck_d3c7acd5.QJ(new Class_iS_888f260e[3]);
            }
        }
        catch (MatchException matchException) {
            throw Class_cm_25af7b08.QR(matchException);
        }
    }

    static {
        NativeLoader.doInit(Class_cm_25af7b08.class);
        Class_cm_25af7b08._d888335a83d063d9e5dc28decb42bdd5();
    }

    public void QN(Class_lC_5322e8cf class_lC_5322e8cf) {
        long l = LwpdX ^ 0x45FFA6D0296AL;
        Iterator<Class_ck_d3c7acd5> iterator = this.MENPa.iterator();
        Class_iS_888f260e[] class_iS_888f260eArray = Class_ck_d3c7acd5.QK();
        while (iterator.hasNext()) {
            float f;
            float f2;
            float f3;
            float f4;
            Vec2f vec2f;
            Class_ck_d3c7acd5 class_ck_d3c7acd5;
            block20: {
                block18: {
                    Class_ck_d3c7acd5 class_ck_d3c7acd52;
                    block17: {
                        float f5;
                        block19: {
                            block16: {
                                Class_ck_d3c7acd5 class_ck_d3c7acd53;
                                block15: {
                                    class_ck_d3c7acd5 = iterator.next();
                                    try {
                                        if (!class_ck_d3c7acd5.QH() && class_iS_888f260eArray == null) continue;
                                    }
                                    catch (MatchException matchException) {
                                        throw Class_cm_25af7b08.QR(matchException);
                                    }
                                    vec2f = Class_rm_d861be3b.dip();
                                    try {
                                        try {
                                            class_ck_d3c7acd53 = class_ck_d3c7acd5;
                                            if (class_iS_888f260eArray != null) break block15;
                                            if (class_ck_d3c7acd53.QF() != Class_cl_0655ee76.zjBim) break block16;
                                        }
                                        catch (MatchException matchException) {
                                            throw Class_cm_25af7b08.QR(matchException);
                                        }
                                        class_ck_d3c7acd53 = class_ck_d3c7acd5;
                                    }
                                    catch (MatchException matchException) {
                                        throw Class_cm_25af7b08.QR(matchException);
                                    }
                                }
                                f5 = class_ck_d3c7acd53.QG();
                                break block19;
                            }
                            f5 = 0.0f;
                        }
                        f4 = f5;
                        try {
                            try {
                                class_ck_d3c7acd52 = class_ck_d3c7acd5;
                                if (class_iS_888f260eArray != null) break block17;
                                if (class_ck_d3c7acd52.QF() != Class_cl_0655ee76.BisXp) break block18;
                            }
                            catch (MatchException matchException) {
                                throw Class_cm_25af7b08.QR(matchException);
                            }
                            class_ck_d3c7acd52 = class_ck_d3c7acd5;
                        }
                        catch (MatchException matchException) {
                            throw Class_cm_25af7b08.QR(matchException);
                        }
                    }
                    f3 = class_ck_d3c7acd52.QG();
                    break block20;
                }
                f3 = 0.0f;
            }
            float f6 = f3;
            try {
                f2 = class_ck_d3c7acd5.QF() == Class_cl_0655ee76.zjBim ? 1.0f : vec2f.x;
            }
            catch (MatchException matchException) {
                throw Class_cm_25af7b08.QR(matchException);
            }
            float f7 = f2;
            try {
                f = class_ck_d3c7acd5.QF() == Class_cl_0655ee76.BisXp ? 1.0f : vec2f.y;
            }
            catch (MatchException matchException) {
                throw Class_cm_25af7b08.QR(matchException);
            }
            float f8 = f;
            class_lC_5322e8cf.cdi(f4, f6, f7, f8, Class_mG_52c8d386.hoGuU.cob(this.ybtAZ.dhj()));
            if (class_iS_888f260eArray == null) continue;
        }
    }

    public void QO() {
        long l = LwpdX ^ 0x348F8ACF7D6L;
        this.MENPa.clear();
        Vec2f vec2f = Class_rm_d861be3b.dip();
        Class_iS_888f260e[] class_iS_888f260eArray = Class_ck_d3c7acd5.QK();
        this.MENPa.add(new Class_ck_d3c7acd5(Class_cl_0655ee76.BisXp, 5.0f));
        this.MENPa.add(new Class_ck_d3c7acd5(Class_cl_0655ee76.BisXp, vec2f.y - 5.0f));
        this.MENPa.add(new Class_ck_d3c7acd5(Class_cl_0655ee76.zjBim, 4.0f));
        this.MENPa.add(new Class_ck_d3c7acd5(Class_cl_0655ee76.zjBim, vec2f.x - 5.0f));
        Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
        this.MENPa.add(new Class_ck_d3c7acd5(Class_cl_0655ee76.zjBim, vec2f.x / 2.0f - 1.0f));
        this.MENPa.add(new Class_ck_d3c7acd5(Class_cl_0655ee76.BisXp, vec2f.y / 2.0f - 0.5f));
        this.MENPa.add(new Class_ck_d3c7acd5(Class_cl_0655ee76.zjBim, vec2f.x / 4.0f - 0.5f));
        this.MENPa.add(new Class_ck_d3c7acd5(Class_cl_0655ee76.zjBim, vec2f.x / 4.0f * 3.0f - 0.5f));
        this.MENPa.add(new Class_ck_d3c7acd5(Class_cl_0655ee76.BisXp, vec2f.y / 4.0f - 0.5f));
        this.MENPa.add(new Class_ck_d3c7acd5(Class_cl_0655ee76.BisXp, vec2f.y / 4.0f * 3.0f - 0.5f));
        for (Class_cr_3ba4ae18 class_cr_3ba4ae18 : ClientMain.dlK().Ry()) {
            block5: {
                float f;
                block6: {
                    this.MENPa.add(new Class_ck_d3c7acd5(Class_cl_0655ee76.BisXp, class_cr_3ba4ae18.RX()));
                    float f2 = class_cr_3ba4ae18.RU();
                    try {
                        try {
                            float f3 = class_cr_3ba4ae18.RW() + f2 / 2.0f - vec2f.x / 2.0f;
                            f = f3 == 0.0f ? 0 : (f3 > 0.0f ? 1 : -1);
                            if (class_iS_888f260eArray2 != null) break block5;
                            if (f <= 0) break block6;
                        }
                        catch (MatchException matchException) {
                            throw Class_cm_25af7b08.QR(matchException);
                        }
                        this.MENPa.add(new Class_ck_d3c7acd5(Class_cl_0655ee76.zjBim, class_cr_3ba4ae18.RW() + f2));
                        if (class_iS_888f260eArray2 == null) continue;
                    }
                    catch (MatchException matchException) {
                        throw Class_cm_25af7b08.QR(matchException);
                    }
                    Class_iS_888f260e.bwK("f7HH9b");
                }
                f = (float)this.MENPa.add(new Class_ck_d3c7acd5(Class_cl_0655ee76.zjBim, class_cr_3ba4ae18.RW()));
            }
            if (class_iS_888f260eArray2 == null) continue;
        }
    }

    private static native MatchException QR(MatchException var0);

    public native List<Class_ck_d3c7acd5> QP();

    public native Class_rk_bf8630d1 QQ();

    private static native void _d888335a83d063d9e5dc28decb42bdd5();
}

