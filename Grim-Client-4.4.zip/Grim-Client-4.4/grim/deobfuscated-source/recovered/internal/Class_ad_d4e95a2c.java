/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_ad_rN_cfdb3a0a;
import recovered.internal.Class_ad_rO_f65cac7a;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mT_db06bea0;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_ad_d4e95a2c
extends Class_az_a4990dcf {
    public static Class_ad_d4e95a2c rmmkh;
    private final HashMap<Character, Float> NobPV;
    private final List<Class_ad_rO_f65cac7a> fulpu;
    private final Class_lq_87a74641 EwbNS;
    private int[] wgjEd;
    private int[] vkfky;
    private final Class_rk_bf8630d1 WlOfW;
    private boolean IwZbt;
    private final Class_rk_bf8630d1 xolxo;
    private int FLiqk;
    private Class_ad_rN_cfdb3a0a yvQlf;
    private float luqMh;
    private float bUoTD;
    private int ubgWo;
    private long jJtPn;
    private int FHUwd;
    private final Class_mT_db06bea0 XLxgE;
    private boolean FsTVb;
    private String SRLdO;
    private int[] NAEKF;
    private float mGKJa;
    private final Class_mT_db06bea0 PEMno;
    private float lPjqv;
    private Class_mG_52c8d386 GoZAw;
    private int nNcGZ;
    private Runnable ioLZh;
    private Runnable tLmZE;
    private static long XBKYY;
    private static long[] pyxuF;
    private static Integer[] RbWCm;
    private static Map IowfT;
    private static long[] aHYAk;
    private static Long[] jkdYO;
    private static Map JsMui;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ad_d4e95a2c(Class_lq_87a74641 class_lq_87a74641) {
        long l = XBKYY ^ 0x2C325C00B915L;
        this.NobPV = new HashMap();
        this.fulpu = new ArrayList<Class_ad_rO_f65cac7a>();
        this.wgjEd = new int[0];
        this.vkfky = new int[0];
        this.WlOfW = new Class_rk_bf8630d1((int)Class_ad_d4e95a2c.mK("c", (int)32011, (long)(0xA499C3A9384F3CFL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.xolxo = new Class_rk_bf8630d1((int)Class_ad_d4e95a2c.mK("c", (int)20221, (long)(0x6242A6B252D1C031L ^ l))).dhs(Class_rj_b691f4f7.XzDkv);
        this.luqMh = 0.0f;
        this.bUoTD = 0.0f;
        this.ubgWo = -1;
        this.jJtPn = 0L;
        this.FHUwd = 0;
        this.XLxgE = Class_mT_db06bea0.cpz();
        this.FsTVb = true;
        this.SRLdO = "";
        this.PEMno = Class_mT_db06bea0.cpz();
        this.lPjqv = 1.0f;
        this.GoZAw = Class_mG_52c8d386.hoGuU;
        this.nNcGZ = (int)Class_ad_d4e95a2c.mK("c", (int)9922, (long)(0x542CE7527A3A80FL ^ l));
        this.EwbNS = class_lq_87a74641;
    }

    static {
        NativeLoader.doInit(Class_ad_d4e95a2c.class);
        Class_ad_d4e95a2c._1cbfcbdede3d8d756f6b4e0c55f6e7fd();
    }

    public native Class_rk_bf8630d1 mn();

    public native Class_ad_d4e95a2c md(Class_mG_52c8d386 var1);

    public native Class_ad_d4e95a2c me(int var1);

    public native Class_ad_d4e95a2c mc(float var1);

    public native Class_ad_d4e95a2c ma(int[] var1);

    public native long mt();

    public native HashMap<Character, Float> mh();

    public native Class_mT_db06bea0 mv();

    public native int[] mk();

    public native Class_ad_d4e95a2c mf(Runnable var1);

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    public native int ms();

    public native Class_rk_bf8630d1 ml();

    public native boolean mm();

    @Override
    public native boolean dm(int var1, int var2, int var3);

    public native float mr();

    public native void lx();

    public native float mq();

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    public native List<Class_ad_rO_f65cac7a> mi();

    public native int mo();

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    public native Class_ad_d4e95a2c mb(float var1);

    private static native void _1cbfcbdede3d8d756f6b4e0c55f6e7fd();

    public native Class_ad_d4e95a2c lW(long var1);

    @Override
    public native boolean eK(char var1);

    public native int lz(boolean var1);

    public native void ly();

    public native int[] my();

    public native Class_ad_d4e95a2c lZ(String var1);

    public native Class_ad_d4e95a2c lQ(boolean var1);

    public native String mx();

    public native Class_ad_d4e95a2c mg(Runnable var1);

    public native Runnable mE();

    public native Runnable mF();

    private native void lJ();

    public native void lB(String var1);

    public native Class_ad_d4e95a2c lR(int var1);

    public native Class_ad_d4e95a2c lX(int var1);

    public native float mz();

    public native int[] lE();

    public native String lF();

    public native Class_ad_d4e95a2c lO(int[] var1);

    public native Class_ad_d4e95a2c lS(Class_ad_rN_cfdb3a0a var1);

    public native Class_ad_rN_cfdb3a0a mp();

    private native void lH(int var1);

    private native List<Class_ad_rO_f65cac7a> lL();

    private native void lN(int var1);

    public native Class_ad_d4e95a2c lP(int[] var1);

    public native Class_ad_d4e95a2c lT(float var1);

    public native Class_ad_d4e95a2c lY(boolean var1);

    public native Class_mT_db06bea0 mA();

    public native Class_lq_87a74641 mj();

    public native float mB();

    public native Class_mG_52c8d386 mC();

    private native void lK();

    private native String lM();

    public native void lG(char var1);

    private native void lA();

    public native Class_ad_d4e95a2c lU(float var1);

    public native Class_ad_d4e95a2c lV(int var1);

    public native void lC(int[] var1);

    private native void lD();

    public native void lI();

    public native int mu();

    public native boolean mw();

    public native int mD();

    private static native /* synthetic */ boolean mG(Class_ad_rO_f65cac7a var0);

    private static native int mJ(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native long mM(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite mK(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native long mL(int var0, long var1);

    private static native MatchException mH(MatchException var0);

    private static native int mI(int var0, long var1);

    private static native CallSite mN(MethodHandles.Lookup var0, String var1, MethodType var2);
}

