/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 */
package recovered.internal;

import net.minecraft.entity.Entity;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_hl_7be73760
extends Class_hH_ae8f8f77 {
    private Entity fBeXf;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hl_7be73760(Entity entity) {
        this.fBeXf = entity;
    }

    public Entity bcM() {
        return this.fBeXf;
    }
}

