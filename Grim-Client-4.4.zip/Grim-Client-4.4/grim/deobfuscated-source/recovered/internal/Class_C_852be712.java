/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_ak_2ff604c7;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_cI_ff5df82f;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;

public class Class_C_852be712
extends Class_ak_2ff604c7<Class_cI_ff5df82f> {
    private static long OjXEr;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_C_852be712(Class_cI_ff5df82f class_cI_ff5df82f, Class_az_a4990dcf class_az_a4990dcf) {
        super(class_cI_ff5df82f, class_az_a4990dcf);
    }

    static {
        NativeLoader.doInit(Class_C_852be712.class);
        Class_C_852be712._eb386c8a51abc37d25082e5e54c290b2();
    }

    @Override
    public native float dn();

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private static native MatchException fo(MatchException var0);

    @Override
    public native void dY();

    private static native void _eb386c8a51abc37d25082e5e54c290b2();
}

