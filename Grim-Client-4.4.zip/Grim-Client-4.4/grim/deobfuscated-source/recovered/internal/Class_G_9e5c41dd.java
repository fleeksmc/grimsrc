/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_E_1cf91f48;
import recovered.internal.Class_F_b668cea7;
import recovered.internal.Class_G_rJ_10635f26;
import recovered.internal.Class_P_2c9819bb;
import recovered.internal.Class_ad_d4e95a2c;
import recovered.internal.Class_ah_02444db4;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public abstract class Class_G_9e5c41dd
extends Class_az_a4990dcf {
    private static float JdxZX = 12.0f;
    private static float KeoSe = 0.5f;
    private static float dYUct = 4.0f;
    private static float vrvmB = 12.5f;
    protected final Class_ah_02444db4 gIoQb;
    protected final Class_ad_d4e95a2c UgfQu;
    protected final Class_rk_bf8630d1 xzWmG;
    protected final Class_rk_bf8630d1 HMvBX;
    private static long wNYKc;
    private static String[] OZJxj;
    private static String[] kWfeQ;
    private static Map YkVxs;
    private static long[] kwkup;
    private static Integer[] FJMeo;
    private static Map NrSEb;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native void _4b4e796a151ec20f4460e8fe10ce3302();

    protected Class_G_9e5c41dd() {
        long l = wNYKc ^ 0x995F84FEC18L;
        this.xzWmG = new Class_rk_bf8630d1((int)Class_G_9e5c41dd.fP("b", (int)27319, (long)(0x719026EEC7FC7332L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        String[] stringArray = Class_F_b668cea7.b();
        try {
            this.HMvBX = new Class_rk_bf8630d1((int)Class_G_9e5c41dd.fP("b", (int)30396, (long)(0xE6186A7BFC8EF3AL ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
            this.gIoQb = new Class_ah_02444db4();
            this.UgfQu = new Class_ad_d4e95a2c(Class_lE_06fbe260.joxgd.bYM(8.0f));
            this.UgfQu.lZ((String)((Object)Class_G_9e5c41dd.fM("w", (int)20196, (long)(0xD8DD88830DD542CL ^ l))));
            if (Class_iS_888f260e.bwL() == null) {
                Class_F_b668cea7.b(new String[4]);
            }
        }
        catch (MatchException matchException) {
            throw Class_G_9e5c41dd.fI(matchException);
        }
    }

    static {
        NativeLoader.doInit(Class_G_9e5c41dd.class);
        Class_G_9e5c41dd._4b4e796a151ec20f4460e8fe10ce3302();
    }

    protected abstract List<Class_E_1cf91f48> i();

    protected abstract void j(int[] var1);

    @Override
    public native float dn();

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean dm(int var1, int var2, int var3);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private native Class_G_rJ_10635f26 fG();

    private native void fF(float var1, float var2, Class_E_1cf91f48 var3);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private native void fE();

    protected native float fB();

    @Override
    public native boolean fC(double var1, double var3, double var5);

    private static native String fJ(byte[] var0);

    private static native Object fL(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native /* synthetic */ void fH(Class_F_b668cea7 var0, Class_P_2c9819bb var1);

    private static native MatchException fI(MatchException var0);

    private native float fD(int var1);

    private static native String fK(int var0, long var1);

    private static native int fN(int var0, long var1);

    private static native int fO(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite fP(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native CallSite fM(MethodHandles.Lookup var0, String var1, MethodType var2);

    @Override
    public native boolean eK(char var1);
}

