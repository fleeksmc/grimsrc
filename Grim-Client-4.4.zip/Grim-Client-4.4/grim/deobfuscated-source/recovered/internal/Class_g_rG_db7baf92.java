/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_g_bd7b3df3;
import recovered.internal.Class_lC_5322e8cf;

class Class_g_rG_db7baf92
extends Class_az_a4990dcf {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_g_rG_db7baf92(Class_g_bd7b3df3 class_g_bd7b3df3) {
    }

    @Override
    protected void bV(Class_lC_5322e8cf class_lC_5322e8cf) {
    }
}

