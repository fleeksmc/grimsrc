/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import recovered.core.NativeLoader;
import recovered.internal.Class_hJ_a20df6c5;
import recovered.internal.Class_hK_37a4c9e8;
import recovered.internal.Class_hM_a36d442e;

public final class Class_hL_db8a30f6<T> {
    private final String qazLg;
    private boolean iCMch;
    private boolean PtCKH;
    private Class_hK_37a4c9e8 wLPMv;
    private List<String> fsmyb;
    public static Class_hK_37a4c9e8 KCXra;
    public static Class_hK_37a4c9e8 WMgOG;
    private static Class_hK_37a4c9e8 fiJbd;
    private static int[] XwmXO;
    private static long YYaWA;
    private static String[] rOgRG;
    private static String[] AoYxu;
    private static Map HSlMb;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_hL_db8a30f6(String string) {
        long l = YYaWA ^ 0x6D6EAB447E1EL;
        this.iCMch = true;
        this.PtCKH = false;
        this.fsmyb = List.of();
        this.qazLg = Objects.requireNonNull(string, (String)((Object)Class_hL_db8a30f6.beq("s", (int)21457, (long)(0x65E0C037A2339661L ^ l))));
    }

    static {
        NativeLoader.doInit(Class_hL_db8a30f6.class);
        Class_hL_db8a30f6._8cd2f5958a7f605309eaf108c86600d6();
    }

    private static native String beg(String var0);

    public native Class_hL_db8a30f6<T> beb(Class_hK_37a4c9e8 var1);

    private static native CallSite beq(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native /* synthetic */ String beh(String var0);

    public static native int[] bel();

    public native Class_hL_db8a30f6<T> bdZ();

    private static native /* synthetic */ Class_hJ_a20df6c5 bej(String var0);

    private static native String ben(byte[] var0);

    public native Class_hM_a36d442e<T> bef();

    private static native NumberFormatException bem(NumberFormatException var0);

    private static native Object bep(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public static native <T> Class_hL_db8a30f6<T> bdY(String var0);

    private static native String beo(int var0, long var1);

    private static native /* synthetic */ Class_hJ_a20df6c5 bei(String var0);

    public native Class_hL_db8a30f6<T> bec(String ... var1);

    public native Class_hL_db8a30f6<T> bea();

    public static native void bek(int[] var0);

    public native Class_hL_db8a30f6<T> bed(List<String> var1);

    public native Class_hL_db8a30f6<T> bee(String ... var1);

    private static native void _8cd2f5958a7f605309eaf108c86600d6();
}

