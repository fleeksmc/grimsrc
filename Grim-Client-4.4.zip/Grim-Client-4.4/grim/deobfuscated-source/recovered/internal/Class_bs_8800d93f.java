/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.item.Item;
import recovered.core.NativeLoader;
import recovered.internal.Class_ad_d4e95a2c;
import recovered.internal.Class_ah_02444db4;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_bs_se_6fe98b85;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jc_20aa808a;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bs_8800d93f
extends Class_aj_95d0a719 {
    private static float qIoed = 14.0f;
    private final String ekbnl;
    private final Class_ah_02444db4 ivYEe;
    private final Class_ad_d4e95a2c XyJZH;
    private final Consumer<String> UCEUh;
    private String BHqWK;
    private final List<Class_bs_se_6fe98b85> IICQJ;
    private final List<Class_bs_se_6fe98b85> modjX;
    private static int[] Pzbyp;
    private static long YTFUn;
    private static String fvhcP;
    private static long[] dyfjK;
    private static Integer[] AXOWA;
    private static Map fscps;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bs_8800d93f(float f, float f2, float f3, String string, String string2, Consumer<String> consumer) {
        long l = YTFUn ^ 0x55937544C424L;
        super(f, f2, 110.0f, 160.0f);
        this.IICQJ = new ArrayList<Class_bs_se_6fe98b85>();
        this.modjX = new ArrayList<Class_bs_se_6fe98b85>();
        this.IzFhM = f3;
        this.ekbnl = string2;
        this.UCEUh = consumer;
        this.BHqWK = string;
        this.IICQJ.addAll(Class_jc_20aa808a.WnbNG.stream().sorted(Comparator.comparing(Class_jc_20aa808a::bzF, String.CASE_INSENSITIVE_ORDER)).map(this::Hr).toList());
        this.ivYEe = new Class_ah_02444db4();
        this.XyJZH = new Class_ad_d4e95a2c(Class_lE_06fbe260.joxgd.bYM(7.0f));
        this.XyJZH.lZ(fvhcP);
        this.XyJZH.me((int)Class_bs_8800d93f.HA("s", (int)18806, (long)(0x7B006A7557A2A7C0L ^ l)));
        this.XyJZH.mg(this::Hm);
        this.Hm();
        this.FHbTC = true;
    }

    static {
        NativeLoader.doInit(Class_bs_8800d93f.class);
        Class_bs_8800d93f._590a1d3aeb4d47eb50934e3a42634ec3();
    }

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean dm(int var1, int var2, int var3);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private native void Hm();

    private static native int Hz(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean fC(double var1, double var3, double var5);

    @Override
    public native boolean eK(char var1);

    public static native int[] Hv();

    public static native void Hu(int[] var0);

    private static native void _590a1d3aeb4d47eb50934e3a42634ec3();

    private native boolean Ho(Item var1);

    private native /* synthetic */ boolean Hp(Class_bs_se_6fe98b85 var1);

    private native /* synthetic */ void Hq(Class_ii_9b427eda var1, Class_lC_5322e8cf var2);

    private static native MatchException Hw(MatchException var0);

    private static native int Hy(int var0, long var1);

    static native /* synthetic */ float Hs(Class_bs_8800d93f var0);

    static native /* synthetic */ Class_rk_bf8630d1 Ht(Class_bs_8800d93f var0);

    private native void Hn(Class_bs_se_6fe98b85 var1);

    private static native String Hx(byte[] var0);

    private native /* synthetic */ Class_bs_se_6fe98b85 Hr(Item var1);

    private static native CallSite HA(MethodHandles.Lookup var0, String var1, MethodType var2);
}

