/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Supplier;
import recovered.internal.Class_al_68896891;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bi_a63df9c8;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jG_69891630;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;

public abstract class Class_aE_a07172c5
extends Class_az_a4990dcf {
    private static final Map<Class<? extends Class_aE_a07172c5>, Class_aE_a07172c5> CaoaN;
    protected List<Class_az_a4990dcf> LGwHI;
    protected int[] YYZes;
    private static Class_iS_888f260e[] APvXi;
    private static final long OvxDD;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aE_a07172c5(int[] nArray) {
        block0: {
            long l = OvxDD ^ 0x4EF4A8376DF9L;
            Class_iS_888f260e[] class_iS_888f260eArray = Class_aE_a07172c5.vG();
            Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
            this.LGwHI = new CopyOnWriteArrayList<Class_az_a4990dcf>();
            this.YYZes = nArray;
            if (Class_iS_888f260e.bwL() != null) break block0;
            Class_aE_a07172c5.vF(new Class_iS_888f260e[5]);
        }
    }

    static {
        OvxDD = Class_gb_9d201141.aYR(-2692304497950348839L, 8007589828775926486L, MethodHandles.lookup().lookupClass()).a(227607518144727L);
        CaoaN = new ConcurrentHashMap<Class<? extends Class_aE_a07172c5>, Class_aE_a07172c5>();
        Class_aE_a07172c5.vF(null);
    }

    @Override
    public void dl(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        long l = OvxDD ^ 0x1FDB07A8C08FL;
        Iterator<Class_az_a4990dcf> iterator = this.LGwHI.iterator();
        Class_iS_888f260e[] class_iS_888f260eArray = Class_aE_a07172c5.vG();
        while (iterator.hasNext()) {
            Class_az_a4990dcf class_az_a4990dcf = iterator.next();
            class_az_a4990dcf.dl(d, d2, class_mA_32d8a5f2);
            if (class_iS_888f260eArray == null) continue;
        }
    }

    @Override
    public boolean dk(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        boolean bl;
        block13: {
            Class_iS_888f260e[] class_iS_888f260eArray;
            block15: {
                boolean bl2;
                block14: {
                    long l = OvxDD ^ 0x6D681A1D25F6L;
                    Class_bi_a63df9c8 class_bi_a63df9c8 = Class_bl_a15fbaa5.Ex().ED();
                    class_iS_888f260eArray = Class_aE_a07172c5.vG();
                    bl2 = class_bi_a63df9c8.Dw(d, d2);
                    if (class_iS_888f260eArray != null) break block14;
                    if (bl2) break block15;
                    bl2 = false;
                }
                return bl2;
            }
            for (Class_az_a4990dcf class_az_a4990dcf : this.LGwHI) {
                block17: {
                    boolean bl3;
                    block16: {
                        bl = class_az_a4990dcf.tf();
                        if (class_iS_888f260eArray != null) break block13;
                        if (class_iS_888f260eArray == null) {
                            if (bl) {
                                bl3 = Class_bl_a15fbaa5.Ex().ED().Dv(class_az_a4990dcf);
                                if (class_iS_888f260eArray == null) {
                                    if (!bl3 && class_iS_888f260eArray == null) continue;
                                }
                            } else {
                                bl3 = class_az_a4990dcf.dk(d, d2, class_mA_32d8a5f2);
                            }
                        }
                        if (class_iS_888f260eArray != null) break block16;
                        if (!bl3) break block17;
                        bl3 = true;
                    }
                    return bl3;
                }
                if (class_iS_888f260eArray == null) continue;
            }
            bl = super.dk(d, d2, class_mA_32d8a5f2);
        }
        return bl;
    }

    @Override
    public void bV(Class_lC_5322e8cf class_lC_5322e8cf) {
        long l = OvxDD ^ 0x30FDD2B4F132L;
        Iterator<Class_az_a4990dcf> iterator = this.LGwHI.iterator();
        Class_iS_888f260e[] class_iS_888f260eArray = Class_aE_a07172c5.vG();
        while (iterator.hasNext()) {
            Class_az_a4990dcf class_az_a4990dcf;
            Class_az_a4990dcf class_az_a4990dcf2 = class_az_a4990dcf = iterator.next();
            if (class_iS_888f260eArray == null) {
                if (!Class_jG_69891630.bHY(class_az_a4990dcf2) && class_iS_888f260eArray == null) continue;
                class_az_a4990dcf2 = class_az_a4990dcf;
            }
            class_az_a4990dcf2.su(class_lC_5322e8cf);
            if (class_iS_888f260eArray == null) continue;
        }
    }

    public abstract void tP(Class_lC_5322e8cf var1, float var2, Class_al_68896891 var3);

    public static Class_iS_888f260e[] vG() {
        return APvXi;
    }

    public List<Class_az_a4990dcf> vC() {
        return this.LGwHI;
    }

    public static void vF(Class_iS_888f260e[] class_iS_888f260eArray) {
        APvXi = class_iS_888f260eArray;
    }

    private static MatchException vH(MatchException matchException) {
        return matchException;
    }

    public int[] vD() {
        return this.YYZes;
    }

    public static <T extends Class_aE_a07172c5> T vB(Class<T> clazz2, Supplier<T> supplier) {
        return (T)((Class_aE_a07172c5)clazz2.cast(CaoaN.computeIfAbsent(clazz2, clazz -> (Class_aE_a07172c5)supplier.get())));
    }

    public static <T extends Class_aE_a07172c5> T vA(Class<T> clazz) {
        return (T)((Class_aE_a07172c5)clazz.cast(CaoaN.get(clazz)));
    }
}

