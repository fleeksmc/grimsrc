/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.entity.PlayerLikeEntity
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.entity.PlayerLikeEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import recovered.core.ClientMain;
import recovered.internal.Class_av_ffcf74a1;
import recovered.internal.Class_bA_8bed88af;
import recovered.internal.Class_bB_f304b0cf;
import recovered.internal.Class_bC_d3181d6f;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_kd_dfbdd90e;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_la_8f67ae40;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mZ_07f59a29;
import recovered.internal.Class_pU_9c706f1a;
import recovered.internal.Class_pW_dde9d10e;
import recovered.internal.Class_pY_4f9ecc6b;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.internal.Class_rm_d861be3b;
import recovered.internal.Class_rr_be159084;
import recovered.modules.InterfaceModule;

public class Class_bD_a76b19c6
extends Class_av_ffcf74a1 {
    private static Class_bD_a76b19c6 tnZYS;
    private static final float zoXBz = -90.0f;
    private static final float WbPKY = 0.43f;
    private static final float lJYPx = 86.0f;
    private static final float IosTn = 118.0f;
    private static final float iXvMv = 34.0f;
    private final List<Class_bC_d3181d6f> OsaDL;
    private int LUWfM;
    private int QYxCg;
    private boolean zRUoI;
    private final Class_rk_bf8630d1 BOnqc;
    private static final long QANEM;
    private static final String VxFyM;
    private static final long[] USzpw;
    private static final Integer[] oWvYs;
    private static final Map PcTAi;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public static Class_bD_a76b19c6 LE() {
        long l = QANEM ^ 0x3DB0960B15A9L;
        int[] nArray = Class_bB_f304b0cf.b();
        Class_bD_a76b19c6 class_bD_a76b19c6 = tnZYS;
        if (nArray == null) {
            if (class_bD_a76b19c6 == null) {
                new Class_bD_a76b19c6();
            }
            class_bD_a76b19c6 = tnZYS;
        }
        return class_bD_a76b19c6;
    }

    public Class_bD_a76b19c6() {
        long l = QANEM ^ 0x449613794A9EL;
        this.OsaDL = new ArrayList<Class_bC_d3181d6f>();
        this.LUWfM = -1;
        this.QYxCg = -1;
        this.BOnqc = new Class_rk_bf8630d1((int)Class_bD_a76b19c6.LW("l", (int)3381, (long)(0x9FF9FF905227C1L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        tnZYS = this;
        this.LF(Class_pU_9c706f1a.cTP());
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        QANEM = Class_gb_9d201141.aYR(8026135256837780643L, 7135336101674305979L, MethodHandles.lookup().lookupClass()).a(100175630757032L);
        long l = QANEM ^ 0x1A4BAFF25F76L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        byte[] byArray3 = cipher.doFinal("\u0083 \u000f6\u00f5\u00d3\n\u00e3".getBytes("ISO-8859-1"));
        VxFyM = Class_bD_a76b19c6.LT(byArray3).intern();
        PcTAi = new HashMap(13);
        Cipher cipher2 = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory2 = SecretKeyFactory.getInstance("DES");
        byte[] byArray4 = new byte[8];
        byte[] byArray5 = byArray4;
        byArray4[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray5 = byArray5;
            byArray5[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher2.init(2, (Key)secretKeyFactory2.generateSecret(new DESKeySpec(byArray5)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "$\u00acX\u00db\u00df\"P\u001d\u007f\u0080\u0094\u0094Y`~u";
        int n2 = "$\u00acX\u00db\u00df\"P\u001d\u007f\u0080\u0094\u0094Y`~u".length();
        int n3 = 0;
        do {
            byte[] byArray6 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray6[0] & 0xFFL) << 56 | ((long)byArray6[1] & 0xFFL) << 48 | ((long)byArray6[2] & 0xFFL) << 40 | ((long)byArray6[3] & 0xFFL) << 32 | ((long)byArray6[4] & 0xFFL) << 24 | ((long)byArray6[5] & 0xFFL) << 16 | ((long)byArray6[6] & 0xFFL) << 8 | (long)byArray6[7] & 0xFFL;
            byte[] byArray7 = cipher2.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray7[0] & 0xFFL) << 56 | ((long)byArray7[1] & 0xFFL) << 48 | ((long)byArray7[2] & 0xFFL) << 40 | ((long)byArray7[3] & 0xFFL) << 32 | ((long)byArray7[4] & 0xFFL) << 24 | ((long)byArray7[5] & 0xFFL) << 16 | ((long)byArray7[6] & 0xFFL) << 8 | (long)byArray7[7] & 0xFFL;
        } while (n3 < n2);
        USzpw = lArray;
        oWvYs = new Integer[2];
    }

    @Override
    protected Vec2f n() {
        float f = 270.0f;
        return new Vec2f(f, f);
    }

    @Override
    public void m(Class_lC_5322e8cf class_lC_5322e8cf) {
        block20: {
            Class_bD_a76b19c6 class_bD_a76b19c6;
            float f;
            float f2;
            float f3;
            block19: {
                int n;
                float f4;
                float f5;
                float f6;
                float f7;
                block17: {
                    int[] nArray;
                    block18: {
                        int n2;
                        block16: {
                            block15: {
                                block13: {
                                    block14: {
                                        long l = QANEM ^ 0x1164FE2E484BL;
                                        int[] nArray2 = Class_bB_f304b0cf.b();
                                        this.Weytw.dhq((int)Class_bD_a76b19c6.LW("l", (int)6832, (long)(0x2A310C3311B43290L ^ l)));
                                        this.Weytw.dhs(Class_rj_b691f4f7.XzDkv);
                                        nArray = nArray2;
                                        n2 = InterfaceModule.aYl().aYm().VP();
                                        Class_bA_8bed88af class_bA_8bed88af = this.LJ();
                                        f3 = class_bA_8bed88af.centerX();
                                        f2 = class_bA_8bed88af.centerY();
                                        f7 = class_bA_8bed88af.outerRadius();
                                        f = class_bA_8bed88af.innerRadius();
                                        f6 = class_bA_8bed88af.diameter();
                                        f5 = this.Weytw.dhd(1.0f);
                                        f4 = this.sf();
                                        n = this.OsaDL.isEmpty();
                                        if (nArray != null) break block13;
                                        if (n == 0) break block14;
                                        this.LUWfM = -1;
                                        if (nArray == null) break block15;
                                    }
                                    n = this.VWsmm;
                                }
                                if (nArray != null) break block16;
                                if (n == 0) {
                                    this.LUWfM = this.LP(class_lC_5322e8cf, f3, f2, f * f4, f7 * f4);
                                }
                            }
                            n = this.LUWfM;
                        }
                        if (nArray == null) {
                            if (n != this.QYxCg) {
                                this.LR(this.QYxCg);
                                this.BOnqc.dhg();
                                this.QYxCg = this.LUWfM;
                            }
                            n = Class_rr_be159084.diW(n2) ? 1 : 0;
                        }
                        if (nArray != null) break block17;
                        if (n != 0) break block18;
                        n = this.VWsmm ? 1 : 0;
                        if (nArray != null) break block17;
                        if (n != 0) break block18;
                        n = this.zRUoI ? 1 : 0;
                        if (nArray != null) break block17;
                        if (n == 0) {
                            Class_bD_a76b19c6 class_bD_a76b19c62 = this;
                            if (nArray == null) {
                                if (class_bD_a76b19c62.LUWfM >= 0) {
                                    this.LH();
                                }
                                this.zRUoI = true;
                                class_bD_a76b19c62 = this;
                            }
                            class_bD_a76b19c62.VWsmm = true;
                        }
                    }
                    class_bD_a76b19c6 = this;
                    if (nArray != null) break block19;
                    n = class_bD_a76b19c6.OsaDL.isEmpty() ? 1 : 0;
                }
                if (n != 0) {
                    return;
                }
                Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, MathHelper.clamp((float)f5, (float)0.0f, (float)1.0f));
                Class_jH_c1172273.bId(class_lC_5322e8cf, f3, f2, f4);
                this.LK(class_lC_5322e8cf, f3, f2, f6, f, f7);
                class_bD_a76b19c6 = this;
            }
            class_bD_a76b19c6.LN(class_lC_5322e8cf, f3, f2, f);
            Class_jH_c1172273.bIf();
            Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, 1.0f);
            if (Class_iS_888f260e.bwL() != null) break block20;
            Class_bB_f304b0cf.b(new int[2]);
        }
    }

    public void LF(Collection<? extends Class_pY_4f9ecc6b> collection) {
        block4: {
            Collection<? extends Class_pY_4f9ecc6b> collection2;
            int[] nArray;
            block3: {
                long l = QANEM ^ 0x26FFA9729BDBL;
                int[] nArray2 = Class_bB_f304b0cf.b();
                this.OsaDL.clear();
                nArray = nArray2;
                collection2 = collection;
                if (nArray != null) break block3;
                if (collection2 == null) break block4;
                collection2 = collection;
            }
            for (Class_pY_4f9ecc6b class_pY_4f9ecc6b : collection2) {
                this.OsaDL.add(new Class_bC_d3181d6f(class_pY_4f9ecc6b));
                if (nArray == null) continue;
            }
        }
    }

    private void LL(Class_lC_5322e8cf class_lC_5322e8cf, float f, float f2, float f3, float f4, float f5) {
        block2: {
            block1: {
                boolean bl;
                block0: {
                    long l = QANEM ^ 0x65465D41584FL;
                    int[] nArray = Class_bB_f304b0cf.b();
                    bl = InterfaceModule.aYf();
                    if (nArray != null) break block0;
                    if (bl) break block1;
                    bl = InterfaceModule.aYe();
                }
                if (!bl) break block2;
            }
            class_lC_5322e8cf.cdN(f, f2, f3, f3, f4, f5, 0.0f, 360.0f, 1.0f, 0.0f);
        }
    }

    private static String LT(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public static void LD() {
        long l = QANEM ^ 0x7C63269C975L;
        if (ClientMain.dlmvG.world == null) {
            return;
        }
        Class_bD_a76b19c6 class_bD_a76b19c6 = Class_bD_a76b19c6.LE();
        class_bD_a76b19c6.VWsmm = false;
        class_bD_a76b19c6.zRUoI = false;
        ClientMain.dlmvG.setScreen((Screen)class_bD_a76b19c6);
    }

    public Class_bC_d3181d6f LG() {
        Object object;
        block4: {
            block5: {
                block3: {
                    int n;
                    block2: {
                        long l = QANEM ^ 0x46B8AF86DA30L;
                        int[] nArray = Class_bB_f304b0cf.b();
                        n = this.LUWfM;
                        if (nArray != null) break block2;
                        if (n < 0) break block3;
                        object = this;
                        if (nArray != null) break block4;
                        n = ((Class_bD_a76b19c6)object).LUWfM;
                    }
                    if (n < this.OsaDL.size()) break block5;
                }
                return null;
            }
            object = this.OsaDL.get(this.LUWfM);
        }
        return (Class_bC_d3181d6f)object;
    }

    private static CallSite LW(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bD_a76b19c6" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    @Override
    public boolean onMouseClicked(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        long l = QANEM ^ 0x51FCF464A8AEL;
        int[] nArray = Class_bB_f304b0cf.b();
        if (class_mA_32d8a5f2 == Class_mA_32d8a5f2.sCBUa) {
            int n;
            Class_bA_8bed88af class_bA_8bed88af = this.LJ();
            float f = this.sf();
            int n2 = n = this.LQ(d, d2, class_bA_8bed88af.centerX(), class_bA_8bed88af.centerY(), class_bA_8bed88af.innerRadius() * f, class_bA_8bed88af.outerRadius() * f);
            if (nArray == null) {
                if (n2 < 0) {
                    return false;
                }
                this.LUWfM = n;
                this.LH();
                this.zRUoI = true;
                this.VWsmm = true;
                n2 = 1;
            }
            return n2 != 0;
        }
        return false;
    }

    private static MatchException LS(MatchException matchException) {
        return matchException;
    }

    public void close() {
        block3: {
            Class_bD_a76b19c6 class_bD_a76b19c6;
            block2: {
                long l = QANEM ^ 0x79C22467AA63L;
                int[] nArray = Class_bB_f304b0cf.b();
                class_bD_a76b19c6 = this;
                if (nArray != null) break block2;
                if (!class_bD_a76b19c6.VWsmm) break block3;
                this.LI();
                class_bD_a76b19c6 = this;
            }
            super.close();
        }
    }

    public void tick() {
        this.si();
        this.close();
    }

    public void init() {
        this.VWsmm = false;
        this.zRUoI = false;
        this.LUWfM = -1;
        this.QYxCg = -1;
        this.Weytw.dhg();
        this.Weytw.dhs(Class_rj_b691f4f7.XzDkv);
        this.BOnqc.dhg();
    }

    private Class_bA_8bed88af LJ() {
        Vec2f vec2f = Class_rm_d861be3b.diq();
        float f = vec2f.x * 0.5f;
        float f2 = vec2f.y * 0.5f;
        float f3 = MathHelper.clamp((float)(Math.min(vec2f.x, vec2f.y) * 0.29f), (float)86.0f, (float)118.0f);
        float f4 = f3 * 0.43f;
        return new Class_bA_8bed88af(f, f2, f4, f3);
    }

    private int LP(Class_lC_5322e8cf class_lC_5322e8cf, float f, float f2, float f3, float f4) {
        return this.LQ(class_lC_5322e8cf.cff(), class_lC_5322e8cf.cfg(), f, f2, f3, f4);
    }

    /*
     * Unable to fully structure code
     */
    private void LN(Class_lC_5322e8cf var1_1, float var2_2, float var3_3, float var4_4) {
        var5_5 = Class_bD_a76b19c6.QANEM ^ 18596352394072L;
        var8_6 = ClientMain.dlM();
        var9_7 = var4_4 * 1.65f;
        var10_8 = var2_2 - var9_7 * 0.5f;
        var11_9 = var3_3 - var9_7 * 0.5f;
        var12_10 = Class_ld_bb1690e1.all(var9_7 * 0.5f);
        v0 = Class_bB_f304b0cf.b();
        var13_11 = var8_6.bjd().cob(0.9f);
        var1_1.cek(Class_kd_dfbdd90e.AhlXN, var10_8, var11_9, var9_7, var9_7, 7.0f, var12_10, 1.0f);
        var1_1.cdg(var10_8, var11_9, var9_7, var9_7, var12_10, var13_11);
        var14_12 = this.LG();
        var7_13 = v0;
        this.LO(var1_1, var8_6, var2_2, var3_3, var9_7);
        var15_14 = Class_lE_06fbe260.SVnNc.bYM(10.0f);
        v1 = var14_12;
        if (var7_13 != null) ** GOTO lbl21
        if (v1 == null) {
            v2 = Class_bD_a76b19c6.VxFyM;
        } else {
            v1 = var14_12;
lbl21:
            // 2 sources

            v2 = v1.Ly();
        }
        var16_15 = v2;
        var1_1.cez(var15_14, var16_15, var2_2 - var15_14.cao(var16_15) * 0.5f, var3_3 - var15_14.cat() * 0.5f, var8_6.bjb());
    }

    private static int LU(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x1338;
        if (oWvYs[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = USzpw[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])PcTAi.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    PcTAi.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bD_a76b19c6", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bD_a76b19c6.oWvYs[n2] = n3;
        }
        return oWvYs[n2];
    }

    private void LR(int n) {
        block4: {
            block3: {
                int n2;
                block2: {
                    long l = QANEM ^ 0x500545FA9AE1L;
                    int[] nArray = Class_bB_f304b0cf.b();
                    n2 = n;
                    if (nArray != null) break block2;
                    if (n2 < 0) break block3;
                    n2 = n;
                }
                if (n2 < this.OsaDL.size()) break block4;
            }
            return;
        }
        this.OsaDL.get(n).Ls();
    }

    private void LM(Class_lC_5322e8cf class_lC_5322e8cf, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
        Class_mG_52c8d386 class_mG_52c8d386 = ClientMain.dlM().bjf().cob(f8);
        float f9 = (f6 + f7) * 0.5f;
        float f10 = (f7 - f6) * 0.5f * f8;
        float f11 = f9 - f10;
        float f12 = f9 + f10;
        Class_la_8f67ae40 class_la_8f67ae40 = Class_la_8f67ae40.bWJ(f9, class_mG_52c8d386, class_mG_52c8d386.cob(0.01f));
        class_lC_5322e8cf.cdG(f, f2, f3, f3, f4, f5, f11, f12, class_la_8f67ae40);
    }

    public void LI() {
        block2: {
            long l = QANEM ^ 0x7BF3668B10B7L;
            Iterator<Class_bC_d3181d6f> iterator = this.OsaDL.iterator();
            int[] nArray = Class_bB_f304b0cf.b();
            while (iterator.hasNext()) {
                Class_bC_d3181d6f class_bC_d3181d6f = iterator.next();
                class_bC_d3181d6f.Ls();
                class_bC_d3181d6f.LB().dhg();
                if (nArray == null) {
                    if (nArray == null) continue;
                }
                break block2;
            }
            this.BOnqc.dhg();
            this.LUWfM = -1;
            this.QYxCg = -1;
        }
    }

    public void LH() {
        Class_bC_d3181d6f class_bC_d3181d6f;
        block4: {
            block3: {
                Class_bC_d3181d6f class_bC_d3181d6f2;
                block2: {
                    long l = QANEM ^ 0x5307E92A4383L;
                    class_bC_d3181d6f = this.LG();
                    int[] nArray = Class_bB_f304b0cf.b();
                    class_bC_d3181d6f2 = class_bC_d3181d6f;
                    if (nArray != null) break block2;
                    if (class_bC_d3181d6f2 == null) break block3;
                    class_bC_d3181d6f2 = class_bC_d3181d6f;
                }
                if (class_bC_d3181d6f2.Lx() != null) break block4;
            }
            return;
        }
        Class_pW_dde9d10e.cTX((PlayerLikeEntity)ClientMain.dlmvG.player, class_bC_d3181d6f.Lx());
    }

    private static int LV(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bD_a76b19c6.LU(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private void LK(Class_lC_5322e8cf class_lC_5322e8cf, float f, float f2, float f3, float f4, float f5) {
        int n;
        float f6;
        float f7;
        long l = QANEM ^ 0x309B90829EC8L;
        float f8 = 360.0f / (float)this.OsaDL.size();
        float f9 = -90.0f - f8 * 0.5f;
        float f10 = f - f3 * 0.5f;
        float f11 = f2 - f3 * 0.5f;
        int[] nArray = Class_bB_f304b0cf.b();
        this.LL(class_lC_5322e8cf, f10, f11, f3, f4, f5);
        int n2 = this.LUWfM;
        if (nArray == null) {
            if (n2 >= 0) {
                float f12 = f9 + (float)this.LUWfM * f8;
                f7 = f9 + (float)(this.LUWfM + 1) * f8;
                f6 = this.BOnqc.dhd(1.0f);
                this.LM(class_lC_5322e8cf, f10, f11, f3, f4, f5, f12, f7, f6);
            }
            n2 = n = 0;
        }
        while (n < this.OsaDL.size()) {
            f7 = f9 + (float)n * f8;
            f6 = f9 + (float)(n + 1) * f8;
            float f13 = f9 + ((float)n + 0.5f) * f8;
            Class_bB_f304b0cf class_bB_f304b0cf = new Class_bB_f304b0cf(n, n == this.LUWfM, f, f2, f3, f4, f5, f7, f6, f13);
            this.OsaDL.get(n).Lq(class_lC_5322e8cf, class_bB_f304b0cf);
            ++n;
            if (nArray == null) continue;
        }
    }

    private int LQ(double d, double d2, float f, float f2, float f3, float f4) {
        double d3;
        double d4;
        block4: {
            double d5;
            block2: {
                block3: {
                    long l = QANEM ^ 0x32F10548CFE5L;
                    d4 = d - (double)f;
                    d3 = d2 - (double)f2;
                    double d6 = Math.sqrt(d4 * d4 + d3 * d3);
                    int[] nArray = Class_bB_f304b0cf.b();
                    double d7 = d6 - (double)f3;
                    d5 = d7 == 0.0 ? 0 : (d7 < 0.0 ? -1 : 1);
                    if (nArray != null) break block2;
                    if (d5 < 0) break block3;
                    double d8 = d6 - (double)f4;
                    d5 = d8 == 0.0 ? 0 : (d8 > 0.0 ? 1 : -1);
                    if (nArray != null) break block2;
                    if (d5 <= 0) break block4;
                }
                d5 = -1;
            }
            return (int)d5;
        }
        float f5 = 360.0f / (float)this.OsaDL.size();
        double d9 = Class_mZ_07f59a29.csu(Math.toDegrees(Math.atan2(d3, d4)));
        double d10 = -90.0f - f5 * 0.5f;
        double d11 = Class_mZ_07f59a29.csu(d9 - d10);
        int n = (int)(d11 / (double)f5);
        return MathHelper.clamp((int)n, (int)0, (int)(this.OsaDL.size() - 1));
    }

    private void LO(Class_lC_5322e8cf class_lC_5322e8cf, Class_ii_9b427eda class_ii_9b427eda, float f, float f2, float f3) {
        long l = QANEM ^ 0x6C87C9AC2DFCL;
        float f4 = f3 * 0.5f - 2.0f;
        float f5 = f4 - f3 * 0.05f;
        float f6 = f4 * 2.0f;
        float f7 = f4 * 2.0f;
        float f8 = f - f4;
        float f9 = f2 - f4;
        int[] nArray = Class_bB_f304b0cf.b();
        float f10 = 360.0f / (float)this.OsaDL.size();
        float f11 = Math.min(8.0f, f10 * 0.34f);
        float f12 = -90.0f - f10 * 0.5f;
        for (int i = 0; i < this.OsaDL.size(); ++i) {
            float f13 = f12 + (float)i * f10 + f11 * 0.5f;
            float f14 = f12 + (float)(i + 1) * f10 - f11 * 0.5f;
            Class_mG_52c8d386 class_mG_52c8d386 = i == this.LUWfM ? class_ii_9b427eda.bjb() : class_ii_9b427eda.bjb().cob(0.5f);
            class_lC_5322e8cf.cdE(f8, f9, f6, f7, f5, f4, f13, f14, class_mG_52c8d386);
            if (nArray == null) continue;
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bD_a76b19c6.class, "LV", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

