/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;
import recovered.core.NativeLoader;
import recovered.internal.Class_Q_88b47dba;
import recovered.internal.Class_aL_efcd921b;
import recovered.internal.Class_aQ_67e7371d;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_pF_d0757029;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_aK_814f8910
extends Class_az_a4990dcf {
    private static float dWavN = 5.0f;
    private static float tdaYU = 5.0f;
    private final Class_Q_88b47dba qNUBO;
    private final Class_Q_88b47dba whyjC;
    private final Class_aQ_67e7371d qfhpW;
    private final BiConsumer<Double, Double> Ghcea;
    private final Supplier<Boolean> dTQSz;
    private final Supplier<Boolean> annmg;
    private final Class_rk_bf8630d1 EocAk;
    private final Class_rk_bf8630d1 PTlYD;
    private static long EMUUd;
    private static String[] lNnKh;
    private static String[] XoVOd;
    private static Map hPqfH;
    private static long[] ehHHq;
    private static Integer[] AUHtk;
    private static Map ojyYD;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aK_814f8910(Supplier<Class_pF_d0757029> supplier, Consumer<Class_pF_d0757029> consumer, Supplier<Boolean> supplier2, Supplier<Boolean> supplier3, Consumer<Boolean> consumer2, BiConsumer<Double, Double> biConsumer) {
        long l = EMUUd ^ 0x3BC35C6EA17FL;
        this.qNUBO = (Class_Q_88b47dba)new Class_Q_88b47dba().io(Class_lf_d247d983.XANQE).je(true).jf(Class_ld_bb1690e1.all(5.0f));
        this.whyjC = (Class_Q_88b47dba)new Class_Q_88b47dba().io(Class_lf_d247d983.ZEjXc).je(true).jf(Class_ld_bb1690e1.all(5.0f)).jd((String)((Object)Class_aK_814f8910.wL("y", (int)12071, (long)(0x599D30A1E0AA519DL ^ l))), new String[]{Class_aK_814f8910.wL("y", (int)16897, (long)(0x54B2BB141D13BCBAL ^ l))});
        String string = Class_aL_efcd921b.wV();
        try {
            this.EocAk = new Class_rk_bf8630d1((int)Class_aK_814f8910.wO("t", (int)31459, (long)(0x1C8DB996380604C3L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
            this.PTlYD = new Class_rk_bf8630d1((int)Class_aK_814f8910.wO("t", (int)11154, (long)(0x23E9B3BC8F8655B3L ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
            this.qfhpW = new Class_aQ_67e7371d(supplier, consumer);
            this.dTQSz = supplier2;
            this.annmg = supplier3;
            this.Ghcea = biConsumer;
            this.whyjC.jb(arg_0 -> Class_aK_814f8910.wG(consumer2, supplier3, arg_0));
            if (Class_iS_888f260e.bwL() == null) {
                Class_aL_efcd921b.wU("g2Opsb");
            }
        }
        catch (MatchException matchException) {
            throw Class_aK_814f8910.wH(matchException);
        }
    }

    static {
        NativeLoader.doInit(Class_aK_814f8910.class);
        Class_aK_814f8910._a6ae06a24283e9a410a2f355a06a8809();
    }

    @Override
    public native float dn();

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private static native void _a6ae06a24283e9a410a2f355a06a8809();

    private static native CallSite wL(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native /* synthetic */ void wG(Consumer var0, Supplier var1, Class_Q_88b47dba var2);

    private static native CallSite wO(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native MatchException wH(MatchException var0);

    private static native String wI(byte[] var0);

    private static native String wJ(int var0, long var1);

    private static native Object wK(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native int wM(int var0, long var1);

    private native void wF(Class_lC_5322e8cf var1, float var2, float var3, float var4, Class_rk_bf8630d1 var5, boolean var6);

    private native void wE();

    private static native int wN(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);
}

