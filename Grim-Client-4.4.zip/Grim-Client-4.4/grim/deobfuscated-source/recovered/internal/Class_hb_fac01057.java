/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import net.minecraft.util.math.Vec3d;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_hb_fac01057
extends Class_hH_ae8f8f77 {
    private Vec3d Jsypv;
    private float jSwLj;
    private float SYWqk;
    private Vec3d cRDZk;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hb_fac01057(Vec3d vec3d, float f, float f2, Vec3d vec3d2) {
        this.Jsypv = vec3d;
        this.jSwLj = f;
        this.SYWqk = f2;
        this.cRDZk = vec3d2;
    }

    public void bcv(Vec3d vec3d) {
        this.cRDZk = vec3d;
    }

    public float bcs() {
        return this.jSwLj;
    }

    public Vec3d bcr() {
        return this.Jsypv;
    }

    public Vec3d bcu() {
        return this.cRDZk;
    }

    public float bct() {
        return this.SYWqk;
    }
}

