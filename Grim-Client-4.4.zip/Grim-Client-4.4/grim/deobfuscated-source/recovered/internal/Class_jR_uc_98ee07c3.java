/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.joml.Matrix3x2fStack
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Matrix3x2fStack;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jO_1924117a;
import recovered.internal.Class_jR_92e73d8b;
import recovered.internal.Class_mG_52c8d386;

public class Class_jR_uc_98ee07c3 {
    private Matrix3x2fStack MnDqG;
    private float xlwkp;
    private float UNuPf;
    private float gUwlx;
    private float AAVcs;
    private float dIauD;
    private float rssKu;
    private float AnQCx;
    private float hhNPD;
    private boolean cwgvR;
    private Class_mG_52c8d386 qFbWj;
    private boolean KGMmK;
    private float udULP;
    private static final long sOzSQ;
    private static final String[] MCHMT;
    private static final String[] ohPkh;
    private static final Map juLjc;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_jR_uc_98ee07c3() {
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_jR_uc_98ee07c3.sOzSQ = Class_gb_9d201141.aYR(4596910150742697019L, -2553292493622331109L, MethodHandles.lookup().lookupClass()).a(205466779026466L);
                Class_jR_uc_98ee07c3.juLjc = new HashMap<K, V>(13);
                var0 = Class_jR_uc_98ee07c3.sOzSQ ^ 57051395425030L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[11];
                var7_4 = 0;
                var6_5 = ",\u0017\u00e1\u00a0\u0016?\u00d9(\u00a2\u00af\u00d4\u000e\u007fT$0%c\u00c3\u0019\u0085\u00ec\u00ab\u00a5\u00d4\u00ea\u00fbSB\u00e9\u0002J(<P\u00e3!\u0084\u0099\u00cc,\u00c4\u00ba\u00da\u001a\u00acr\u0099#\u0083\u00cb\u00a6g\u00fd\u00b3\u00ef\u0002C\u00e4\u000f\u00d3r\u00eey\u00cf]\u0016\u000f,\u00e8\u00b2$3 \u00ff\u00c7\u00c6\u00cc\u00fa$Q2\u00afA\u0018\u00ef\u008c\u0007z\u00b6T\u008bS\",bf\u00d9\u00a6\u00cf\u00de9\u00dd\u00b8r\u00e3\u0010\"d>K\u0002{,hq\t\u00a8v\u001f\u008a\u00fc\u0099\u0010\u0090\u00df\u00dcs\u00c0'\u00a7\u00b5f\u00a5S\u000b\u00e1\u00f6?m \u00d4\u008e\u0097\u000f\u00f6\u00ba/M\u00dbC\u00b8\u00ca\u0094\u0092y\u00bagD\u00e4c\u00bc]\u00d2\u00f2\u0094\u00f4.\u009a\u00c1\u00ae,\u00c8P%\u00ab\u0004u2I\u0085\u00b0\u0084r-I\u00a8\u000bx$1X9E\u0082\u00f0\u00d8E\u00c6\u00cb}b\u000b\f\u0091\u00d6\tm\u008d\u001e\u00a7\u00cc\u00e2\u0003\fr\u00f6\u00ac\u0086\u00b6\u000fK\u0091\u009b\u00b7\u00e6AC\u00a3C\u00b7W{\u0086\u0095g@\u0083/6\u00d0\u00a3\u00c7iK\u00dd\u0087\u00a5\u0095\u00b6&\u0000\u001d)\u0018\u0098\u00e0s\u00d5\u00b2hz\u0018\u00cc\u00aa\u00e6\u00b6\u00de\u00d8\u009e\u00c86\u0003\u00ea\u00bd[+\u00e6\u00a9 \u00f0#\u00ca\u00aa\u00a5W\u009ce\u00a4\u0082\u001b'\u00c03\u0092\u00a9i\u00fb-Z'\u00cd3\u0088oL\u001dsV\u0088s\u001e";
                var8_6 = ",\u0017\u00e1\u00a0\u0016?\u00d9(\u00a2\u00af\u00d4\u000e\u007fT$0%c\u00c3\u0019\u0085\u00ec\u00ab\u00a5\u00d4\u00ea\u00fbSB\u00e9\u0002J(<P\u00e3!\u0084\u0099\u00cc,\u00c4\u00ba\u00da\u001a\u00acr\u0099#\u0083\u00cb\u00a6g\u00fd\u00b3\u00ef\u0002C\u00e4\u000f\u00d3r\u00eey\u00cf]\u0016\u000f,\u00e8\u00b2$3 \u00ff\u00c7\u00c6\u00cc\u00fa$Q2\u00afA\u0018\u00ef\u008c\u0007z\u00b6T\u008bS\",bf\u00d9\u00a6\u00cf\u00de9\u00dd\u00b8r\u00e3\u0010\"d>K\u0002{,hq\t\u00a8v\u001f\u008a\u00fc\u0099\u0010\u0090\u00df\u00dcs\u00c0'\u00a7\u00b5f\u00a5S\u000b\u00e1\u00f6?m \u00d4\u008e\u0097\u000f\u00f6\u00ba/M\u00dbC\u00b8\u00ca\u0094\u0092y\u00bagD\u00e4c\u00bc]\u00d2\u00f2\u0094\u00f4.\u009a\u00c1\u00ae,\u00c8P%\u00ab\u0004u2I\u0085\u00b0\u0084r-I\u00a8\u000bx$1X9E\u0082\u00f0\u00d8E\u00c6\u00cb}b\u000b\f\u0091\u00d6\tm\u008d\u001e\u00a7\u00cc\u00e2\u0003\fr\u00f6\u00ac\u0086\u00b6\u000fK\u0091\u009b\u00b7\u00e6AC\u00a3C\u00b7W{\u0086\u0095g@\u0083/6\u00d0\u00a3\u00c7iK\u00dd\u0087\u00a5\u0095\u00b6&\u0000\u001d)\u0018\u0098\u00e0s\u00d5\u00b2hz\u0018\u00cc\u00aa\u00e6\u00b6\u00de\u00d8\u009e\u00c86\u0003\u00ea\u00bd[+\u00e6\u00a9 \u00f0#\u00ca\u00aa\u00a5W\u009ce\u00a4\u0082\u001b'\u00c03\u0092\u00a9i\u00fb-Z'\u00cd3\u0088oL\u001dsV\u0088s\u001e".length();
                var5_7 = 32;
                var4_8 = -1;
lbl20:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl25:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jR_uc_98ee07c3.drN(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "s\u0016z\u008a\u008d\u001c\u0098\u00f1\u0003Ku:`\u00d9\u00af\u00e7z\u00c0\u0000\u0089!\u00e3\u0095\u00a5\u00e5\u00ef9\u0017\ny(\u00fa \u00fc\u0089\u00aa?\u00f7\u00af$\u00c4\u00b7\u00fbmu\u009dt\u00f3d\u00b4-\u0082Zd\u00ff\u0004\u00a5N\u00df\u00de\\\u00d0\u00deM\u00c3";
                    var8_6 = "s\u0016z\u008a\u008d\u001c\u0098\u00f1\u0003Ku:`\u00d9\u00af\u00e7z\u00c0\u0000\u0089!\u00e3\u0095\u00a5\u00e5\u00ef9\u0017\ny(\u00fa \u00fc\u0089\u00aa?\u00f7\u00af$\u00c4\u00b7\u00fbmu\u009dt\u00f3d\u00b4-\u0082Zd\u00ff\u0004\u00a5N\u00df\u00de\\\u00d0\u00deM\u00c3".length();
                    var5_7 = 32;
                    var4_8 = -1;
lbl34:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jR_uc_98ee07c3.drN(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl51:
                // 1 sources

                ** continue;
            }
        }
        Class_jR_uc_98ee07c3.MCHMT = var9_3;
        Class_jR_uc_98ee07c3.ohPkh = new String[11];
    }

    public String toString() {
        long l = sOzSQ ^ 0x4F9BDF31EF10L;
        float f = this.udULP;
        String string = String.valueOf(this.qFbWj);
        float f2 = this.hhNPD;
        float f3 = this.AnQCx;
        float f4 = this.rssKu;
        float f5 = this.dIauD;
        float f6 = this.AAVcs;
        float f7 = this.gUwlx;
        float f8 = this.UNuPf;
        float f9 = this.xlwkp;
        String string2 = String.valueOf(this.MnDqG);
        return (String)((Object)Class_jR_uc_98ee07c3.drQ("w", (int)28970, (long)(0x3008305EAAF618DFL ^ l))) + string2 + (String)((Object)Class_jR_uc_98ee07c3.drQ("w", (int)216, (long)(0x4A1DB48FCD04E92FL ^ l))) + f9 + (String)((Object)Class_jR_uc_98ee07c3.drQ("w", (int)11941, (long)(0x3B4832B1C4824755L ^ l))) + f8 + (String)((Object)Class_jR_uc_98ee07c3.drQ("w", (int)169, (long)(0x3D609BEE42A4E952L ^ l))) + f7 + (String)((Object)Class_jR_uc_98ee07c3.drQ("w", (int)14509, (long)(0x12DA06AFE65BD15CL ^ l))) + f6 + (String)((Object)Class_jR_uc_98ee07c3.drQ("w", (int)29911, (long)(0xD86C3697D1D1D21L ^ l))) + f5 + (String)((Object)Class_jR_uc_98ee07c3.drQ("w", (int)25664, (long)(0x7791A5F275D90DB3L ^ l))) + f4 + (String)((Object)Class_jR_uc_98ee07c3.drQ("w", (int)17920, (long)(0x13F5B61FB042FFAL ^ l))) + f3 + (String)((Object)Class_jR_uc_98ee07c3.drQ("w", (int)12830, (long)(0x521898E78542DBEAL ^ l))) + f2 + (String)((Object)Class_jR_uc_98ee07c3.drQ("w", (int)28167, (long)(0x721B1CF1784007FEL ^ l))) + string + (String)((Object)Class_jR_uc_98ee07c3.drQ("w", (int)23554, (long)(0x72F293A3064735F0L ^ l))) + f + ")";
    }

    public Class_jR_uc_98ee07c3 drF(float f) {
        this.dIauD = f;
        return this;
    }

    private static MatchException drM(MatchException matchException) {
        return matchException;
    }

    private static CallSite drQ(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jR_uc_98ee07c3" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static String drN(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static String drO(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5FF4;
        if (ohPkh[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])juLjc.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    juLjc.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jR_uc_98ee07c3", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = MCHMT[n2].getBytes("ISO-8859-1");
            Class_jR_uc_98ee07c3.ohPkh[n2] = Class_jR_uc_98ee07c3.drN(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return ohPkh[n2];
    }

    private static Object drP(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_jR_uc_98ee07c3.drO(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    public Class_jR_uc_98ee07c3 drI(float f) {
        this.hhNPD = f;
        return this;
    }

    public Class_jR_92e73d8b drL() {
        long l = sOzSQ ^ 0x1795207B4AC4L;
        Class_mG_52c8d386 class_mG_52c8d386 = this.qFbWj;
        String string = Class_jO_1924117a.bKy();
        Class_jR_uc_98ee07c3 class_jR_uc_98ee07c3 = this;
        if (string != null) {
            if (!class_jR_uc_98ee07c3.cwgvR) {
                class_mG_52c8d386 = Class_jR_92e73d8b.bLN();
            }
            class_jR_uc_98ee07c3 = this;
        }
        float f = class_jR_uc_98ee07c3.udULP;
        if (!this.KGMmK) {
            f = Class_jR_92e73d8b.bLO();
        }
        return new Class_jR_92e73d8b(this.MnDqG, this.xlwkp, this.UNuPf, this.gUwlx, this.AAVcs, this.dIauD, this.rssKu, this.AnQCx, this.hhNPD, class_mG_52c8d386, f);
    }

    public Class_jR_uc_98ee07c3 drJ(Class_mG_52c8d386 class_mG_52c8d386) {
        this.qFbWj = class_mG_52c8d386;
        this.cwgvR = true;
        return this;
    }

    public Class_jR_uc_98ee07c3 drH(float f) {
        this.AnQCx = f;
        return this;
    }

    public Class_jR_uc_98ee07c3 drG(float f) {
        this.rssKu = f;
        return this;
    }

    public Class_jR_uc_98ee07c3 drK(float f) {
        this.udULP = f;
        this.KGMmK = true;
        return this;
    }

    public Class_jR_uc_98ee07c3 drD(float f) {
        this.gUwlx = f;
        return this;
    }

    public Class_jR_uc_98ee07c3 drE(float f) {
        this.AAVcs = f;
        return this;
    }

    public Class_jR_uc_98ee07c3 drA(Matrix3x2fStack matrix3x2fStack) {
        this.MnDqG = matrix3x2fStack;
        return this;
    }

    public Class_jR_uc_98ee07c3 drB(float f) {
        this.xlwkp = f;
        return this;
    }

    public Class_jR_uc_98ee07c3 drC(float f) {
        this.UNuPf = f;
        return this;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jR_uc_98ee07c3.class, "drP", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

