/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_f_2512a74f;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;

class Class_bl_sd_eb769ac3
extends Class_az_a4990dcf {
    final Class_bl_a15fbaa5 HhcTI;
    private static long IbZaP;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_bl_sd_eb769ac3(Class_bl_a15fbaa5 class_bl_a15fbaa5) {
        this.HhcTI = class_bl_a15fbaa5;
    }

    static {
        NativeLoader.doInit(Class_bl_sd_eb769ac3.class);
        Class_bl_sd_eb769ac3._30c8952bbb4038b983843e0da9f31c2b();
    }

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean dm(int var1, int var2, int var3);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private static native MatchException dnj(MatchException var0);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean eK(char var1);

    @Override
    public native void sA(Class_f_2512a74f var1);

    @Override
    protected native boolean nZ();

    private static native void _30c8952bbb4038b983843e0da9f31c2b();
}

