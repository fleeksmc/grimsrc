/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_bS_979bca5c;
import recovered.internal.Class_cv_f4b0140a;
import recovered.internal.Class_mr_7eac5189;

public class Class_bV_61960ba1
extends Class_bS_979bca5c {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bV_61960ba1(Class_cv_f4b0140a class_cv_f4b0140a, Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_cv_f4b0140a, class_mr_7eac5189);
    }

    @Override
    public boolean MH() {
        return false;
    }
}

