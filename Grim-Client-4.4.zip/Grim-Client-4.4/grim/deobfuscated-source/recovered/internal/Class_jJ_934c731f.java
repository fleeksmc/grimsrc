/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mixin.accessors.LevelRendererAccessor
 *  net.minecraft.block.entity.BlockEntity
 *  net.minecraft.client.render.Frustum
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.Box
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import mixin.accessors.LevelRendererAccessor;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.Frustum;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_mN_b43eff31;

public class Class_jJ_934c731f {
    private static final long lrkPY = Class_gb_9d201141.aYR(-2468805518013952715L, 5312314740014689892L, MethodHandles.lookup().lookupClass()).a(43666576135917L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static MatchException bIE(MatchException matchException) {
        return matchException;
    }

    private static Frustum bID() {
        long l = lrkPY ^ 0x176C9052849BL;
        LevelRendererAccessor levelRendererAccessor = (LevelRendererAccessor)ClientMain.dlmvG.worldRenderer;
        Frustum frustum = levelRendererAccessor.getCapturedFrustum();
        String[] stringArray = Class_jH_c1172273.bIh();
        Frustum frustum2 = frustum;
        if (stringArray == null) {
            if (frustum2 != null) {
                Vec3d vec3d = ((Class_mN_b43eff31)ClientMain.dlmvG.worldRenderer).getFrustumPos();
                frustum.setPosition(vec3d.x, vec3d.y, vec3d.z);
                return frustum;
            }
            frustum2 = ((Class_mN_b43eff31)ClientMain.dlmvG.worldRenderer).getCullingFrustum();
        }
        return frustum2;
    }

    public static boolean bIB(Entity entity) {
        long l = lrkPY ^ 0x49EC6EDD4B87L;
        Frustum frustum = Class_jJ_934c731f.bID();
        String[] stringArray = Class_jH_c1172273.bIh();
        Frustum frustum2 = frustum;
        if (stringArray == null) {
            if (frustum2 == null) {
                return false;
            }
            frustum2 = frustum;
        }
        return frustum2.isVisible(entity.getBoundingBox());
    }

    public static boolean bIC(BlockEntity blockEntity) {
        return Class_jJ_934c731f.bIA(blockEntity.getPos().toCenterPos());
    }

    public static boolean bIA(Vec3d vec3d) {
        long l = lrkPY ^ 0x11DDBA0263D2L;
        Frustum frustum = Class_jJ_934c731f.bID();
        String[] stringArray = Class_jH_c1172273.bIh();
        Frustum frustum2 = frustum;
        if (stringArray == null) {
            if (frustum2 == null) {
                return false;
            }
            frustum2 = frustum;
        }
        return frustum2.isVisible(new Box(vec3d.x - 0.5, vec3d.y - 0.5, vec3d.z - 0.5, vec3d.x + 0.5, vec3d.y + 0.5, vec3d.z + 0.5));
    }
}

