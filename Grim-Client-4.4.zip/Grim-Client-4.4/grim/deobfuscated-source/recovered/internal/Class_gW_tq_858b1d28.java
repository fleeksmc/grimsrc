/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemUsageContext
 *  net.minecraft.util.ActionResult
 */
package recovered.internal;

import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import recovered.internal.Class_gW_bfd02107;

public class Class_gW_tq_858b1d28
extends Class_gW_bfd02107 {
    private ActionResult ZFhqn;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gW_tq_858b1d28(ItemUsageContext itemUsageContext, ActionResult actionResult) {
        super(itemUsageContext);
        this.ZFhqn = actionResult;
    }

    public ActionResult dpr() {
        return this.ZFhqn;
    }
}

