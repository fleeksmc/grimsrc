/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.util.math.Box
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_kH_96821764;
import recovered.internal.Class_mG_52c8d386;

public class Class_kH_up_e45b7ab9 {
    private MatrixStack FKGjF;
    private Box rVjdp;
    private Class_mG_52c8d386 ecgxR;
    private Class_mG_52c8d386 jFenm;
    private Class_mG_52c8d386 LTfSx;
    private boolean MpISF;
    private boolean TjEAh;
    private static final long xwbNq;
    private static final String[] bPYDx;
    private static final String[] ACzdb;
    private static final Map qnlhy;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_kH_up_e45b7ab9() {
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_kH_up_e45b7ab9.xwbNq = Class_gb_9d201141.aYR(584322236403852889L, -3795337152887394363L, MethodHandles.lookup().lookupClass()).a(249880812500847L);
                Class_kH_up_e45b7ab9.qnlhy = new HashMap<K, V>(13);
                var0 = Class_kH_up_e45b7ab9.xwbNq ^ 124723709472395L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[7];
                var7_4 = 0;
                var6_5 = "3\u0017d\u0011b\u001c\u00e21\u00e2;\u00a0\u009c\u00e1\u00ab\u00d9\u00ca\u00e3\n*\u00b5\u001f\u00a6i\u00ab\u00c3w\u00ff,`VL\u009dXe'\u0096\u00e0\u0081\u00c9,\u00da\u008f'\u008eD\u00bb\u00b5\u00fd\u009c\u00a5\u00e1\u0017\u00c5S\u00804<\u0015\u009b\u0014\u00c8PW9\u0005\u0002\u00ca\u007f\u00ae\u0090g\u00c9\u000b\u00b3\u0090`U\u00c4\u0092\u00f6\u00b5\u00c2\\4\u001d\u00f7\u00b7\u0090\u00b0\u000f\u00ef\u00c7\u0018Y\u0083'\u00cbn\u0081\u00e7\u00ff\u00a2\u0095\u00da\u00c5#\u009f\u00d8\u000fe\u0094\u0081\u00dd\u00bb\u0005\u00f9\u0098\u00bcV\u00ca\u0099\u0018laO\u00b2\u0093\u00c8\u00aaLe\u00c8`\u0018\u00fc\u0080\u00c9w\u00f3C\u00b3\u00ee\u00d5s\f\u008d \fx\u001e\u000e\u00c2\u00c1\u00a7\u00f0X\u0005st\u0014k\u00ceR\u0090\u0017\u0095~\u00fe\u00df\u00d2\u00bfd\u00df\u00c3HW\u00d25\u00c9\u0018\u00adA\u007f\u0099\u0019vK:\u00dd\u00a8\u00eaEc\u00f2\u00f6P\u00a0\u008c4\u0083\u00ca\u0084\u001b\u001c";
                var8_6 = "3\u0017d\u0011b\u001c\u00e21\u00e2;\u00a0\u009c\u00e1\u00ab\u00d9\u00ca\u00e3\n*\u00b5\u001f\u00a6i\u00ab\u00c3w\u00ff,`VL\u009dXe'\u0096\u00e0\u0081\u00c9,\u00da\u008f'\u008eD\u00bb\u00b5\u00fd\u009c\u00a5\u00e1\u0017\u00c5S\u00804<\u0015\u009b\u0014\u00c8PW9\u0005\u0002\u00ca\u007f\u00ae\u0090g\u00c9\u000b\u00b3\u0090`U\u00c4\u0092\u00f6\u00b5\u00c2\\4\u001d\u00f7\u00b7\u0090\u00b0\u000f\u00ef\u00c7\u0018Y\u0083'\u00cbn\u0081\u00e7\u00ff\u00a2\u0095\u00da\u00c5#\u009f\u00d8\u000fe\u0094\u0081\u00dd\u00bb\u0005\u00f9\u0098\u00bcV\u00ca\u0099\u0018laO\u00b2\u0093\u00c8\u00aaLe\u00c8`\u0018\u00fc\u0080\u00c9w\u00f3C\u00b3\u00ee\u00d5s\f\u008d \fx\u001e\u000e\u00c2\u00c1\u00a7\u00f0X\u0005st\u0014k\u00ceR\u0090\u0017\u0095~\u00fe\u00df\u00d2\u00bfd\u00df\u00c3HW\u00d25\u00c9\u0018\u00adA\u007f\u0099\u0019vK:\u00dd\u00a8\u00eaEc\u00f2\u00f6P\u00a0\u008c4\u0083\u00ca\u0084\u001b\u001c".length();
                var5_7 = 32;
                var4_8 = -1;
lbl20:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl25:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_kH_up_e45b7ab9.dtT(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "T\u008d{\u0081\u0006\u000e[\u008d\u00bf\u00bb\u0011r\u00f3\u00f893\u00cbT\u00feU\u009a\f\u00c5a\u0018]\u0097\u0007g\u008e\u00ef,\u0010\u00e4o\u00e0\u0097A\u00ce8\u00a3\u00a9\u00f6\\\u00a6pO{/";
                    var8_6 = "T\u008d{\u0081\u0006\u000e[\u008d\u00bf\u00bb\u0011r\u00f3\u00f893\u00cbT\u00feU\u009a\f\u00c5a\u0018]\u0097\u0007g\u008e\u00ef,\u0010\u00e4o\u00e0\u0097A\u00ce8\u00a3\u00a9\u00f6\\\u00a6pO{/".length();
                    var5_7 = 32;
                    var4_8 = -1;
lbl34:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_kH_up_e45b7ab9.dtT(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl51:
                // 1 sources

                ** continue;
            }
        }
        Class_kH_up_e45b7ab9.bPYDx = var9_3;
        Class_kH_up_e45b7ab9.ACzdb = new String[7];
    }

    public String toString() {
        long l = xwbNq ^ 0x786468201F12L;
        boolean bl = this.TjEAh;
        boolean bl2 = this.MpISF;
        String string = String.valueOf(this.LTfSx);
        String string2 = String.valueOf(this.jFenm);
        String string3 = String.valueOf(this.ecgxR);
        String string4 = String.valueOf(this.rVjdp);
        String string5 = String.valueOf(this.FKGjF);
        return (String)((Object)Class_kH_up_e45b7ab9.dtW("m", (int)13358, (long)(0x6CCC4FECEE7FBB80L ^ l))) + string5 + (String)((Object)Class_kH_up_e45b7ab9.dtW("m", (int)12213, (long)(0x614AF2564482A01CL ^ l))) + string4 + (String)((Object)Class_kH_up_e45b7ab9.dtW("m", (int)31821, (long)(0x7A616B83D434F3E0L ^ l))) + string3 + (String)((Object)Class_kH_up_e45b7ab9.dtW("m", (int)29938, (long)(0x355068AEF9F17B59L ^ l))) + string2 + (String)((Object)Class_kH_up_e45b7ab9.dtW("m", (int)23657, (long)(0x34D189D08EC053C5L ^ l))) + string + (String)((Object)Class_kH_up_e45b7ab9.dtW("m", (int)12465, (long)(0x118134384BFFBF1BL ^ l))) + bl2 + (String)((Object)Class_kH_up_e45b7ab9.dtW("m", (int)30754, (long)(0x12343DD8DC93F78DL ^ l))) + bl + ")";
    }

    public Class_kH_96821764 dtS() {
        return new Class_kH_96821764(this.FKGjF, this.rVjdp, this.ecgxR, this.jFenm, this.LTfSx, this.MpISF, this.TjEAh);
    }

    public Class_kH_up_e45b7ab9 dtN(Class_mG_52c8d386 class_mG_52c8d386) {
        this.ecgxR = class_mG_52c8d386;
        return this;
    }

    public Class_kH_up_e45b7ab9 dtP(Class_mG_52c8d386 class_mG_52c8d386) {
        this.LTfSx = class_mG_52c8d386;
        return this;
    }

    public Class_kH_up_e45b7ab9 dtL(MatrixStack matrixStack) {
        this.FKGjF = matrixStack;
        return this;
    }

    public Class_kH_up_e45b7ab9 dtM(Box box) {
        this.rVjdp = box;
        return this;
    }

    private static String dtU(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x22C2;
        if (ACzdb[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])qnlhy.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    qnlhy.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_kH_up_e45b7ab9", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = bPYDx[n2].getBytes("ISO-8859-1");
            Class_kH_up_e45b7ab9.ACzdb[n2] = Class_kH_up_e45b7ab9.dtT(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return ACzdb[n2];
    }

    private static CallSite dtW(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_kH_up_e45b7ab9" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public Class_kH_up_e45b7ab9 dtR(boolean bl) {
        this.TjEAh = bl;
        return this;
    }

    public Class_kH_up_e45b7ab9 dtQ(boolean bl) {
        this.MpISF = bl;
        return this;
    }

    private static String dtT(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static Object dtV(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_kH_up_e45b7ab9.dtU(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    public Class_kH_up_e45b7ab9 dtO(Class_mG_52c8d386 class_mG_52c8d386) {
        this.jFenm = class_mG_52c8d386;
        return this;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_kH_up_e45b7ab9.class, "dtV", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

