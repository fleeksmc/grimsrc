/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.core.ClientMain;
import recovered.internal.Class_bH_2433d459;
import recovered.internal.Class_cn_4308f1f5;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jg_83a87f1c;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mr_7eac5189;

public class Class_bI_270b0f75
extends Class_cn_4308f1f5 {
    private final Class_bH_2433d459 EOqRP;
    private final Class_bH_2433d459 dqBnO;
    private static final long cNgNw;
    private static final String[] QFEJf;
    private static final String[] iySMc;
    private static final Map Xlfqe;
    private static final long[] PqrSJ;
    private static final Integer[] TyQEX;
    private static final Map jhHvO;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bI_270b0f75() {
        block0: {
            long l = cNgNw ^ 0x72ED3C8C8889L;
            int[] nArray = new int[Class_bI_270b0f75.MF("w", (int)1702, (long)(0x7644CA88F5D490DL ^ l))];
            nArray[0] = (int)Class_bI_270b0f75.MF("w", (int)17698, (long)(0x1A76EEECEA8E0A90L ^ l));
            nArray[1] = (int)Class_bI_270b0f75.MF("w", (int)24356, (long)(0x2046C3708FCC109FL ^ l));
            nArray[2] = (int)Class_bI_270b0f75.MF("w", (int)31336, (long)(0x53319968B55BB5C4L ^ l));
            nArray[3] = (int)Class_bI_270b0f75.MF("w", (int)29124, (long)(0x23FDD3284B81BE64L ^ l));
            nArray[4] = (int)Class_bI_270b0f75.MF("w", (int)15197, (long)(0x4E7B67151FFE74FBL ^ l));
            nArray[5] = (int)Class_bI_270b0f75.MF("w", (int)2377, (long)(0x271219C14564C6F0L ^ l));
            nArray[Class_bI_270b0f75.MF("w", (int)26742, (long)(0x3E3E8238B3B427C1L ^ l))] = (int)Class_bI_270b0f75.MF("w", (int)32120, (long)(0x36910D648C08B2C0L ^ l));
            nArray[Class_bI_270b0f75.MF("w", (int)14679, (long)(0x2DC98CC472BF76E1L ^ l))] = (int)Class_bI_270b0f75.MF("w", (int)12503, (long)(0x69B51C4DACA3FF63L ^ l));
            nArray[Class_bI_270b0f75.MF("w", (int)27043, (long)(0x5C8A6661B38C260DL ^ l))] = (int)Class_bI_270b0f75.MF("w", (int)15691, (long)(0x7137A4CEF64872EEL ^ l));
            nArray[Class_bI_270b0f75.MF("w", (int)23892, (long)(0x5B46EBD796B712F9L ^ l))] = (int)Class_bI_270b0f75.MF("w", (int)19854, (long)(0xEA78DE3F4E88224L ^ l));
            nArray[Class_bI_270b0f75.MF("w", (int)27310, (long)(0x22EBDC782A81250CL ^ l))] = (int)Class_bI_270b0f75.MF("w", (int)9602, (long)(0x74045BB97A746A23L ^ l));
            super(nArray, Class_lf_d247d983.GHxLj);
            int[] nArray2 = new int[Class_bI_270b0f75.MF("w", (int)20877, (long)(0x102DA6A2B5B61E38L ^ l))];
            nArray2[0] = (int)Class_bI_270b0f75.MF("w", (int)18002, (long)(0x4B9D1B14367609FDL ^ l));
            nArray2[1] = (int)Class_bI_270b0f75.MF("w", (int)31336, (long)(0x53319968B55BB5C4L ^ l));
            nArray2[2] = (int)Class_bI_270b0f75.MF("w", (int)31336, (long)(0x53319968B55BB5C4L ^ l));
            nArray2[3] = (int)Class_bI_270b0f75.MF("w", (int)24319, (long)(0x3D53CDB87BC2115BL ^ l));
            nArray2[4] = (int)Class_bI_270b0f75.MF("w", (int)23758, (long)(0xA251D0504B11374L ^ l));
            nArray2[5] = (int)Class_bI_270b0f75.MF("w", (int)3581, (long)(0x128AB6568486424DL ^ l));
            this.EOqRP = new Class_bH_2433d459(this.ZpVra, Class_mr_7eac5189.clS(nArray2), (String)((Object)Class_bI_270b0f75.MC("j", (int)10156, (long)(0x602E1B0C37D72664L ^ l))));
            String[] stringArray = Class_bH_2433d459.Mt();
            int[] nArray3 = new int[Class_bI_270b0f75.MF("w", (int)20877, (long)(0x102DA6A2B5B61E38L ^ l))];
            nArray3[0] = (int)Class_bI_270b0f75.MF("w", (int)21360, (long)(0x75195F8A23A01CD3L ^ l));
            nArray3[1] = (int)Class_bI_270b0f75.MF("w", (int)8679, (long)(0xB4FC69CCC76E4EL ^ l));
            nArray3[2] = (int)Class_bI_270b0f75.MF("w", (int)2914, (long)(0x630CAA08D9A4C4D3L ^ l));
            nArray3[3] = (int)Class_bI_270b0f75.MF("w", (int)18296, (long)(0x6B7FBFE71E3F88CBL ^ l));
            nArray3[4] = (int)Class_bI_270b0f75.MF("w", (int)2395, (long)(0x3C0F6C0A6EE9C6FCL ^ l));
            nArray3[5] = (int)Class_bI_270b0f75.MF("w", (int)15888, (long)(0x63A2CA4D521F71B8L ^ l));
            this.dqBnO = new Class_bH_2433d459(this.ZpVra, Class_mr_7eac5189.clS(nArray3), (String)((Object)Class_bI_270b0f75.MC("j", (int)809, (long)(0x2ABABB9B9D2D82E0L ^ l))));
            if (Class_iS_888f260e.bwL() != null) break block0;
            Class_bH_2433d459.Ms(new String[2]);
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block14: {
            block13: {
                block12: {
                    Class_bI_270b0f75.cNgNw = Class_gb_9d201141.aYR(7391329729738366473L, -6258484634165681461L, MethodHandles.lookup().lookupClass()).a(61652026067547L);
                    Class_bI_270b0f75.Xlfqe = new HashMap<K, V>(13);
                    var11 = Class_bI_270b0f75.cNgNw ^ 115757924585657L;
                    var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                    v0 = SecretKeyFactory.getInstance("DES");
                    v1 = new byte[8];
                    v2 = v1;
                    v1[0] = (byte)(var11 >>> 56);
                    for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                        v2 = v2;
                        v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                    }
                    var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                    var20_3 = new String[2];
                    var18_4 = 0;
                    var17_5 = ".YI\u00d9W\u009d\u0017\u00cbo\u00abE\u00adS\u00fe\u001c\u00c6\u0010\u00f5\u00aey\u00b7\u00fc,\u00af\u0016\u0095\u00d8\u00d9\u00d4\u00cbg%9";
                    var19_6 = ".YI\u00d9W\u009d\u0017\u00cbo\u00abE\u00adS\u00fe\u001c\u00c6\u0010\u00f5\u00aey\u00b7\u00fc,\u00af\u0016\u0095\u00d8\u00d9\u00d4\u00cbg%9".length();
                    var16_7 = 16;
                    var15_8 = -1;
lbl20:
                    // 2 sources

                    while (true) {
                        continue;
                        break;
                    }
lbl22:
                    // 1 sources

                    while (true) {
                        var20_3[var18_4++] = Class_bI_270b0f75.Mz(var21_9).intern();
                        if ((var15_8 += var16_7) < var19_6) {
                            var16_7 = var17_5.charAt(var15_8);
                            ** continue;
                        }
                        break block12;
                        break;
                    }
                    v3 = ++var15_8;
                    var21_9 = var13_1.doFinal(var17_5.substring(v3, v3 + var16_7).getBytes("ISO-8859-1"));
                    ** while (true)
                }
                Class_bI_270b0f75.QFEJf = var20_3;
                Class_bI_270b0f75.iySMc = new String[2];
                Class_bI_270b0f75.jhHvO = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v4 = SecretKeyFactory.getInstance("DES");
                v5 = new byte[8];
                v6 = v5;
                v5[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v6 = v6;
                    v6[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v4.generateSecret(new DESKeySpec(v6)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[28];
                var3_13 = 0;
                var4_14 = "\u000eV<\u00c9c\u00de\u00c9q3\u00b0K\u00c3\u00b1\u00a1|\u0001\u009e!\u000b\u0089E8\u00c1\u007fK\u0082\u009d\u00fe\u0084\u00ad\u00cf@B\u00e2\u0003\u0005\u009b\u0000v'\u0085j\u00f1\u00e3\u00a3\u00d6S\u00ec\u00a5\u000fH\u0019\u008f\u00f6\u001d\u0004^\u009dK\u009d(\u00d6\u00b7\u00b8x\u00a8\t\u0012u\u00b1\u00e1\u008a\u00001\u0016\u00a8=\u00b0\u0094\u00de\u009dG\u00c39\u00b2t\u00d0\u00b9M\u0084L\u00cb\u00d7\u009c\u00edtH\u0007X\u00a7\u00a8\u00a6Y%Vw}eu\u00ed\u00dd4\u0011Q\u0006\u00d4I\u00f20?G\u00ac\u00b0\u0091\u00a0\u00d7\u00fe_\u00e0lJj\u00f0c/\u00045\u0017\u0003\u00eb\u00fe\"\u00e9\u00bb\u001dl\u00e1^l<\u0095\u00bc>F\u00e3\u00abOEI\u0084q+=\u00ca\u00f0\u0088\u00eb\u0001.n6\u00bfH\u0086\f\u00ca\u00cd\u00d0\u00d2\u00964\rp\u0094\u001dA\u00b4J\u0081'\u001d\n~b\u00aa\u00af\u00cfTq\u00a1y\u00b3Q\u00cc\u00e7\u00e3t\u00a9";
                var5_15 = "\u000eV<\u00c9c\u00de\u00c9q3\u00b0K\u00c3\u00b1\u00a1|\u0001\u009e!\u000b\u0089E8\u00c1\u007fK\u0082\u009d\u00fe\u0084\u00ad\u00cf@B\u00e2\u0003\u0005\u009b\u0000v'\u0085j\u00f1\u00e3\u00a3\u00d6S\u00ec\u00a5\u000fH\u0019\u008f\u00f6\u001d\u0004^\u009dK\u009d(\u00d6\u00b7\u00b8x\u00a8\t\u0012u\u00b1\u00e1\u008a\u00001\u0016\u00a8=\u00b0\u0094\u00de\u009dG\u00c39\u00b2t\u00d0\u00b9M\u0084L\u00cb\u00d7\u009c\u00edtH\u0007X\u00a7\u00a8\u00a6Y%Vw}eu\u00ed\u00dd4\u0011Q\u0006\u00d4I\u00f20?G\u00ac\u00b0\u0091\u00a0\u00d7\u00fe_\u00e0lJj\u00f0c/\u00045\u0017\u0003\u00eb\u00fe\"\u00e9\u00bb\u001dl\u00e1^l<\u0095\u00bc>F\u00e3\u00abOEI\u0084q+=\u00ca\u00f0\u0088\u00eb\u0001.n6\u00bfH\u0086\f\u00ca\u00cd\u00d0\u00d2\u00964\rp\u0094\u001dA\u00b4J\u0081'\u001d\n~b\u00aa\u00af\u00cfTq\u00a1y\u00b3Q\u00cc\u00e7\u00e3t\u00a9".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v7 = var6_12;
                    v8 = var3_13++;
                    v9 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v10 = -1;
                    break block13;
                    break;
                }
lbl58:
                // 1 sources

                while (true) {
                    v7[v8] = v11;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u0084\u00aa\u00e5w8\u009c\u008d\u0017\u00f0\u0016_\u0004!\u008eI\u00a7";
                    var5_15 = "\u0084\u00aa\u00e5w8\u009c\u008d\u0017\u00f0\u0016_\u0004!\u008eI\u00a7".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v7 = var6_12;
                        v8 = var3_13++;
                        v9 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v10 = 0;
                        break block13;
                        break;
                    }
                    break;
                }
lbl71:
                // 1 sources

                while (true) {
                    v7[v8] = v11;
                    if (var2_16 < var5_15) ** continue;
                    break block14;
                    break;
                }
            }
            var8_18 = v9;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v11 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v10) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl84:
                // 1 sources

                ** continue;
            }
        }
        Class_bI_270b0f75.PqrSJ = var6_12;
        Class_bI_270b0f75.TyQEX = new Integer[28];
    }

    private static Object MB(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_bI_270b0f75.MA(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    @Override
    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        super.LX(class_lC_5322e8cf);
        this.EOqRP.Mo(Math.round(ClientMain.dlmvG.player.getX()) + " " + Math.round(ClientMain.dlmvG.player.getY()) + " " + Math.round(ClientMain.dlmvG.player.getZ()));
        this.dqBnO.Mo(Class_jg_83a87f1c.bBO(ClientMain.dlmvG.player.getYaw()));
    }

    private static CallSite MF(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bI_270b0f75" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static CallSite MC(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bI_270b0f75" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static MatchException My(MatchException matchException) {
        return matchException;
    }

    private static int ME(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bI_270b0f75.MD(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static String Mz(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static String MA(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x1058;
        if (iySMc[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])Xlfqe.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    Xlfqe.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bI_270b0f75", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = QFEJf[n2].getBytes("ISO-8859-1");
            Class_bI_270b0f75.iySMc[n2] = Class_bI_270b0f75.Mz(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return iySMc[n2];
    }

    private static int MD(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5E30;
        if (TyQEX[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = PqrSJ[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])jhHvO.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    jhHvO.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bI_270b0f75", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bI_270b0f75.TyQEX[n2] = n3;
        }
        return TyQEX[n2];
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bI_270b0f75.class, "ME", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_bI_270b0f75.class, "MB", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

