/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import recovered.internal.Class_iD_f0bb28c7;
import recovered.internal.Class_iu_bf2db566;
import recovered.internal.Class_iy_c88c0f4f;
import recovered.internal.Class_iz_2ddebd14;

public interface Class_ix_05f2a225 {
    public CompletableFuture<Class_iz_2ddebd14> fetchKeyPreset(String var1);

    public CompletableFuture<Class_iy_c88c0f4f> updateProfile(String var1, Class_iD_f0bb28c7 var2);

    public CompletableFuture<Class_iy_c88c0f4f> createProfile(Class_iD_f0bb28c7 var1);

    public CompletableFuture<Class_iu_bf2db566> deleteProfile(String var1);

    public CompletableFuture<Class_iu_bf2db566> importProfile(String var1);

    public CompletableFuture<List<Class_iy_c88c0f4f>> fetchProfiles();

    public CompletableFuture<Class_iu_bf2db566> loadProfile(Class_iy_c88c0f4f var1);

    public CompletableFuture<Class_iy_c88c0f4f> fetchProfile(String var1);
}

