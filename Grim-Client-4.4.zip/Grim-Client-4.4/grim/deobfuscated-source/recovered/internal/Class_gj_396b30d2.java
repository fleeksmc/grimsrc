/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.command.OrderedRenderCommandQueue
 *  net.minecraft.client.render.entity.EntityRenderManager
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.PlayerLikeEntity
 */
package recovered.internal;

import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.PlayerLikeEntity;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gj_396b30d2
extends Class_hH_ae8f8f77 {
    private MatrixStack UlhDQ;
    private PlayerLikeEntity dGSXa;
    private EntityRenderManager JmnUb;
    private OrderedRenderCommandQueue AMllE;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gj_396b30d2(MatrixStack matrixStack, PlayerLikeEntity playerLikeEntity, EntityRenderManager entityRenderManager, OrderedRenderCommandQueue orderedRenderCommandQueue) {
        this.UlhDQ = matrixStack;
        this.dGSXa = playerLikeEntity;
        this.JmnUb = entityRenderManager;
        this.AMllE = orderedRenderCommandQueue;
    }

    public EntityRenderManager baR() {
        return this.JmnUb;
    }

    public OrderedRenderCommandQueue baS() {
        return this.AMllE;
    }

    public MatrixStack baP() {
        return this.UlhDQ;
    }

    public PlayerLikeEntity baQ() {
        return this.dGSXa;
    }
}

