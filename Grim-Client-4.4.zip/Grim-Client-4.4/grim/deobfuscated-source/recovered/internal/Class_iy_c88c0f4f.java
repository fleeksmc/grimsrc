/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package recovered.internal;

import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_nf_8f40fc48;
import recovered.internal.Class_rp_2e61368f;

public class Class_iy_c88c0f4f
implements Class_rp_2e61368f {
    private String ZNDLV;
    private String dCbyG;
    private int[] WIYHr;
    private String tfcpU;
    private String bgmZd;
    private int GCcfx;
    private int aXnDv;
    private String pPHkv;
    private String DwGFV;
    private boolean xMEWX;
    private boolean lVoCP;
    private boolean fuxWh;
    private int mLRsL;
    private boolean PlvNc;
    private boolean vfzTQ;
    private String OMxKv;
    private int ZZeNO;
    private int VWVuq;
    private int UeIfz;
    private int EKGdz;
    private List<Class_nf_8f40fc48> AiMOQ;
    private static int[] EBjXO;
    private static long sqLOm;
    private static String[] CqZmG;
    private static String[] yWmRp;
    private static Map lxPFC;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native void _7dffbe5dbd71ee4d7cd37b2a171e70a0();

    static {
        NativeLoader.doInit(Class_iy_c88c0f4f.class);
        Class_iy_c88c0f4f._7dffbe5dbd71ee4d7cd37b2a171e70a0();
    }

    public native boolean box();

    @Override
    public native void fromJson(JsonObject var1);

    @Override
    public native JsonObject toJson();

    public native boolean bos();

    public native boolean bow();

    private static native Object bpe(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public native String bon();

    public native String bor();

    public native boolean bou();

    public native int boo();

    public native boolean bot();

    public native int bov();

    public native Class_iy_c88c0f4f boY(List<Class_nf_8f40fc48> var1);

    public native List<Class_nf_8f40fc48> boD();

    public native boolean boi();

    public native int[] bol();

    public native String bom();

    public native int bop();

    public native String boq();

    public native String boj();

    public native int boC();

    public native int boB();

    public native int boz();

    public native int boA();

    public native String boy();

    public native Class_iy_c88c0f4f boP(boolean var1);

    private static native MatchException bpb(MatchException var0);

    private static native CallSite bpf(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native Class_iy_c88c0f4f boV(int var1);

    public native Class_iy_c88c0f4f boG(int[] var1);

    public native Class_iy_c88c0f4f boO(boolean var1);

    public native Class_iy_c88c0f4f boW(int var1);

    public native Class_iy_c88c0f4f boE(String var1);

    private static native String bpd(int var0, long var1);

    public native Class_iy_c88c0f4f boT(String var1);

    public native Class_iy_c88c0f4f boJ(int var1);

    public static native int[] bpa();

    public native Class_iy_c88c0f4f boF(String var1);

    public native String bok();

    public native Class_iy_c88c0f4f boQ(int var1);

    public native Class_iy_c88c0f4f boU(int var1);

    public native Class_iy_c88c0f4f boM(String var1);

    public native Class_iy_c88c0f4f boK(int var1);

    public native Class_iy_c88c0f4f boN(boolean var1);

    public native Class_iy_c88c0f4f boR(boolean var1);

    public native Class_iy_c88c0f4f boI(String var1);

    public native Class_iy_c88c0f4f boS(boolean var1);

    private static native String bpc(byte[] var0);

    public native Class_iy_c88c0f4f boH(String var1);

    public native Class_iy_c88c0f4f boX(int var1);

    public static native void boZ(int[] var0);

    public native Class_iy_c88c0f4f boL(String var1);
}

