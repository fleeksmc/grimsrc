/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;

public class Class_gU_9448080d
extends Class_hH_ae8f8f77 {
    private String wxmgD;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gU_9448080d(String string) {
        this.wxmgD = string;
    }

    public String bcj() {
        return this.wxmgD;
    }
}

