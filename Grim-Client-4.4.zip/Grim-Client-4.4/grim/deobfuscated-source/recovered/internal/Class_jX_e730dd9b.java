/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderPass
 *  com.mojang.blaze3d.vertex.VertexFormat$DrawMode
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.util.BufferAllocator
 */
package recovered.internal;

import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandles;
import java.security.Key;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jL_e8aba6a1;
import recovered.internal.Class_jO_1924117a;
import recovered.internal.Class_jT_87816f30;
import recovered.internal.Class_kR_e9b8cad1;
import recovered.internal.Class_ke_512fbaf0;
import recovered.internal.Class_kh_19daf527;
import recovered.internal.Class_kk_ea401760;
import recovered.internal.Class_lF_27593463;
import recovered.internal.Class_lt_a3a39a2f;
import recovered.internal.Class_rm_d861be3b;

public class Class_jX_e730dd9b
implements Class_kh_19daf527<Class_jO_1924117a> {
    private static final long kRcjs = Class_gb_9d201141.aYR(-6360556769871776842L, -1933544579734279765L, MethodHandles.lookup().lookupClass()).a(169418617892138L);
    private static final String cvxBK;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = kRcjs ^ 0x383A9BF6A3B4L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                byte[] byArray3 = cipher.doFinal("\u0093\u0019\u0012\u0097uI\u00ac\u00cd\u00de\u0086\u000e\u00e3\u00cb@?\u00b0".getBytes("ISO-8859-1"));
                cvxBK = Class_jX_e730dd9b.bNC(byArray3).intern();
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    /*
     * Unable to fully structure code
     */
    public void bNz(Class_jO_1924117a var1_1) {
        var2_2 = Class_jX_e730dd9b.kRcjs ^ 51959087305734L;
        var5_3 = var1_1.bKi();
        var4_4 = Class_jT_87816f30.bMR();
        if (var5_3.cnW()) {
            return;
        }
        var6_5 = Class_rm_d861be3b.dip();
        var7_6 = var1_1.bKb();
        var8_7 = var1_1.bKc();
        var9_8 = var1_1.bKd();
        var10_9 = var1_1.bKe();
        var11_10 = var7_6 / var6_5.x;
        var12_11 = (var7_6 + var9_8) / var6_5.x;
        var13_12 = 1.0f - var8_7 / var6_5.y;
        var14_13 = 1.0f - (var8_7 + var10_9) / var6_5.y;
        var15_14 = new BufferAllocator(VertexFormats.POSITION_TEXTURE_COLOR.getVertexSize() * 4);
        try {
            var16_15 = new BufferBuilder(var15_14, VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            Class_jX_e730dd9b.FroVm.uv_quad_region_color(var16_15, var1_1.bKa(), var7_6, var8_7, var9_8, var10_9, var11_10, var13_12, var12_11, var14_13, var1_1.bKi());
            var17_17 = var16_15.end();
            try {
                Class_lF_27593463.cfB(Class_kR_e9b8cad1.alRAH, var17_17, (Consumer<RenderPass>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, bNA(recovered.internal.Class_jO_1924117a com.mojang.blaze3d.systems.RenderPass ), (Lcom/mojang/blaze3d/systems/RenderPass;)V)((Class_jO_1924117a)var1_1));
                ** if (var4_4 || var17_17 == null) goto lbl-1000
            }
            catch (Throwable var18_19) {
                block16: {
                    v0 = var17_17;
                    if (var4_4) ** GOTO lbl31
                    if (v0 == null) break block16;
                    try {
                        v0 = var17_17;
lbl31:
                        // 2 sources

                        v0.close();
                    }
                    catch (Throwable var19_20) {
                        var18_19.addSuppressed(var19_20);
                    }
                }
                throw var18_19;
            }
lbl-1000:
            // 1 sources

            {
                var17_17.close();
            }
lbl-1000:
            // 2 sources

            {
            }
        }
        finally {
            var15_14.close();
        }
    }

    private static Throwable bNB(Throwable throwable) {
        return throwable;
    }

    private static /* synthetic */ void bNA(Class_jO_1924117a class_jO_1924117a, RenderPass renderPass) {
        long l = kRcjs ^ 0x778DCBECA3E1L;
        renderPass.bindTexture(cvxBK, Class_kk_ea401760.bPN().getColorAttachmentView(), Class_lt_a3a39a2f.caX());
        Class_ke_512fbaf0.bOj(Class_jL_e8aba6a1.VBAOv, class_jO_1924117a, ClientMain.dlmvG.getWindow().getFramebufferWidth(), ClientMain.dlmvG.getWindow().getFramebufferHeight());
    }

    private static String bNC(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }
}

