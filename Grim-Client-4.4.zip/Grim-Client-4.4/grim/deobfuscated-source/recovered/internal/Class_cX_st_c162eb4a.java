/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.consume.UseAction
 */
package recovered.internal;

import net.minecraft.item.consume.UseAction;

class Class_cX_st_c162eb4a {
    static final int[] uFllB = new int[UseAction.values().length];
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        try {
            Class_cX_st_c162eb4a.uFllB[UseAction.EAT.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class_cX_st_c162eb4a.uFllB[UseAction.DRINK.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

