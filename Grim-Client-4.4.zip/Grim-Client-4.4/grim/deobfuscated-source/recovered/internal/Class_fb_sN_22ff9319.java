/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

final class Class_fb_sN_22ff9319
extends Enum<Class_fb_sN_22ff9319> {
    public static /* enum */ Class_fb_sN_22ff9319 OUxZP;
    public static /* enum */ Class_fb_sN_22ff9319 yVCMq;
    public static /* enum */ Class_fb_sN_22ff9319 JRycS;
    public static /* enum */ Class_fb_sN_22ff9319 ifDZh;
    public static /* enum */ Class_fb_sN_22ff9319 mgytQ;
    private static Class_fb_sN_22ff9319[] VXqFu;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_fb_sN_22ff9319.class);
        Class_fb_sN_22ff9319._5adc0fb619bb872b2a08958b8071e1f2();
    }

    public static native Class_fb_sN_22ff9319[] values();

    public static native Class_fb_sN_22ff9319 valueOf(String var0);

    private static native void _5adc0fb619bb872b2a08958b8071e1f2();

    private static native String doX(byte[] var0);

    private static native Class_fb_sN_22ff9319[] doW();
}

