/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.texture.AbstractTexture
 *  org.joml.Matrix3x2fStack
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.texture.AbstractTexture;
import org.joml.Matrix3x2fStack;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jO_1924117a;
import recovered.internal.Class_kd_dfbdd90e;
import recovered.internal.Class_kf_f68d320f;
import recovered.internal.Class_la_8f67ae40;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mG_52c8d386;

public class Class_jO_tZ_935a142d {
    private Matrix3x2fStack zqyMa;
    private float ViidM;
    private float QEyRn;
    private float GfHAw;
    private float UHtFB;
    private boolean avkzP;
    private Class_kd_dfbdd90e QvCTr;
    private boolean YAJPy;
    private Class_kf_f68d320f ScNJe;
    private boolean vPiDj;
    private Class_ld_bb1690e1 UaHoW;
    private boolean NqnQn;
    private Class_mG_52c8d386 wLguT;
    private Class_la_8f67ae40 fcOAu;
    private AbstractTexture mMDiK;
    private boolean KOTFK;
    private boolean HXHff;
    private boolean WnNZm;
    private float UwXpQ;
    private boolean gTFVI;
    private float rNfXw;
    private boolean gBPCX;
    private float vwICI;
    private boolean aBbKD;
    private float lmpfr;
    private boolean hzTrm;
    private float UpAGt;
    private boolean IkXsY;
    private float BNfdr;
    private boolean nCioZ;
    private float XmitP;
    private boolean XTvuT;
    private float RcElA;
    private boolean bYgMB;
    private float UxNBE;
    private boolean KZbcI;
    private float oFQqY;
    private boolean bqdjk;
    private float RkjyL;
    private static final long BfVpk;
    private static final String[] Kxqtf;
    private static final String[] YClXp;
    private static final Map cYqfd;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_jO_tZ_935a142d() {
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_jO_tZ_935a142d.BfVpk = Class_gb_9d201141.aYR(432562138399754221L, 2540498334252928184L, MethodHandles.lookup().lookupClass()).a(58561791290852L);
                Class_jO_tZ_935a142d.cYqfd = new HashMap<K, V>(13);
                var0 = Class_jO_tZ_935a142d.BfVpk ^ 78323890482015L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[23];
                var7_4 = 0;
                var6_5 = "F\u00fc\u0098\u00fbU\u0017\b\u007f-\u00cc\u00e9\u00a9\u0094\u00d4>\u0007 1\u00bd\u001d|\u009a\u00ad\u00d8\u00a4l\u001cH\u00c2x\u0005\u00d3\n\u00af\u009d\u00fc\u000f\u00d5x\u00a4\u0095\u001cg\u00bf\u0001(\u00bd\u00a6\u00ed ZA+\u00e0p\u00a3P\u00f6x'\u00b1\u00d1\u0085\u0094t)\u0018!B\u00d9\u0013\u00e1m\u00b3\u0099\u008eT\u00cb\u009f:t\u00e38\u00d5\fH\u00c3\u0013\u009a\u00d9\u00d3\u00dd\u0015\u00eb\u00fd\u00b4e\u00c9j\u000b?\u00a9\u00f3/\n\u00a1\u00d0j\u00c3Y\u009e#\u00d0JS\u00a1\u00b4W\u00c0\u00c9{\u00beR\u0018\u000fq9;\u00a4\u009c\u0006\u0000\u00ce\u00a7\u001b\u0010\b(\u00e5(\u00c9\u0088\u0004\u000f)V\u00a5w\u00b9\u009a\u0005k\u0095Z6\u00bc\u00dcd\u009cs\u000bj\u001a\u00f1\u00d0\u00a7\u0011f\u00fd\u00dc\u00a9\u001e\u0015m\u00c3\u00f0[\u00c04\u00d2\u0010G~\u00f1\u00ef\u0003\u00be\u0018\u00f9z\u0093\u0001 \u0000\u0010\u00a7\u00ee\u0018=y\u0016&\u00f4&2{\u00ac)UA\u00e4\u0083$O]\u00924\"\u00ac\u00e1\u00f3<(\u00f2w%4\u009d\u00bb\u0000Q\u00a8\u00dd\u00ee M\u00a7\u001f\u00de\u0019\u00b2\u00ba '\u00bd\"\u0092\u00f4h\u001fI\u00ab\u0092\u00ad\u0086\u00f4G?\u0088\u008d@}\u00dc \u009dNt\u00f9\u00fa\u00d0{\u00be7+\u00e1>K\u00c9v^k\u00d5\u00b3\u0093\u008f`\u000e\u00ab\u0094\u0094L\u00dcSkE\u0086\u0018Vz\u00c3\u0096FC\u008c\u00bf\u0001\u00a9\u00d1\u00e4O\u0089\u00e0\r\u00ef\u00a1\u001eH\u008aTL\u0087(0\u009a\u00b4*\u00ea\u00c4\u00fe_=\u00e2\u00f1[`\u00e2\u009a\u0013\u00b2\u00c4.\u0089\u00e4j\u00bd.\u00a8\u0098\u00b0\u00f0\u00db-\u00b3\u00b1\u0087v6\u00dc(\f\u00e2\u00920\u00b8]h\u0017~[\u001d\u0085\u00d0?8\u00f4G\u00de\u008f\u00df\u0017\u0080]\u0000\u009e\u00bd\u001f\u00cfV!\u0083\u0010 )u\u00f4\u00b7\u00a3%6\u0092\u00ee\u00a3\u00ee>/g\u00a4c\t\u009f\u00a0 `\u00f8\u00a6\u00df\u00c8\u00ac\u0095yo\u00f6\u00f19\u00d8&`\u00d0\u0011F\u00f7\u0096\u00f8h\u0088zZ\u0090{#\u00e2\u0000\u00c0\u0085H\u00815\u00a5\u0018v\u00ca\u00f7\u00dd\u00a9\u008f\u0087\u00ba\u00be\u00af\u00a2Xn)\u00c4\u0014\n\u00c8\u00d6\u008a\u00c6\u00fci\u00a4<\u00fe\u00198\u00d4\u0085\u00be\u00d1\u008a\u0083\u0017l\u00a7\u00e0o\u0002/4\u009a}d\u00e2\u00fc7N\u00bd=\u00bf\u00a1t\u0011;\u00ad\u0099\u0082B\u00d1q\u00afu\u0092?\u00f6\u00b3(\u00ab_\u00b5xU\u00ff:|\u00ef'\u00d1?M\u00a9\u00ff\u00d2=[I\u0098\u00a8\u00a19Z\u00d9\u0096\u00da\u00c6\u00f1\u00cf\u00ad\u00a1sE\u009ed\u00ae\u00eb\u0098\u00e6 \u0087\u00c4\u00c8\u00ee<\u00b8\u00b9^X\u00b0n\u009a\u00a5\u0096\u00c5\u00d0\u00d8\u00b5\u0015\u000b\u00c2\u00c5\u00c9\u0092\r\u0017\u008b>\u00fc\u00af\u00cd\u00f5(\u0010\u00a8\u00b2\u0007\u00ae\u00f4\u0015\u00ba#R\u0003\u00eb\u0016=5B#\u00ab'0\u0019\u00b4\u008b<\u00ae\u00f0\u00f5\u0006\"0\u0006\u00e2\u001a\u00fe[_\u00ed\u00b8\n\u001e8\u000f\u00d9gxQ\u00b2\u0097\u00ce\u00a8\u00c2pF\u00d1\u00e7\nL2\u0080\u0091\u0082/\u00c3\u00a8VA\u001a/\u0092\u00c4(\u0085\u00f39\u0092ObJ\u00d8\u00cdI\u0006@\u00bf\r0$\\\u00d2i\u001d\u00d6H\u00921\u009c\u00b4\u0018&\u0096\u00bb\u00d3\u000eE@,\u009bQ\u00f1\u009f?\u00a3\u00a3A~\u00bf \u00f3e\u00e1/\u00e5\u00188\u0003\u0092\u00c2\u00c3\u0003\u0095\u001a\u0017\u0080\u0092J\u00df\u0016\u00e2\u00f1\u008e\u00bc\u00bd\u00c8\t\u00afO\u007f !\t,\f\u0081F\u00b2-\u0001\u009dx\u00ea\u00c2\u00e8\u00df\u0011\u001f\t-\u00ef\u00ec\u00b1\u00c6q\t\u0007X\u00cc\u00a2\u00e4\t\u0090";
                var8_6 = "F\u00fc\u0098\u00fbU\u0017\b\u007f-\u00cc\u00e9\u00a9\u0094\u00d4>\u0007 1\u00bd\u001d|\u009a\u00ad\u00d8\u00a4l\u001cH\u00c2x\u0005\u00d3\n\u00af\u009d\u00fc\u000f\u00d5x\u00a4\u0095\u001cg\u00bf\u0001(\u00bd\u00a6\u00ed ZA+\u00e0p\u00a3P\u00f6x'\u00b1\u00d1\u0085\u0094t)\u0018!B\u00d9\u0013\u00e1m\u00b3\u0099\u008eT\u00cb\u009f:t\u00e38\u00d5\fH\u00c3\u0013\u009a\u00d9\u00d3\u00dd\u0015\u00eb\u00fd\u00b4e\u00c9j\u000b?\u00a9\u00f3/\n\u00a1\u00d0j\u00c3Y\u009e#\u00d0JS\u00a1\u00b4W\u00c0\u00c9{\u00beR\u0018\u000fq9;\u00a4\u009c\u0006\u0000\u00ce\u00a7\u001b\u0010\b(\u00e5(\u00c9\u0088\u0004\u000f)V\u00a5w\u00b9\u009a\u0005k\u0095Z6\u00bc\u00dcd\u009cs\u000bj\u001a\u00f1\u00d0\u00a7\u0011f\u00fd\u00dc\u00a9\u001e\u0015m\u00c3\u00f0[\u00c04\u00d2\u0010G~\u00f1\u00ef\u0003\u00be\u0018\u00f9z\u0093\u0001 \u0000\u0010\u00a7\u00ee\u0018=y\u0016&\u00f4&2{\u00ac)UA\u00e4\u0083$O]\u00924\"\u00ac\u00e1\u00f3<(\u00f2w%4\u009d\u00bb\u0000Q\u00a8\u00dd\u00ee M\u00a7\u001f\u00de\u0019\u00b2\u00ba '\u00bd\"\u0092\u00f4h\u001fI\u00ab\u0092\u00ad\u0086\u00f4G?\u0088\u008d@}\u00dc \u009dNt\u00f9\u00fa\u00d0{\u00be7+\u00e1>K\u00c9v^k\u00d5\u00b3\u0093\u008f`\u000e\u00ab\u0094\u0094L\u00dcSkE\u0086\u0018Vz\u00c3\u0096FC\u008c\u00bf\u0001\u00a9\u00d1\u00e4O\u0089\u00e0\r\u00ef\u00a1\u001eH\u008aTL\u0087(0\u009a\u00b4*\u00ea\u00c4\u00fe_=\u00e2\u00f1[`\u00e2\u009a\u0013\u00b2\u00c4.\u0089\u00e4j\u00bd.\u00a8\u0098\u00b0\u00f0\u00db-\u00b3\u00b1\u0087v6\u00dc(\f\u00e2\u00920\u00b8]h\u0017~[\u001d\u0085\u00d0?8\u00f4G\u00de\u008f\u00df\u0017\u0080]\u0000\u009e\u00bd\u001f\u00cfV!\u0083\u0010 )u\u00f4\u00b7\u00a3%6\u0092\u00ee\u00a3\u00ee>/g\u00a4c\t\u009f\u00a0 `\u00f8\u00a6\u00df\u00c8\u00ac\u0095yo\u00f6\u00f19\u00d8&`\u00d0\u0011F\u00f7\u0096\u00f8h\u0088zZ\u0090{#\u00e2\u0000\u00c0\u0085H\u00815\u00a5\u0018v\u00ca\u00f7\u00dd\u00a9\u008f\u0087\u00ba\u00be\u00af\u00a2Xn)\u00c4\u0014\n\u00c8\u00d6\u008a\u00c6\u00fci\u00a4<\u00fe\u00198\u00d4\u0085\u00be\u00d1\u008a\u0083\u0017l\u00a7\u00e0o\u0002/4\u009a}d\u00e2\u00fc7N\u00bd=\u00bf\u00a1t\u0011;\u00ad\u0099\u0082B\u00d1q\u00afu\u0092?\u00f6\u00b3(\u00ab_\u00b5xU\u00ff:|\u00ef'\u00d1?M\u00a9\u00ff\u00d2=[I\u0098\u00a8\u00a19Z\u00d9\u0096\u00da\u00c6\u00f1\u00cf\u00ad\u00a1sE\u009ed\u00ae\u00eb\u0098\u00e6 \u0087\u00c4\u00c8\u00ee<\u00b8\u00b9^X\u00b0n\u009a\u00a5\u0096\u00c5\u00d0\u00d8\u00b5\u0015\u000b\u00c2\u00c5\u00c9\u0092\r\u0017\u008b>\u00fc\u00af\u00cd\u00f5(\u0010\u00a8\u00b2\u0007\u00ae\u00f4\u0015\u00ba#R\u0003\u00eb\u0016=5B#\u00ab'0\u0019\u00b4\u008b<\u00ae\u00f0\u00f5\u0006\"0\u0006\u00e2\u001a\u00fe[_\u00ed\u00b8\n\u001e8\u000f\u00d9gxQ\u00b2\u0097\u00ce\u00a8\u00c2pF\u00d1\u00e7\nL2\u0080\u0091\u0082/\u00c3\u00a8VA\u001a/\u0092\u00c4(\u0085\u00f39\u0092ObJ\u00d8\u00cdI\u0006@\u00bf\r0$\\\u00d2i\u001d\u00d6H\u00921\u009c\u00b4\u0018&\u0096\u00bb\u00d3\u000eE@,\u009bQ\u00f1\u009f?\u00a3\u00a3A~\u00bf \u00f3e\u00e1/\u00e5\u00188\u0003\u0092\u00c2\u00c3\u0003\u0095\u001a\u0017\u0080\u0092J\u00df\u0016\u00e2\u00f1\u008e\u00bc\u00bd\u00c8\t\u00afO\u007f !\t,\f\u0081F\u00b2-\u0001\u009dx\u00ea\u00c2\u00e8\u00df\u0011\u001f\t-\u00ef\u00ec\u00b1\u00c6q\t\u0007X\u00cc\u00a2\u00e4\t\u0090".length();
                var5_7 = 16;
                var4_8 = -1;
lbl20:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl25:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jO_tZ_935a142d.dqB(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "\u00cb\u00ee\u00b5k\u0000\u00f4\u00b1\u00adY\u00ac\u009c\u0091\u009f\u00e7=\u00ad\u001a\u00ac&?u'\u0089\u0010\u0018\u000b5!\u00d5\u00ed\u00ec\u00b48#\u00d8\u00c3\u0012\u008ap\u009dGfj\u000b\u00d8\fL2G";
                    var8_6 = "\u00cb\u00ee\u00b5k\u0000\u00f4\u00b1\u00adY\u00ac\u009c\u0091\u009f\u00e7=\u00ad\u001a\u00ac&?u'\u0089\u0010\u0018\u000b5!\u00d5\u00ed\u00ec\u00b48#\u00d8\u00c3\u0012\u008ap\u009dGfj\u000b\u00d8\fL2G".length();
                    var5_7 = 24;
                    var4_8 = -1;
lbl34:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jO_tZ_935a142d.dqB(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl51:
                // 1 sources

                ** continue;
            }
        }
        Class_jO_tZ_935a142d.Kxqtf = var9_3;
        Class_jO_tZ_935a142d.YClXp = new String[23];
    }

    public String toString() {
        long l = BfVpk ^ 0x67A90CEBB052L;
        float f = this.RkjyL;
        float f2 = this.oFQqY;
        float f3 = this.UxNBE;
        float f4 = this.RcElA;
        float f5 = this.XmitP;
        float f6 = this.BNfdr;
        float f7 = this.UpAGt;
        float f8 = this.lmpfr;
        float f9 = this.vwICI;
        float f10 = this.rNfXw;
        float f11 = this.UwXpQ;
        boolean bl = this.HXHff;
        String string = String.valueOf(this.mMDiK);
        String string2 = String.valueOf(this.fcOAu);
        String string3 = String.valueOf(this.wLguT);
        String string4 = String.valueOf(this.UaHoW);
        String string5 = String.valueOf((Object)this.ScNJe);
        String string6 = String.valueOf((Object)this.QvCTr);
        float f12 = this.UHtFB;
        float f13 = this.GfHAw;
        float f14 = this.QEyRn;
        float f15 = this.ViidM;
        String string7 = String.valueOf(this.zqyMa);
        return (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)6136, (long)(0x39EDA3941154F86EL ^ l))) + string7 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)7819, (long)(0x3A5C192757CA7110L ^ l))) + f15 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)32317, (long)(0x4138F10002C711A3L ^ l))) + f14 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)2664, (long)(0x35459261A1C5E5FFL ^ l))) + f13 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)1466, (long)(0x276A128FF2A5EA2EL ^ l))) + f12 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)16232, (long)(0x42804B9E903AD0E3L ^ l))) + string6 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)9610, (long)(0x47E5A5DC81B1CA13L ^ l))) + string5 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)30430, (long)(0x37069F4DD915994CL ^ l))) + string4 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)2160, (long)(0x453EB9952AC567F8L ^ l))) + string3 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)9922, (long)(0x3CD86658E39A494DL ^ l))) + string2 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)10728, (long)(0x113E4AA5C7BBC666L ^ l))) + string + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)14714, (long)(0x2AC3539DACB6D6EFL ^ l))) + bl + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)1351, (long)(0x4495C7BDF9026AD6L ^ l))) + f11 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)8819, (long)(0x379C3FB1384BCDEBL ^ l))) + f10 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)14748, (long)(0x4AA2C3629DD5D60CL ^ l))) + f9 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)988, (long)(0x533A9D350EFC6C56L ^ l))) + f8 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)4069, (long)(0x267E8591ECD76079L ^ l))) + f7 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)31421, (long)(0x2628327E7F2F1522L ^ l))) + f6 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)7847, (long)(0x14C55263168F713DL ^ l))) + f5 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)3583, (long)(0x5927974986B7E276L ^ l))) + f4 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)23545, (long)(0x74ECF5A2007A3474L ^ l))) + f3 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)32575, (long)(0x43AAC7AF0E5190ACL ^ l))) + f2 + (String)((Object)Class_jO_tZ_935a142d.dqE("t", (int)2465, (long)(0x1879D70877AB663CL ^ l))) + f + ")";
    }

    public Class_jO_tZ_935a142d dqx(float f) {
        this.oFQqY = f;
        this.KZbcI = true;
        return this;
    }

    public Class_jO_1924117a dqz() {
        Class_jO_1924117a class_jO_1924117a;
        block31: {
            long l = BfVpk ^ 0x7AC191F2348BL;
            Class_kd_dfbdd90e class_kd_dfbdd90e = this.QvCTr;
            String string = Class_jO_1924117a.bKy();
            Class_jO_tZ_935a142d class_jO_tZ_935a142d = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d.avkzP) {
                    class_kd_dfbdd90e = Class_jO_1924117a.bJJ();
                }
                class_jO_tZ_935a142d = this;
            }
            Class_kf_f68d320f class_kf_f68d320f = class_jO_tZ_935a142d.ScNJe;
            Class_jO_tZ_935a142d class_jO_tZ_935a142d2 = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d2.YAJPy) {
                    class_kf_f68d320f = Class_jO_1924117a.bJK();
                }
                class_jO_tZ_935a142d2 = this;
            }
            Class_ld_bb1690e1 class_ld_bb1690e1 = class_jO_tZ_935a142d2.UaHoW;
            Class_jO_tZ_935a142d class_jO_tZ_935a142d3 = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d3.vPiDj) {
                    class_ld_bb1690e1 = Class_jO_1924117a.bJL();
                }
                class_jO_tZ_935a142d3 = this;
            }
            Class_mG_52c8d386 class_mG_52c8d386 = class_jO_tZ_935a142d3.wLguT;
            boolean bl = this.NqnQn;
            if (string != null) {
                if (!bl) {
                    class_mG_52c8d386 = Class_jO_1924117a.bJM();
                }
                bl = this.HXHff;
            }
            boolean bl2 = bl;
            Class_jO_tZ_935a142d class_jO_tZ_935a142d4 = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d4.KOTFK) {
                    bl2 = Class_jO_1924117a.bJN();
                }
                class_jO_tZ_935a142d4 = this;
            }
            float f = class_jO_tZ_935a142d4.UwXpQ;
            Class_jO_tZ_935a142d class_jO_tZ_935a142d5 = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d5.WnNZm) {
                    f = Class_jO_1924117a.bJO();
                }
                class_jO_tZ_935a142d5 = this;
            }
            float f2 = class_jO_tZ_935a142d5.rNfXw;
            Class_jO_tZ_935a142d class_jO_tZ_935a142d6 = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d6.gTFVI) {
                    f2 = Class_jO_1924117a.bJP();
                }
                class_jO_tZ_935a142d6 = this;
            }
            float f3 = class_jO_tZ_935a142d6.vwICI;
            Class_jO_tZ_935a142d class_jO_tZ_935a142d7 = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d7.gBPCX) {
                    f3 = Class_jO_1924117a.bJQ();
                }
                class_jO_tZ_935a142d7 = this;
            }
            float f4 = class_jO_tZ_935a142d7.lmpfr;
            Class_jO_tZ_935a142d class_jO_tZ_935a142d8 = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d8.aBbKD) {
                    f4 = Class_jO_1924117a.bJR();
                }
                class_jO_tZ_935a142d8 = this;
            }
            float f5 = class_jO_tZ_935a142d8.UpAGt;
            Class_jO_tZ_935a142d class_jO_tZ_935a142d9 = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d9.hzTrm) {
                    f5 = Class_jO_1924117a.bJS();
                }
                class_jO_tZ_935a142d9 = this;
            }
            float f6 = class_jO_tZ_935a142d9.BNfdr;
            Class_jO_tZ_935a142d class_jO_tZ_935a142d10 = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d10.IkXsY) {
                    f6 = Class_jO_1924117a.bJT();
                }
                class_jO_tZ_935a142d10 = this;
            }
            float f7 = class_jO_tZ_935a142d10.XmitP;
            Class_jO_tZ_935a142d class_jO_tZ_935a142d11 = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d11.nCioZ) {
                    f7 = Class_jO_1924117a.bJU();
                }
                class_jO_tZ_935a142d11 = this;
            }
            float f8 = class_jO_tZ_935a142d11.RcElA;
            Class_jO_tZ_935a142d class_jO_tZ_935a142d12 = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d12.XTvuT) {
                    f8 = Class_jO_1924117a.bJV();
                }
                class_jO_tZ_935a142d12 = this;
            }
            float f9 = class_jO_tZ_935a142d12.UxNBE;
            Class_jO_tZ_935a142d class_jO_tZ_935a142d13 = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d13.bYgMB) {
                    f9 = Class_jO_1924117a.bJW();
                }
                class_jO_tZ_935a142d13 = this;
            }
            float f10 = class_jO_tZ_935a142d13.oFQqY;
            Class_jO_tZ_935a142d class_jO_tZ_935a142d14 = this;
            if (string != null) {
                if (!class_jO_tZ_935a142d14.KZbcI) {
                    f10 = Class_jO_1924117a.bJX();
                }
                class_jO_tZ_935a142d14 = this;
            }
            float f11 = class_jO_tZ_935a142d14.RkjyL;
            if (!this.bqdjk) {
                f11 = Class_jO_1924117a.bJY();
            }
            class_jO_1924117a = new Class_jO_1924117a(this.zqyMa, this.ViidM, this.QEyRn, this.GfHAw, this.UHtFB, class_kd_dfbdd90e, class_kf_f68d320f, class_ld_bb1690e1, class_mG_52c8d386, this.fcOAu, this.mMDiK, bl2, f, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11);
            if (Class_iS_888f260e.bwL() != null) break block31;
            Class_jO_1924117a.bKx("Dlh2P");
        }
        return class_jO_1924117a;
    }

    public Class_jO_tZ_935a142d dqy(float f) {
        this.RkjyL = f;
        this.bqdjk = true;
        return this;
    }

    public Class_jO_tZ_935a142d dqk(Class_mG_52c8d386 class_mG_52c8d386) {
        this.wLguT = class_mG_52c8d386;
        this.NqnQn = true;
        return this;
    }

    public Class_jO_tZ_935a142d dqv(float f) {
        this.RcElA = f;
        this.XTvuT = true;
        return this;
    }

    public Class_jO_tZ_935a142d dqm(AbstractTexture abstractTexture) {
        this.mMDiK = abstractTexture;
        return this;
    }

    public Class_jO_tZ_935a142d dqo(float f) {
        this.UwXpQ = f;
        this.WnNZm = true;
        return this;
    }

    public Class_jO_tZ_935a142d dqw(float f) {
        this.UxNBE = f;
        this.bYgMB = true;
        return this;
    }

    public Class_jO_tZ_935a142d dqh(Class_kd_dfbdd90e class_kd_dfbdd90e) {
        this.QvCTr = class_kd_dfbdd90e;
        this.avkzP = true;
        return this;
    }

    public Class_jO_tZ_935a142d dqj(Class_ld_bb1690e1 class_ld_bb1690e1) {
        this.UaHoW = class_ld_bb1690e1;
        this.vPiDj = true;
        return this;
    }

    public Class_jO_tZ_935a142d dql(Class_la_8f67ae40 class_la_8f67ae40) {
        this.fcOAu = class_la_8f67ae40;
        return this;
    }

    public Class_jO_tZ_935a142d dqr(float f) {
        this.lmpfr = f;
        this.aBbKD = true;
        return this;
    }

    public Class_jO_tZ_935a142d dqu(float f) {
        this.XmitP = f;
        this.nCioZ = true;
        return this;
    }

    public Class_jO_tZ_935a142d dqt(float f) {
        this.BNfdr = f;
        this.IkXsY = true;
        return this;
    }

    public Class_jO_tZ_935a142d dqs(float f) {
        this.UpAGt = f;
        this.hzTrm = true;
        return this;
    }

    private static MatchException dqA(MatchException matchException) {
        return matchException;
    }

    public Class_jO_tZ_935a142d dqp(float f) {
        this.rNfXw = f;
        this.gTFVI = true;
        return this;
    }

    private static String dqB(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static CallSite dqE(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jO_tZ_935a142d" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static String dqC(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0xC3D;
        if (YClXp[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])cYqfd.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    cYqfd.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jO_tZ_935a142d", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = Kxqtf[n2].getBytes("ISO-8859-1");
            Class_jO_tZ_935a142d.YClXp[n2] = Class_jO_tZ_935a142d.dqB(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return YClXp[n2];
    }

    private static Object dqD(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_jO_tZ_935a142d.dqC(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    public Class_jO_tZ_935a142d dqi(Class_kf_f68d320f class_kf_f68d320f) {
        this.ScNJe = class_kf_f68d320f;
        this.YAJPy = true;
        return this;
    }

    public Class_jO_tZ_935a142d dqq(float f) {
        this.vwICI = f;
        this.gBPCX = true;
        return this;
    }

    public Class_jO_tZ_935a142d dqn(boolean bl) {
        this.HXHff = bl;
        this.KOTFK = true;
        return this;
    }

    public Class_jO_tZ_935a142d dqc(Matrix3x2fStack matrix3x2fStack) {
        this.zqyMa = matrix3x2fStack;
        return this;
    }

    public Class_jO_tZ_935a142d dqf(float f) {
        this.GfHAw = f;
        return this;
    }

    public Class_jO_tZ_935a142d dqd(float f) {
        this.ViidM = f;
        return this;
    }

    public Class_jO_tZ_935a142d dqe(float f) {
        this.QEyRn = f;
        return this;
    }

    public Class_jO_tZ_935a142d dqg(float f) {
        this.UHtFB = f;
        return this;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jO_tZ_935a142d.class, "dqD", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

