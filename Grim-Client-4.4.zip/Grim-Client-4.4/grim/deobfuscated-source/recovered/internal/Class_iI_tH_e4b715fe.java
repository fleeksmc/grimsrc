/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.reflect.TypeToken
 */
package recovered.internal;

import com.google.common.reflect.TypeToken;
import java.util.Deque;

class Class_iI_tH_e4b715fe
extends TypeToken<Deque<Integer>> {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_iI_tH_e4b715fe() {
    }
}

