/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockState
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 */
package recovered.internal;

import com.google.gson.JsonElement;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mr_7eac5189;

public class Class_cK_54b0e25a
extends Class_cB_67aec11c {
    private Set<Item> NBjNm;
    private Set<Item> eAose;
    private int mnYah;
    private boolean nppnu;
    private static final long bQhZo = Class_gb_9d201141.aYR(-8797029917334817476L, -5087725111209576123L, MethodHandles.lookup().lookupClass()).a(262354789439710L);
    private static final long[] peAVW;
    private static final Integer[] RNZMo;
    private static final Map bjEhz;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cK_54b0e25a(Class_mr_7eac5189 class_mr_7eac5189) {
        long l = bQhZo ^ 0x2165C5BFB6F5L;
        super(class_mr_7eac5189);
        this.NBjNm = new LinkedHashSet<Item>();
        this.eAose = new LinkedHashSet<Item>();
        this.mnYah = (int)Class_cK_54b0e25a.Xj("o", (int)32104, (long)(0x50D7CF82A46FB97CL ^ l));
        this.nppnu = true;
    }

    public Class_cK_54b0e25a(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        bjEhz = new HashMap(13);
        long l = bQhZo ^ 0x7F6A299F80F9L;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "\u00ed\u00f2W\u00d8\u008f\"\u00eb\u00f9\u00c7\u00adD\u008d\u00d3\ni\u00a7";
        int n2 = "\u00ed\u00f2W\u00d8\u008f\"\u00eb\u00f9\u00c7\u00adD\u008d\u00d3\ni\u00a7".length();
        int n3 = 0;
        do {
            byte[] byArray3 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
            byte[] byArray4 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray4[0] & 0xFFL) << 56 | ((long)byArray4[1] & 0xFFL) << 48 | ((long)byArray4[2] & 0xFFL) << 40 | ((long)byArray4[3] & 0xFFL) << 32 | ((long)byArray4[4] & 0xFFL) << 24 | ((long)byArray4[5] & 0xFFL) << 16 | ((long)byArray4[6] & 0xFFL) << 8 | (long)byArray4[7] & 0xFFL;
        } while (n3 < n2);
        peAVW = lArray;
        RNZMo = new Integer[2];
    }

    public Class_cK_54b0e25a WS(boolean bl) {
        this.nppnu = bl;
        this.Xa(this.eAose, true);
        return this;
    }

    private static CallSite Xj(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cK_54b0e25a" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public Set<Item> WL() {
        return this.NBjNm;
    }

    private boolean Xa(Set<Item> set, boolean bl) {
        boolean bl2;
        boolean bl3;
        LinkedHashSet linkedHashSet;
        block8: {
            block9: {
                Item item;
                long l = bQhZo ^ 0x362BDD31C65AL;
                linkedHashSet = set.stream().filter(Objects::nonNull).filter(this.NBjNm::contains).collect(Collectors.toCollection(LinkedHashSet::new));
                bl3 = Class_cB_67aec11c.Vu();
                bl2 = bl;
                if (!bl3) {
                    if (bl2) {
                        this.Xb(linkedHashSet);
                    }
                    bl2 = this.nppnu;
                }
                if (bl3) break block8;
                if (bl2) break block9;
                bl2 = linkedHashSet.isEmpty();
                if (bl3) break block8;
                if (bl2 && (item = (Item)this.NBjNm.stream().findFirst().orElse(null)) != null) {
                    linkedHashSet.add(item);
                }
            }
            bl2 = linkedHashSet.equals(this.eAose);
        }
        if (!bl3) {
            if (bl2) {
                return false;
            }
            this.eAose.clear();
            this.eAose.addAll(linkedHashSet);
            bl2 = true;
        }
        return bl2;
    }

    public Class_cK_54b0e25a WO(Set<Item> set) {
        long l = bQhZo ^ 0x53E75E4ED52BL;
        boolean bl = Class_cB_67aec11c.Vt();
        LinkedHashSet<Item> linkedHashSet = set == null ? new LinkedHashSet<Item>() : new LinkedHashSet<Item>(set);
        Class_cK_54b0e25a class_cK_54b0e25a = this;
        if (bl) {
            if (class_cK_54b0e25a.Xa(linkedHashSet, true)) {
                this.Vk();
            }
            class_cK_54b0e25a = this;
        }
        return class_cK_54b0e25a;
    }

    public Class_cK_54b0e25a WQ() {
        long l = bQhZo ^ 0x89D517F20ADL;
        boolean bl = Class_cB_67aec11c.Vt();
        Class_cK_54b0e25a class_cK_54b0e25a = this;
        if (bl) {
            if (class_cK_54b0e25a.Xa(this.NBjNm, true)) {
                this.Vk();
            }
            class_cK_54b0e25a = this;
        }
        return class_cK_54b0e25a;
    }

    public Class_cK_54b0e25a WR(int n) {
        long l = bQhZo ^ 0x1A2CD48D03A5L;
        boolean bl = Class_cB_67aec11c.Vt();
        Object object = n;
        if (bl) {
            object = object <= 0 ? (Object)Class_cK_54b0e25a.Xj("o", (int)12788, (long)(0x364A08F5CD0EC0B1L ^ l)) : n;
        }
        this.mnYah = object;
        this.Xa(this.eAose, true);
        return this;
    }

    private static MatchException Xg(MatchException matchException) {
        return matchException;
    }

    @Override
    public void SS(JsonElement jsonElement) {
        block6: {
            Class_cK_54b0e25a class_cK_54b0e25a;
            block7: {
                long l = bQhZo ^ 0x280DA67BF764L;
                LinkedHashSet<Item> linkedHashSet = new LinkedHashSet<Item>();
                Iterator iterator = jsonElement.getAsJsonArray().iterator();
                boolean bl = Class_cB_67aec11c.Vu();
                while (iterator.hasNext()) {
                    JsonElement jsonElement2 = (JsonElement)iterator.next();
                    linkedHashSet.add(Item.byRawId((int)jsonElement2.getAsInt()));
                    if (!bl) {
                        if (!bl) continue;
                    }
                    break block6;
                }
                class_cK_54b0e25a = this;
                if (bl) break block7;
                if (!class_cK_54b0e25a.Xa(linkedHashSet, true)) break block6;
                class_cK_54b0e25a = this;
            }
            class_cK_54b0e25a.Vk();
        }
    }

    public Class_cK_54b0e25a WM(Set<Item> set) {
        long l = bQhZo ^ 0x35C805DA27D4L;
        boolean bl = Class_cB_67aec11c.Vt();
        this.NBjNm = set == null ? new LinkedHashSet<Item>() : new LinkedHashSet<Item>(set);
        Class_cK_54b0e25a class_cK_54b0e25a = this;
        if (bl) {
            if (class_cK_54b0e25a.Xa(this.eAose, true)) {
                this.Vk();
            }
            class_cK_54b0e25a = this;
        }
        return class_cK_54b0e25a;
    }

    public Class_cK_54b0e25a WK(Item ... itemArray) {
        return this.WM(Arrays.stream(itemArray).collect(Collectors.toCollection(LinkedHashSet::new)));
    }

    public Class_cK_54b0e25a WN(Item ... itemArray) {
        long l = bQhZo ^ 0xB63F203B379L;
        Set set = Arrays.stream(itemArray).collect(Collectors.toCollection(LinkedHashSet::new));
        boolean bl = Class_cB_67aec11c.Vu();
        Class_cK_54b0e25a class_cK_54b0e25a = this;
        if (!bl) {
            if (class_cK_54b0e25a.Xa(set, true)) {
                this.Vk();
            }
            class_cK_54b0e25a = this;
        }
        return class_cK_54b0e25a;
    }

    public Set<Item> WP() {
        return this.eAose;
    }

    private void Xb(LinkedHashSet<Item> linkedHashSet) {
        long l = bQhZo ^ 0x357510F727EEL;
        boolean bl = Class_cB_67aec11c.Vt();
        while (linkedHashSet.size() > this.mnYah) {
            Iterator iterator;
            Iterator iterator2 = iterator = linkedHashSet.iterator();
            if (bl) {
                if (!iterator2.hasNext()) {
                    return;
                }
                iterator.next();
                iterator2 = iterator;
            }
            iterator2.remove();
            if (bl) continue;
        }
    }

    private static int Xi(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_cK_54b0e25a.Xh(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static int Xh(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x2D2E;
        if (RNZMo[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = peAVW[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])bjEhz.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    bjEhz.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cK_54b0e25a", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_cK_54b0e25a.RNZMo[n2] = n3;
        }
        return RNZMo[n2];
    }

    public int Xc() {
        return this.mnYah;
    }

    public Class_cK_54b0e25a Xf(boolean bl) {
        this.nppnu = bl;
        return this;
    }

    public void WV(Item item) {
        block12: {
            Class_cK_54b0e25a class_cK_54b0e25a;
            block11: {
                boolean bl;
                block10: {
                    int n;
                    block9: {
                        long l = bQhZo ^ 0xFFFE5EBEF45L;
                        bl = Class_cB_67aec11c.Vu();
                        n = this.eAose.contains(item);
                        if (!bl) {
                            if (n == 0) {
                                return;
                            }
                            n = this.nppnu;
                        }
                        if (bl) break block9;
                        if (n != 0) break block10;
                        n = this.eAose.size();
                    }
                    if (n == 1) {
                        return;
                    }
                }
                LinkedHashSet<Item> linkedHashSet = new LinkedHashSet<Item>(this.eAose);
                linkedHashSet.remove(item);
                class_cK_54b0e25a = this;
                if (bl) break block11;
                if (!class_cK_54b0e25a.Xa(linkedHashSet, true)) break block12;
                class_cK_54b0e25a = this;
            }
            class_cK_54b0e25a.Vk();
        }
    }

    public boolean WY(Block block) {
        return this.eAose.contains(block.asItem());
    }

    public boolean WZ(BlockState blockState) {
        return this.eAose.contains(blockState.getBlock().asItem());
    }

    public Class_cK_54b0e25a WT() {
        this.mnYah = 1;
        this.nppnu = false;
        this.Xa(this.eAose, true);
        return this;
    }

    public boolean WW(Item item) {
        return this.eAose.contains(item);
    }

    public boolean WX(ItemStack itemStack) {
        return this.eAose.contains(itemStack.getItem());
    }

    public boolean Xd() {
        return this.nppnu;
    }

    public Class_cK_54b0e25a Xe(int n) {
        this.mnYah = n;
        return this;
    }

    public void WU(Item item) {
        block8: {
            Class_cK_54b0e25a class_cK_54b0e25a;
            block7: {
                boolean bl;
                block6: {
                    block4: {
                        boolean bl2;
                        block5: {
                            long l = bQhZo ^ 0x7AE6F10B7986L;
                            bl = Class_cB_67aec11c.Vt();
                            if (item == null) break block4;
                            bl2 = this.NBjNm.contains(item);
                            if (!bl) break block5;
                            if (!bl2) break block4;
                            bl2 = this.eAose.contains(item);
                        }
                        if (!bl2) break block6;
                    }
                    return;
                }
                LinkedHashSet<Item> linkedHashSet = new LinkedHashSet<Item>(this.eAose);
                linkedHashSet.add(item);
                class_cK_54b0e25a = this;
                if (!bl) break block7;
                if (!class_cK_54b0e25a.Xa(linkedHashSet, true)) break block8;
                class_cK_54b0e25a = this;
            }
            class_cK_54b0e25a.Vk();
        }
    }

    @Override
    public void SR(Map<String, Object> map) {
        Set set = this.eAose.stream().map(Item::getRawId).collect(Collectors.toSet());
        map.put(Arrays.toString(this.NwlSF), set);
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cK_54b0e25a.class, "Xi", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

