/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.ClientMain;
import recovered.core.NativeLoader;
import recovered.internal.Class_af_98bd07d0;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_am_1d88617e;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_iM_910cda2e;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mG_52c8d386;

public abstract class Class_aY_e9eaa44d
extends Class_aj_95d0a719 {
    int[] RigKG;
    Class_iM_910cda2e SpjTW;
    Class_am_1d88617e FaAqV;
    Class_af_98bd07d0 BZqcU;
    Class_af_98bd07d0 Uzust;
    Class_af_98bd07d0 RCCrz;
    private static String[] KHdFB;
    private static long jbWwp;
    private static String[] dfpPk;
    private static String[] mcgFu;
    private static Map ZKveJ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aY_e9eaa44d(float f, int[] nArray, Class_iM_910cda2e class_iM_910cda2e) {
        long l = jbWwp ^ 0x7B0FEAE802FAL;
        this.BcpIo = 290.0f;
        this.WjISQ = 165.0f;
        Class_lc_b8480f87 class_lc_b8480f87 = Class_bl_a15fbaa5.Ex().Ey();
        float f2 = class_lc_b8480f87.bXF() + Class_jf_d1c4f950.bAH(this.BcpIo, class_lc_b8480f87.bXH());
        float f3 = class_lc_b8480f87.bXG() + Class_jf_d1c4f950.bAH(this.WjISQ, class_lc_b8480f87.bXI());
        this.MCnYt = f2;
        this.pNyTQ = f3;
        this.IzFhM = f;
        this.FHbTC = true;
        this.RigKG = nArray;
        this.SpjTW = class_iM_910cda2e;
        this.FaAqV = (Class_am_1d88617e)new Class_am_1d88617e(class_iM_910cda2e.btw()).sX(65.0f, 110.0f);
        Class_ig_ca326427 class_ig_ca326427 = ClientMain.dlM().bjG();
        Class_mG_52c8d386 class_mG_52c8d386 = class_ig_ca326427.biq().cob(0.3f);
        this.BZqcU = (Class_af_98bd07d0)new Class_af_98bd07d0().nj(Class_ld_bb1690e1.all(3.0f)).nb(String.valueOf(class_iM_910cda2e.buh())).nd((String)((Object)Class_aY_e9eaa44d.Ag("m", (int)20158, (long)(0x4DD340F3BD2DB99CL ^ l)))).ni(class_mG_52c8d386).sX(65.0f, 40.0f);
        this.Uzust = (Class_af_98bd07d0)new Class_af_98bd07d0().nj(Class_ld_bb1690e1.all(3.0f)).nb(Class_jf_d1c4f950.bAT(class_iM_910cda2e.bul())).nd((String)((Object)Class_aY_e9eaa44d.Ag("m", (int)25030, (long)(0x577C7A8F88BC16E5L ^ l)))).ni(class_mG_52c8d386).sX(65.0f, 40.0f);
        this.RCCrz = (Class_af_98bd07d0)new Class_af_98bd07d0().nj(Class_ld_bb1690e1.all(3.0f)).nb(String.valueOf(class_iM_910cda2e.buj())).nd((String)((Object)Class_aY_e9eaa44d.Ag("m", (int)27983, (long)(0x1FE70F065CD41A6EL ^ l)))).ni(class_mG_52c8d386).sX(65.0f, 40.0f);
    }

    static {
        NativeLoader.doInit(Class_aY_e9eaa44d.class);
        Class_aY_e9eaa44d._4b4858161f15e00bdcc164d6c97f7d0d();
    }

    protected abstract void sv(Class_lC_5322e8cf var1);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean fC(double var1, double var3, double var5);

    private static native String Ae(int var0, long var1);

    public native Class_iM_910cda2e zU();

    public native int[] zT();

    public native Class_am_1d88617e zV();

    public native Class_af_98bd07d0 zW();

    private static native CallSite Ag(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native Class_af_98bd07d0 zX();

    public native Class_af_98bd07d0 zY();

    private native /* synthetic */ void zZ(Class_lC_5322e8cf var1);

    public static native void Aa(String[] var0);

    public static native String[] Ab();

    private static native MatchException Ac(MatchException var0);

    private static native String Ad(byte[] var0);

    private static native Object Af(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native void _4b4858161f15e00bdcc164d6c97f7d0d();
}

