/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

public final class Class_j_75349621
extends Enum<Class_j_75349621> {
    public static /* enum */ Class_j_75349621 LjCBS;
    public static /* enum */ Class_j_75349621 PWbEP;
    public static /* enum */ Class_j_75349621 EOvXB;
    public static /* enum */ Class_j_75349621 UtniR;
    private static /* synthetic */ Class_j_75349621[] HWPaj;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_j_75349621.class);
        Class_j_75349621._00cbc1ce29f702c3f3108560bc3d9d68();
    }

    public static native Class_j_75349621[] values();

    public static native Class_j_75349621 valueOf(String var0);

    private static native String bU(byte[] var0);

    private static native /* synthetic */ Class_j_75349621[] bT();

    private static native void _00cbc1ce29f702c3f3108560bc3d9d68();
}

