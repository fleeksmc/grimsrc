/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_hJ_a20df6c5;

public final class Class_hJ_tx_aa3012d6<T>
extends Record
implements Class_hJ_a20df6c5 {
    private final T value;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hJ_tx_aa3012d6(T t) {
        this.value = t;
    }

    static {
        NativeLoader.doInit(Class_hJ_tx_aa3012d6.class);
    }

    public native T value();

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();
}

