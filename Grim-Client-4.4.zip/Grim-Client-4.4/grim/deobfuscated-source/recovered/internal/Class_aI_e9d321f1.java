/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_od_f9118ebf;

public final class Class_aI_e9d321f1
extends Enum<Class_aI_e9d321f1> {
    public static final /* enum */ Class_aI_e9d321f1 JkFqu;
    public static final /* enum */ Class_aI_e9d321f1 OOZEg;
    public static final /* enum */ Class_aI_e9d321f1 PGwMP;
    public static final /* enum */ Class_aI_e9d321f1 ejRch;
    public static final /* enum */ Class_aI_e9d321f1 fhJit;
    public static final /* enum */ Class_aI_e9d321f1 MltoB;
    public static final /* enum */ Class_aI_e9d321f1 LYUHl;
    public static final /* enum */ Class_aI_e9d321f1 mMivt;
    private final Class_od_f9118ebf KPbhi;
    private static final /* synthetic */ Class_aI_e9d321f1[] ufWCI;
    private static final long oldYq;
    private static final long[] ToNoi;
    private static final Integer[] naBWA;
    private static final Map nSztn;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_aI_e9d321f1(Class_od_f9118ebf class_od_f9118ebf) {
        this.KPbhi = class_od_f9118ebf;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Class_aI_e9d321f1.oldYq = Class_gb_9d201141.aYR(2029796362745907490L, -873967833286070265L, MethodHandles.lookup().lookupClass()).a(36526231130882L);
                        var20 = Class_aI_e9d321f1.oldYq ^ 74037699898462L;
                        var12_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var20 >>> 56);
                        for (var13_2 = 1; var13_2 < 8; ++var13_2) {
                            v2 = v2;
                            v2[var13_2] = (byte)(var20 << var13_2 * 8 >>> 56);
                        }
                        var12_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var11_3 = new String[16];
                        var17_4 = 0;
                        var16_5 = "\u00c1c:\u00d4%\u00cb\u00b3\u00bc \u008d\u001a\u00c0&vC\u00db\u00c9eD\u009e\u007f-7U\u0010\u00c1c:\u00d4%\u00cb\u00b3\u00bc\u00ed\u00ec\u001f\u0091\u00ce\u000bD\u00f5\b\u000b(\u00ed\u00c3!\u00fb\u00ffq\b\u00cf\u00a9\u0016\u00ac\u009fot\u00d7\u0018\u00c1c:\u00d4%\u00cb\u00b3\u00bc:\u0002\u00bf\u00b7\u00ee?C\u001a\u00e8VR\u0088\rBzJ\b^Tdw\u008c2\u00a3\u00da\u0010\u00c1c:\u00d4%\u00cb\u00b3\u00bc\u00dd;@S\u00e0\u00ce\u0080\u0014\b\u00d9\u00fc\u0098\u00ddc\u00eb\u00f87\u0018\u00c1c:\u00d4%\u00cb\u00b3\u00bc\u00e8\u000fZYE\u00ff\u00fcT\u00de\u00c7#`<UK\u0003\u00107\u009b\u00d5t\u0016\u00c1F\u00ad\u00b3\u0005X\u0014\u00ed\u000b]\u00b8\b\u00de\u0018E$\u00fc\u00c1(\u00e2\bB\u00ca\u00cdS8\u00bb\u0017\u00db\u0018\u00c1c:\u00d4%\u00cb\u00b3\u00bc\u00cd;\u00aa\u00ce;TB\u00aea\u0018Q\u00dd\u00f0L\u00c2\u00d7\u0010\u00c1c:\u00d4%\u00cb\u00b3\u00bc\u001dz\u0086\u00f3\u00c9\u008d=\u00e6";
                        var18_6 = "\u00c1c:\u00d4%\u00cb\u00b3\u00bc \u008d\u001a\u00c0&vC\u00db\u00c9eD\u009e\u007f-7U\u0010\u00c1c:\u00d4%\u00cb\u00b3\u00bc\u00ed\u00ec\u001f\u0091\u00ce\u000bD\u00f5\b\u000b(\u00ed\u00c3!\u00fb\u00ffq\b\u00cf\u00a9\u0016\u00ac\u009fot\u00d7\u0018\u00c1c:\u00d4%\u00cb\u00b3\u00bc:\u0002\u00bf\u00b7\u00ee?C\u001a\u00e8VR\u0088\rBzJ\b^Tdw\u008c2\u00a3\u00da\u0010\u00c1c:\u00d4%\u00cb\u00b3\u00bc\u00dd;@S\u00e0\u00ce\u0080\u0014\b\u00d9\u00fc\u0098\u00ddc\u00eb\u00f87\u0018\u00c1c:\u00d4%\u00cb\u00b3\u00bc\u00e8\u000fZYE\u00ff\u00fcT\u00de\u00c7#`<UK\u0003\u00107\u009b\u00d5t\u0016\u00c1F\u00ad\u00b3\u0005X\u0014\u00ed\u000b]\u00b8\b\u00de\u0018E$\u00fc\u00c1(\u00e2\bB\u00ca\u00cdS8\u00bb\u0017\u00db\u0018\u00c1c:\u00d4%\u00cb\u00b3\u00bc\u00cd;\u00aa\u00ce;TB\u00aea\u0018Q\u00dd\u00f0L\u00c2\u00d7\u0010\u00c1c:\u00d4%\u00cb\u00b3\u00bc\u001dz\u0086\u00f3\u00c9\u008d=\u00e6".length();
                        var15_7 = 24;
                        var14_8 = -1;
lbl19:
                        // 2 sources

                        while (true) {
                            v3 = ++var14_8;
                            v4 = var16_5.substring(v3, v3 + var15_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl24:
                        // 1 sources

                        while (true) {
                            var11_3[var17_4++] = Class_aI_e9d321f1.wa(var19_9).intern();
                            if ((var14_8 += var15_7) < var18_6) {
                                var15_7 = var16_5.charAt(var14_8);
                                ** continue;
                            }
                            var16_5 = "\u00c1c:\u00d4%\u00cb\u00b3\u00bc\u0012M`\u00fb\u00e8\u00a1;\u0017\b\u001f\u00d9\u00d0\u00e9KJ\u0016\u001b";
                            var18_6 = "\u00c1c:\u00d4%\u00cb\u00b3\u00bc\u0012M`\u00fb\u00e8\u00a1;\u0017\b\u001f\u00d9\u00d0\u00e9KJ\u0016\u001b".length();
                            var15_7 = 16;
                            var14_8 = -1;
lbl33:
                            // 2 sources

                            while (true) {
                                v6 = ++var14_8;
                                v4 = var16_5.substring(v6, v6 + var15_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl38:
                        // 1 sources

                        while (true) {
                            var11_3[var17_4++] = Class_aI_e9d321f1.wa(var19_9).intern();
                            if ((var14_8 += var15_7) < var18_6) {
                                var15_7 = var16_5.charAt(var14_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var19_9 = var12_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl50:
                        // 1 sources

                        ** continue;
                    }
                }
                Class_aI_e9d321f1.nSztn = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var20 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var20 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[5];
                var3_13 = 0;
                var4_14 = "e_2\u0018\u00e5\u00c8W\u00ba\u009a\u001c)U5\u00ba\u00a1d&i9\u00f4qv\u00ea\u001b";
                var5_15 = "e_2\u0018\u00e5\u00c8W\u00ba\u009a\u001c)U5\u00ba\u00a1d&i9\u00f4qv\u00ea\u001b".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl75:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "z\u00d5h\u0013'\u00e4H\u00e0s-\u00c3\u00bb\u00da\u00c5\u0098\u00f6";
                    var5_15 = "z\u00d5h\u0013'\u00e4H\u00e0s-\u00c3\u00bb\u00da\u00c5\u0098\u00f6".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl88:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl101:
                // 1 sources

                ** continue;
            }
        }
        Class_aI_e9d321f1.ToNoi = var6_12;
        Class_aI_e9d321f1.naBWA = new Integer[5];
        Class_aI_e9d321f1.JkFqu = new Class_aI_e9d321f1(Class_od_f9118ebf.cBQ(var11_3[13]));
        Class_aI_e9d321f1.OOZEg = new Class_aI_e9d321f1(Class_od_f9118ebf.cBQ(var11_3[8]));
        Class_aI_e9d321f1.PGwMP = new Class_aI_e9d321f1(Class_od_f9118ebf.cBQ(var11_3[1]));
        Class_aI_e9d321f1.ejRch = new Class_aI_e9d321f1(Class_od_f9118ebf.cBQ(var11_3[0]));
        Class_aI_e9d321f1.fhJit = new Class_aI_e9d321f1(Class_od_f9118ebf.cBQ(var11_3[6]));
        Class_aI_e9d321f1.MltoB = new Class_aI_e9d321f1(Class_od_f9118ebf.cBQ(var11_3[12]));
        Class_aI_e9d321f1.LYUHl = new Class_aI_e9d321f1(Class_od_f9118ebf.cBQ(var11_3[4]));
        Class_aI_e9d321f1.mMivt = new Class_aI_e9d321f1(Class_od_f9118ebf.cBQ(var11_3[14]));
        Class_aI_e9d321f1.ufWCI = Class_aI_e9d321f1.vZ();
    }

    public static Class_aI_e9d321f1[] values() {
        return (Class_aI_e9d321f1[])ufWCI.clone();
    }

    public static Class_aI_e9d321f1 valueOf(String string) {
        return Enum.valueOf(Class_aI_e9d321f1.class, string);
    }

    private static int wc(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_aI_e9d321f1.wb(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static CallSite wd(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_aI_e9d321f1" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static String wa(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static int wb(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x450A;
        if (naBWA[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = ToNoi[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])nSztn.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    nSztn.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_aI_e9d321f1", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_aI_e9d321f1.naBWA[n2] = n3;
        }
        return naBWA[n2];
    }

    public Class_od_f9118ebf vY() {
        return this.KPbhi;
    }

    private static /* synthetic */ Class_aI_e9d321f1[] vZ() {
        long l = oldYq ^ 0x3308EB5E07A6L;
        Class_aI_e9d321f1[] class_aI_e9d321f1Array = new Class_aI_e9d321f1[Class_aI_e9d321f1.wd("w", (int)30910, (long)(0x6A39D7DFE934F52FL ^ l))];
        class_aI_e9d321f1Array[0] = JkFqu;
        class_aI_e9d321f1Array[1] = OOZEg;
        class_aI_e9d321f1Array[2] = PGwMP;
        class_aI_e9d321f1Array[3] = ejRch;
        class_aI_e9d321f1Array[4] = fhJit;
        class_aI_e9d321f1Array[5] = MltoB;
        class_aI_e9d321f1Array[Class_aI_e9d321f1.wd("w", (int)27632, (long)(0x3827B5D46218E663L ^ l))] = LYUHl;
        class_aI_e9d321f1Array[Class_aI_e9d321f1.wd("w", (int)14316, (long)(0x2861EBABCD85BA7CL ^ l))] = mMivt;
        return class_aI_e9d321f1Array;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_aI_e9d321f1.class, "wc", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

