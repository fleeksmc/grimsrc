/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;

public final class Class_kd_dfbdd90e
extends Enum<Class_kd_dfbdd90e> {
    public static final /* enum */ Class_kd_dfbdd90e AhlXN;
    public static final /* enum */ Class_kd_dfbdd90e sQVlR;
    public static final /* enum */ Class_kd_dfbdd90e IbNTv;
    private final int hYhDr;
    private static final /* synthetic */ Class_kd_dfbdd90e[] VeRTR;
    private static Class_iS_888f260e[] qESfC;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_kd_dfbdd90e(int n2) {
        this.hYhDr = n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = Class_gb_9d201141.aYR(-3065632304402411693L, -4551052499802911118L, MethodHandles.lookup().lookupClass()).a(7103219834343L) ^ 0x6AC63355FE12L;
        if (Class_kd_dfbdd90e.bOg() == null) {
            Class_kd_dfbdd90e.bOf(new Class_iS_888f260e[3]);
        }
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[3];
        int n = 0;
        String string = "A\u00bc\u00d4\n\u00e9\u0012\u008c,\u0019\u009b\u00f4\u00c2\u0084I\u0089\u00eb\u0010\u00e6\u0013\u009e*#\u00d5\u00b9\u009a}\u00cc\u0002\u00f2\u009a\u0080\u00cc\u001c\u00108\u00ca\u000f\u00f3\u00e1Z\u0011\u00c9\u00ef\u00ca\u00f4/c\u0081h\u0019";
        int n2 = "A\u00bc\u00d4\n\u00e9\u0012\u008c,\u0019\u009b\u00f4\u00c2\u0084I\u0089\u00eb\u0010\u00e6\u0013\u009e*#\u00d5\u00b9\u009a}\u00cc\u0002\u00f2\u009a\u0080\u00cc\u001c\u00108\u00ca\u000f\u00f3\u00e1Z\u0011\u00c9\u00ef\u00ca\u00f4/c\u0081h\u0019".length();
        int n3 = 16;
        int n4 = -1;
        while (true) {
            int n5 = ++n4;
            byte[] byArray3 = cipher.doFinal(string.substring(n5, n5 + n3).getBytes("ISO-8859-1"));
            stringArray[n++] = Class_kd_dfbdd90e.bOh(byArray3).intern();
            if ((n4 += n3) >= n2) {
                AhlXN = new Class_kd_dfbdd90e(0);
                sQVlR = new Class_kd_dfbdd90e(1);
                IbNTv = new Class_kd_dfbdd90e(2);
                VeRTR = Class_kd_dfbdd90e.bOe();
                return;
            }
            n3 = string.charAt(n4);
        }
    }

    public static Class_kd_dfbdd90e[] values() {
        return (Class_kd_dfbdd90e[])VeRTR.clone();
    }

    public static Class_kd_dfbdd90e valueOf(String string) {
        return Enum.valueOf(Class_kd_dfbdd90e.class, string);
    }

    private static /* synthetic */ Class_kd_dfbdd90e[] bOe() {
        return new Class_kd_dfbdd90e[]{AhlXN, sQVlR, IbNTv};
    }

    public static Class_iS_888f260e[] bOg() {
        return qESfC;
    }

    public static void bOf(Class_iS_888f260e[] class_iS_888f260eArray) {
        qESfC = class_iS_888f260eArray;
    }

    private static String bOh(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public int bOd() {
        return this.hYhDr;
    }
}

