/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 */
package recovered.internal;

import net.minecraft.client.util.math.MatrixStack;
import recovered.internal.Class_hH_ae8f8f77;

public abstract class Class_go_72b5d3a1
extends Class_hH_ae8f8f77 {
    private MatrixStack cLmrQ;
    private float smUoY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_go_72b5d3a1(MatrixStack matrixStack, float f) {
        this.cLmrQ = matrixStack;
        this.smUoY = f;
    }

    public MatrixStack bbh() {
        return this.cLmrQ;
    }

    public float bbi() {
        return this.smUoY;
    }
}

