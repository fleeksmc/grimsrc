/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

class Class_az_rU_d532d676 {
    static int[] xmlDG;
    static int[] WjdnF;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_az_rU_d532d676.class);
        Class_az_rU_d532d676._0dab8b099d33c9a6a17b61a3a90a48d6();
    }

    private static native void _0dab8b099d33c9a6a17b61a3a90a48d6();
}

