/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_gO_46ab3598;

public class Class_gO_tm_9eaa80c1
extends Class_gO_46ab3598 {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

