/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.Camera
 *  net.minecraft.client.render.state.CameraRenderState
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.util.math.RotationAxis
 *  net.minecraft.util.math.Vec2f
 *  net.minecraft.util.math.Vec3d
 *  org.joml.Matrix3x2fStack
 *  org.joml.Matrix3x2fc
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Quaternionfc
 *  org.joml.Vector4f
 *  org.jspecify.annotations.Nullable
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix3x2fc;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionfc;
import org.joml.Vector4f;
import org.jspecify.annotations.Nullable;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_jK_8ad0bed0;
import recovered.internal.Class_rm_d861be3b;

public class Class_jI_616cf0dd {
    private static Matrix4f BfOvs;
    private static Matrix4f GDhOW;
    private static Matrix4f ruTXP;
    private static final long PXtDs;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static MatchException bIz(MatchException matchException) {
        return matchException;
    }

    public static void bIt(MatrixStack matrixStack, double d) {
        matrixStack.translate(d, d, d);
    }

    public static MatrixStack bIm(Matrix3x2fc matrix3x2fc) {
        MatrixStack matrixStack = new MatrixStack();
        matrixStack.multiplyPositionMatrix((Matrix4fc)Class_jI_616cf0dd.bIl(matrix3x2fc));
        return matrixStack;
    }

    public static MatrixStack bIp(double d, double d2, double d3) {
        return Class_jI_616cf0dd.bIo(new Vec3d(d, d2, d3));
    }

    public static float bIy() {
        return Math.max((float)ClientMain.dlmvG.options.getClampedViewDistance() * 4.0f, 4.0f);
    }

    public static Matrix3x2fStack bIn(@Nullable Matrix3x2fc matrix3x2fc) {
        Matrix3x2fStack matrix3x2fStack;
        block0: {
            long l = PXtDs ^ 0x6071A34E4586L;
            matrix3x2fStack = new Matrix3x2fStack();
            if (matrix3x2fc == null) break block0;
            matrix3x2fStack.set(matrix3x2fc);
        }
        return matrix3x2fStack;
    }

    public static void bIv(MatrixStack matrixStack, float f, float f2, float f3, float f4) {
        matrixStack.translate(f, f2, f3);
        matrixStack.multiply((Quaternionfc)RotationAxis.POSITIVE_Z.rotationDegrees(f4));
        matrixStack.translate(-f, -f2, f3);
    }

    public static Matrix4f bIx(CameraRenderState cameraRenderState, float f) {
        return Class_jK_8ad0bed0.bIF(((Integer)ClientMain.dlmvG.options.getFov().getValue()).floatValue(), f, Class_jI_616cf0dd.bIy());
    }

    static {
        PXtDs = Class_gb_9d201141.aYR(704151637779864399L, -6002197135173590387L, MethodHandles.lookup().lookupClass()).a(135865284138013L);
        BfOvs = new Matrix4f();
        GDhOW = new Matrix4f();
        ruTXP = new Matrix4f();
    }

    public static void bIr(MatrixStack matrixStack) {
        Camera camera = ClientMain.dlmvG.gameRenderer.getCamera();
        Vec3d vec3d = camera.getCameraPos().negate();
        matrixStack.translate(vec3d.x, vec3d.y, vec3d.z);
    }

    public static void bIs(MatrixStack matrixStack, Vec3d vec3d) {
        Camera camera = ClientMain.dlmvG.gameRenderer.getCamera();
        Vec3d vec3d2 = camera.getCameraPos();
        Vec3d vec3d3 = vec3d.subtract(vec3d2);
        matrixStack.translate(vec3d3.x, vec3d3.y, vec3d3.z);
    }

    public static void bIj(Matrix4f matrix4f, Matrix4f matrix4f2, Matrix4f matrix4f3) {
        BfOvs = new Matrix4f((Matrix4fc)matrix4f);
        GDhOW = new Matrix4f((Matrix4fc)matrix4f2);
        ruTXP = new Matrix4f((Matrix4fc)matrix4f3);
    }

    public static Matrix4f bIl(Matrix3x2fc matrix3x2fc) {
        return new Matrix4f(matrix3x2fc.m00(), matrix3x2fc.m01(), 0.0f, 0.0f, matrix3x2fc.m10(), matrix3x2fc.m11(), 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, matrix3x2fc.m20(), matrix3x2fc.m21(), 0.0f, 1.0f);
    }

    public static MatrixStack bIo(Vec3d vec3d) {
        MatrixStack matrixStack;
        block0: {
            long l = PXtDs ^ 0x29772E792A2FL;
            matrixStack = new MatrixStack();
            String[] stringArray = Class_jH_c1172273.bIh();
            Camera camera = ClientMain.dlmvG.gameRenderer.getCamera();
            matrixStack.multiply((Quaternionfc)RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
            matrixStack.multiply((Quaternionfc)RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0f));
            Vec3d vec3d2 = vec3d.subtract(camera.getCameraPos());
            matrixStack.translate(vec3d2.x, vec3d2.y, vec3d2.z);
            String[] stringArray2 = stringArray;
            if (Class_iS_888f260e.bwL() != null) break block0;
            Class_jH_c1172273.bIg(new String[2]);
        }
        return matrixStack;
    }

    public static void bIu(MatrixStack matrixStack) {
        Camera camera = ClientMain.dlmvG.gameRenderer.getCamera();
        matrixStack.multiply((Quaternionfc)RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
        matrixStack.multiply((Quaternionfc)RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
    }

    public static void bIq(MatrixStack matrixStack) {
        Camera camera = ClientMain.dlmvG.gameRenderer.getCamera();
        matrixStack.multiply((Quaternionfc)camera.getRotation());
    }

    public static Vec2f bIw(Vec3d vec3d) {
        Vec2f vec2f;
        block2: {
            long l = PXtDs ^ 0x49BDF9D1599DL;
            Camera camera = ClientMain.dlmvG.gameRenderer.getCamera();
            String[] stringArray = Class_jH_c1172273.bIh();
            Vec3d vec3d2 = camera.getCameraPos();
            float f = (float)(vec3d.x - vec3d2.x);
            float f2 = (float)(vec3d.y - vec3d2.y);
            float f3 = (float)(vec3d.z - vec3d2.z);
            Vector4f vector4f = new Vector4f(f, f2, f3, 1.0f);
            vector4f.mul((Matrix4fc)ruTXP).mul((Matrix4fc)BfOvs).mul((Matrix4fc)GDhOW);
            Vector4f vector4f2 = vector4f;
            if (stringArray == null) {
                if (vector4f2.w <= 0.0f) {
                    return null;
                }
                vector4f2 = vector4f.div(vector4f.w);
            }
            Vector4f vector4f3 = vector4f2;
            Vec2f vec2f2 = Class_rm_d861be3b.dip();
            float f4 = (vector4f3.x + 1.0f) / 2.0f * vec2f2.x;
            float f5 = (1.0f - vector4f3.y) / 2.0f * vec2f2.y;
            vec2f = new Vec2f(f4, f5);
            if (stringArray == null) break block2;
            Class_iS_888f260e.bwK("TXQKec");
        }
        return vec2f;
    }

    public static Matrix4f bIk() {
        return new Matrix4f((Matrix4fc)GDhOW);
    }
}

