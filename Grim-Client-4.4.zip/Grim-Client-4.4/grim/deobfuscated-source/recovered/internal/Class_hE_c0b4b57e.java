/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;

public class Class_hE_c0b4b57e
extends Class_hH_ae8f8f77 {
    private final char koOia;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hE_c0b4b57e(char c) {
        this.koOia = c;
    }

    public char bdG() {
        return this.koOia;
    }
}

