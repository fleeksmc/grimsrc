/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_kb_995b2295;
import recovered.internal.Class_lc_b8480f87;

public interface Class_kh_19daf527<T> {
    public static final Class_kb_995b2295 FroVm = new Class_kb_995b2295();

    public void render(T var1);

    default public Class_lc_b8480f87 expandBySmoothness(float f, float f2, float f3, float f4, float f5) {
        float f6 = f5 * 1.5f;
        return new Class_lc_b8480f87(f - f6 * 0.5f, f2 - f6 * 0.5f, f3 + f6, f4 + f6);
    }
}

