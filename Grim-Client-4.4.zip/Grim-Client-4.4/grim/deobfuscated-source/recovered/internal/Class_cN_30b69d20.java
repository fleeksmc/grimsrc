/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import recovered.internal.Class_cM_7a9de181;
import recovered.internal.Class_cO_0438f88e;
import recovered.internal.Class_mZ_07f59a29;

public class Class_cN_30b69d20 {
    public static Queue<Class_cO_0438f88e> YyPjC = new ConcurrentLinkedQueue<Class_cO_0438f88e>();
    private static int LtlqA;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        Class_cN_30b69d20.XR(0);
    }

    public static void XI(String string) {
        YyPjC.add(new Class_cO_0438f88e(Class_mZ_07f59a29.csh(string), Class_cM_7a9de181.WCwDP));
    }

    public static void XF(int[] nArray) {
        YyPjC.add(new Class_cO_0438f88e(nArray, Class_cM_7a9de181.MENWL));
    }

    public static void XK(int[] nArray) {
        YyPjC.add(new Class_cO_0438f88e(nArray, Class_cM_7a9de181.dzTse));
    }

    public static void XH(int[] nArray) {
        YyPjC.add(new Class_cO_0438f88e(nArray, Class_cM_7a9de181.WCwDP));
    }

    public static void XM(String string, String string2) {
        YyPjC.add(new Class_cO_0438f88e(Class_mZ_07f59a29.csh(string), Class_mZ_07f59a29.csh(string2), Class_cM_7a9de181.MENWL));
    }

    public static void XN(int[] nArray, int[] nArray2) {
        YyPjC.add(new Class_cO_0438f88e(nArray, nArray2, Class_cM_7a9de181.WCwDP));
    }

    public static void XO(String string, String string2) {
        YyPjC.add(new Class_cO_0438f88e(Class_mZ_07f59a29.csh(string), Class_mZ_07f59a29.csh(string2), Class_cM_7a9de181.WCwDP));
    }

    public static void XL(int[] nArray, int[] nArray2) {
        YyPjC.add(new Class_cO_0438f88e(nArray, nArray2, Class_cM_7a9de181.MENWL));
    }

    public static void XP(int[] nArray, int[] nArray2) {
        YyPjC.add(new Class_cO_0438f88e(nArray, nArray2, Class_cM_7a9de181.dzTse));
    }

    private static MatchException XU(MatchException matchException) {
        return matchException;
    }

    public static void XQ(String string, String string2) {
        YyPjC.add(new Class_cO_0438f88e(Class_mZ_07f59a29.csh(string), Class_mZ_07f59a29.csh(string2), Class_cM_7a9de181.dzTse));
    }

    public static void XJ(String string) {
        YyPjC.add(new Class_cO_0438f88e(Class_mZ_07f59a29.csh(string), Class_cM_7a9de181.dzTse));
    }

    public static void XG(String string) {
        YyPjC.add(new Class_cO_0438f88e(Class_mZ_07f59a29.csh(string), Class_cM_7a9de181.MENWL));
    }

    public static void XR(int n) {
        LtlqA = n;
    }

    public static int XS() {
        return LtlqA;
    }

    public static int XT() {
        int n = Class_cN_30b69d20.XS();
        if (n == 0) {
            return 67;
        }
        return 0;
    }
}

