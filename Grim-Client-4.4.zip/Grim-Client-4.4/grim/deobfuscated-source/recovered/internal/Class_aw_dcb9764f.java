/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screen.Screen
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.util.Iterator;
import net.minecraft.client.gui.screen.Screen;
import recovered.core.ClientMain;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_ap_f3b7a87f;
import recovered.internal.Class_ay_c070a086;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_g_bd7b3df3;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_k_759fe111;

public interface Class_aw_dcb9764f {
    public static final long WbltW = Class_gb_9d201141.aYR(5997638455782309412L, 2626269204656746336L, MethodHandles.lookup().lookupClass()).a(58560763372423L);

    private static MatchException a(MatchException matchException) {
        return matchException;
    }

    default public boolean closing() {
        return false;
    }

    public Class_g_bd7b3df3 manager();

    public static boolean route(Class_ap_f3b7a87f class_ap_f3b7a87f) {
        long l = WbltW ^ 0x5ADBBF885DEDL;
        Screen screen = ClientMain.dlmvG.currentScreen;
        String string = Class_az_a4990dcf.tE();
        boolean bl = screen instanceof Class_aw_dcb9764f;
        if (string != null) {
            if (bl) {
                Class_aw_dcb9764f class_aw_dcb9764f = (Class_aw_dcb9764f)screen;
                class_aw_dcb9764f.addPopup(class_ap_f3b7a87f);
                return true;
            }
            bl = false;
        }
        return bl;
    }

    public static boolean route(Class_k_759fe111 class_k_759fe111) {
        long l = WbltW ^ 0x471B0693C4ACL;
        Screen screen = ClientMain.dlmvG.currentScreen;
        String string = Class_az_a4990dcf.tE();
        boolean bl = screen instanceof Class_aw_dcb9764f;
        if (string != null) {
            if (bl) {
                Class_aw_dcb9764f class_aw_dcb9764f = (Class_aw_dcb9764f)screen;
                class_k_759fe111.cB(Class_ay_c070a086.ss());
                class_aw_dcb9764f.addTooltip(class_k_759fe111);
                return true;
            }
            bl = false;
        }
        return bl;
    }

    public static boolean route(Class_aj_95d0a719 class_aj_95d0a719) {
        long l = WbltW ^ 0x30FDD16B6B54L;
        Screen screen = ClientMain.dlmvG.currentScreen;
        String string = Class_az_a4990dcf.tE();
        boolean bl = screen instanceof Class_aw_dcb9764f;
        if (string != null) {
            if (bl) {
                Class_aw_dcb9764f class_aw_dcb9764f = (Class_aw_dcb9764f)screen;
                class_aw_dcb9764f.addPopupComponent(class_aj_95d0a719);
                return true;
            }
            bl = false;
        }
        return bl;
    }

    default public void addOverlay(Class_aj_95d0a719 class_aj_95d0a719) {
        this.addPopupComponent(class_aj_95d0a719);
    }

    default public void addOverlay(Class_aj_95d0a719 class_aj_95d0a719, boolean bl) {
        this.addOverlay(class_aj_95d0a719);
    }

    public void addTooltip(Class_k_759fe111 var1);

    public void addPopup(Class_ap_f3b7a87f var1);

    default public Object hoveredRoot(Iterable<? extends Class_az_a4990dcf> iterable, double d, double d2) {
        long l = WbltW ^ 0x2DF747E1A9BAL;
        Iterator<? extends Class_az_a4990dcf> iterator = iterable.iterator();
        String string = Class_az_a4990dcf.tE();
        while (iterator.hasNext()) {
            block4: {
                Class_az_a4990dcf class_az_a4990dcf;
                block3: {
                    Class_az_a4990dcf class_az_a4990dcf2;
                    class_az_a4990dcf = class_az_a4990dcf2 = iterator.next();
                    if (string == null) break block3;
                    if (!class_az_a4990dcf.tg(d, d2)) break block4;
                    class_az_a4990dcf = class_az_a4990dcf2;
                }
                return class_az_a4990dcf;
            }
            if (string != null) continue;
        }
        return null;
    }

    public static boolean routeOverlay(Class_aj_95d0a719 class_aj_95d0a719, boolean bl) {
        long l = WbltW ^ 0x42E5A632D4C8L;
        Screen screen = ClientMain.dlmvG.currentScreen;
        String string = Class_az_a4990dcf.tE();
        boolean bl2 = screen instanceof Class_aw_dcb9764f;
        if (string != null) {
            if (bl2) {
                Class_aw_dcb9764f class_aw_dcb9764f = (Class_aw_dcb9764f)screen;
                class_aw_dcb9764f.addOverlay(class_aj_95d0a719, bl);
                return true;
            }
            bl2 = false;
        }
        return bl2;
    }

    public void addPopupComponent(Class_aj_95d0a719 var1);
}

