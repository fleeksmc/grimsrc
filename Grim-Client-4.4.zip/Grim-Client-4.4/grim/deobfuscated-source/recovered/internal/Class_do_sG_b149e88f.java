/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.entity.Entity;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_kG_82f650e3;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lG_79349165;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.modules.AmbienceModule;

class Class_do_sG_b149e88f {
    private final Entity ZaYMC;
    private boolean hkzUL;
    private final Class_rk_bf8630d1 zzzOY;
    private static final long yWgTa = Class_gb_9d201141.aYR(6292795855422193390L, 741134432073114025L, MethodHandles.lookup().lookupClass()).a(62048899624806L);
    private static final long dEIfC;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_do_sG_b149e88f(Entity entity) {
        long l = yWgTa ^ 0x1B91BCF2CC66L;
        this.hkzUL = false;
        this.zzzOY = new Class_rk_bf8630d1((int)dEIfC).dhs(Class_rj_b691f4f7.XzDkv);
        this.ZaYMC = entity;
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = yWgTa ^ 0x2B454819E891L;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                long l2 = 7637147985002929944L;
                byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
                dEIfC = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    private static MatchException doO(MatchException matchException) {
        return matchException;
    }

    public void doM(Class_lC_5322e8cf class_lC_5322e8cf, float f, float f2, float f3, Class_mG_52c8d386 class_mG_52c8d386) {
        long l = yWgTa ^ 0x2EF2F6D0494AL;
        Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
        boolean bl = this.hkzUL;
        if (class_iS_888f260eArray == null) {
            bl = !bl;
        }
        this.zzzOY.dhc(bl);
        float f4 = this.zzzOY.dhj();
        Class_mG_52c8d386 class_mG_52c8d3862 = class_mG_52c8d386.cob(f4);
        float f5 = 30.0f - 30.0f * f4;
        Class_lG_79349165.XSRvt.bUH(Class_kG_82f650e3.bTw(class_lC_5322e8cf.cfc(), f - f3 / 2.0f, f2 - f5, 0.0, f3, f3).dtF(class_mG_52c8d3862).dtG());
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean doN() {
        long l = yWgTa ^ 0x4961D9DF9F4AL;
        Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
        boolean bl = this.hkzUL;
        if (class_iS_888f260eArray == null) {
            if (!bl) return false;
            float f = this.zzzOY.dhj() - 0.0f;
            bl = f == 0.0f ? 0 : (f > 0.0f ? 1 : -1);
        }
        if (class_iS_888f260eArray != null) return bl;
        if (bl) return false;
        return true;
    }
}

