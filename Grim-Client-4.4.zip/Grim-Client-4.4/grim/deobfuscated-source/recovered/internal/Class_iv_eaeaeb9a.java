/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import recovered.core.NativeLoader;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_it_6213c445;
import recovered.internal.Class_iu_bf2db566;

public class Class_iv_eaeaeb9a {
    private final Class_it_6213c445 QSnra;
    private volatile Class_iu_bf2db566 iMNtZ;
    private final CopyOnWriteArrayList<Runnable> YBBgC;
    private static String FjYKk;
    private static long bvKIY;
    private static String lrwfu;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_iv_eaeaeb9a(Class_it_6213c445 class_it_6213c445) {
        long l = bvKIY ^ 0x5E2190696D9CL;
        String string = Class_iv_eaeaeb9a.bnQ();
        String string2 = string;
        try {
            this.YBBgC = new CopyOnWriteArrayList();
            this.QSnra = class_it_6213c445;
            if (string2 == null) {
                Class_iS_888f260e.bwK("IwRUt");
            }
        }
        catch (MatchException matchException) {
            throw Class_iv_eaeaeb9a.bnR(matchException);
        }
    }

    static {
        NativeLoader.doInit(Class_iv_eaeaeb9a.class);
        Class_iv_eaeaeb9a._1c48381a34d1c5da094b65381060527d();
    }

    public static native void bnP(String var0);

    public static native String bnQ();

    private static native /* synthetic */ Class_iu_bf2db566 bnN(Throwable var0);

    private native void bnJ();

    private static native MatchException bnR(MatchException var0);

    public native void bnI(Runnable var1);

    private native /* synthetic */ Class_iu_bf2db566 bnO(Class_iu_bf2db566 var1);

    public native void bnK(Class_iu_bf2db566 var1);

    public native CompletableFuture<Class_iu_bf2db566> bnL();

    private static native String bnS(byte[] var0);

    public native Class_iu_bf2db566 bnM();

    private static native void _1c48381a34d1c5da094b65381060527d();
}

