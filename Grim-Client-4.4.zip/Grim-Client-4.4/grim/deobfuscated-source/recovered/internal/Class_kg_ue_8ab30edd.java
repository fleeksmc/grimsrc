/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;

final class Class_kg_ue_8ab30edd
extends Enum<Class_kg_ue_8ab30edd> {
    public static final /* enum */ Class_kg_ue_8ab30edd ubqbG;
    public static final /* enum */ Class_kg_ue_8ab30edd risei;
    public static final /* enum */ Class_kg_ue_8ab30edd KXgXu;
    private static final Class_kg_ue_8ab30edd[] KnqDP;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static String dsv(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = Class_gb_9d201141.aYR(-4143980138689717270L, 8557271582994429577L, MethodHandles.lookup().lookupClass()).a(246127802278549L) ^ 0x2B9ADF4753BFL;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[3];
        int n = 0;
        String string = "\u000f\u000f\u00f1\u0019\u00d8|a\u009b\b8\u0094\u001a\u00ba\u00cb\u00e5\u0016n\b\u00c1\u00a2\u00f1\u00eb\u00c0Xs\u0095";
        int n2 = "\u000f\u000f\u00f1\u0019\u00d8|a\u009b\b8\u0094\u001a\u00ba\u00cb\u00e5\u0016n\b\u00c1\u00a2\u00f1\u00eb\u00c0Xs\u0095".length();
        int n3 = 8;
        int n4 = -1;
        while (true) {
            int n5 = ++n4;
            byte[] byArray3 = cipher.doFinal(string.substring(n5, n5 + n3).getBytes("ISO-8859-1"));
            stringArray[n++] = Class_kg_ue_8ab30edd.dsv(byArray3).intern();
            if ((n4 += n3) >= n2) {
                ubqbG = new Class_kg_ue_8ab30edd();
                risei = new Class_kg_ue_8ab30edd();
                KXgXu = new Class_kg_ue_8ab30edd();
                KnqDP = Class_kg_ue_8ab30edd.dsu();
                return;
            }
            n3 = string.charAt(n4);
        }
    }

    public static Class_kg_ue_8ab30edd[] values() {
        return (Class_kg_ue_8ab30edd[])KnqDP.clone();
    }

    public static Class_kg_ue_8ab30edd valueOf(String string) {
        return Enum.valueOf(Class_kg_ue_8ab30edd.class, string);
    }

    private static Class_kg_ue_8ab30edd[] dsu() {
        return new Class_kg_ue_8ab30edd[]{ubqbG, risei, KXgXu};
    }
}

