/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.ClientMain;
import recovered.core.NativeLoader;
import recovered.internal.Class_aa_5f3e46cf;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_ab_035d8734
extends Class_az_a4990dcf {
    private final Class_rk_bf8630d1 fIMlO;
    private final Class_rk_bf8630d1 IMZfY;
    private Class_mG_52c8d386 ffdLg;
    private Class_mG_52c8d386 BiXTn;
    private final Class_ri_288534d5 hEOCR;
    private Class_aa_5f3e46cf xkYOr;
    private boolean GgyNW;
    private static long CZTRF;
    private static long[] UPBXc;
    private static Integer[] OtpWj;
    private static Map uQDgA;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ab_035d8734(boolean bl) {
        Class_mG_52c8d386 class_mG_52c8d386;
        CallSite callSite;
        Class_ri_288534d5 class_ri_288534d5;
        Class_ri_288534d5 class_ri_288534d52;
        long l = CZTRF ^ 0x384C44EC619CL;
        this.fIMlO = new Class_rk_bf8630d1((int)Class_ab_035d8734.ln("g", (int)3284, (long)(0x33F0F06FC27CF97EL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.IMZfY = new Class_rk_bf8630d1((int)Class_ab_035d8734.ln("g", (int)19452, (long)(0x6AE7B3645AF3E57L ^ l))).dhs(Class_rj_b691f4f7.XzDkv);
        this.GgyNW = bl;
        this.BcpIo = 15.0f;
        this.WjISQ = 8.0f;
        Class_ig_ca326427 class_ig_ca326427 = ClientMain.dlM().bjG();
        try {
            Class_ri_288534d5 class_ri_288534d53;
            this.ffdLg = class_ig_ca326427.bir();
            this.BiXTn = class_ig_ca326427.bis();
            Class_ab_035d8734 class_ab_035d8734 = this;
            class_ri_288534d52 = class_ri_288534d53;
            class_ri_288534d5 = class_ri_288534d53;
            callSite = Class_ab_035d8734.ln("g", (int)19452, (long)(0x6AE7B3645AF3E57L ^ l));
            class_mG_52c8d386 = bl ? this.BiXTn : this.ffdLg;
        }
        catch (MatchException matchException) {
            throw Class_ab_035d8734.lk(matchException);
        }
        class_ri_288534d52((int)callSite, class_mG_52c8d386);
        class_ab_035d8734.hEOCR = class_ri_288534d5.dfW(Class_rj_b691f4f7.UPXqT);
    }

    static {
        NativeLoader.doInit(Class_ab_035d8734.class);
        Class_ab_035d8734._b631bee9f62e8bc7f2a74f5399522219();
    }

    public native Class_ri_288534d5 ld();

    public native boolean lf();

    @Override
    public native float dn();

    public native Class_aa_5f3e46cf le();

    private static native CallSite ln(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native Class_mG_52c8d386 lc();

    public native Class_ab_035d8734 li(Class_aa_5f3e46cf var1);

    private static native MatchException lk(MatchException var0);

    public native Class_mG_52c8d386 lb();

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    public native Class_ab_035d8734 lg(Class_mG_52c8d386 var1);

    public native Class_rk_bf8630d1 la();

    public native Class_ab_035d8734 lh(Class_mG_52c8d386 var1);

    private static native int lm(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    @Override
    public native float kN();

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private static native int ll(int var0, long var1);

    private static native void _b631bee9f62e8bc7f2a74f5399522219();

    public native Class_rk_bf8630d1 kZ();

    public native Class_ab_035d8734 lj(boolean var1);
}

