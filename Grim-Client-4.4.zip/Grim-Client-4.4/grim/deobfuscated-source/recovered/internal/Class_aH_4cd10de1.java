/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_aG_2c81b041;
import recovered.internal.Class_aI_e9d321f1;
import recovered.internal.Class_aJ_1c28c0cb;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_ly_4fa08cac;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_aH_4cd10de1
extends Class_az_a4990dcf {
    private Class_aJ_1c28c0cb EUggH;
    private Class_aI_e9d321f1 mLpVD;
    private Class_aG_2c81b041 VQXjm;
    private Class_ly_4fa08cac KGwHJ;
    private Class_rk_bf8630d1 fvYpk;
    private boolean WZTtS;
    private static final long VPJAH = Class_gb_9d201141.aYR(-3229573293973007931L, -8764105840300668402L, MethodHandles.lookup().lookupClass()).a(102772226970044L);
    private static final long YuHPh;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aH_4cd10de1(Class_aJ_1c28c0cb class_aJ_1c28c0cb, Class_aI_e9d321f1 class_aI_e9d321f1) {
        long l = VPJAH ^ 0x670B1987C2C5L;
        this.fvYpk = new Class_rk_bf8630d1((int)YuHPh).dhs(Class_rj_b691f4f7.XzDkv);
        this.EUggH = class_aJ_1c28c0cb;
        this.mLpVD = class_aI_e9d321f1;
        this.KGwHJ = new Class_ly_4fa08cac(class_aI_e9d321f1.vY());
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = VPJAH ^ 0x2D5BA197088CL;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                long l2 = 585617301487581928L;
                byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
                YuHPh = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l << n * 8 >>> 56);
            ++n;
        }
    }

    @Override
    public boolean dk(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        boolean bl;
        block5: {
            block6: {
                Class_aH_4cd10de1 class_aH_4cd10de1;
                String[] stringArray;
                block7: {
                    block8: {
                        block11: {
                            Class_aG_2c81b041 class_aG_2c81b041;
                            block9: {
                                Class_aJ_1c28c0cb class_aJ_1c28c0cb;
                                block10: {
                                    long l = VPJAH ^ 0x3A6454603567L;
                                    stringArray = Class_aJ_1c28c0cb.wv();
                                    bl = this.th(d, d2, this.EUggH.tr() + this.MCnYt, this.EUggH.ts() + this.pNyTQ, this.BcpIo, this.WjISQ);
                                    if (stringArray != null) break block5;
                                    if (!bl) break block6;
                                    class_aJ_1c28c0cb = Class_bl_a15fbaa5.Ex().EB();
                                    class_aH_4cd10de1 = class_aJ_1c28c0cb.wq();
                                    if (stringArray != null) break block7;
                                    if (class_aH_4cd10de1 == this) break block8;
                                    class_aG_2c81b041 = this.VQXjm;
                                    if (stringArray != null) break block9;
                                    if (class_aG_2c81b041 != null) break block10;
                                    class_aJ_1c28c0cb.wf(this);
                                    if (stringArray == null) break block11;
                                }
                                class_aJ_1c28c0cb.wg(this);
                                class_aG_2c81b041 = this.VQXjm;
                            }
                            class_aG_2c81b041.run(this);
                        }
                        this.KGwHJ.ccz();
                    }
                    class_aH_4cd10de1 = this;
                }
                boolean bl2 = class_aH_4cd10de1.KGwHJ.ccp();
                if (stringArray == null) {
                    if (bl2) {
                        this.KGwHJ.cco();
                    }
                    bl2 = true;
                }
                return bl2;
            }
            bl = super.dk(d, d2, class_mA_32d8a5f2);
        }
        return bl;
    }

    @Override
    protected void bV(Class_lC_5322e8cf class_lC_5322e8cf) {
        long l = VPJAH ^ 0x67F19CC9E1A3L;
        Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
        boolean bl = Class_bl_a15fbaa5.Ex().EB().wq() == this;
        this.fvYpk.dhc(bl);
        float f = Math.min(1.0f, Class_bl_a15fbaa5.Ex().sj().dhj());
        Class_mG_52c8d386 class_mG_52c8d386 = this.CtPwV.bjf().coa(255.0f * this.fvYpk.dhj()).cob(f);
        Class_mG_52c8d386 class_mG_52c8d3862 = this.CtPwV.bjb().coa(255.0f * f);
        class_lC_5322e8cf.cdm(this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ, 10.0f, Class_ld_bb1690e1.all(4.0f), class_mG_52c8d386);
        float f2 = this.MCnYt + 5.0f;
        float f3 = this.pNyTQ + Class_jf_d1c4f950.bAH(this.KGwHJ.dn(), this.WjISQ);
        this.KGwHJ.sW(f2, f3);
        this.KGwHJ.su(class_lC_5322e8cf);
        float f4 = this.KGwHJ.tc() + 5.0f;
        float f5 = this.KGwHJ.ts() + Class_jf_d1c4f950.bAH(class_lq_87a74641.cat(), this.KGwHJ.dn());
        class_lC_5322e8cf.cez(class_lq_87a74641, Class_jf_d1c4f950.bAL(this.mLpVD.name()), f4, f5, class_mG_52c8d3862);
    }

    public Class_aH_4cd10de1 vU(Class_ly_4fa08cac class_ly_4fa08cac) {
        this.KGwHJ = class_ly_4fa08cac;
        return this;
    }

    public Class_aG_2c81b041 vN() {
        return this.VQXjm;
    }

    public Class_aH_4cd10de1 vV(Class_rk_bf8630d1 class_rk_bf8630d1) {
        this.fvYpk = class_rk_bf8630d1;
        return this;
    }

    public Class_aH_4cd10de1 vT(Class_aG_2c81b041 class_aG_2c81b041) {
        this.VQXjm = class_aG_2c81b041;
        return this;
    }

    public Class_aI_e9d321f1 vM() {
        return this.mLpVD;
    }

    public Class_rk_bf8630d1 vP() {
        return this.fvYpk;
    }

    public Class_aH_4cd10de1 vW(boolean bl) {
        this.WZTtS = bl;
        return this;
    }

    private static MatchException vX(MatchException matchException) {
        return matchException;
    }

    public Class_ly_4fa08cac vO() {
        return this.KGwHJ;
    }

    public Class_aJ_1c28c0cb vL() {
        return this.EUggH;
    }

    public boolean vQ() {
        return this.WZTtS;
    }

    public Class_aH_4cd10de1 vR(Class_aJ_1c28c0cb class_aJ_1c28c0cb) {
        this.EUggH = class_aJ_1c28c0cb;
        return this;
    }

    public Class_aH_4cd10de1 vS(Class_aI_e9d321f1 class_aI_e9d321f1) {
        this.mLpVD = class_aI_e9d321f1;
        return this;
    }
}

