/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Collection;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.util.math.Vec2f;
import recovered.core.ClientMain;
import recovered.core.NativeLoader;
import recovered.internal.Class_Q_88b47dba;
import recovered.internal.Class_ac_rM_8a33ea18;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_ap_f3b7a87f;
import recovered.internal.Class_av_ffcf74a1;
import recovered.internal.Class_aw_dcb9764f;
import recovered.internal.Class_b_cd9d9ee6;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_cC_14ef8bb5;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_cL_ccb21d14;
import recovered.internal.Class_c_rE_c9f44d07;
import recovered.internal.Class_cy_687dcdb6;
import recovered.internal.Class_d_c860402f;
import recovered.internal.Class_g_bd7b3df3;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_in_57efefb0;
import recovered.internal.Class_k_759fe111;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mr_7eac5189;

public class Class_c_b33cdc52
extends Class_av_ffcf74a1
implements Class_aw_dcb9764f {
    private static Class_c_b33cdc52 MGKQD;
    private final Class_g_bd7b3df3 OOoLn;
    private final Class_ap_f3b7a87f KvjMc;
    private final Class_ap_f3b7a87f EknuQ;
    private final Class_ap_f3b7a87f ItmaE;
    private final Class_ap_f3b7a87f cJonW;
    private final Class_ap_f3b7a87f uFsRc;
    private final Class_d_c860402f TPXYP;
    private final Class_d_c860402f OPcaS;
    private final Class_iS_888f260e pXzKY;
    private final Class_cJ_2ae1a557 BbgWr;
    private final Class_cC_14ef8bb5 ayNwz;
    private final Class_cJ_2ae1a557 ugpZM;
    private final Class_cJ_2ae1a557 KDIPU;
    private final Class_cJ_2ae1a557 kYwHO;
    private final Class_iS_888f260e ReKgb;
    private final Class_cL_ccb21d14 lOVKq;
    private Class_in_57efefb0 BVqbK;
    private boolean RtXXb;
    private static boolean rYxNo;
    private static long aEFGH;
    private static String[] oLZGs;
    private static String[] NjfvR;
    private static Map IjHGR;
    private static long[] LPQVU;
    private static Integer[] RxnRu;
    private static Map dmLYJ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native void _4f84036bfae9883b4cc5c5a67d6c2a06();

    private static native int O(int var0, long var1);

    public Class_c_b33cdc52() {
        block4: {
            boolean bl;
            block6: {
                block5: {
                    long l = aEFGH ^ 0x189FFA3C1A67L;
                    this.OOoLn = new Class_g_bd7b3df3();
                    this.KvjMc = (Class_ap_f3b7a87f)new Class_ap_f3b7a87f().pW((String)((Object)Class_c_b33cdc52.N("l", (int)20235, (long)(0x3B5C465EF6A4379BL ^ l)))).qp(false).ol(false);
                    this.EknuQ = (Class_ap_f3b7a87f)new Class_ap_f3b7a87f().pY((String)((Object)Class_c_b33cdc52.N("l", (int)19160, (long)(0x4EB3E6EAE9E5324DL ^ l))), (String)((Object)Class_c_b33cdc52.N("l", (int)29258, (long)(0x2404ACD082D10AD7L ^ l))), Class_ac_rM_8a33ea18.WpzHJ).qp(false).ol(false);
                    this.ItmaE = (Class_ap_f3b7a87f)new Class_ap_f3b7a87f().pW((String)((Object)Class_c_b33cdc52.N("l", (int)5526, (long)(0x475871FDFEE26D05L ^ l)))).qp(false).ol(false);
                    this.cJonW = (Class_ap_f3b7a87f)new Class_ap_f3b7a87f().pY((String)((Object)Class_c_b33cdc52.N("l", (int)14485, (long)(0x140B9E2B83E5C009L ^ l))), (String)((Object)Class_c_b33cdc52.N("l", (int)2921, (long)(0x649FDF3770F673F8L ^ l))), Class_ac_rM_8a33ea18.iKApR).qp(false).ol(false);
                    this.uFsRc = (Class_ap_f3b7a87f)new Class_ap_f3b7a87f().pY((String)((Object)Class_c_b33cdc52.N("l", (int)14485, (long)(0x140B9E2B83E5C009L ^ l))), (String)((Object)Class_c_b33cdc52.N("l", (int)8411, (long)(0x7F24D41F88ADD845L ^ l))), Class_ac_rM_8a33ea18.iKApR).qp(false).ol(false);
                    this.TPXYP = new Class_d_c860402f();
                    this.OPcaS = new Class_d_c860402f();
                    this.pXzKY = new Class_iS_888f260e();
                    int[] nArray = new int[Class_c_b33cdc52.Q("r", (int)17729, (long)(0x732F4A05966EDD95L ^ l))];
                    nArray[0] = (int)Class_c_b33cdc52.Q("r", (int)5429, (long)(0x3DDF6AB50D110DFBL ^ l));
                    nArray[1] = (int)Class_c_b33cdc52.Q("r", (int)29186, (long)(0x7E797E1D08C36AA0L ^ l));
                    nArray[2] = (int)Class_c_b33cdc52.Q("r", (int)2345, (long)(0x131DB9A27FBD1187L ^ l));
                    nArray[3] = (int)Class_c_b33cdc52.Q("r", (int)21795, (long)(0x372A34FC9D41CDE1L ^ l));
                    nArray[4] = (int)Class_c_b33cdc52.Q("r", (int)28011, (long)(0x39F22BC0A1FAF587L ^ l));
                    nArray[5] = (int)Class_c_b33cdc52.Q("r", (int)1592, (long)(0x3E9EBEAAB60C1EF8L ^ l));
                    nArray[Class_c_b33cdc52.Q("r", (int)11102, (long)(0x751FFC62383833ADL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)16392, (long)(0x63503255EA3FD8D1L ^ l));
                    nArray[Class_c_b33cdc52.Q("r", (int)19744, (long)(0x5379BB046425D5C6L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)11606, (long)(0x6377247674C8B5ABL ^ l));
                    nArray[Class_c_b33cdc52.Q("r", (int)10260, (long)(0x4600324D862EB0D1L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)11798, (long)(0xF7249A4CCF436EEL ^ l));
                    nArray[Class_c_b33cdc52.Q("r", (int)2188, (long)(0x576A272E2B599043L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)5917, (long)(0x269F7A14B1E50FE6L ^ l));
                    this.BbgWr = new Class_cJ_2ae1a557(this.pXzKY, Class_mr_7eac5189.clS(nArray)).WE(true);
                    int[] nArray2 = new int[Class_c_b33cdc52.Q("r", (int)1658, (long)(0x711409A5C8189EDDL ^ l))];
                    nArray2[0] = (int)Class_c_b33cdc52.Q("r", (int)7941, (long)(0x1FA7771728AB07DFL ^ l));
                    nArray2[1] = (int)Class_c_b33cdc52.Q("r", (int)4586, (long)(0xE175D0CBF368923L ^ l));
                    nArray2[2] = (int)Class_c_b33cdc52.Q("r", (int)17549, (long)(0x6484852295E05C5DL ^ l));
                    nArray2[3] = (int)Class_c_b33cdc52.Q("r", (int)27951, (long)(0x4C5D49540F16F58EL ^ l));
                    nArray2[4] = (int)Class_c_b33cdc52.Q("r", (int)8925, (long)(0x21548B588FF3BA33L ^ l));
                    nArray2[5] = (int)Class_c_b33cdc52.Q("r", (int)21286, (long)(0x18B5493867794B82L ^ l));
                    nArray2[Class_c_b33cdc52.Q("r", (int)30847, (long)(0x445C73C6C235608AL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)7941, (long)(0x1FA7771728AB07DFL ^ l));
                    nArray2[Class_c_b33cdc52.Q("r", (int)30223, (long)(0x5B7811070B5CEEECL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)1932, (long)(0x5FF4A55A5A359F5BL ^ l));
                    nArray2[Class_c_b33cdc52.Q("r", (int)8182, (long)(0x5D2D89233B9D870CL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)30402, (long)(0x504CA95DE7626E1CL ^ l));
                    nArray2[Class_c_b33cdc52.Q("r", (int)25790, (long)(0x765D3C968D7EFC11L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)28739, (long)(0x2BFFB576535AE891L ^ l));
                    nArray2[Class_c_b33cdc52.Q("r", (int)6762, (long)(0x1217321B60C602AEL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)24711, (long)(0x64861EBF3B1CF84CL ^ l));
                    this.ayNwz = new Class_cC_14ef8bb5(this.pXzKY, Class_mr_7eac5189.clS(nArray2)).Vy(1.0).Vw(1.0).Vx(10.0).VA(2.0);
                    int[] nArray3 = new int[Class_c_b33cdc52.Q("r", (int)13892, (long)(0x75FB831701DAAE99L ^ l))];
                    nArray3[0] = (int)Class_c_b33cdc52.Q("r", (int)20244, (long)(0x5C9F478C93C3D7B4L ^ l));
                    nArray3[1] = (int)Class_c_b33cdc52.Q("r", (int)17549, (long)(0x6484852295E05C5DL ^ l));
                    nArray3[2] = (int)Class_c_b33cdc52.Q("r", (int)7731, (long)(0x50060F6FCD4486CAL ^ l));
                    nArray3[3] = (int)Class_c_b33cdc52.Q("r", (int)28739, (long)(0x2BFFB576535AE891L ^ l));
                    nArray3[4] = (int)Class_c_b33cdc52.Q("r", (int)21286, (long)(0x18B5493867794B82L ^ l));
                    nArray3[5] = (int)Class_c_b33cdc52.Q("r", (int)32452, (long)(0x41B7BDEE42D1662BL ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)30847, (long)(0x445C73C6C235608AL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)1965, (long)(0x56E299811CCE1F53L ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)30223, (long)(0x5B7811070B5CEEECL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)30962, (long)(0x5DD3B35079D86018L ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)8182, (long)(0x5D2D89233B9D870CL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)17549, (long)(0x6484852295E05C5DL ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)25790, (long)(0x765D3C968D7EFC11L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)5898, (long)(0x5F27EB93FD720FE1L ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)6762, (long)(0x1217321B60C602AEL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)21286, (long)(0x18B5493867794B82L ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)14084, (long)(0x4139A541AD18AFE5L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)15548, (long)(0xA64980FA6A2244AL ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)974, (long)(0x6472F911515A1B23L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)10874, (long)(0x272E9EBF7246B2D9L ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)29552, (long)(0x27EA0B081FADEBA6L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)17549, (long)(0x6484852295E05C5DL ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)13423, (long)(0x105B4A1451DF2CA5L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)27951, (long)(0x4C5D49540F16F58EL ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)17868, (long)(0x1D3D30E9D6F45D10L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)21286, (long)(0x18B5493867794B82L ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)17297, (long)(0x620C5EAB04815B66L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)15618, (long)(0x45D4FC385E9925D9L ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)22717, (long)(0x27928376C86A407CL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)10874, (long)(0x272E9EBF7246B2D9L ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)1096, (long)(0x1A2592007B231C99L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)27951, (long)(0x4C5D49540F16F58EL ^ l));
                    nArray3[Class_c_b33cdc52.Q("r", (int)15937, (long)(0x4FBB02AFB34C26B0L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)7731, (long)(0x50060F6FCD4486CAL ^ l));
                    this.ugpZM = new Class_cJ_2ae1a557(this.pXzKY, Class_mr_7eac5189.clS(nArray3));
                    int[] nArray4 = new int[Class_c_b33cdc52.Q("r", (int)25414, (long)(0x5E5C18292412FB8AL ^ l))];
                    nArray4[0] = (int)Class_c_b33cdc52.Q("r", (int)15618, (long)(0x45D4FC385E9925D9L ^ l));
                    nArray4[1] = (int)Class_c_b33cdc52.Q("r", (int)17549, (long)(0x6484852295E05C5DL ^ l));
                    nArray4[2] = (int)Class_c_b33cdc52.Q("r", (int)7731, (long)(0x50060F6FCD4486CAL ^ l));
                    nArray4[3] = (int)Class_c_b33cdc52.Q("r", (int)28739, (long)(0x2BFFB576535AE891L ^ l));
                    nArray4[4] = (int)Class_c_b33cdc52.Q("r", (int)21286, (long)(0x18B5493867794B82L ^ l));
                    nArray4[5] = (int)Class_c_b33cdc52.Q("r", (int)1138, (long)(0x7BC026D035F39C82L ^ l));
                    nArray4[Class_c_b33cdc52.Q("r", (int)30847, (long)(0x445C73C6C235608AL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)11971, (long)(0x8BCD45F5271B616L ^ l));
                    nArray4[Class_c_b33cdc52.Q("r", (int)30223, (long)(0x5B7811070B5CEEECL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)16206, (long)(0x7A814DA092D527AEL ^ l));
                    nArray4[Class_c_b33cdc52.Q("r", (int)8182, (long)(0x5D2D89233B9D870CL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)17549, (long)(0x6484852295E05C5DL ^ l));
                    nArray4[Class_c_b33cdc52.Q("r", (int)25790, (long)(0x765D3C968D7EFC11L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)5898, (long)(0x5F27EB93FD720FE1L ^ l));
                    nArray4[Class_c_b33cdc52.Q("r", (int)6762, (long)(0x1217321B60C602AEL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)21286, (long)(0x18B5493867794B82L ^ l));
                    nArray4[Class_c_b33cdc52.Q("r", (int)14084, (long)(0x4139A541AD18AFE5L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)4381, (long)(0x2AE9BEE2CD9709FAL ^ l));
                    nArray4[Class_c_b33cdc52.Q("r", (int)2677, (long)(0x140628DB520C9289L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)30478, (long)(0x2E368238D041EFEBL ^ l));
                    nArray4[Class_c_b33cdc52.Q("r", (int)25650, (long)(0x2367C50361BE7CEDL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)619, (long)(0x324EE9F9A7229A89L ^ l));
                    nArray4[Class_c_b33cdc52.Q("r", (int)3924, (long)(0x355B62C239FA17A6L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)21286, (long)(0x18B5493867794B82L ^ l));
                    nArray4[Class_c_b33cdc52.Q("r", (int)18280, (long)(0x64D0666C05105FA0L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)15618, (long)(0x45D4FC385E9925D9L ^ l));
                    nArray4[Class_c_b33cdc52.Q("r", (int)2780, (long)(0x4BA13A8BF5F19204L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)10874, (long)(0x272E9EBF7246B2D9L ^ l));
                    nArray4[Class_c_b33cdc52.Q("r", (int)28193, (long)(0x3B7E866540C5F684L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)27951, (long)(0x4C5D49540F16F58EL ^ l));
                    nArray4[Class_c_b33cdc52.Q("r", (int)22101, (long)(0x4C67BD73F388CE93L ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)7731, (long)(0x50060F6FCD4486CAL ^ l));
                    this.KDIPU = new Class_cJ_2ae1a557(this.pXzKY, Class_mr_7eac5189.clS(nArray4));
                    int[] nArray5 = new int[Class_c_b33cdc52.Q("r", (int)25790, (long)(0x765D3C968D7EFC11L ^ l))];
                    nArray5[0] = (int)Class_c_b33cdc52.Q("r", (int)15618, (long)(0x45D4FC385E9925D9L ^ l));
                    nArray5[1] = (int)Class_c_b33cdc52.Q("r", (int)17549, (long)(0x6484852295E05C5DL ^ l));
                    nArray5[2] = (int)Class_c_b33cdc52.Q("r", (int)7731, (long)(0x50060F6FCD4486CAL ^ l));
                    nArray5[3] = (int)Class_c_b33cdc52.Q("r", (int)28739, (long)(0x2BFFB576535AE891L ^ l));
                    nArray5[4] = (int)Class_c_b33cdc52.Q("r", (int)21286, (long)(0x18B5493867794B82L ^ l));
                    nArray5[5] = (int)Class_c_b33cdc52.Q("r", (int)7941, (long)(0x1FA7771728AB07DFL ^ l));
                    nArray5[Class_c_b33cdc52.Q("r", (int)30847, (long)(0x445C73C6C235608AL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)4586, (long)(0xE175D0CBF368923L ^ l));
                    nArray5[Class_c_b33cdc52.Q("r", (int)30223, (long)(0x5B7811070B5CEEECL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)10874, (long)(0x272E9EBF7246B2D9L ^ l));
                    nArray5[Class_c_b33cdc52.Q("r", (int)8182, (long)(0x5D2D89233B9D870CL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)14245, (long)(0x2E6DDB205933AF5AL ^ l));
                    this.kYwHO = new Class_cJ_2ae1a557(this.pXzKY, Class_mr_7eac5189.clS(nArray5));
                    this.ReKgb = new Class_iS_888f260e();
                    int[] nArray6 = new int[Class_c_b33cdc52.Q("r", (int)25790, (long)(0x765D3C968D7EFC11L ^ l))];
                    nArray6[0] = (int)Class_c_b33cdc52.Q("r", (int)25132, (long)(0x7739A5C183DAFAFFL ^ l));
                    nArray6[1] = (int)Class_c_b33cdc52.Q("r", (int)27951, (long)(0x4C5D49540F16F58EL ^ l));
                    nArray6[2] = (int)Class_c_b33cdc52.Q("r", (int)17549, (long)(0x6484852295E05C5DL ^ l));
                    nArray6[3] = (int)Class_c_b33cdc52.Q("r", (int)21644, (long)(0x4D04750E7AE2CC41L ^ l));
                    nArray6[4] = (int)Class_c_b33cdc52.Q("r", (int)10874, (long)(0x272E9EBF7246B2D9L ^ l));
                    nArray6[5] = (int)Class_c_b33cdc52.Q("r", (int)18111, (long)(0x40175B003EA25E57L ^ l));
                    nArray6[Class_c_b33cdc52.Q("r", (int)30847, (long)(0x445C73C6C235608AL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)17549, (long)(0x6484852295E05C5DL ^ l));
                    nArray6[Class_c_b33cdc52.Q("r", (int)30223, (long)(0x5B7811070B5CEEECL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)16813, (long)(0xD3CAFD627FFD959L ^ l));
                    nArray6[Class_c_b33cdc52.Q("r", (int)8182, (long)(0x5D2D89233B9D870CL ^ l))] = (int)Class_c_b33cdc52.Q("r", (int)27951, (long)(0x4C5D49540F16F58EL ^ l));
                    this.lOVKq = new Class_cL_ccb21d14(this.ReKgb, Class_mr_7eac5189.clS(nArray6)).Xk(0.5f, 1.0f).Xl(0.5f, 0.0f);
                    MGKQD = this;
                    this.OOoLn.aV(() -> Class_c_b33cdc52.F(this));
                    this.w(this.pXzKY.bwI(), this.ItmaE);
                    this.w(this.ReKgb.bwI(), this.EknuQ);
                    this.w(this.TPXYP.bwI(), this.cJonW);
                    this.w(this.OPcaS.bwI(), this.uFsRc);
                    Class_ig_ca326427 class_ig_ca326427 = ClientMain.dlM().bjG();
                    Class_mG_52c8d386 class_mG_52c8d386 = class_ig_ca326427.bio();
                    Class_mG_52c8d386 class_mG_52c8d3862 = class_ig_ca326427.biq().cob(0.3f);
                    Class_Q_88b47dba class_Q_88b47dba = new Class_Q_88b47dba().ip((String)((Object)Class_c_b33cdc52.N("l", (int)22054, (long)(0x5D0DD0538999AEB2L ^ l)))).io(Class_lf_d247d983.blMVg).is(8.0f).je(true).jq(class_mG_52c8d3862).jr(class_mG_52c8d3862).js(class_mG_52c8d3862).jk(class_mG_52c8d386).jl(class_mG_52c8d386).jm(class_mG_52c8d386).jf(Class_ld_bb1690e1.all(6.0f)).jb(this::E);
                    boolean bl2 = Class_c_b33cdc52.H();
                    try {
                        try {
                            this.KvjMc.pV(new Class_b_cd9d9ee6());
                            this.KvjMc.pV(new Class_c_rE_c9f44d07(this, class_Q_88b47dba));
                            this.r();
                            this.KvjMc.sP(0);
                            this.EknuQ.sP(1);
                            this.ItmaE.sP(2);
                            this.cJonW.sP(3);
                            this.uFsRc.sP(4);
                            this.OOoLn.aE(this.KvjMc);
                            this.OOoLn.aE(this.EknuQ);
                            this.OOoLn.aE(this.ItmaE);
                            this.OOoLn.aE(this.cJonW);
                            this.OOoLn.aE(this.uFsRc);
                            if (Class_iS_888f260e.bwL() != null) break block4;
                            if (!bl2) break block5;
                        }
                        catch (MatchException matchException) {
                            throw Class_c_b33cdc52.J(matchException);
                        }
                        bl = false;
                        break block6;
                    }
                    catch (MatchException matchException) {
                        throw Class_c_b33cdc52.J(matchException);
                    }
                }
                bl = true;
            }
            Class_c_b33cdc52.G(bl);
        }
    }

    static {
        NativeLoader.doInit(Class_c_b33cdc52.class);
        Class_c_b33cdc52._4f84036bfae9883b4cc5c5a67d6c2a06();
    }

    private static native /* synthetic */ void B(Class_cy_687dcdb6 var0, Class_aj_95d0a719 var1);

    private static native /* synthetic */ void C(Class_aj_95d0a719 var0, Boolean var1);

    private static native /* synthetic */ void D(Class_ap_f3b7a87f var0);

    private static native /* synthetic */ void F(Class_c_b33cdc52 var0);

    public static native boolean I();

    private static native MatchException J(MatchException var0);

    private native void x();

    private native void s(Iterable<Class_cB_67aec11c> var1);

    @Override
    protected native Vec2f n();

    @Override
    public native void m(Class_lC_5322e8cf var1);

    private native void o();

    private native void p();

    private native void t();

    private native void v();

    private native float q(Class_ap_f3b7a87f var1, float var2);

    public static native void z();

    private native void w(Collection<Class_cB_67aec11c> var1, Class_ap_f3b7a87f var2);

    private native void u(Class_in_57efefb0 var1);

    private native void r();

    private native void y(Consumer<Class_ap_f3b7a87f> var1);

    private native /* synthetic */ void E(Class_Q_88b47dba var1);

    public static native Class_c_b33cdc52 A();

    private static native String L(int var0, long var1);

    @Override
    public native Class_g_bd7b3df3 manager();

    private static native Object M(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite N(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native int P(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public static native boolean H();

    private static native String K(byte[] var0);

    private static native CallSite Q(MethodHandles.Lookup var0, String var1, MethodType var2);

    public static native void G(boolean var0);

    @Override
    public native boolean onMouseDragged(double var1, double var3, Class_mA_32d8a5f2 var5, double var6, double var8);

    @Override
    public native boolean onCharTyped(char var1);

    @Override
    public native boolean onMouseClicked(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean onKeyPressed(int var1, int var2, int var3);

    @Override
    public native boolean onMouseReleased(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean onMouseScrolled(double var1, double var3, double var5);

    @Override
    public native void addTooltip(Class_k_759fe111 var1);

    @Override
    public native void addPopup(Class_ap_f3b7a87f var1);

    @Override
    public native void addPopupComponent(Class_aj_95d0a719 var1);

    public native void close();

    public native void init();

    public native void tick();
}

