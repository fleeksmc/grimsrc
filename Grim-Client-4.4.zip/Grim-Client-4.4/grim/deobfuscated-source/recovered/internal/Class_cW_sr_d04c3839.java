/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.util.math.Vec3d;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_rg_7e1cad55;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.modules.AmbienceModule;

class Class_cW_sr_d04c3839 {
    private final Class_rg_7e1cad55 TgsVq;
    private final Class_rk_bf8630d1 HxWES;
    private int hRZdA;
    private Vec3d AqODg;
    private boolean YMQFH;
    private boolean tIPuz;
    private static final long qQuCT = Class_gb_9d201141.aYR(509936826766451556L, 85579035793697715L, MethodHandles.lookup().lookupClass()).a(274841104533760L);
    private static final long[] yHRsF;
    private static final Integer[] wVrvT;
    private static final Map GdEsA;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_cW_sr_d04c3839() {
        long l = qQuCT ^ 0x2C4E254DA875L;
        this.TgsVq = new Class_rg_7e1cad55((int)Class_cW_sr_d04c3839.dnR("n", (int)21556, (long)(0xC4FBF42F4E1ECBDL ^ l)));
        this.HxWES = new Class_rk_bf8630d1((int)Class_cW_sr_d04c3839.dnR("n", (int)28298, (long)(0x29D17C7D5AECD602L ^ l)));
        this.AqODg = Vec3d.ZERO;
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        GdEsA = new HashMap(13);
        long l = qQuCT ^ 0x1D51F9C93795L;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "\u00e2\u00e5f2\u00b4\u001a\u0084#\u00bc\u00b8v\u00c9=\u009a\u00b96";
        int n2 = "\u00e2\u00e5f2\u00b4\u001a\u0084#\u00bc\u00b8v\u00c9=\u009a\u00b96".length();
        int n3 = 0;
        do {
            byte[] byArray3 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
            byte[] byArray4 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray4[0] & 0xFFL) << 56 | ((long)byArray4[1] & 0xFFL) << 48 | ((long)byArray4[2] & 0xFFL) << 40 | ((long)byArray4[3] & 0xFFL) << 32 | ((long)byArray4[4] & 0xFFL) << 24 | ((long)byArray4[5] & 0xFFL) << 16 | ((long)byArray4[6] & 0xFFL) << 8 | (long)byArray4[7] & 0xFFL;
        } while (n3 < n2);
        yHRsF = lArray;
        wVrvT = new Integer[2];
    }

    private static CallSite dnR(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cW_sr_d04c3839" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static MatchException dnO(MatchException matchException) {
        return matchException;
    }

    private static int dnQ(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_cW_sr_d04c3839.dnP(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static int dnP(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x4192;
        if (wVrvT[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = yHRsF[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])GdEsA.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    GdEsA.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cW_sr_d04c3839", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_cW_sr_d04c3839.wVrvT[n2] = n3;
        }
        return wVrvT[n2];
    }

    public void dnK() {
        this.tIPuz = true;
        this.HxWES.dhs(Class_rj_b691f4f7.AYqck);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean dnN() {
        long l = qQuCT ^ 0x383DD31A0165L;
        Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
        boolean bl = this.tIPuz;
        if (class_iS_888f260eArray == null) {
            if (!bl) return false;
            float f = this.HxWES.dhj() - 0.0f;
            bl = f == 0.0f ? 0 : (f > 0.0f ? 1 : -1);
        }
        if (class_iS_888f260eArray != null) return bl;
        if (bl) return false;
        return true;
    }

    public float dnM() {
        long l = qQuCT ^ 0x38349ABFE9FFL;
        Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
        boolean bl = this.tIPuz;
        if (class_iS_888f260eArray == null) {
            bl = !bl;
        }
        this.HxWES.dhc(bl);
        return this.HxWES.dhj();
    }

    public Vec3d dnL() {
        long l = qQuCT ^ 0x562F7B64B535L;
        Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
        Class_cW_sr_d04c3839 class_cW_sr_d04c3839 = this;
        if (class_iS_888f260eArray == null) {
            if (!class_cW_sr_d04c3839.YMQFH) {
                this.TgsVq.dfE(this.AqODg);
                this.YMQFH = true;
                return this.AqODg;
            }
            class_cW_sr_d04c3839 = this;
        }
        return class_cW_sr_d04c3839.TgsVq.dfA(this.AqODg);
    }

    public void dnJ(int n, Vec3d vec3d) {
        this.hRZdA = n;
        this.AqODg = vec3d;
        this.tIPuz = false;
        this.HxWES.dhs(Class_rj_b691f4f7.XzDkv);
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cW_sr_d04c3839.class, "dnQ", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

