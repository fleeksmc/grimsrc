/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_mG_52c8d386;

class Class_dt_sH_a158a344 {
    String gbfPR;
    Class_mG_52c8d386 qZmEr;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_dt_sH_a158a344(String string, Class_mG_52c8d386 class_mG_52c8d386) {
        this.gbfPR = string;
        this.qZmEr = class_mG_52c8d386;
    }
}

