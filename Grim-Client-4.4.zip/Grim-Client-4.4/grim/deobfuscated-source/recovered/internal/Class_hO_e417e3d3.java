/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_hX_15329af5;
import recovered.internal.Class_hZ_076851ce;

public class Class_hO_e417e3d3 {
    private static long RfHLy;
    private static String nsZjr;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_hO_e417e3d3.class);
        Class_hO_e417e3d3._e31d03df7599efea95bc25fff66c0060();
    }

    private static native void _e31d03df7599efea95bc25fff66c0060();

    private static native String beB(byte[] var0);

    public native Class_hZ_076851ce bez();

    private static native /* synthetic */ void beA(Class_hX_15329af5 var0);
}

