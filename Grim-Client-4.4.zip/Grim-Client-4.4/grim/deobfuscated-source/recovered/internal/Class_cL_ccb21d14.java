/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.util.math.Vec2f;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_io_666f07e0;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_rj_b691f4f7;

public class Class_cL_ccb21d14
extends Class_cB_67aec11c {
    private Vec2f lWTUx = Vec2f.ZERO;
    private Vec2f rciMJ = new Vec2f(1.0f, 1.0f);
    private static final long JrqPd;
    private static final String[] BwAAb;
    private static final String[] fPPzo;
    private static final Map HDgaN;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cL_ccb21d14(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_cL_ccb21d14.JrqPd = Class_gb_9d201141.aYR(-953890712074032818L, -7957121300344467127L, MethodHandles.lookup().lookupClass()).a(150848065840668L);
                Class_cL_ccb21d14.HDgaN = new HashMap<K, V>(13);
                var0 = Class_cL_ccb21d14.JrqPd ^ 41818288140684L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[4];
                var7_4 = 0;
                var6_5 = "\u0093\u00b6\u00c6O\t\u0098\u0085\u00d8\u00a9\u0092\t\u009d\u0000\u00dao\u0017\u0010\u00e9\u00f3\u00b2GK\u00bfD`\u00b31\u00cb\u00f9\u00e8\u00161O";
                var8_6 = "\u0093\u00b6\u00c6O\t\u0098\u0085\u00d8\u00a9\u0092\t\u009d\u0000\u00dao\u0017\u0010\u00e9\u00f3\u00b2GK\u00bfD`\u00b31\u00cb\u00f9\u00e8\u00161O".length();
                var5_7 = 16;
                var4_8 = -1;
lbl20:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl25:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_cL_ccb21d14.Xw(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "\u0098aq<O\u009d\u001cQ\u00b8\u0081\u0095\u0087\u00f8\u0012\u00ae\u00d9\u0010h\u00ae\u00b1i;\u00ab\u0083\u00f5r\u00c3\u00f3XV\u007f\u00ae<";
                    var8_6 = "\u0098aq<O\u009d\u001cQ\u00b8\u0081\u0095\u0087\u00f8\u0012\u00ae\u00d9\u0010h\u00ae\u00b1i;\u00ab\u0083\u00f5r\u00c3\u00f3XV\u007f\u00ae<".length();
                    var5_7 = 16;
                    var4_8 = -1;
lbl34:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_cL_ccb21d14.Xw(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl51:
                // 1 sources

                ** continue;
            }
        }
        Class_cL_ccb21d14.BwAAb = var9_3;
        Class_cL_ccb21d14.fPPzo = new String[4];
    }

    public Class_cL_ccb21d14 Xp(Class_io_666f07e0 class_io_666f07e0) {
        return this.Xn(new Vec2f(class_io_666f07e0.bly(), class_io_666f07e0.blz()));
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void SS(JsonElement var1_1) {
        var2_2 = Class_cL_ccb21d14.JrqPd ^ 88905912080417L;
        var4_3 = Class_cB_67aec11c.Vt();
        v0 = var1_1;
        if (var4_3) {
            if (!v0.isJsonObject()) {
                return;
            }
            v0 = var1_1;
        }
        var5_4 = v0.getAsJsonObject();
        var6_5 = this.Xs(var5_4, (String)Class_cL_ccb21d14.Xz("v", (int)16954, (long)(8456473716545696071L ^ var2_2)), this.lWTUx);
        var7_6 = this.Xs(var5_4, (String)Class_cL_ccb21d14.Xz("v", (int)29979, (long)(1405616224424396391L ^ var2_2)), this.rciMJ);
        v1 = this;
        if (var4_3) {
            if (v1.lWTUx.equals(var6_5)) {
                v1 = this;
                if (var4_3) {
                    if (v1.rciMJ.equals(var7_6)) {
                        return;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                this.lWTUx = var6_5;
                this.rciMJ = var7_6;
                v1 = this;
            }
        }
        v1.Vk();
    }

    public Vec2f Xu() {
        return this.rciMJ;
    }

    public Vec2f Xt() {
        return this.lWTUx;
    }

    @Override
    public void SR(Map<String, Object> map) {
        long l = JrqPd ^ 0x3A58F2C458DL;
        HashMap<CallSite, Map<String, Object>> hashMap = new HashMap<CallSite, Map<String, Object>>();
        hashMap.put(Class_cL_ccb21d14.Xz("v", (int)14478, (long)(0x8E8ED383359D65DL ^ l)), this.Xr(this.lWTUx));
        hashMap.put(Class_cL_ccb21d14.Xz("v", (int)11079, (long)(0x4BEC1FA87DA4595L ^ l)), this.Xr(this.rciMJ));
        map.put(Arrays.toString(this.NwlSF), hashMap);
    }

    public Class_cL_ccb21d14 Xl(float f, float f2) {
        return this.Xn(new Vec2f(f, f2));
    }

    public Class_cL_ccb21d14 Xk(float f, float f2) {
        return this.Xm(new Vec2f(f, f2));
    }

    public Class_cL_ccb21d14 Xm(Vec2f vec2f) {
        long l = JrqPd ^ 0x6B7AE3BE38E1L;
        boolean bl = Class_cB_67aec11c.Vt();
        if (bl) {
            if (vec2f.equals(this.lWTUx)) {
                return this;
            }
            this.lWTUx = vec2f;
            this.Vk();
        }
        return this;
    }

    /*
     * Unable to fully structure code
     */
    private Vec2f Xs(JsonObject var1_1, String var2_2, Vec2f var3_3) {
        block13: {
            block14: {
                block12: {
                    block11: {
                        var4_4 = Class_cL_ccb21d14.JrqPd ^ 60754616890553L;
                        var6_5 = Class_cB_67aec11c.Vt();
                        v0 = var1_1.has(var2_2);
                        if (!var6_5) break block11;
                        if (!v0) break block12;
                        v1 = var1_1;
                        v2 = var2_2;
                        if (!var6_5) break block13;
                        v0 = v1.get(v2).isJsonObject();
                    }
                    if (v0) break block14;
                }
                return var3_3;
            }
            v1 = var1_1;
            v2 = var2_2;
        }
        var7_6 = v1.getAsJsonObject(v2);
        v3 = var3_3;
        if (!var6_5) ** GOTO lbl23
        if (v3 != null) {
            v3 = var3_3;
lbl23:
            // 2 sources

            v4 = v3.x;
        } else {
            v4 = 0.0f;
        }
        var8_7 = v4;
        v5 = var3_3;
        if (!var6_5) ** GOTO lbl31
        if (v5 != null) {
            v5 = var3_3;
lbl31:
            // 2 sources

            v6 = v5.y;
        } else {
            v6 = 0.0f;
        }
        var9_8 = v6;
        v7 = var7_6;
        v8 = "x";
        if (!var6_5) ** GOTO lbl41
        if (v7.has(v8)) {
            v7 = var7_6;
            v8 = "x";
lbl41:
            // 2 sources

            v9 = v7.get(v8).getAsFloat();
        } else {
            v9 = var8_7;
        }
        var10_9 = v9;
        v10 = var7_6;
        v11 = "y";
        if (!var6_5) ** GOTO lbl51
        if (v10.has(v11)) {
            v10 = var7_6;
            v11 = "y";
lbl51:
            // 2 sources

            v12 = v10.get(v11).getAsFloat();
        } else {
            v12 = var9_8;
        }
        var11_10 = v12;
        return new Vec2f(var10_9, var11_10);
    }

    private static CallSite Xz(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cL_ccb21d14" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public Class_rj_b691f4f7 Xq() {
        return Class_rj_b691f4f7.dgc(this.lWTUx.x, 1.0f - this.lWTUx.y, this.rciMJ.x, 1.0f - this.rciMJ.y);
    }

    private static String Xw(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public Class_cL_ccb21d14 Xn(Vec2f vec2f) {
        long l = JrqPd ^ 0x1BADAB84F3DEL;
        boolean bl = Class_cB_67aec11c.Vu();
        if (!bl) {
            if (vec2f.equals(this.rciMJ)) {
                return this;
            }
            this.rciMJ = vec2f;
            this.Vk();
        }
        return this;
    }

    private static Object Xy(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_cL_ccb21d14.Xx(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    public Class_cL_ccb21d14 Xo(Class_io_666f07e0 class_io_666f07e0) {
        return this.Xm(new Vec2f(class_io_666f07e0.bly(), class_io_666f07e0.blz()));
    }

    private static MatchException Xv(MatchException matchException) {
        return matchException;
    }

    private static String Xx(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5BD7;
        if (fPPzo[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])HDgaN.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    HDgaN.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cL_ccb21d14", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = BwAAb[n2].getBytes("ISO-8859-1");
            Class_cL_ccb21d14.fPPzo[n2] = Class_cL_ccb21d14.Xw(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return fPPzo[n2];
    }

    private Map<String, Object> Xr(Vec2f vec2f) {
        long l = JrqPd ^ 0x639611E515D9L;
        HashMap<String, Object> hashMap = new HashMap<String, Object>();
        boolean bl = Class_cB_67aec11c.Vu();
        Object object = vec2f;
        if (!bl && object != null) {
            hashMap.put("x", Float.valueOf(vec2f.x));
            object = hashMap.put("y", Float.valueOf(vec2f.y));
        }
        return hashMap;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cL_ccb21d14.class, "Xy", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

