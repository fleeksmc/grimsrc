/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_P_2c9819bb;
import recovered.internal.Class_aA_8076b584;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_iy_c88c0f4f;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bu_edcf85ea
extends Class_aA_8076b584 {
    private Class_iy_c88c0f4f gGApI;
    boolean EdPWB;
    private final Class_rk_bf8630d1 KsVLK;
    private static long CRMjj;
    private static String[] GXAvt;
    private static String[] JWvHj;
    private static Map vzzuz;
    private static long epSLH;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bu_edcf85ea(Class_iy_c88c0f4f class_iy_c88c0f4f) {
        long l = CRMjj ^ 0x109414448D31L;
        this.EdPWB = false;
        this.KsVLK = new Class_rk_bf8630d1((int)epSLH).dhs(Class_rj_b691f4f7.UPXqT);
        this.gGApI = class_iy_c88c0f4f;
        this.BcpIo = 20.0f;
        this.WjISQ = 20.0f;
        this.tI(false);
    }

    static {
        NativeLoader.doInit(Class_bu_edcf85ea.class);
        Class_bu_edcf85ea._a07a3316d0a56375ce22c208f90d8aba();
    }

    private static native /* synthetic */ void In(Class_iy_c88c0f4f var0, Class_P_2c9819bb var1);

    private static native CallSite Is(MethodHandles.Lookup var0, String var1, MethodType var2);

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private native Class_P_2c9819bb Id(Class_aj_95d0a719 var1, Class_iy_c88c0f4f var2);

    @Override
    public native boolean oi();

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private static native void _a07a3316d0a56375ce22c208f90d8aba();

    public native boolean Ii();

    public native Class_rk_bf8630d1 Ij();

    private static native /* synthetic */ void Im(Class_iy_c88c0f4f var0, Class_P_2c9819bb var1);

    private native Class_P_2c9819bb Ic(Class_aj_95d0a719 var1, Class_iy_c88c0f4f var2);

    private native Class_P_2c9819bb Ie(Class_aj_95d0a719 var1, Class_iy_c88c0f4f var2);

    private static native String Ip(byte[] var0);

    private static native /* synthetic */ void Il(Class_P_2c9819bb var0, Boolean var1);

    public native Class_bu_edcf85ea Ig(boolean var1);

    private native void Ia();

    private static native /* synthetic */ void Ik(Class_iy_c88c0f4f var0, Class_P_2c9819bb var1);

    public native Class_bu_edcf85ea If(Class_iy_c88c0f4f var1);

    private static native String Iq(int var0, long var1);

    public native Class_iy_c88c0f4f Ih();

    private static native Object Ir(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native MatchException Io(MatchException var0);

    private native void Ib();
}

