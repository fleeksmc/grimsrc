/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;

public class Class_ha_270ff5b9
extends Class_hH_ae8f8f77 {
    private float pXWCg;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public void bcp(float f) {
        this.pXWCg = f;
    }

    public float bcq() {
        return this.pXWCg;
    }
}

