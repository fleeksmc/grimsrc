/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderPass
 *  com.mojang.blaze3d.vertex.VertexFormat$DrawMode
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.util.BufferAllocator
 */
package recovered.internal;

import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jL_e8aba6a1;
import recovered.internal.Class_jO_1924117a;
import recovered.internal.Class_jT_87816f30;
import recovered.internal.Class_kR_e9b8cad1;
import recovered.internal.Class_kh_19daf527;
import recovered.internal.Class_lF_27593463;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mG_52c8d386;

public class Class_jU_03a919ae
implements Class_kh_19daf527<Class_jO_1924117a> {
    private static final long iIURF;
    private static final String[] QaDIb;
    private static final String[] NMTNJ;
    private static final Map YBUhC;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_jU_03a919ae.iIURF = Class_gb_9d201141.aYR(6987229562181160938L, 7444533500002196327L, MethodHandles.lookup().lookupClass()).a(41633260938310L);
                Class_jU_03a919ae.YBUhC = new HashMap<K, V>(13);
                var0 = Class_jU_03a919ae.iIURF ^ 40564356388678L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[4];
                var7_4 = 0;
                var6_5 = "\"\u0093\u00d4:C5\u001d\u0094**\u00cb\u009f\u0018\u00ca3Lq*P\u00f0\u0000\u00bb@\n>\u00ce\u00fby\u00d79j\u00ef \u0006\u00f1\u00cd^\u0010\u00bd\u001b(e^T+`\u00ebV\u0083Z\u00fc\u0000\u00a2\u00b6\u00fe\u001d\u00e5\u0011V\u0099\u0095~\u0085\u00a2\f";
                var8_6 = "\"\u0093\u00d4:C5\u001d\u0094**\u00cb\u009f\u0018\u00ca3Lq*P\u00f0\u0000\u00bb@\n>\u00ce\u00fby\u00d79j\u00ef \u0006\u00f1\u00cd^\u0010\u00bd\u001b(e^T+`\u00ebV\u0083Z\u00fc\u0000\u00a2\u00b6\u00fe\u001d\u00e5\u0011V\u0099\u0095~\u0085\u00a2\f".length();
                var5_7 = 32;
                var4_8 = -1;
lbl20:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl25:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jU_03a919ae.bNc(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "@o\u0094&\u0097\u00f1%2}4\u00f15\u00ea\u00ff\u00a2*\u009c?\u0089g\u00a8Y\u0007>{\u00cb;\b1\t\u001fE\u00c6\u00ffW\u00a0\u00ff2r\u00f68\u009d\u0012|\u00c1L\u00d3ICDSd4\u00d7\u00aa5\u00fe\u008f\u0081\u00c4'p\u00f0\u00cd\u00abk\u000bA\u001f\u00bd\u00cdC\u00ed\u008eM\u008b\u000f?6\u00d8\u00a6\u001f\f\u00d3\u0099\t\u009c\u00a2\u00bfT\u0010\u00c8H<x\u009c\u0095";
                    var8_6 = "@o\u0094&\u0097\u00f1%2}4\u00f15\u00ea\u00ff\u00a2*\u009c?\u0089g\u00a8Y\u0007>{\u00cb;\b1\t\u001fE\u00c6\u00ffW\u00a0\u00ff2r\u00f68\u009d\u0012|\u00c1L\u00d3ICDSd4\u00d7\u00aa5\u00fe\u008f\u0081\u00c4'p\u00f0\u00cd\u00abk\u000bA\u001f\u00bd\u00cdC\u00ed\u008eM\u008b\u000f?6\u00d8\u00a6\u001f\f\u00d3\u0099\t\u009c\u00a2\u00bfT\u0010\u00c8H<x\u009c\u0095".length();
                    var5_7 = 40;
                    var4_8 = -1;
lbl34:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_jU_03a919ae.bNc(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl51:
                // 1 sources

                ** continue;
            }
        }
        Class_jU_03a919ae.QaDIb = var9_3;
        Class_jU_03a919ae.NMTNJ = new String[4];
    }

    private static Throwable bNb(Throwable throwable) {
        return throwable;
    }

    /*
     * Unable to fully structure code
     */
    public void bMX(Class_jO_1924117a var1_1) {
        block22: {
            block23: {
                block21: {
                    block20: {
                        var2_2 = Class_jU_03a919ae.iIURF ^ 68493295521108L;
                        var5_3 = var1_1.bKi();
                        var4_4 = Class_jT_87816f30.bMR();
                        if (var5_3.cnW()) {
                            return;
                        }
                        var6_5 = Math.max(var1_1.bKm(), 0.001f);
                        var7_6 = var1_1.bKd();
                        var8_7 = var1_1.bKe();
                        cfr_temp_0 = var7_6 - 0.0f;
                        v0 = cfr_temp_0 == 0.0f ? 0 : (cfr_temp_0 < 0.0f ? -1 : 1);
                        if (var4_4) break block20;
                        if (v0 <= 0) break block21;
                        v1 = var8_7;
                        v2 = 0.0f;
                        if (var4_4) break block22;
                        cfr_temp_1 = v1 - v2;
                        v0 = cfr_temp_1 == 0.0f ? 0 : (cfr_temp_1 < 0.0f ? -1 : 1);
                    }
                    if (v0 > 0) break block23;
                }
                return;
            }
            v1 = var1_1.bKb();
            v2 = var6_5;
        }
        var9_8 = v1 - v2;
        var10_9 = var1_1.bKc() - var6_5;
        var11_10 = var7_6 + var6_5 * 2.0f;
        var12_11 = var8_7 + var6_5 * 2.0f;
        var13_12 = new BufferAllocator(VertexFormats.POSITION_TEXTURE_COLOR.getVertexSize() * 4);
        try {
            var14_13 = new BufferBuilder(var13_12, VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            Class_jU_03a919ae.FroVm.uv_quad_region_color(var14_13, var1_1.bKa(), var9_8, var10_9, var11_10, var12_11, 0.0f, 0.0f, 1.0f, 1.0f, Class_mG_52c8d386.hoGuU);
            var15_15 = var14_13.end();
            try {
                Class_lF_27593463.cfB(Class_kR_e9b8cad1.bAgoy, var15_15, (Consumer<RenderPass>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, bNa(recovered.internal.Class_jO_1924117a float com.mojang.blaze3d.systems.RenderPass ), (Lcom/mojang/blaze3d/systems/RenderPass;)V)((Class_jU_03a919ae)this, (Class_jO_1924117a)var1_1, (float)var6_5));
                ** if (var4_4 || var15_15 == null) goto lbl-1000
            }
            catch (Throwable var16_17) {
                block24: {
                    v3 = var15_15;
                    if (var4_4) ** GOTO lbl46
                    if (v3 == null) break block24;
                    try {
                        v3 = var15_15;
lbl46:
                        // 2 sources

                        v3.close();
                    }
                    catch (Throwable var17_18) {
                        var16_17.addSuppressed(var17_18);
                    }
                }
                throw var16_17;
            }
lbl-1000:
            // 1 sources

            {
                var15_15.close();
            }
lbl-1000:
            // 2 sources

            {
            }
        }
        finally {
            var13_12.close();
        }
    }

    private /* synthetic */ void bNa(Class_jO_1924117a class_jO_1924117a, float f, RenderPass renderPass) {
        this.bMY(class_jO_1924117a, f);
    }

    private static CallSite bNf(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jU_03a919ae" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private float bMZ(Class_ld_bb1690e1 class_ld_bb1690e1, float f, float f2) {
        float f3 = Math.min(f, f2);
        return Math.max(0.0f, Math.min(class_ld_bb1690e1.value(), f3));
    }

    private static String bNd(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x4E50;
        if (NMTNJ[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])YBUhC.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    YBUhC.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jU_03a919ae", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = QaDIb[n2].getBytes("ISO-8859-1");
            Class_jU_03a919ae.NMTNJ[n2] = Class_jU_03a919ae.bNc(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return NMTNJ[n2];
    }

    private static Object bNe(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_jU_03a919ae.bNd(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private void bMY(Class_jO_1924117a class_jO_1924117a, float f) {
        long l = iIURF ^ 0x4A0619509FBFL;
        float f2 = class_jO_1924117a.bKd() * 0.5f;
        float f3 = class_jO_1924117a.bKe() * 0.5f;
        float f4 = this.bMZ(class_jO_1924117a.bKh(), f2, f3);
        Class_jL_e8aba6a1.wcOYb.bJl();
        Class_jL_e8aba6a1.wcOYb.bJr((String)((Object)Class_jU_03a919ae.bNf("n", (int)27965, (long)(0x6F339A38470FEFD2L ^ l))), f2 / f, f3 / f);
        Class_jL_e8aba6a1.wcOYb.bJq((String)((Object)Class_jU_03a919ae.bNf("n", (int)16015, (long)(0xDC82D7219A7BC61L ^ l))), f4 / f);
        Class_jL_e8aba6a1.wcOYb.bJu((String)((Object)Class_jU_03a919ae.bNf("n", (int)624, (long)(0x64B10286D73C809DL ^ l))), class_jO_1924117a.bKi().con());
        Class_jL_e8aba6a1.wcOYb.bJu((String)((Object)Class_jU_03a919ae.bNf("n", (int)13885, (long)(0x7B8B272A2BA534D1L ^ l))), Class_jF_38b68c76.bHw());
    }

    private static String bNc(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jU_03a919ae.class, "bNe", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

