/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mixin.accessors.CooldownInstanceAccessor
 *  mixin.accessors.ItemCooldownsAccessor
 *  net.minecraft.block.Block
 *  net.minecraft.block.Blocks
 *  net.minecraft.client.render.item.ItemRenderState
 *  net.minecraft.client.texture.NativeImage
 *  net.minecraft.component.DataComponentTypes
 *  net.minecraft.component.type.AttributeModifiersComponent
 *  net.minecraft.component.type.ChargedProjectilesComponent
 *  net.minecraft.component.type.EquippableComponent
 *  net.minecraft.component.type.WeaponComponent
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.enchantment.Enchantments
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EquipmentSlot
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.attribute.EntityAttributeInstance
 *  net.minecraft.entity.attribute.EntityAttributeModifier
 *  net.minecraft.entity.attribute.EntityAttributes
 *  net.minecraft.entity.damage.DamageSource
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemDisplayContext
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.ItemUsageContext
 *  net.minecraft.item.Items
 *  net.minecraft.item.equipment.EquipmentType
 *  net.minecraft.registry.Registries
 *  net.minecraft.registry.RegistryKey
 *  net.minecraft.registry.tag.ItemTags
 *  net.minecraft.server.world.ServerWorld
 *  net.minecraft.text.Style
 *  net.minecraft.text.Text
 *  net.minecraft.util.ActionResult
 *  net.minecraft.util.Hand
 *  net.minecraft.util.HeldItemContext
 *  net.minecraft.util.Identifier
 *  net.minecraft.util.math.random.Random
 *  net.minecraft.world.World
 */
package recovered.internal;

import java.io.InputStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.security.Key;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import mixin.accessors.CooldownInstanceAccessor;
import mixin.accessors.ItemCooldownsAccessor;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.component.type.WeaponComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.Items;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.HeldItemContext;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jc_tI_47a1be77;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_jh_282f5b34;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mZ_07f59a29;
import recovered.internal.Class_oI_0a14d25a;
import recovered.internal.Class_oP_6ecdf500;
import recovered.internal.Class_oR_7de26dc4;
import recovered.internal.Class_qO_d37ef529;

public class Class_jc_20aa808a {
    public static final Set<Item> WnbNG;
    public static final Set<Item> GjreY;
    public static final Set<Item> FFgfM;
    private static final Item vSOjt;
    private static final Map<String, Item> alGsc;
    private static final Map<String, Class_mG_52c8d386> xxvZl;
    private static final Map<String, Class_mG_52c8d386> IckfH;
    private static int jlfNZ;
    private static final long WedAj;
    private static final String[] UOSQi;
    private static final String[] GXVbC;
    private static final Map baifd;
    private static final long[] NCEKq;
    private static final Integer[] ZHAjc;
    private static final Map uhkkf;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public static boolean bzr(ItemStack itemStack) {
        long l = WedAj ^ 0x473B08F72EE9L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        boolean bl = Class_jc_20aa808a.bzm(itemStack);
        if (stringArray != null) {
            if (!bl) {
                return false;
            }
            bl = Class_jh_282f5b34.bCg(itemStack, (RegistryKey<Enchantment>)Enchantments.LUNGE);
        }
        return bl;
    }

    public static boolean bzd(ItemStack itemStack, Class<? extends Item> clazz) {
        return itemStack.getItem().getClass().equals(clazz);
    }

    public static boolean bzt(ItemStack itemStack) {
        return Class_jh_282f5b34.bCg(itemStack, (RegistryKey<Enchantment>)Enchantments.KNOCKBACK);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean bzb(ItemStack itemStack) {
        long l = WedAj ^ 0x5310756235E5L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        boolean bl = Class_jc_20aa808a.bza(itemStack, EquipmentType.CHESTPLATE);
        if (stringArray != null) {
            if (!bl) return false;
            bl = itemStack.isOf(Items.ELYTRA);
        }
        if (stringArray == null) return bl;
        if (bl) return false;
        return true;
    }

    public static int bze(ItemStack itemStack) {
        int n;
        block4: {
            block5: {
                Object object;
                block2: {
                    long l;
                    block3: {
                        l = WedAj ^ 0x67B7E8478A46L;
                        String[] stringArray = Class_jf_d1c4f950.bBe();
                        object = itemStack.isEmpty();
                        if (stringArray == null) break block2;
                        if (object != 0) break block3;
                        n = itemStack.isDamageable();
                        if (stringArray == null) break block4;
                        if (n != 0) break block5;
                    }
                    object = Class_jc_20aa808a.bAd("q", (int)27274, (long)(0x4A1D673663258138L ^ l));
                }
                return object;
            }
            n = itemStack.getMaxDamage() - itemStack.getDamage();
        }
        int n2 = n;
        return (int)((double)n2 / (double)itemStack.getMaxDamage() * 100.0);
    }

    private static CallSite bAa(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jc_20aa808a" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public static float bzi(ItemStack itemStack) {
        float f = ClientMain.dlmvG.getRenderTickCounter().getTickProgress(true);
        return Class_mZ_07f59a29.csc(ClientMain.dlmvG.player.getItemCooldownManager().getCooldownProgress(itemStack, f) * 100.0f, 0);
    }

    public static List<Item> byY(Predicate<Item> predicate) {
        return WnbNG.stream().filter(predicate).toList();
    }

    public static List<Item> byZ(Predicate<Item> predicate) {
        return GjreY.stream().filter(predicate).toList();
    }

    private static Throwable bzW(Throwable throwable) {
        return throwable;
    }

    private static CallSite bAd(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jc_20aa808a" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public static int bzh(Item item) {
        long l = WedAj ^ 0x1606BEB4D43EL;
        ItemCooldownsAccessor itemCooldownsAccessor = (ItemCooldownsAccessor)ClientMain.dlmvG.player.getItemCooldownManager();
        Map map = itemCooldownsAccessor.getCooldowns();
        Object v = map.get(Registries.ITEM.getId((Object)item));
        String[] stringArray = Class_jf_d1c4f950.bBe();
        Object v2 = v;
        if (stringArray != null) {
            if (v2 == null) {
                return 0;
            }
            v2 = v;
        }
        CooldownInstanceAccessor cooldownInstanceAccessor = (CooldownInstanceAccessor)v2;
        double d = (float)itemCooldownsAccessor.getTickCount() + ClientMain.dlmvG.getRenderTickCounter().getTickProgress(true);
        double d2 = (double)cooldownInstanceAccessor.getEndTime() - d;
        return (int)Math.max(0.0, Math.ceil(d2));
    }

    public static boolean bza(ItemStack itemStack, EquipmentType equipmentType) {
        long l = WedAj ^ 0x3711F805DA7L;
        EquipmentType equipmentType2 = Class_jc_20aa808a.bzc(itemStack);
        return equipmentType2 == equipmentType;
    }

    public static float bzj(ItemStack itemStack) {
        double d;
        EntityAttributeInstance entityAttributeInstance2;
        String[] stringArray;
        block12: {
            AttributeModifiersComponent attributeModifiersComponent;
            block11: {
                AttributeModifiersComponent attributeModifiersComponent2;
                block10: {
                    block8: {
                        ItemStack itemStack2;
                        block9: {
                            long l = WedAj ^ 0x5816C446EB08L;
                            stringArray = Class_jf_d1c4f950.bBe();
                            if (ClientMain.dlmvG.player == null) break block8;
                            itemStack2 = itemStack;
                            if (stringArray == null) break block9;
                            if (itemStack2 == null) break block8;
                            itemStack2 = itemStack;
                        }
                        if (!itemStack2.isEmpty()) break block10;
                    }
                    return 0.0f;
                }
                entityAttributeInstance2 = new EntityAttributeInstance(EntityAttributes.ATTACK_SPEED, entityAttributeInstance -> {});
                entityAttributeInstance2.setBaseValue(ClientMain.dlmvG.player.getAttributeBaseValue(EntityAttributes.ATTACK_SPEED));
                attributeModifiersComponent = attributeModifiersComponent2 = (AttributeModifiersComponent)itemStack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
                if (stringArray == null) break block11;
                if (attributeModifiersComponent == null) break block12;
                attributeModifiersComponent = attributeModifiersComponent2;
            }
            attributeModifiersComponent.applyModifiers(EquipmentSlot.MAINHAND, (registryEntry, entityAttributeModifier) -> {
                block0: {
                    long l = WedAj ^ 0x3B3D759D3DF7L;
                    if (registryEntry != EntityAttributes.ATTACK_SPEED) break block0;
                    entityAttributeInstance2.updateModifier(entityAttributeModifier);
                }
            });
        }
        double d2 = d = entityAttributeInstance2.getValue();
        double d3 = 0.0;
        if (stringArray != null) {
            if (d2 <= d3) {
                return Float.MAX_VALUE;
            }
            d2 = 20.0;
            d3 = d;
        }
        return (float)(d2 / d3);
    }

    public static boolean bzk(ItemStack itemStack) {
        return itemStack.getComponents().contains(DataComponentTypes.FOOD);
    }

    public static boolean bzl(ItemStack itemStack) {
        return itemStack.isIn(ItemTags.AXES);
    }

    public static String bzf(ItemStack itemStack) {
        int n;
        int n2;
        long l;
        block6: {
            int n3;
            block7: {
                block5: {
                    String[] stringArray;
                    block4: {
                        l = WedAj ^ 0xE20184F2F76L;
                        stringArray = Class_jf_d1c4f950.bBe();
                        n3 = itemStack.isEmpty();
                        if (stringArray == null) break block4;
                        if (n3 != 0) break block5;
                        n3 = itemStack.isDamageable();
                    }
                    if (stringArray == null) break block6;
                    if (n3 != 0) break block7;
                }
                return Class_jc_20aa808a.bAa("o", (int)24893, (long)(0x1D0121355EED5684L ^ l));
            }
            n3 = n2 = itemStack.getMaxDamage();
        }
        if ((n = itemStack.getDamage()) >= n2) {
            return Class_jc_20aa808a.bAa("o", (int)20835, (long)(0x2A5D13158B6266D1L ^ l));
        }
        double d = 100.0 - (double)n / (double)n2 * 100.0;
        return String.format((String)((Object)Class_jc_20aa808a.bAa("o", (int)1325, (long)(0x1ED446C2F0D3B29EL ^ l))), d);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean bzo(ItemStack itemStack) {
        float f;
        long l = WedAj ^ 0x10E8AA7B1A21L;
        WeaponComponent weaponComponent = (WeaponComponent)itemStack.get(DataComponentTypes.WEAPON);
        String[] stringArray = Class_jf_d1c4f950.bBe();
        WeaponComponent weaponComponent2 = weaponComponent;
        if (stringArray != null) {
            if (weaponComponent2 == null) return 0 != 0;
            weaponComponent2 = weaponComponent;
        }
        int n = (f = weaponComponent2.comp_3602() - 0.0f) == 0.0f ? 0 : (f > 0.0f ? 1 : -1);
        if (stringArray == null) return n != 0;
        if (n <= 0) return 0 != 0;
        return 1 != 0;
    }

    public static double bzg(Item item) {
        long l = WedAj ^ 0x2F733E18EAB9L;
        ItemCooldownsAccessor itemCooldownsAccessor = (ItemCooldownsAccessor)ClientMain.dlmvG.player.getItemCooldownManager();
        Map map = itemCooldownsAccessor.getCooldowns();
        Object v = map.get(Registries.ITEM.getId((Object)item));
        String[] stringArray = Class_jf_d1c4f950.bBe();
        Object v2 = v;
        if (stringArray != null) {
            if (v2 == null) {
                return 0.0;
            }
            v2 = v;
        }
        CooldownInstanceAccessor cooldownInstanceAccessor = (CooldownInstanceAccessor)v2;
        int n = itemCooldownsAccessor.getTickCount();
        int n2 = cooldownInstanceAccessor.getEndTime();
        float f = ClientMain.dlmvG.getRenderTickCounter().getTickProgress(true);
        double d = (float)n2 - ((float)n + f);
        return Class_mZ_07f59a29.csb(Math.max(0.0, d) * 50.0 / 1000.0, 1);
    }

    public static boolean bzn() {
        return Class_jc_20aa808a.bzo(ClientMain.dlmvG.player.getMainHandStack());
    }

    public static boolean bzm(ItemStack itemStack) {
        return itemStack.isIn(ItemTags.SPEARS);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean bzp(ItemStack itemStack) {
        long l = WedAj ^ 0x156D6A90FEFDL;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        int n = itemStack.getDamage();
        if (stringArray != null) {
            if (n >= itemStack.getMaxDamage() - 1) return 0 != 0;
            n = itemStack.isOf(Items.ELYTRA) ? 1 : 0;
        }
        if (stringArray == null) return n != 0;
        if (n == 0) return 0 != 0;
        return 1 != 0;
    }

    public static boolean bzq(ItemStack itemStack) {
        return Class_jh_282f5b34.bCg(itemStack, (RegistryKey<Enchantment>)Enchantments.WIND_BURST);
    }

    private static int bAb(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x46A7;
        if (ZHAjc[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = NCEKq[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])uhkkf.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    uhkkf.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jc_20aa808a", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_jc_20aa808a.ZHAjc[n2] = n3;
        }
        return ZHAjc[n2];
    }

    public static float bzu(ItemStack itemStack, LivingEntity livingEntity) {
        EntityAttributeInstance entityAttributeInstance2;
        block8: {
            AttributeModifiersComponent attributeModifiersComponent;
            block7: {
                AttributeModifiersComponent attributeModifiersComponent2;
                String[] stringArray;
                block6: {
                    long l = WedAj ^ 0x4CF2A6C0034BL;
                    EntityAttributeInstance entityAttributeInstance3 = livingEntity.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE);
                    entityAttributeInstance2 = new EntityAttributeInstance(EntityAttributes.ATTACK_DAMAGE, entityAttributeInstance -> {});
                    stringArray = Class_jf_d1c4f950.bBe();
                    entityAttributeInstance2.setBaseValue(entityAttributeInstance3.getBaseValue());
                    attributeModifiersComponent2 = entityAttributeInstance3.getModifiers().iterator();
                    while (attributeModifiersComponent2.hasNext()) {
                        EntityAttributeModifier entityAttributeModifier2 = (EntityAttributeModifier)attributeModifiersComponent2.next();
                        entityAttributeInstance2.addTemporaryModifier(entityAttributeModifier2);
                        if (stringArray != null) {
                            if (stringArray != null) continue;
                        }
                        break block6;
                    }
                    entityAttributeInstance2.removeModifier(Item.BASE_ATTACK_DAMAGE_MODIFIER_ID);
                }
                attributeModifiersComponent = attributeModifiersComponent2 = (AttributeModifiersComponent)itemStack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
                if (stringArray == null) break block7;
                if (attributeModifiersComponent == null) break block8;
                attributeModifiersComponent = attributeModifiersComponent2;
            }
            attributeModifiersComponent.applyModifiers(EquipmentSlot.MAINHAND, (registryEntry, entityAttributeModifier) -> {
                block0: {
                    long l = WedAj ^ 0x78A93D4D4339L;
                    if (registryEntry != EntityAttributes.ATTACK_DAMAGE) break block0;
                    entityAttributeInstance2.updateModifier(entityAttributeModifier);
                }
            });
        }
        return (float)entityAttributeInstance2.getValue();
    }

    private static void bzH(StringBuilder stringBuilder, Style style) {
        block15: {
            int n;
            String[] stringArray;
            long l;
            block14: {
                Style style2;
                block12: {
                    block13: {
                        l = WedAj ^ 0x4EC643400DB0L;
                        stringArray = Class_jf_d1c4f950.bBe();
                        style2 = style;
                        if (stringArray == null) break block12;
                        if (style2.getColor() == null) break block13;
                        n = style.getColor().getRgb();
                        if (stringArray == null) break block14;
                        Character c = Class_jk_a0800133.bDx(n);
                        if (c != null) {
                            stringBuilder.append((char)Class_jc_20aa808a.bAd("q", (int)29286, (long)(0x1E507CC8DF729E2BL ^ l))).append(c);
                        }
                    }
                    style2 = style;
                }
                n = style2.isBold();
            }
            if (stringArray != null) {
                if (n != 0) {
                    stringBuilder.append((String)((Object)Class_jc_20aa808a.bAa("o", (int)16883, (long)(0x7DD5AAAB28AFD48AL ^ l))));
                }
                n = style.isItalic() ? 1 : 0;
            }
            if (stringArray != null) {
                if (n != 0) {
                    stringBuilder.append((String)((Object)Class_jc_20aa808a.bAa("o", (int)30876, (long)(0x1EF17EE49D7CEDEDL ^ l))));
                }
                n = style.isUnderlined() ? 1 : 0;
            }
            if (stringArray != null) {
                if (n != 0) {
                    stringBuilder.append((String)((Object)Class_jc_20aa808a.bAa("o", (int)10733, (long)(0x491A415659993C9EL ^ l))));
                }
                n = style.isStrikethrough() ? 1 : 0;
            }
            if (stringArray != null) {
                if (n != 0) {
                    stringBuilder.append((String)((Object)Class_jc_20aa808a.bAa("o", (int)25573, (long)(0x7C29E3D0E4937697L ^ l))));
                }
                n = style.isObfuscated() ? 1 : 0;
            }
            if (n == 0) break block15;
            stringBuilder.append((String)((Object)Class_jc_20aa808a.bAa("o", (int)24338, (long)(0x646D7F6E32424A62L ^ l))));
        }
    }

    public static boolean bzI(Item item) {
        long l = WedAj ^ 0x3709BB6E6CF3L;
        return Class_jc_20aa808a.bzL(item, (String)((Object)Class_jc_20aa808a.bAa("o", (int)29443, (long)(0x3EC1E65DD45F073AL ^ l))), World.class, PlayerEntity.class, Hand.class);
    }

    public static int bzU() {
        return jlfNZ;
    }

    public static Item bzz(String string) {
        Item item;
        block14: {
            Object object;
            String[] stringArray;
            block23: {
                block22: {
                    Identifier identifier;
                    block21: {
                        Identifier identifier2;
                        block20: {
                            Item item2;
                            Item item3;
                            block19: {
                                String string2;
                                block17: {
                                    block18: {
                                        block16: {
                                            block15: {
                                                long l = WedAj ^ 0x551B48CCD89BL;
                                                stringArray = Class_jf_d1c4f950.bBe();
                                                string2 = string;
                                                if (stringArray == null) break block15;
                                                if (string2 == null) break block16;
                                                string2 = string;
                                            }
                                            if (stringArray == null) break block17;
                                            if (!string2.isBlank()) break block18;
                                        }
                                        return null;
                                    }
                                    string2 = alGsc.get(string);
                                }
                                item2 = item3 = (Item)string2;
                                if (stringArray == null) break block19;
                                if (item2 == null) break block20;
                                item2 = item3;
                            }
                            return item2 == vSOjt ? null : item3;
                        }
                        item = null;
                        identifier = identifier2 = Identifier.tryParse((String)string);
                        if (stringArray == null) break block21;
                        if (identifier == null) break block22;
                        identifier = Registries.ITEM.getOptionalValue(identifier2).orElse(null);
                    }
                    item = (Item)identifier;
                }
                if (item != null) break block23;
                for (Item item4 : Registries.ITEM) {
                    block25: {
                        block24: {
                            if (stringArray == null) break block24;
                            object = string;
                            if (stringArray == null) break block14;
                            if (!((String)object).equals(item4.getTranslationKey())) break block25;
                            item = item4;
                        }
                        if (stringArray != null) break;
                    }
                    if (stringArray != null) continue;
                }
            }
            Item item5 = item;
            if (stringArray != null) {
                item5 = item5 == null ? vSOjt : item;
            }
            object = alGsc.put(string, item5);
        }
        return item;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public static Class_mG_52c8d386 bzB(Item var0) {
        block38: {
            block32: {
                block37: {
                    block31: {
                        block36: {
                            block35: {
                                block34: {
                                    block33: {
                                        var1_1 = Class_jc_20aa808a.WedAj ^ 78620183132112L;
                                        var3_2 = Class_jf_d1c4f950.bBe();
                                        if (var0 == null) {
                                            return Class_mG_52c8d386.hoGuU;
                                        }
                                        var4_3 = Registries.ITEM.getId((Object)var0);
                                        var5_4 = var4_3.toString();
                                        v0 = Class_jc_20aa808a.IckfH;
                                        v1 = var5_4;
                                        if (var3_2 == null) break block33;
                                        if (!v0.containsKey(v1)) break block34;
                                        v0 = Class_jc_20aa808a.IckfH;
                                        v1 = var5_4;
                                    }
                                    return v0.get(v1);
                                }
                                v2 /* !! */  = var6_5 = Class_jc_20aa808a.bzD(var0);
                                if (var3_2 == null) break block35;
                                if (v2 /* !! */  != null) break block36;
                                v2 /* !! */  = Class_jc_20aa808a.IckfH.put(var5_4, Class_mG_52c8d386.hoGuU);
                            }
                            return Class_mG_52c8d386.hoGuU;
                        }
                        var7_6 = ClientMain.dlmvG.getResourceManager().open(var6_5);
                        var8_8 = NativeImage.read((InputStream)var7_6);
                        var9_10 = Class_jc_20aa808a.bzC(var8_8, 2);
                        Class_jc_20aa808a.IckfH.put(var5_4, var9_10);
                        var10_13 = var9_10;
                        v3 = var8_8;
                        if (var3_2 == null) break block31;
                        if (v3 == null) break block37;
                        v3 = var8_8;
                    }
                    v3.close();
                }
                v4 = var7_6;
                if (var3_2 == null) break block32;
                if (v4 == null) break block38;
                v4 = var7_6;
            }
            v4.close();
        }
        return var10_13;
        {
            catch (Throwable var9_11) {
                try {
                    try {
                        block39: {
                            v5 = var8_8;
                            if (var3_2 == null) ** GOTO lbl55
                            if (v5 == null) break block39;
                            try {
                                v5 = var8_8;
lbl55:
                                // 2 sources

                                v5.close();
                            }
                            catch (Throwable var10_14) {
                                var9_11.addSuppressed(var10_14);
                            }
                        }
                        throw var9_11;
                    }
                    catch (Throwable var8_9) {
                        block40: {
                            v6 = var7_6;
                            if (var3_2 == null) ** GOTO lbl67
                            if (v6 == null) break block40;
                            try {
                                v6 = var7_6;
lbl67:
                                // 2 sources

                                v6.close();
                            }
                            catch (Throwable var9_12) {
                                var8_9.addSuppressed(var9_12);
                            }
                        }
                        throw var8_9;
                    }
                }
                catch (Exception var7_7) {
                    Class_jc_20aa808a.IckfH.put(var5_4, Class_mG_52c8d386.hoGuU);
                    return Class_mG_52c8d386.hoGuU;
                }
            }
        }
    }

    private static Class_mG_52c8d386 bzC(NativeImage nativeImage, int n) {
        double d;
        double d2;
        Class_mG_52c8d386 class_mG_52c8d386;
        double d3;
        String[] stringArray;
        double d4;
        double d5;
        block18: {
            int n2;
            double d6;
            block13: {
                long l = WedAj ^ 0x20EEFC065516L;
                int n3 = nativeImage.getWidth();
                int n4 = nativeImage.getHeight();
                d6 = 0.0;
                d5 = 0.0;
                d4 = 0.0;
                stringArray = Class_jf_d1c4f950.bBe();
                d3 = 0.0;
                class_mG_52c8d386 = Class_mG_52c8d386.hoGuU;
                float f = -1.0f;
                int n5 = 0;
                block0: while (true) {
                    int n6 = n5;
                    block1: while (n6 < n4) {
                        n2 = 0;
                        if (stringArray == null) break block13;
                        int n7 = n2;
                        while (n7 < n3) {
                            block17: {
                                block15: {
                                    int n8;
                                    int n9;
                                    int n10;
                                    int n11;
                                    block16: {
                                        int n12;
                                        block14: {
                                            n6 = (n7 + n5 * n3) % n;
                                            if (stringArray == null) continue block1;
                                            if (stringArray == null) break block14;
                                            if (n6 != 0) break block15;
                                            n12 = nativeImage.getColorArgb(n7, n5);
                                        }
                                        void var19_16 = n12;
                                        int n13 = var19_16 >> Class_jc_20aa808a.bAd("q", (int)25841, (long)(0x1A29EBF464F35010L ^ l)) & Class_jc_20aa808a.bAd("q", (int)22631, (long)(0x7112DAF392D8EC84L ^ l));
                                        n11 = var19_16 >> Class_jc_20aa808a.bAd("q", (int)13107, (long)(0x4BE67E9FB97A07DDL ^ l)) & Class_jc_20aa808a.bAd("q", (int)24819, (long)(0x3F36EF9CAF3D541BL ^ l));
                                        n10 = var19_16 >> Class_jc_20aa808a.bAd("q", (int)19805, (long)(0x710E407F1689F9A9L ^ l)) & Class_jc_20aa808a.bAd("q", (int)24819, (long)(0x3F36EF9CAF3D541BL ^ l));
                                        n9 = var19_16 & Class_jc_20aa808a.bAd("q", (int)24819, (long)(0x3F36EF9CAF3D541BL ^ l));
                                        n8 = n13;
                                        if (stringArray == null) break block16;
                                        if (n8 < Class_jc_20aa808a.bAd("q", (int)18498, (long)(0x54072DA9B867CA2L ^ l)) && stringArray != null) break block15;
                                        n8 = n11;
                                    }
                                    Class_mG_52c8d386 class_mG_52c8d3862 = Class_mG_52c8d386.cnP(n8, n10, n9);
                                    float f2 = class_mG_52c8d3862.cok();
                                    float f3 = class_mG_52c8d3862.coj();
                                    float f4 = (0.35f + f2 * 0.65f) * (0.45f + f3 * 0.55f);
                                    d6 += (double)((float)n11 * f4);
                                    d5 += (double)((float)n10 * f4);
                                    d4 += (double)((float)n9 * f4);
                                    d3 += (double)f4;
                                    float f5 = f2 * 0.7f + f3 * 0.3f;
                                    if (stringArray == null) break block17;
                                    if (f5 > f) {
                                        f = f5;
                                        class_mG_52c8d386 = class_mG_52c8d3862;
                                    }
                                }
                                ++n7;
                            }
                            if (stringArray != null) continue;
                        }
                        ++n5;
                        if (stringArray != null) continue block0;
                    }
                    break;
                }
                d2 = d3;
                d = 0.0;
                if (stringArray == null) break block18;
                double d7 = d2 - d;
                n2 = d7 == 0.0 ? 0 : (d7 < 0.0 ? -1 : 1);
            }
            if (n2 <= 0) {
                return Class_mG_52c8d386.hoGuU;
            }
            d2 = d6;
            d = d3;
        }
        Class_mG_52c8d386 class_mG_52c8d3863 = Class_mG_52c8d386.cnP((float)(d2 / d), (float)(d5 / d3), (float)(d4 / d3));
        Class_mG_52c8d386 class_mG_52c8d3864 = class_mG_52c8d3863.coc(class_mG_52c8d386, 0.35f);
        float f = class_mG_52c8d3864.cok();
        float f6 = class_mG_52c8d3864.coj();
        float f7 = f;
        float f8 = 0.2f;
        if (stringArray != null) {
            if (f7 > f8) {
                f = Math.min(1.0f, f * 1.1f);
            }
            f6 = Math.min(1.0f, Math.max(0.72f, f6 * 1.25f));
            f7 = class_mG_52c8d3864.coi();
            f8 = f;
        }
        return Class_mG_52c8d386.cnS(f7, f8, f6).coa(class_mG_52c8d3864.cou());
    }

    public static String bzF(Item item) {
        long l = WedAj ^ 0x149A04DD7A9EL;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        Item item2 = item;
        if (stringArray != null) {
            if (item2 == null) {
                return "";
            }
            item2 = item;
        }
        return item2.getDefaultStack().getName().getString();
    }

    private static boolean bzL(Item item, String string, Class<?> ... classArray) {
        long l = WedAj ^ 0x11A5EC7FA41AL;
        try {
            return item.getClass().getMethod(string, classArray).getDeclaringClass() != Item.class;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            return false;
        }
    }

    private static Object bzZ(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_jc_20aa808a.bzY(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static Set<Item> bzN() {
        Field[] fieldArray;
        long l = WedAj ^ 0x3D0C2FFEE6D9L;
        LinkedHashSet<Item> linkedHashSet = new LinkedHashSet<Item>();
        Class<Blocks> clazz = Blocks.class;
        for (Field field : fieldArray = clazz.getDeclaredFields()) {
            try {
                Block block;
                Object object = field.get(null);
                if (!(object instanceof Block) || (block = (Block)object).asItem() == Items.AIR) continue;
                linkedHashSet.add(block.asItem());
            }
            catch (IllegalAccessException illegalAccessException) {
                // empty catch block
            }
        }
        return linkedHashSet;
    }

    public static boolean bzx() {
        Class_oI_0a14d25a class_oI_0a14d25a;
        Optional<Hand> optional;
        int n;
        String[] stringArray;
        block11: {
            int n2;
            block12: {
                boolean bl;
                block9: {
                    block10: {
                        long l = WedAj ^ 0x6596B23E856CL;
                        ItemStack itemStack = ClientMain.dlmvG.player.getEquippedStack(EquipmentSlot.CHEST);
                        stringArray = Class_jf_d1c4f950.bBe();
                        bl = itemStack.isOf(Items.ELYTRA);
                        if (stringArray != null) {
                            if (!bl) {
                                return false;
                            }
                            bl = ClientMain.dlmvG.player.isGliding();
                        }
                        if (stringArray == null) break block9;
                        if (!bl) break block10;
                        n2 = ClientMain.dlmvG.player.isUsingItem();
                        if (stringArray == null) break block11;
                        if (n2 == 0) break block12;
                    }
                    bl = false;
                }
                return bl;
            }
            n2 = n = ClientMain.dlmvG.player.getInventory().getSelectedSlot();
        }
        if ((optional = Class_oR_7de26dc4.cKi(Items.FIREWORK_ROCKET)).isEmpty()) {
            Class_oI_0a14d25a class_oI_0a14d25a2 = class_oI_0a14d25a = Class_oP_6ecdf500.cJm().cJu(Items.FIREWORK_ROCKET);
            if (stringArray != null) {
                if (class_oI_0a14d25a2 == null) {
                    return false;
                }
                class_oI_0a14d25a2 = class_oI_0a14d25a;
            }
            Class_oR_7de26dc4.cJS(class_oI_0a14d25a2.cIE());
            optional = Optional.of(Hand.MAIN_HAND);
        }
        class_oI_0a14d25a = ClientMain.dlmvG.interactionManager.interactItem((PlayerEntity)ClientMain.dlmvG.player, optional.get());
        int n3 = n;
        if (stringArray != null) {
            Class_oR_7de26dc4.cJS(n3);
            n3 = class_oI_0a14d25a != ActionResult.FAIL ? 1 : 0;
        }
        return n3 != 0;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public static Class_mG_52c8d386 bzA(Item var0) {
        block38: {
            block32: {
                block37: {
                    block31: {
                        block36: {
                            block35: {
                                block34: {
                                    block33: {
                                        var1_1 = Class_jc_20aa808a.WedAj ^ 18994902555722L;
                                        var3_2 = Class_jf_d1c4f950.bBe();
                                        if (var0 == null) {
                                            return Class_mG_52c8d386.hoGuU;
                                        }
                                        var4_3 = Registries.ITEM.getId((Object)var0);
                                        var5_4 = var4_3.toString();
                                        v0 = Class_jc_20aa808a.xxvZl;
                                        v1 = var5_4;
                                        if (var3_2 == null) break block33;
                                        if (!v0.containsKey(v1)) break block34;
                                        v0 = Class_jc_20aa808a.xxvZl;
                                        v1 = var5_4;
                                    }
                                    return v0.get(v1);
                                }
                                v2 /* !! */  = var6_5 = Class_jc_20aa808a.bzD(var0);
                                if (var3_2 == null) break block35;
                                if (v2 /* !! */  != null) break block36;
                                v2 /* !! */  = Class_jc_20aa808a.xxvZl.put(var5_4, Class_mG_52c8d386.hoGuU);
                            }
                            return Class_mG_52c8d386.hoGuU;
                        }
                        var7_6 = ClientMain.dlmvG.getResourceManager().open(var6_5);
                        var8_8 = NativeImage.read((InputStream)var7_6);
                        var9_10 = Class_qO_d37ef529.dcM(var8_8, 2);
                        Class_jc_20aa808a.xxvZl.put(var5_4, var9_10);
                        var10_13 = var9_10;
                        v3 = var8_8;
                        if (var3_2 == null) break block31;
                        if (v3 == null) break block37;
                        v3 = var8_8;
                    }
                    v3.close();
                }
                v4 = var7_6;
                if (var3_2 == null) break block32;
                if (v4 == null) break block38;
                v4 = var7_6;
            }
            v4.close();
        }
        return var10_13;
        {
            catch (Throwable var9_11) {
                try {
                    try {
                        block39: {
                            v5 = var8_8;
                            if (var3_2 == null) ** GOTO lbl55
                            if (v5 == null) break block39;
                            try {
                                v5 = var8_8;
lbl55:
                                // 2 sources

                                v5.close();
                            }
                            catch (Throwable var10_14) {
                                var9_11.addSuppressed(var10_14);
                            }
                        }
                        throw var9_11;
                    }
                    catch (Throwable var8_9) {
                        block40: {
                            v6 = var7_6;
                            if (var3_2 == null) ** GOTO lbl67
                            if (v6 == null) break block40;
                            try {
                                v6 = var7_6;
lbl67:
                                // 2 sources

                                v6.close();
                            }
                            catch (Throwable var9_12) {
                                var8_9.addSuppressed(var9_12);
                            }
                        }
                        throw var8_9;
                    }
                }
                catch (Exception var7_7) {
                    Class_jc_20aa808a.xxvZl.put(var5_4, Class_mG_52c8d386.hoGuU);
                    return Class_mG_52c8d386.hoGuU;
                }
            }
        }
    }

    public static String bzG(Text text) {
        StringBuilder stringBuilder = new StringBuilder();
        boolean[] blArray = new boolean[]{true};
        text.visit((style, string) -> {
            block6: {
                int n;
                boolean[] blArray2;
                boolean bl;
                long l;
                block5: {
                    l = WedAj ^ 0x773EEA3E8843L;
                    String[] stringArray = Class_jf_d1c4f950.bBe();
                    bl = string.isEmpty();
                    if (stringArray == null) break block5;
                    if (bl) {
                        return Optional.empty();
                    }
                    blArray2 = blArray;
                    n = 0;
                    if (stringArray == null) break block6;
                    bl = blArray2[n];
                }
                if (!bl) {
                    stringBuilder.append((String)((Object)Class_jc_20aa808a.bAa("o", (int)25640, (long)(0x69B00FF0AF4374A0L ^ l))));
                }
                Class_jc_20aa808a.bzH(stringBuilder, style);
                stringBuilder.append(string);
                blArray2 = blArray;
                n = 0;
            }
            blArray2[n] = false;
            return Optional.empty();
        }, Style.EMPTY);
        return stringBuilder.toString();
    }

    public static int bzV() {
        int n = Class_jc_20aa808a.bzU();
        if (n == 0) {
            return 18;
        }
        return 0;
    }

    public static boolean bzJ(Item item) {
        long l = WedAj ^ 0x687D2F51F432L;
        return Class_jc_20aa808a.bzL(item, (String)((Object)Class_jc_20aa808a.bAa("o", (int)76, (long)(0x5CD8D96AC7A66CB8L ^ l))), ItemUsageContext.class);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean bzw(LivingEntity livingEntity) {
        double d;
        block5: {
            String[] stringArray;
            block4: {
                long l = WedAj ^ 0x73CF09DC9D40L;
                stringArray = Class_jf_d1c4f950.bBe();
                double d2 = livingEntity.fallDistance - 1.5;
                d = d2 == 0.0 ? 0 : (d2 > 0.0 ? 1 : -1);
                if (stringArray == null) break block4;
                if (d <= 0) break block5;
                d = (double)livingEntity.isGliding();
            }
            if (stringArray == null) return (boolean)d;
            if (d == false) {
                d = 1.0;
                return (boolean)d;
            }
        }
        d = 0.0;
        return (boolean)d;
    }

    public static String bzE(ItemStack itemStack) {
        return Class_jc_20aa808a.bzG(itemStack.getName());
    }

    /*
     * Unable to fully structure code
     */
    public static Identifier bzD(Item var0) {
        var1_1 = Class_jc_20aa808a.WedAj ^ 37062398389628L;
        var3_2 = Class_jf_d1c4f950.bBe();
        v0 = var0;
        if (var3_2 == null) ** GOTO lbl9
        if (v0 == null) {
            return null;
        }
        try {
            v0 = var0;
lbl9:
            // 2 sources

            var4_3 = v0.getDefaultStack();
            var5_5 = new ItemRenderState();
            ClientMain.dlmvG.getItemModelManager().clearAndUpdate(var5_5, var4_3, ItemDisplayContext.GUI, (World)ClientMain.dlmvG.world, (HeldItemContext)ClientMain.dlmvG.player, 0);
            v1 = var6_6 = var5_5.getParticleSprite(Random.create((long)0L));
            if (var3_2 != null) {
                if (v1 == null) {
                    return null;
                }
                v1 = var6_6;
            }
            var7_7 = v1.getContents().getId();
            return Identifier.tryParse((String)(var7_7.getNamespace() + (String)Class_jc_20aa808a.bAa("o", (int)14745, (long)(7329241294461013037L ^ var1_1)) + var7_7.getPath() + (String)Class_jc_20aa808a.bAa("o", (int)6813, (long)(854439150398418726L ^ var1_1))));
        }
        catch (Exception var4_4) {
            return null;
        }
    }

    private static Set<Item> bzM() {
        Field[] fieldArray;
        long l = WedAj ^ 0xFF58004F622L;
        LinkedHashSet<Item> linkedHashSet = new LinkedHashSet<Item>();
        Class<Items> clazz = Items.class;
        for (Field field : fieldArray = clazz.getDeclaredFields()) {
            try {
                Item item;
                Object object = field.get(null);
                if (!(object instanceof Item) || (item = (Item)object) == Items.AIR) continue;
                linkedHashSet.add(item);
            }
            catch (IllegalAccessException illegalAccessException) {
                // empty catch block
            }
        }
        return linkedHashSet;
    }

    public static void bzT(int n) {
        jlfNZ = n;
    }

    public static ChargedProjectilesComponent bzy(ItemStack itemStack) {
        return (ChargedProjectilesComponent)itemStack.get(DataComponentTypes.CHARGED_PROJECTILES);
    }

    public static float bzv(Entity entity, float f, DamageSource damageSource) {
        block8: {
            double d;
            block15: {
                World world;
                double d2;
                LivingEntity livingEntity;
                block14: {
                    World world2;
                    String[] stringArray;
                    block11: {
                        double d3;
                        double d4;
                        block12: {
                            block13: {
                                double d5;
                                block9: {
                                    block10: {
                                        Entity entity2;
                                        block7: {
                                            long l = WedAj ^ 0x6D8953B944FL;
                                            Entity entity3 = damageSource.getSource();
                                            stringArray = Class_jf_d1c4f950.bBe();
                                            entity2 = entity3;
                                            if (stringArray == null) break block7;
                                            if (!(entity2 instanceof LivingEntity)) break block8;
                                            entity2 = entity3;
                                        }
                                        if (!Class_jc_20aa808a.bzw(livingEntity = (LivingEntity)entity2)) {
                                            return 0.0f;
                                        }
                                        double d6 = 3.0;
                                        double d7 = 8.0;
                                        d2 = livingEntity.fallDistance;
                                        double d8 = d2 - 3.0;
                                        d5 = d8 == 0.0 ? 0 : (d8 < 0.0 ? -1 : 1);
                                        if (stringArray == null) break block9;
                                        if (d5 > 0) break block10;
                                        d = 4.0 * d2;
                                        if (stringArray != null) break block11;
                                    }
                                    d4 = d2;
                                    d3 = 8.0;
                                    if (stringArray == null) break block12;
                                    double d9 = d4 - d3;
                                    d5 = d9 == 0.0 ? 0 : (d9 < 0.0 ? -1 : 1);
                                }
                                if (d5 > 0) break block13;
                                d = 12.0 + 2.0 * (d2 - 3.0);
                                if (stringArray != null) break block11;
                            }
                            d4 = 22.0 + d2;
                            d3 = 8.0;
                        }
                        d = d4 - d3;
                    }
                    world = world2 = livingEntity.getEntityWorld();
                    if (stringArray == null) break block14;
                    if (!(world instanceof ServerWorld)) break block15;
                    world = world2;
                }
                ServerWorld serverWorld = (ServerWorld)world;
                return (float)(d + (double)EnchantmentHelper.getSmashDamagePerFallenBlock((ServerWorld)serverWorld, (ItemStack)livingEntity.getWeaponStack(), (Entity)entity, (DamageSource)damageSource, (float)0.0f) * d2);
            }
            return (float)d;
        }
        return 0.0f;
    }

    public static boolean bzK(Item item) {
        long l = WedAj ^ 0x2D68DB775FBL;
        return Class_jc_20aa808a.bzL(item, (String)((Object)Class_jc_20aa808a.bAa("o", (int)20168, (long)(0x7A0FAC25126923FDL ^ l))), ItemStack.class, PlayerEntity.class, LivingEntity.class, Hand.class);
    }

    private static String bzY(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x3F96;
        if (GXVbC[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])baifd.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    baifd.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jc_20aa808a", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = UOSQi[n2].getBytes("ISO-8859-1");
            Class_jc_20aa808a.GXVbC[n2] = Class_jc_20aa808a.bzX(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return GXVbC[n2];
    }

    private static int bAc(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_jc_20aa808a.bAb(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static String bzX(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Class_jc_20aa808a.WedAj = Class_gb_9d201141.aYR(4430819896916382669L, -3846377035431529824L, MethodHandles.lookup().lookupClass()).a(135650011832529L);
                        var20 = Class_jc_20aa808a.WedAj ^ 11685133715039L;
                        Class_jc_20aa808a.baifd = new HashMap<K, V>(13);
                        Class_jc_20aa808a.bzT(0);
                        var11_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var20 >>> 56);
                        for (var12_2 = 1; var12_2 < 8; ++var12_2) {
                            v2 = v2;
                            v2[var12_2] = (byte)(var20 << var12_2 * 8 >>> 56);
                        }
                        var11_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var18_3 = new String[14];
                        var16_4 = 0;
                        var15_5 = "x\u0093@\u00fa\u00ea5\u00c6n\u00edI\u00a9\u00b7\u009a\u00e4d\u0014\u0010\u00ca4\u008dc~\u0006\rL\u0092t\u00ca{\u0091\u00e7\u00dfl\u0010=\u008e\u00c6Vz\u0007\u009a\u00dc!T\u00e0;\u00f0]0,\u0010_2|\u00f3\u00e3\u00c7\u00aa\u00c2\u00da\u009c\u00e2QYZI\u00e1\u0010\u00e3\n\f\u00fb\u00f4N\u00bf\u0002a\u00df\u00be\u00caP\u0097\u00aeo\u0010s\u0013\u00b1[7Y\u00a0\u00ae\u007f\u00fd\u00e9i\u00f2\u0087\u00c8v\u0010\u00b5\u00f5\u00c4\u0002\u0016\u00d9w\u00df.\u0007\u00f1\u00c8Y,\u009d\u00e6\u0010\u0002%\u00f9\u00b0aaO\u009cli\u0081\u00c0\u00c5\u0083\u0004\u0099\u0010\u00cc\u0084,x{\u00ceW\u00cc\u0090\t\u00bc\u00c1a\r\u0019\u0091\u0010\u00b6e3\u00c0&`w\u0082\u00af\u00e8N\u008dtS\u00fc\u00d4\u0010\u00e3n\u0015Cha5mp\u0088W\u009e\u00cc\u00f4\u00b6\t .{'_\u00cd\u0095NG\u00ed\u00c2\u00a56\u001fS\u00c4Y\u008eIJ,\u00dc\u00c16.\u0080r\u00d5\u009es@\u008fu";
                        var17_6 = "x\u0093@\u00fa\u00ea5\u00c6n\u00edI\u00a9\u00b7\u009a\u00e4d\u0014\u0010\u00ca4\u008dc~\u0006\rL\u0092t\u00ca{\u0091\u00e7\u00dfl\u0010=\u008e\u00c6Vz\u0007\u009a\u00dc!T\u00e0;\u00f0]0,\u0010_2|\u00f3\u00e3\u00c7\u00aa\u00c2\u00da\u009c\u00e2QYZI\u00e1\u0010\u00e3\n\f\u00fb\u00f4N\u00bf\u0002a\u00df\u00be\u00caP\u0097\u00aeo\u0010s\u0013\u00b1[7Y\u00a0\u00ae\u007f\u00fd\u00e9i\u00f2\u0087\u00c8v\u0010\u00b5\u00f5\u00c4\u0002\u0016\u00d9w\u00df.\u0007\u00f1\u00c8Y,\u009d\u00e6\u0010\u0002%\u00f9\u00b0aaO\u009cli\u0081\u00c0\u00c5\u0083\u0004\u0099\u0010\u00cc\u0084,x{\u00ceW\u00cc\u0090\t\u00bc\u00c1a\r\u0019\u0091\u0010\u00b6e3\u00c0&`w\u0082\u00af\u00e8N\u008dtS\u00fc\u00d4\u0010\u00e3n\u0015Cha5mp\u0088W\u009e\u00cc\u00f4\u00b6\t .{'_\u00cd\u0095NG\u00ed\u00c2\u00a56\u001fS\u00c4Y\u008eIJ,\u00dc\u00c16.\u0080r\u00d5\u009es@\u008fu".length();
                        var14_7 = 16;
                        var13_8 = -1;
lbl21:
                        // 2 sources

                        while (true) {
                            v3 = ++var13_8;
                            v4 = var15_5.substring(v3, v3 + var14_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl26:
                        // 1 sources

                        while (true) {
                            var18_3[var16_4++] = Class_jc_20aa808a.bzX(var19_9).intern();
                            if ((var13_8 += var14_7) < var17_6) {
                                var14_7 = var15_5.charAt(var13_8);
                                ** continue;
                            }
                            var15_5 = "\u0012\u0081+(\u00d5\u000f\u00cb\u00df\u008e\u0085<\u0097\u0014\u0097\u00ec\u0086(\u00cc\u00b4a]8\u009a\u0007\u0081o\u00e2]HE\u0096 r\u00e9\u009b\u00a5\u001f\u001d{\u0005[\u00ba\u001cQ\u00b4\u0091\rH\u0006,\u001d\u00ee\u0098\u00c7EKe";
                            var17_6 = "\u0012\u0081+(\u00d5\u000f\u00cb\u00df\u008e\u0085<\u0097\u0014\u0097\u00ec\u0086(\u00cc\u00b4a]8\u009a\u0007\u0081o\u00e2]HE\u0096 r\u00e9\u009b\u00a5\u001f\u001d{\u0005[\u00ba\u001cQ\u00b4\u0091\rH\u0006,\u001d\u00ee\u0098\u00c7EKe".length();
                            var14_7 = 16;
                            var13_8 = -1;
lbl35:
                            // 2 sources

                            while (true) {
                                v6 = ++var13_8;
                                v4 = var15_5.substring(v6, v6 + var14_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl40:
                        // 1 sources

                        while (true) {
                            var18_3[var16_4++] = Class_jc_20aa808a.bzX(var19_9).intern();
                            if ((var13_8 += var14_7) < var17_6) {
                                var14_7 = var15_5.charAt(var13_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var19_9 = var11_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl52:
                        // 1 sources

                        ** continue;
                    }
                }
                Class_jc_20aa808a.UOSQi = var18_3;
                Class_jc_20aa808a.GXVbC = new String[14];
                Class_jc_20aa808a.uhkkf = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var20 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var20 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[20];
                var3_13 = 0;
                var4_14 = "`\u00d0\u008e\u00d0\u00d7\u00e7\u0002\u00bb5.2\u0006<\u009e\u00b0\u00ca\u000ff\u00b7w\u0088\u009b\u00e7\u00888\u00cfC\u00dd[\u0019#\u001bC\u001dao\b\u00fc\u0083\u00b9A\u008a\u00d4>R\u00ad4\u00e8\u0011\u0016K\u00b6\u00e9G\u001f.C%\u0019\u0001\u008c\u00fb\u00e2\u008fX\u00c7Uk\u0099lnj\u00a9j\u00d7\u00d0\u00bf\u0007\u001d\u0017tjj\u00f0N\u00974B\u00f1%J\u00a9\u0095\u00f29\u00b6\u008c{\u00dc\u00e4\u0086\u00e7{\u00e6S\u0002]\u0089\u00ff?\u00e5\u0014X\u00b0K\u00ca\u00f8\u00f2b\u00cb\u00b4\u00c1\u0089\u00079z\u00d7\u00a8KQ\u0010}'\u0097\u00e4\u00aa\u0086\u00f5uW\u0000\u0083\u0098\u00bd";
                var5_15 = "`\u00d0\u008e\u00d0\u00d7\u00e7\u0002\u00bb5.2\u0006<\u009e\u00b0\u00ca\u000ff\u00b7w\u0088\u009b\u00e7\u00888\u00cfC\u00dd[\u0019#\u001bC\u001dao\b\u00fc\u0083\u00b9A\u008a\u00d4>R\u00ad4\u00e8\u0011\u0016K\u00b6\u00e9G\u001f.C%\u0019\u0001\u008c\u00fb\u00e2\u008fX\u00c7Uk\u0099lnj\u00a9j\u00d7\u00d0\u00bf\u0007\u001d\u0017tjj\u00f0N\u00974B\u00f1%J\u00a9\u0095\u00f29\u00b6\u008c{\u00dc\u00e4\u0086\u00e7{\u00e6S\u0002]\u0089\u00ff?\u00e5\u0014X\u00b0K\u00ca\u00f8\u00f2b\u00cb\u00b4\u00c1\u0089\u00079z\u00d7\u00a8KQ\u0010}'\u0097\u00e4\u00aa\u0086\u00f5uW\u0000\u0083\u0098\u00bd".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl79:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00a8J.rJ\u00e3\u00e1WK\u00db(\u00bd\u00ad\u0013\u0085\u00f0";
                    var5_15 = "\u00a8J.rJ\u00e3\u00e1WK\u00db(\u00bd\u00ad\u0013\u0085\u00f0".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl92:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl105:
                // 1 sources

                ** continue;
            }
        }
        Class_jc_20aa808a.NCEKq = var6_12;
        Class_jc_20aa808a.ZHAjc = new Integer[20];
        Class_jc_20aa808a.WnbNG = Class_jc_20aa808a.bzM();
        Class_jc_20aa808a.GjreY = Class_jc_20aa808a.bzN();
        v15 = new Item[Class_jc_20aa808a.bAd("q", (int)28173, (long)(7959716020461767086L ^ var20))];
        v15[0] = Items.SHULKER_BOX;
        v15[1] = Items.WHITE_SHULKER_BOX;
        v15[2] = Items.ORANGE_SHULKER_BOX;
        v15[3] = Items.MAGENTA_SHULKER_BOX;
        v15[4] = Items.LIGHT_BLUE_SHULKER_BOX;
        v15[5] = Items.YELLOW_SHULKER_BOX;
        v15[Class_jc_20aa808a.bAd("q", (int)23554, (long)(2561424996368268198L ^ var20))] = Items.LIME_SHULKER_BOX;
        v15[Class_jc_20aa808a.bAd("q", (int)16110, (long)(618795366467721553L ^ var20))] = Items.PINK_SHULKER_BOX;
        v15[Class_jc_20aa808a.bAd("q", (int)530, (long)(564843112810702269L ^ var20))] = Items.GRAY_SHULKER_BOX;
        v15[Class_jc_20aa808a.bAd("q", (int)18511, (long)(91995185070583786L ^ var20))] = Items.LIGHT_GRAY_SHULKER_BOX;
        v15[Class_jc_20aa808a.bAd("q", (int)1805, (long)(4702210129977663651L ^ var20))] = Items.CYAN_SHULKER_BOX;
        v15[Class_jc_20aa808a.bAd("q", (int)28448, (long)(6515264552589985950L ^ var20))] = Items.PURPLE_SHULKER_BOX;
        v15[Class_jc_20aa808a.bAd("q", (int)1524, (long)(2652687055726436953L ^ var20))] = Items.BLUE_SHULKER_BOX;
        v15[Class_jc_20aa808a.bAd("q", (int)21200, (long)(5702791272268674416L ^ var20))] = Items.BROWN_SHULKER_BOX;
        v15[Class_jc_20aa808a.bAd("q", (int)6643, (long)(8917329054465621599L ^ var20))] = Items.GREEN_SHULKER_BOX;
        v15[Class_jc_20aa808a.bAd("q", (int)6839, (long)(5662279751145291019L ^ var20))] = Items.RED_SHULKER_BOX;
        v15[Class_jc_20aa808a.bAd("q", (int)7895, (long)(1852830847504972145L ^ var20))] = Items.BLACK_SHULKER_BOX;
        Class_jc_20aa808a.FFgfM = Set.of(v15);
        Class_jc_20aa808a.vSOjt = Items.AIR;
        Class_jc_20aa808a.alGsc = new ConcurrentHashMap<String, Item>();
        Class_jc_20aa808a.xxvZl = new ConcurrentHashMap<String, Class_mG_52c8d386>();
        Class_jc_20aa808a.IckfH = new ConcurrentHashMap<String, Class_mG_52c8d386>();
    }

    public static boolean bzs(ItemStack itemStack) {
        return Class_jh_282f5b34.bCg(itemStack, (RegistryKey<Enchantment>)Enchantments.BREACH);
    }

    public static EquipmentType bzc(ItemStack itemStack) {
        long l = WedAj ^ 0x6348508E72C2L;
        EquippableComponent equippableComponent = (EquippableComponent)itemStack.get(DataComponentTypes.EQUIPPABLE);
        String[] stringArray = Class_jf_d1c4f950.bBe();
        EquippableComponent equippableComponent2 = equippableComponent;
        if (stringArray != null) {
            if (equippableComponent2 == null) {
                return null;
            }
            equippableComponent2 = equippableComponent;
        }
        EquipmentSlot equipmentSlot = equippableComponent2.comp_3174();
        return switch (Class_jc_tI_47a1be77.Wxgue[equipmentSlot.ordinal()]) {
            case 1 -> EquipmentType.HELMET;
            case 2 -> EquipmentType.CHESTPLATE;
            case 3 -> EquipmentType.LEGGINGS;
            case 4 -> EquipmentType.BOOTS;
            case 5 -> EquipmentType.BODY;
            default -> null;
        };
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jc_20aa808a.class, "bzZ", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_jc_20aa808a.class, "bAc", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

