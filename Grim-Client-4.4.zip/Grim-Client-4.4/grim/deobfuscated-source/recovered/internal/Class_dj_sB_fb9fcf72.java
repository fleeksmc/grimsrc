/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_dj_sE_5c7d31af;

record Class_dj_sB_fb9fcf72(Class_dj_sE_5c7d31af hole, float fadeFactor) {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

