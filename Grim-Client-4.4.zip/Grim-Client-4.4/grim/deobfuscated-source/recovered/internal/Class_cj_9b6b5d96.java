/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screen.ChatScreen
 *  net.minecraft.item.ItemStack
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.item.ItemStack;
import recovered.core.ClientMain;
import recovered.internal.Class_Z_a19ce218;
import recovered.internal.Class_ca_75c833b3;
import recovered.internal.Class_co_c10d0572;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jc_20aa808a;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_oP_6ecdf500;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_cj_9b6b5d96
extends Class_co_c10d0572 {
    private final Class_rk_bf8630d1[] uXrKR;
    private final Class_Z_a19ce218[] nfdDW;
    private final Class_rk_bf8630d1 JSzyq;
    private static final long KQivZ;
    private static final long[] oTiFn;
    private static final Integer[] cyVUI;
    private static final Map FZjbT;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cj_9b6b5d96() {
        long l = KQivZ ^ 0x3BF06B49CCB9L;
        super(new int[]{(int)Class_cj_9b6b5d96.QE("v", (int)21426, (long)(0x4C243EAC19ECB3E9L ^ l)), (int)Class_cj_9b6b5d96.QE("v", (int)8633, (long)(0x1F847BF1AA07C1E3L ^ l)), (int)Class_cj_9b6b5d96.QE("v", (int)8607, (long)(0x6E2026EFB2AC41C1L ^ l)), (int)Class_cj_9b6b5d96.QE("v", (int)9213, (long)(0x411257467C50C3A4L ^ l)), (int)Class_cj_9b6b5d96.QE("v", (int)3976, (long)(0x255AB2D51DEAEFD7L ^ l))}, Class_lf_d247d983.tCZuD);
        this.uXrKR = new Class_rk_bf8630d1[4];
        this.nfdDW = new Class_Z_a19ce218[4];
        this.JSzyq = new Class_rk_bf8630d1((int)Class_cj_9b6b5d96.QE("v", (int)4464, (long)(0x1C45256284F3F12DL ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        boolean bl = Class_ca_75c833b3.OX();
        for (int i = 0; i < this.uXrKR.length; ++i) {
            this.uXrKR[i] = new Class_rk_bf8630d1((int)Class_cj_9b6b5d96.QE("v", (int)24644, (long)(0x673A52CE8D66001CL ^ l))).dhs(Class_rj_b691f4f7.XzDkv);
            Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.joxgd.bYM(7.0f);
            this.nfdDW[i] = new Class_Z_a19ce218().kJ(class_lq_87a74641).kK(3.0f).kL((int)Class_cj_9b6b5d96.QE("v", (int)24644, (long)(0x673A52CE8D66001CL ^ l))).kM(Class_rj_b691f4f7.UPXqT).kP("%");
            if (!bl) continue;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_cj_9b6b5d96.KQivZ = Class_gb_9d201141.aYR(-5358398472619022768L, 7241789623132261359L, MethodHandles.lookup().lookupClass()).a(274983036465735L);
                Class_cj_9b6b5d96.FZjbT = new HashMap<K, V>(13);
                var0 = Class_cj_9b6b5d96.KQivZ ^ 134886543400919L;
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[7];
                var5_4 = 0;
                var6_5 = "\u008dEA\u00fc\u00d4\u00ad\u00a9jU\u00e4\u00f9z\u0000g\u009b\u00d6\u00b4\u009d\u00eb\u00e3\u0088\u0002^\u00ba\u00b3\u00edn\u0007\u00bc\u00859\u0096\u00f1\u001f\u00d4gT\u00f0J\u00e5";
                var7_6 = "\u008dEA\u00fc\u00d4\u00ad\u00a9jU\u00e4\u00f9z\u0000g\u009b\u00d6\u00b4\u009d\u00eb\u00e3\u0088\u0002^\u00ba\u00b3\u00edn\u0007\u00bc\u00859\u0096\u00f1\u001f\u00d4gT\u00f0J\u00e5".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl26:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = "N\u00fa\u008cy[\u00eb\u0099lz\u008e\u00af{\u0080\f\u00f4X";
                    var7_6 = "N\u00fa\u008cy[\u00eb\u0099lz\u008e\u00af{\u0080\f\u00f4X".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl52:
                // 1 sources

                ** continue;
            }
        }
        Class_cj_9b6b5d96.oTiFn = var8_3;
        Class_cj_9b6b5d96.cyVUI = new Integer[7];
    }

    private static int QC(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x2C09;
        if (cyVUI[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = oTiFn[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])FZjbT.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    FZjbT.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cj_9b6b5d96", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_cj_9b6b5d96.cyVUI[n2] = n3;
        }
        return cyVUI[n2];
    }

    @Override
    protected void NV(Class_lC_5322e8cf class_lC_5322e8cf) {
        long l = KQivZ ^ 0x70AF61DB693FL;
        Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
        Class_lq_87a74641 class_lq_87a746412 = Class_lE_06fbe260.joxgd.bYM(7.0f);
        Class_ii_9b427eda class_ii_9b427eda = ClientMain.dlM();
        boolean bl = Class_ca_75c833b3.OX();
        float f = this.ormBS.dhj();
        float f2 = this.gILqY.dhj();
        Class_mG_52c8d386 class_mG_52c8d386 = class_ii_9b427eda.bjb().coa(255.0f * f);
        Class_mG_52c8d386 class_mG_52c8d3862 = class_ii_9b427eda.bjc().coa(255.0f * f);
        Class_mG_52c8d386 class_mG_52c8d3863 = class_ii_9b427eda.bjc().cob(0.5f);
        float f3 = 20.0f;
        class_lC_5322e8cf.ccU(this.toIeR, this.QWaAn, this.jTsqG, f3, f, f2);
        float f4 = this.toIeR + 7.0f;
        float f5 = this.QWaAn + Class_jf_d1c4f950.bAH(class_lq_87a74641.cat(), f3);
        class_lC_5322e8cf.ceA(class_lq_87a74641, this.eqWHC, f4, f5, class_mG_52c8d386);
        float f6 = 8.0f;
        float f7 = this.toIeR + this.jTsqG - f6 - 7.0f;
        float f8 = this.QWaAn + Class_jf_d1c4f950.bAH(f6, f3);
        boolean bl2 = bl;
        class_lC_5322e8cf.cem(this.jAncU, f7, f8, f6, class_mG_52c8d3862);
        float f9 = 16.0f;
        float f10 = 22.0f;
        List<ItemStack> list = Class_oP_6ecdf500.cJq().cJE();
        float f11 = this.ormBS.dhj() * this.KgDVz.dhj() - 1.0f;
        float f12 = f11 == 0.0f ? 0 : (f11 > 0.0f ? 1 : -1);
        if (!bl2) {
            f12 = f12 >= 0 ? 1.0f : 0.0f;
        }
        this.JSzyq.dhc((boolean)f12);
        for (int i = list.size() - 1; i >= 0; --i) {
            ItemStack itemStack = list.get(i);
            Class_rk_bf8630d1 class_rk_bf8630d1 = this.uXrKR[i];
            Class_Z_a19ce218 class_Z_a19ce218 = this.nfdDW[i];
            boolean bl3 = itemStack.isEmpty();
            if (!bl2) {
                bl3 = !bl3;
            }
            class_rk_bf8630d1.dhc(bl3);
            float f13 = this.JSzyq.dhj() * class_rk_bf8630d1.dhj();
            Class_mG_52c8d386 class_mG_52c8d3864 = class_ii_9b427eda.bjb().coa(255.0f * f13);
            class_lC_5322e8cf.ccU(this.toIeR, this.QWaAn + f10, this.jTsqG, f9, f, f2);
            float f14 = Class_jF_38b68c76.bHw()[3];
            Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, f14 * f13);
            class_lC_5322e8cf.cea(itemStack, this.toIeR + 7.0f, this.QWaAn + f10 + Class_jf_d1c4f950.bAH(8.0f, f9), 0.5f).bGv();
            Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, f14);
            float f15 = this.toIeR + this.jTsqG - 7.0f;
            int n = Class_jc_20aa808a.bze(itemStack);
            String string = n + "%";
            float f16 = class_lq_87a746412.cao(string);
            float f17 = this.toIeR + 15.0f;
            float f18 = f15 - f16;
            float f19 = (f18 - f17) / 2.0f - 1.0f;
            float f20 = f17 + f19;
            float f21 = this.QWaAn + f10 + f9 / 2.0f - 1.0f;
            class_lC_5322e8cf.cdc(f20, f21, class_mG_52c8d3863);
            float f22 = this.QWaAn + f10 + Class_jf_d1c4f950.bAH(class_lq_87a746412.cat(), f9);
            class_Z_a19ce218.kS(false, class_mG_52c8d3864);
            class_Z_a19ce218.kO(n);
            class_Z_a19ce218.sW(f18, f22);
            class_Z_a19ce218.su(class_lC_5322e8cf);
            f10 += 18.0f * f13;
            if (!bl2) continue;
        }
    }

    @Override
    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        block3: {
            long l = KQivZ ^ 0x64148BDE86FFL;
            this.jTsqG = 55.0f;
            boolean bl = Class_ca_75c833b3.OY();
            this.Xtjvx = 20.0f;
            for (ItemStack itemStack : Class_oP_6ecdf500.cJq().cJE()) {
                if (bl) {
                    if (bl) {
                        if (itemStack.isEmpty() && bl) continue;
                        this.Xtjvx += 18.0f;
                    }
                    if (bl) continue;
                }
                break block3;
            }
            super.LX(class_lC_5322e8cf);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean Om() {
        long l = KQivZ ^ 0x7322F75B2C15L;
        boolean bl = Class_ca_75c833b3.OX();
        boolean bl2 = Class_oP_6ecdf500.cJq().cJE().stream().allMatch(ItemStack::isEmpty);
        if (!bl) {
            bl2 = !bl2;
        }
        boolean bl3 = bl2;
        boolean bl4 = ClientMain.dlmvG.currentScreen instanceof ChatScreen;
        boolean bl5 = bl3;
        if (bl) return bl5;
        if (bl5) return true;
        bl5 = bl4;
        if (bl) return bl5;
        if (!bl5) return false;
        return true;
    }

    private static CallSite QE(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cj_9b6b5d96" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static MatchException QB(MatchException matchException) {
        return matchException;
    }

    private static int QD(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_cj_9b6b5d96.QC(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cj_9b6b5d96.class, "QD", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

