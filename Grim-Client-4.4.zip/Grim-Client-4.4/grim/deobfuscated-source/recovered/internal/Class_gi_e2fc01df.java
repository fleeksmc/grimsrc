/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.command.OrderedRenderCommandQueue
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.Entity
 *  net.minecraft.text.Text
 */
package recovered.internal;

import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gi_e2fc01df
extends Class_hH_ae8f8f77 {
    private Entity PkMHK;
    private Text KWUnr;
    private MatrixStack KSVnW;
    private OrderedRenderCommandQueue fqnYk;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gi_e2fc01df(Entity entity, Text text, MatrixStack matrixStack, OrderedRenderCommandQueue orderedRenderCommandQueue) {
        this.PkMHK = entity;
        this.KWUnr = text;
        this.KSVnW = matrixStack;
        this.fqnYk = orderedRenderCommandQueue;
    }

    public OrderedRenderCommandQueue baO() {
        return this.fqnYk;
    }

    public MatrixStack baN() {
        return this.KSVnW;
    }

    public Entity baL() {
        return this.PkMHK;
    }

    public Text baM() {
        return this.KWUnr;
    }
}

