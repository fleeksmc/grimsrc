/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.collection.DefaultedList
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.item.ItemStack;
import net.minecraft.util.collection.DefaultedList;
import recovered.core.ClientMain;
import recovered.internal.Class_ca_75c833b3;
import recovered.internal.Class_co_c10d0572;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_ju_e398051e;
import recovered.internal.Class_jv_4c1871b8;
import recovered.internal.Class_jw_a460984a;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_cf_8f2d5596
extends Class_co_c10d0572 {
    private final Class_rk_bf8630d1[] UlmqM;
    private final Class_rk_bf8630d1 FPFaU;
    private static final long NGoqZ;
    private static final long[] QbRBk;
    private static final Integer[] gXJqM;
    private static final Map TolKa;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cf_8f2d5596() {
        long l = NGoqZ ^ 0x1AE0CA72D6CDL;
        int[] nArray = new int[Class_cf_8f2d5596.Qa("c", (int)21440, (long)(0x1484670D81BE69CCL ^ l))];
        nArray[0] = (int)Class_cf_8f2d5596.Qa("c", (int)31172, (long)(0x7ED001EFC25F43CFL ^ l));
        nArray[1] = (int)Class_cf_8f2d5596.Qa("c", (int)20836, (long)(0x72102D19BD416B65L ^ l));
        nArray[2] = (int)Class_cf_8f2d5596.Qa("c", (int)17365, (long)(0x593C0442DC7179D3L ^ l));
        nArray[3] = (int)Class_cf_8f2d5596.Qa("c", (int)31692, (long)(0x4987EBCB63E741DBL ^ l));
        nArray[4] = (int)Class_cf_8f2d5596.Qa("c", (int)6568, (long)(0x7652F0C20B3F23A6L ^ l));
        nArray[5] = (int)Class_cf_8f2d5596.Qa("c", (int)30177, (long)(0x143851551CA44FE3L ^ l));
        nArray[Class_cf_8f2d5596.Qa("c", (int)6381, (long)(0x3E546C8C83AA2E9L ^ l))] = (int)Class_cf_8f2d5596.Qa("c", (int)7856, (long)(0x280C7C72FF5B24B5L ^ l));
        nArray[Class_cf_8f2d5596.Qa("c", (int)21277, (long)(0x18DA06B0ED8DE910L ^ l))] = (int)Class_cf_8f2d5596.Qa("c", (int)9337, (long)(0x2716FD098BDB9E71L ^ l));
        nArray[Class_cf_8f2d5596.Qa("c", (int)3214, (long)(0x293FE5DFF4033689L ^ l))] = (int)Class_cf_8f2d5596.Qa("c", (int)29027, (long)(0x5C8B959F6A774B60L ^ l));
        super(nArray, Class_lf_d247d983.fEKkJ);
        this.UlmqM = new Class_rk_bf8630d1[Class_cf_8f2d5596.Qa("c", (int)16681, (long)(0x18DA985EF78EFB20L ^ l))];
        this.FPFaU = new Class_rk_bf8630d1((int)Class_cf_8f2d5596.Qa("c", (int)30941, (long)(0x2C06430B935B42D7L ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
        boolean bl = Class_ca_75c833b3.OY();
        for (int i = 0; i < this.UlmqM.length; ++i) {
            this.UlmqM[i] = new Class_rk_bf8630d1((int)Class_cf_8f2d5596.Qa("c", (int)1103, (long)(0x3552160B12C03E40L ^ l))).dhs(Class_rj_b691f4f7.XzDkv);
            if (bl) continue;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_cf_8f2d5596.NGoqZ = Class_gb_9d201141.aYR(-5723543788386125114L, 6796361726211910234L, MethodHandles.lookup().lookupClass()).a(204007560076448L);
                Class_cf_8f2d5596.TolKa = new HashMap<K, V>(13);
                var0 = Class_cf_8f2d5596.NGoqZ ^ 97440077249969L;
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[17];
                var5_4 = 0;
                var6_5 = "\u00ed\u00d0\\\u009a\u00e0H\u0015+\u0015\u00a3\u00f6\u0014~\u00fe3\u00d0\u00ba\u0093/\u00d938N pl\u00ce\u0012\u0001\u00aeZ\u00c1>\u00d8\nm\u00d9,\u0085\u00c8\u00cazE\u00ec\u0093k|{\u00b5\u00ea\u00c2\u001aa>\u00d6}\u00a3\u008e$\u0082\u00be\u0018\u00cdx\u00e2\u00fd;8\u0004\u00aa\u00d7yU\u00c2L\u00f1\u00bajT\u00d2r\u0092|\u00d1\u00ebR\u0016\u00fd\u0096p\u00b5\tO\u00e6\u001d\u00b2lKv\u00b0\u009f\u009d\u00ca\u00e5\u00ee\u00ca\u0003\u00fb\u00e1!\u00845\u00f9\u0094)\u0084\u00d2wT,";
                var7_6 = "\u00ed\u00d0\\\u009a\u00e0H\u0015+\u0015\u00a3\u00f6\u0014~\u00fe3\u00d0\u00ba\u0093/\u00d938N pl\u00ce\u0012\u0001\u00aeZ\u00c1>\u00d8\nm\u00d9,\u0085\u00c8\u00cazE\u00ec\u0093k|{\u00b5\u00ea\u00c2\u001aa>\u00d6}\u00a3\u008e$\u0082\u00be\u0018\u00cdx\u00e2\u00fd;8\u0004\u00aa\u00d7yU\u00c2L\u00f1\u00bajT\u00d2r\u0092|\u00d1\u00ebR\u0016\u00fd\u0096p\u00b5\tO\u00e6\u001d\u00b2lKv\u00b0\u009f\u009d\u00ca\u00e5\u00ee\u00ca\u0003\u00fb\u00e1!\u00845\u00f9\u0094)\u0084\u00d2wT,".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl26:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = "a\u00cc\u00cb\u00a6Y\u00fa\u0007\u00df\u00ebx+\u0082\u001d\u00dcI\u0012";
                    var7_6 = "a\u00cc\u00cb\u00a6Y\u00fa\u0007\u00df\u00ebx+\u0082\u001d\u00dcI\u0012".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl52:
                // 1 sources

                ** continue;
            }
        }
        Class_cf_8f2d5596.QbRBk = var8_3;
        Class_cf_8f2d5596.gXJqM = new Integer[17];
    }

    private static CallSite Qa(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cf_8f2d5596" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static MatchException PX(MatchException matchException) {
        return matchException;
    }

    @Override
    protected void NV(Class_lC_5322e8cf class_lC_5322e8cf) {
        block7: {
            long l = NGoqZ ^ 0x4235D6E6EA39L;
            Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
            Class_ii_9b427eda class_ii_9b427eda = ClientMain.dlM();
            float f = this.ormBS.dhj();
            float f2 = this.gILqY.dhj();
            Class_mG_52c8d386 class_mG_52c8d386 = class_ii_9b427eda.bjb().coa(255.0f * f);
            Class_mG_52c8d386 class_mG_52c8d3862 = class_ii_9b427eda.bjc().coa(255.0f * f);
            boolean bl = Class_ca_75c833b3.OX();
            float f3 = 20.0f;
            class_lC_5322e8cf.ccU(this.toIeR, this.QWaAn, this.jTsqG, f3, f, f2);
            float f4 = this.toIeR + 7.0f;
            float f5 = this.QWaAn + Class_jf_d1c4f950.bAH(class_lq_87a74641.cat(), f3);
            class_lC_5322e8cf.ceA(class_lq_87a74641, this.eqWHC, f4, f5, class_mG_52c8d386);
            float f6 = 8.0f;
            float f7 = this.toIeR + this.jTsqG - f6 - 7.0f;
            float f8 = this.QWaAn + Class_jf_d1c4f950.bAH(f6, f3);
            class_lC_5322e8cf.cem(this.jAncU, f7, f8, f6, class_mG_52c8d3862);
            float f9 = this.ormBS.dhj() * this.KgDVz.dhj() - 1.0f;
            float f10 = f9 == 0.0f ? 0 : (f9 > 0.0f ? 1 : -1);
            if (!bl) {
                f10 = f10 >= 0 ? 1.0f : 0.0f;
            }
            this.FPFaU.dhc((boolean)f10);
            float f11 = 16.0f;
            DefaultedList defaultedList = ClientMain.dlmvG.player.getInventory().getMainStacks();
            float f12 = 22.0f;
            int n = 0;
            block0: while (true) {
                int n2 = n;
                block1: while (n2 < 3) {
                    class_lC_5322e8cf.ccU(this.toIeR, this.QWaAn + f12, this.jTsqG, f11, f, f2);
                    float f13 = 7.0f;
                    float f14 = f12 + Class_jf_d1c4f950.bAH(8.0f, f11);
                    reference var23_22 = Class_cf_8f2d5596.Qa("c", (int)24262, (long)(0xA641A4C49585832L ^ l)) + n * Class_cf_8f2d5596.Qa("c", (int)21440, (long)(0x14843FD89D2A5538L ^ l));
                    int n3 = Math.min((int)(var23_22 + Class_cf_8f2d5596.Qa("c", (int)21440, (long)(0x14843FD89D2A5538L ^ l))), defaultedList.size());
                    List list = defaultedList.subList((int)var23_22, n3);
                    if (bl) break block7;
                    int n4 = 0;
                    while (n4 < list.size()) {
                        int n5 = n * Class_cf_8f2d5596.Qa("c", (int)21440, (long)(0x14843FD89D2A5538L ^ l)) + n4;
                        ItemStack itemStack = (ItemStack)list.get(n4);
                        if (!bl) {
                            n2 = itemStack.isEmpty() ? 1 : 0;
                            if (bl) continue block1;
                            if (n2 == 0) {
                                Class_rk_bf8630d1 class_rk_bf8630d1 = this.UlmqM[n5];
                                boolean bl2 = itemStack.isEmpty();
                                if (!bl) {
                                    bl2 = !bl2;
                                }
                                class_rk_bf8630d1.dhc(bl2);
                                float f15 = this.FPFaU.dhj() * this.UlmqM[n5].dhj();
                                float f16 = Class_jF_38b68c76.bHw()[3];
                                Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, f16 * f15);
                                ((Class_jv_4c1871b8)class_lC_5322e8cf.cea(itemStack, this.toIeR + f13, this.QWaAn + f14, 0.5f).bGw()).bGv();
                                ((Class_jw_a460984a)class_lC_5322e8cf.ceb(itemStack, this.toIeR + f13, this.QWaAn + f14, 0.5f).bGw()).bGv();
                                Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, f16);
                                f13 += 15.0f;
                            }
                            ++n4;
                        }
                        if (!bl) continue;
                    }
                    f12 += f11 + 2.0f;
                    ++n;
                    if (!bl) continue block0;
                }
                break;
            }
            Class_ju_e398051e.bFV();
        }
    }

    @Override
    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        this.jTsqG = 142.0f;
        this.Xtjvx = 74.0f;
        super.LX(class_lC_5322e8cf);
    }

    private static int PZ(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_cf_8f2d5596.PY(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static int PY(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x6F27;
        if (gXJqM[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = QbRBk[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])TolKa.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    TolKa.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cf_8f2d5596", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_cf_8f2d5596.gXJqM[n2] = n3;
        }
        return gXJqM[n2];
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cf_8f2d5596.class, "PZ", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

