/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.Camera
 *  net.minecraft.client.util.math.MatrixStack
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_ml_b921e8c4;
import recovered.modules.AmbienceModule;
import recovered.modules.SoulEffectsModule;

final class Class_cZ_su_836fa66f {
    private final List<Class_ml_b921e8c4> FYVSB;
    private final UUID Abjlp;
    private boolean nYGDp;
    private static final long byLhk = Class_gb_9d201141.aYR(-3416882283050841335L, -5259282583627597540L, MethodHandles.lookup().lookupClass()).a(87722170772133L);
    private static final long[] dzFFK;
    private static final Integer[] EqhUH;
    private static final Map uPfsb;
    private static final long[] NMglr;
    private static final Long[] alVkZ;
    private static final Map affoO;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_cZ_su_836fa66f(LivingEntity livingEntity, int n, float f, long l, Class_mG_52c8d386 class_mG_52c8d386, float f2) {
        block2: {
            List<float[]> list;
            float f3;
            double d;
            double d2;
            Vec3d vec3d;
            float f4;
            Vec3d vec3d2;
            block1: {
                Class_iS_888f260e[] class_iS_888f260eArray;
                block0: {
                    long l2 = byLhk ^ 0x4A80666C5D64L;
                    Class_iS_888f260e[] class_iS_888f260eArray2 = AmbienceModule.afl();
                    this.FYVSB = new ArrayList<Class_ml_b921e8c4>();
                    this.nYGDp = true;
                    class_iS_888f260eArray = class_iS_888f260eArray2;
                    this.Abjlp = livingEntity.getUuid();
                    vec3d2 = livingEntity.getEntityPos();
                    float f5 = livingEntity.getWidth();
                    f4 = livingEntity.getHeight();
                    vec3d = new Vec3d(vec3d2.x, vec3d2.y + (double)f4 * 0.5, vec3d2.z);
                    double d3 = Math.toRadians(livingEntity.bodyYaw);
                    d2 = Math.sin(d3);
                    d = Math.cos(d3);
                    f3 = (float)Math.sqrt(f5 * f5 + f4 * f4);
                    list = SoulEffectsModule.abf(livingEntity);
                    if (class_iS_888f260eArray != null) break block0;
                    if (!list.isEmpty()) break block1;
                    this.dnX(n, vec3d2, vec3d, f5, f4, f3, f2, d2, d, f, l, class_mG_52c8d386);
                }
                if (class_iS_888f260eArray == null) break block2;
            }
            this.dnW(n, list, vec3d2, vec3d, f4, f3, f2, d2, d, f, l, class_mG_52c8d386);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        uPfsb = new HashMap(13);
        long l = byLhk ^ 0x2975064E6BDDL;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "\u00b0.j\u009fR\u0017\u001e\u00e6 /\u0093z\u00d3\\\u00f6\u001b";
        int n2 = "\u00b0.j\u009fR\u0017\u001e\u00e6 /\u0093z\u00d3\\\u00f6\u001b".length();
        int n3 = 0;
        do {
            byte[] byArray3 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
            byte[] byArray4 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray4[0] & 0xFFL) << 56 | ((long)byArray4[1] & 0xFFL) << 48 | ((long)byArray4[2] & 0xFFL) << 40 | ((long)byArray4[3] & 0xFFL) << 32 | ((long)byArray4[4] & 0xFFL) << 24 | ((long)byArray4[5] & 0xFFL) << 16 | ((long)byArray4[6] & 0xFFL) << 8 | (long)byArray4[7] & 0xFFL;
        } while (n3 < n2);
        dzFFK = lArray;
        EqhUH = new Integer[2];
        affoO = new HashMap(13);
        Cipher cipher2 = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory2 = SecretKeyFactory.getInstance("DES");
        byte[] byArray5 = new byte[8];
        byte[] byArray6 = byArray5;
        byArray5[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray6 = byArray6;
            byArray6[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher2.init(2, (Key)secretKeyFactory2.generateSecret(new DESKeySpec(byArray6)), new IvParameterSpec(new byte[8]));
        long[] lArray2 = new long[2];
        int n5 = 0;
        String string2 = "\u0005S`\u00b2\u00a5\u0095\u00afk\u009e9g)\u00d6\u00a1z\u00fc";
        int n6 = "\u0005S`\u00b2\u00a5\u0095\u00afk\u009e9g)\u00d6\u00a1z\u00fc".length();
        int n7 = 0;
        do {
            byte[] byArray7 = string2.substring(n7, n7 += 8).getBytes("ISO-8859-1");
            int n8 = n5++;
            long l3 = ((long)byArray7[0] & 0xFFL) << 56 | ((long)byArray7[1] & 0xFFL) << 48 | ((long)byArray7[2] & 0xFFL) << 40 | ((long)byArray7[3] & 0xFFL) << 32 | ((long)byArray7[4] & 0xFFL) << 24 | ((long)byArray7[5] & 0xFFL) << 16 | ((long)byArray7[6] & 0xFFL) << 8 | (long)byArray7[7] & 0xFFL;
            byte[] byArray8 = cipher2.doFinal(new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3});
            lArray2[n8] = ((long)byArray8[0] & 0xFFL) << 56 | ((long)byArray8[1] & 0xFFL) << 48 | ((long)byArray8[2] & 0xFFL) << 40 | ((long)byArray8[3] & 0xFFL) << 32 | ((long)byArray8[4] & 0xFFL) << 24 | ((long)byArray8[5] & 0xFFL) << 16 | ((long)byArray8[6] & 0xFFL) << 8 | (long)byArray8[7] & 0xFFL;
        } while (n7 < n6);
        NMglr = lArray2;
        alVkZ = new Long[2];
    }

    private static MatchException doc(MatchException matchException) {
        return matchException;
    }

    /*
     * Unable to fully structure code
     */
    private void dnW(int var1_1, List<float[]> var2_2, Vec3d var3_3, Vec3d var4_4, float var5_5, float var6_6, float var7_7, double var8_8, double var10_9, float var12_10, long var13_11, Class_mG_52c8d386 var15_12) {
        block5: {
            var16_13 = Class_cZ_su_836fa66f.byLhk ^ 24913676967819L;
            var19_14 = Infinityf;
            var20_15 = Infinityf;
            var21_16 = Infinityf;
            var22_17 = -Infinityf;
            var23_18 = -Infinityf;
            var24_19 = -Infinityf;
            var25_20 = 0.0f;
            var18_21 = AmbienceModule.afl();
            for (float[] var27_24 : var2_2) {
                var19_14 = Math.min(var19_14, var27_24[0]);
                var20_15 = Math.min(var20_15, var27_24[1]);
                var21_16 = Math.min(var21_16, var27_24[2]);
                var22_17 = Math.max(var22_17, var27_24[3]);
                var23_18 = Math.max(var23_18, var27_24[4]);
                var24_19 = Math.max(var24_19, var27_24[5]);
                v0 = var25_20 + var27_24[Class_cZ_su_836fa66f.dof("a", (int)3323, (long)(5919368968920556359L ^ var16_13))];
                if (var18_21 == null) {
                    var25_20 = v0;
                    if (var18_21 == null) continue;
                }
                break block5;
            }
            v0 = (var19_14 + var22_17) * 0.5f;
        }
        var26_23 = v0;
        var27_25 = (var21_16 + var24_19) * 0.5f;
        v1 = var28_26 = (var23_18 - var20_15) / 16.0f;
        v2 = 0.01f;
        if (var18_21 != null) ** GOTO lbl32
        if (v1 > v2) {
            v1 = var5_5;
            v2 = var28_26;
lbl32:
            // 2 sources

            v3 = v1 / v2;
        } else {
            v3 = 1.0f;
        }
        var29_27 = v3;
        for (var30_28 = 0; var30_28 < var1_1; ++var30_28) {
            var31_29 = Class_cZ_su_836fa66f.dnY(var2_2, var25_20);
            var32_30 = Class_cZ_su_836fa66f.dnZ(var31_29);
            var33_31 = (double)(var32_30[0] - var26_23) / 16.0;
            var35_32 = (double)(var23_18 - var32_30[1]) / 16.0 * (double)var29_27;
            var37_33 = (double)(var32_30[2] - var27_25) / 16.0;
            var39_34 = var33_31 * var10_9 - var37_33 * var8_8;
            var41_35 = var33_31 * var8_8 + var37_33 * var10_9;
            this.doa(new Vec3d(var3_3.x + var39_34, var3_3.y + var35_32, var3_3.z + var41_35), var4_4, var6_6, var7_7, var12_10, var13_11, var15_12);
            if (var18_21 == null) continue;
        }
    }

    private void dnX(int n, Vec3d vec3d, Vec3d vec3d2, float f, float f2, float f3, float f4, double d, double d2, float f5, long l, Class_mG_52c8d386 class_mG_52c8d386) {
        long l2 = byLhk ^ 0x35BE4689819L;
        Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
        for (int i = 0; i < n; ++i) {
            double d3 = SoulEffectsModule.abk(0.0f, (float)Math.PI * 2);
            double d4 = Math.acos(SoulEffectsModule.abk(-1.0f, 1.0f));
            double d5 = Math.cbrt(SoulEffectsModule.abk(0.0f, 1.0f));
            double d6 = (double)f * 0.45 * d5 * Math.sin(d4) * Math.cos(d3);
            double d7 = (double)f2 * 0.45 * d5 * Math.cos(d4) + (double)f2 * 0.5;
            double d8 = (double)f * 0.45 * d5 * Math.sin(d4) * Math.sin(d3);
            double d9 = d6 * d2 - d8 * d;
            double d10 = d6 * d + d8 * d2;
            this.doa(new Vec3d(vec3d.x + d9, vec3d.y + d7, vec3d.z + d10), vec3d2, f3, f4, f5, l, class_mG_52c8d386);
            if (class_iS_888f260eArray == null) continue;
        }
    }

    private static int doe(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_cZ_su_836fa66f.dod(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static long dog(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x1FF6;
        if (alVkZ[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = NMglr[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])affoO.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    affoO.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cZ_su_836fa66f", exception);
            }
            long l4 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            Class_cZ_su_836fa66f.alVkZ[n2] = l4;
        }
        return alVkZ[n2];
    }

    private static long doh(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        long l2 = Class_cZ_su_836fa66f.dog(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l2;
    }

    private static CallSite dof(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cZ_su_836fa66f" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static float[] dnZ(float[] fArray) {
        long l = byLhk ^ 0x7C0294BB5A9L;
        Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
        float f = SoulEffectsModule.abk(0.0f, 1.0f) - 0.7f;
        float f2 = f == 0.0f ? 0 : (f < 0.0f ? -1 : 1);
        if (class_iS_888f260eArray == null) {
            if (f2 < 0) {
                return SoulEffectsModule.abi(fArray[0], fArray[1], fArray[2], fArray[3], fArray[4], fArray[5]);
            }
            f2 = 3;
        }
        float[] fArray2 = new float[f2];
        fArray2[0] = SoulEffectsModule.abk(fArray[0], fArray[3]);
        fArray2[1] = SoulEffectsModule.abk(fArray[1], fArray[4]);
        fArray2[2] = SoulEffectsModule.abk(fArray[2], fArray[5]);
        return fArray2;
    }

    private static CallSite doi(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cZ_su_836fa66f" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private void doa(Vec3d vec3d, Vec3d vec3d2, float f, float f2, float f3, long l, Class_mG_52c8d386 class_mG_52c8d386) {
        long l2 = byLhk ^ 0x7452102CA529L;
        Vec3d vec3d3 = vec3d.subtract(vec3d2);
        double d = vec3d3.length();
        Vec3d vec3d4 = d > 0.001 ? vec3d3.multiply(1.0 / d) : SoulEffectsModule.abj();
        vec3d4 = SoulEffectsModule.abh(vec3d4, Math.min(0.6f, f2 * 0.5f));
        float f4 = f * f2 * SoulEffectsModule.abk(0.6f, 1.4f);
        float f5 = f3 * SoulEffectsModule.abk(0.85f, 1.15f);
        long[] lArray = Class_cZ_su_836fa66f.dob(l, (float)d, f);
        this.FYVSB.add(new Class_ml_b921e8c4(vec3d, vec3d4, f4, f5, lArray[0], lArray[1], lArray[2], class_mG_52c8d386));
    }

    /*
     * Unable to fully structure code
     */
    private static long[] dob(long var0, float var2_1, float var3_2) {
        var4_3 = Class_cZ_su_836fa66f.byLhk ^ 132097837722583L;
        var6_4 = AmbienceModule.afl();
        v0 = var3_2;
        v1 = 0.001f;
        if (var6_4 != null) ** GOTO lbl9
        if (v0 > v1) {
            v0 = 1.0f;
            v1 = var2_1 / (var3_2 * 0.5f);
lbl9:
            // 2 sources

            v2 = Math.min(v0, v1);
        } else {
            v2 = 0.0f;
        }
        var7_5 = v2;
        var8_6 = (1.0f - var7_5 * 0.7f) * SoulEffectsModule.abk(0.4f, 1.0f);
        var9_7 = Math.max(0L, (long)Math.round((float)var0 * var8_6));
        var11_8 = Math.max((long)Class_cZ_su_836fa66f.doi("v", (int)32204, (long)(80754262270070159L ^ var4_3)), var0 / Class_cZ_su_836fa66f.doi("v", (int)543, (long)(5229822448085086813L ^ var4_3)));
        var13_9 = var0 + var9_7;
        var15_10 = var13_9 + var11_8;
        return new long[]{var0, var13_9, var15_10};
    }

    private static float[] dnY(List<float[]> list, float f) {
        float[] fArray;
        block3: {
            long l = byLhk ^ 0x788F69BF4915L;
            float f2 = SoulEffectsModule.abk(0.0f, f);
            float f3 = 0.0f;
            Iterator<float[]> iterator = list.iterator();
            Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
            while (iterator.hasNext()) {
                fArray = iterator.next();
                if (class_iS_888f260eArray == null) {
                    float[] fArray2 = fArray;
                    if (f2 <= (f3 += fArray2[Class_cZ_su_836fa66f.dof("a", (int)5605, (long)(0x4557BA395D882CC6L ^ l))])) {
                        return fArray2;
                    }
                    if (class_iS_888f260eArray == null) continue;
                }
                break block3;
            }
            fArray = list.getLast();
        }
        return fArray;
    }

    private static int dod(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x3454;
        if (EqhUH[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = dzFFK[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])uPfsb.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    uPfsb.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cZ_su_836fa66f", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_cZ_su_836fa66f.EqhUH[n2] = n3;
        }
        return EqhUH[n2];
    }

    private void dnU(BufferBuilder bufferBuilder, MatrixStack matrixStack, Camera camera, float f) {
        long l = byLhk ^ 0x573BCC58A13DL;
        Iterator<Class_ml_b921e8c4> iterator = this.FYVSB.iterator();
        Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
        while (iterator.hasNext()) {
            Class_ml_b921e8c4 class_ml_b921e8c4 = iterator.next();
            class_ml_b921e8c4.clh(bufferBuilder, matrixStack, camera, f);
            if (class_iS_888f260eArray == null) continue;
        }
    }

    private void dnV() {
        block9: {
            block8: {
                Class_cZ_su_836fa66f class_cZ_su_836fa66f;
                boolean bl;
                block7: {
                    long l = byLhk ^ 0x4E3AD7557E1EL;
                    Iterator<Class_ml_b921e8c4> iterator = this.FYVSB.iterator();
                    Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
                    while (iterator.hasNext()) {
                        Class_ml_b921e8c4 class_ml_b921e8c4 = iterator.next();
                        bl = class_ml_b921e8c4.clg();
                        if (class_iS_888f260eArray == null) {
                            if (bl) {
                                iterator.remove();
                            }
                            if (class_iS_888f260eArray == null) continue;
                        }
                        break block7;
                    }
                    class_cZ_su_836fa66f = this;
                    if (class_iS_888f260eArray != null) break block8;
                    bl = class_cZ_su_836fa66f.FYVSB.isEmpty();
                }
                if (!bl) break block9;
                class_cZ_su_836fa66f = this;
            }
            class_cZ_su_836fa66f.nYGDp = false;
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cZ_su_836fa66f.class, "doe", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_cZ_su_836fa66f.class, "doh", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

