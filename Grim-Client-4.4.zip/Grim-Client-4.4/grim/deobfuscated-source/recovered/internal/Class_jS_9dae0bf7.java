/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.textures.GpuTextureView
 *  net.minecraft.client.gl.GpuSampler
 *  net.minecraft.client.texture.AbstractTexture
 *  org.joml.Matrix3x2fStack
 */
package recovered.internal;

import com.mojang.blaze3d.textures.GpuTextureView;
import java.lang.invoke.MethodHandles;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.texture.AbstractTexture;
import org.joml.Matrix3x2fStack;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jO_1924117a;
import recovered.internal.Class_jS_ud_1d857bd9;
import recovered.internal.Class_la_8f67ae40;
import recovered.internal.Class_mG_52c8d386;

public class Class_jS_9dae0bf7 {
    private Matrix3x2fStack qdEgK;
    private float fJLAQ;
    private float qcPHr;
    private float oICdU;
    private float vcHFg;
    private float RAeDt;
    private float cJAVH;
    private float wNynT;
    private float qSyFE;
    private Class_la_8f67ae40 AteDY;
    private AbstractTexture hidqE;
    private GpuTextureView DVfPi;
    private GpuSampler Ececs;
    private Class_mG_52c8d386 HNbHD;
    private float XBDjq;
    private boolean dkkca;
    private boolean FVUmG;
    private float pXLNU;
    private float mlmTL;
    private float TUKKT;
    private float mUMdD;
    private float MYjCe;
    private float XubWX;
    private static final long wYBnW = Class_gb_9d201141.aYR(8614683303637920897L, 900304589961710054L, MethodHandles.lookup().lookupClass()).a(266415103904527L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_jS_9dae0bf7(Matrix3x2fStack matrix3x2fStack, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, Class_la_8f67ae40 class_la_8f67ae40, AbstractTexture abstractTexture, GpuTextureView gpuTextureView, GpuSampler gpuSampler, Class_mG_52c8d386 class_mG_52c8d386, float f9, boolean bl, boolean bl2, float f10, float f11, float f12, float f13, float f14, float f15) {
        this.qdEgK = matrix3x2fStack;
        this.fJLAQ = f;
        this.qcPHr = f2;
        this.oICdU = f3;
        this.vcHFg = f4;
        this.RAeDt = f5;
        this.cJAVH = f6;
        this.wNynT = f7;
        this.qSyFE = f8;
        this.AteDY = class_la_8f67ae40;
        this.hidqE = abstractTexture;
        this.DVfPi = gpuTextureView;
        this.Ececs = gpuSampler;
        this.HNbHD = class_mG_52c8d386;
        this.XBDjq = f9;
        this.dkkca = bl;
        this.FVUmG = bl2;
        this.pXLNU = f10;
        this.mlmTL = f11;
        this.TUKKT = f12;
        this.mUMdD = f13;
        this.MYjCe = f14;
        this.XubWX = f15;
    }

    public boolean bME() {
        return this.FVUmG;
    }

    public float bMp() {
        return this.fJLAQ;
    }

    public float bMr() {
        return this.oICdU;
    }

    public Matrix3x2fStack bMo() {
        return this.qdEgK;
    }

    public float bMI() {
        return this.mUMdD;
    }

    public float bMK() {
        return this.XubWX;
    }

    public float bMq() {
        return this.qcPHr;
    }

    public float bMJ() {
        return this.MYjCe;
    }

    public float bMw() {
        return this.qSyFE;
    }

    public float bMH() {
        return this.TUKKT;
    }

    public Class_la_8f67ae40 bMx() {
        return this.AteDY;
    }

    public float bMG() {
        return this.mlmTL;
    }

    public AbstractTexture bMy() {
        return this.hidqE;
    }

    public GpuTextureView bMz() {
        return this.DVfPi;
    }

    public float bMs() {
        return this.vcHFg;
    }

    public Class_mG_52c8d386 bMB() {
        return this.HNbHD;
    }

    public float bMC() {
        return this.XBDjq;
    }

    public GpuSampler bMA() {
        return this.Ececs;
    }

    public float bMu() {
        return this.cJAVH;
    }

    public float bMv() {
        return this.wNynT;
    }

    public boolean bMD() {
        return this.dkkca;
    }

    public float bMF() {
        return this.pXLNU;
    }

    public float bMt() {
        return this.RAeDt;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean bMb() {
        long l = wYBnW ^ 0x27B539FBA403L;
        String string = Class_jO_1924117a.bKy();
        Class_jS_9dae0bf7 class_jS_9dae0bf7 = this;
        if (string != null) {
            if (class_jS_9dae0bf7.hidqE != null) return true;
            class_jS_9dae0bf7 = this;
        }
        if (class_jS_9dae0bf7.DVfPi == null) return false;
        return true;
    }

    private static float bMm() {
        return 1.0f;
    }

    private static boolean bMf() {
        return false;
    }

    private static float bMe() {
        return 0.75f;
    }

    private static boolean bMg() {
        return false;
    }

    private static float bMk() {
        return 0.0f;
    }

    private static float bMi() {
        return 0.0f;
    }

    private static float bMh() {
        return 0.0f;
    }

    private static float bMj() {
        return 0.0f;
    }

    private static float bMl() {
        return 1.0f;
    }

    private static Class_mG_52c8d386 bMd() {
        return Class_mG_52c8d386.hoGuU;
    }

    private static MatchException bML(MatchException matchException) {
        return matchException;
    }

    public static Class_jS_ud_1d857bd9 bMn() {
        return new Class_jS_ud_1d857bd9();
    }

    public static Class_jS_ud_1d857bd9 bMc(Matrix3x2fStack matrix3x2fStack, double d, double d2, double d3, double d4) {
        return Class_jS_9dae0bf7.bMn().drR(matrix3x2fStack).drS((float)d).drT((float)d2).drU((float)d3).drV((float)d4);
    }
}

