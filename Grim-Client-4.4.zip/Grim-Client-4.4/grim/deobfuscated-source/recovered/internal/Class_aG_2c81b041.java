/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_aH_4cd10de1;

public interface Class_aG_2c81b041 {
    public void run(Class_aH_4cd10de1 var1);
}

