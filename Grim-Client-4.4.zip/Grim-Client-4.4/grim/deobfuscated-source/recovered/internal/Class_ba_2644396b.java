/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_bb_631496ef;

public interface Class_ba_2644396b {
    public void run(Class_bb_631496ef<?> var1);
}

