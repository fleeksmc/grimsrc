/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.MinecraftClient
 *  net.minecraft.client.gui.screen.ChatScreen
 *  net.minecraft.client.network.ClientPlayNetworkHandler
 *  net.minecraft.client.network.PlayerListEntry
 *  net.minecraft.scoreboard.Team
 *  net.minecraft.text.Style
 *  net.minecraft.text.Text
 *  net.minecraft.text.TextColor
 *  net.minecraft.util.Formatting
 *  net.minecraft.world.GameMode
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.world.GameMode;
import recovered.core.ClientMain;
import recovered.internal.Class_ca_sl_9d1d6eea;
import recovered.internal.Class_co_c10d0572;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mT_db06bea0;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.internal.Class_ru_937c8ae6;

public class Class_ca_75c833b3
extends Class_co_c10d0572 {
    private final Class_mT_db06bea0 kkoKC;
    private Map<String, Class_ca_sl_9d1d6eea> BmYio;
    private final Set<Class_ca_sl_9d1d6eea> SZBrr;
    private static boolean tONvf;
    private static final long PHZMk;
    private static final String[] pbFOM;
    private static final String[] qtBBV;
    private static final Map mckkR;
    private static final long[] zZGgU;
    private static final Integer[] vMfEW;
    private static final Map WQoAo;
    private static final long pgXwp;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ca_75c833b3() {
        long l = PHZMk ^ 0x62737EAAC90EL;
        int[] nArray = new int[Class_ca_75c833b3.Pg("e", (int)16402, (long)(0x50A4FF85924A8DC1L ^ l))];
        nArray[0] = (int)Class_ca_75c833b3.Pg("e", (int)14970, (long)(0x4BF11D3DEFB277A8L ^ l));
        nArray[1] = (int)Class_ca_75c833b3.Pg("e", (int)30956, (long)(0x5DEEA6D217923533L ^ l));
        nArray[2] = (int)Class_ca_75c833b3.Pg("e", (int)32614, (long)(0xB977EC69C3B2B6L ^ l));
        nArray[3] = (int)Class_ca_75c833b3.Pg("e", (int)2733, (long)(0x7D4D354F33254777L ^ l));
        nArray[4] = (int)Class_ca_75c833b3.Pg("e", (int)746, (long)(0x618E6619D2494F31L ^ l));
        nArray[5] = (int)Class_ca_75c833b3.Pg("e", (int)32183, (long)(0x56C74F81F3403066L ^ l));
        nArray[Class_ca_75c833b3.Pg("e", (int)24895, (long)(0x4E34B2E029E1ACE2L ^ l))] = (int)Class_ca_75c833b3.Pg("e", (int)29561, (long)(0x67596095D794BEAFL ^ l));
        nArray[Class_ca_75c833b3.Pg("e", (int)4831, (long)(0x1B6C1532B22F5F07L ^ l))] = (int)Class_ca_75c833b3.Pg("e", (int)19010, (long)(0x3750F88FBC0C8784L ^ l));
        nArray[Class_ca_75c833b3.Pg("e", (int)7587, (long)(0x17423B18EDAFD07FL ^ l))] = (int)Class_ca_75c833b3.Pg("e", (int)31858, (long)(0xD1E57874A5C31ACL ^ l));
        nArray[Class_ca_75c833b3.Pg("e", (int)14659, (long)(0x67CC6824BA3A7496L ^ l))] = (int)Class_ca_75c833b3.Pg("e", (int)1528, (long)(0x6AD59CBBECE7482CL ^ l));
        super(nArray, Class_lf_d247d983.MiBKQ);
        this.kkoKC = Class_mT_db06bea0.cpA();
        this.BmYio = new TreeMap<String, Class_ca_sl_9d1d6eea>();
        this.SZBrr = new HashSet<Class_ca_sl_9d1d6eea>();
    }

    /*
     * Unable to fully structure code
     */
    static {
        block24: {
            block23: {
                block22: {
                    block21: {
                        block20: {
                            Class_ca_75c833b3.PHZMk = Class_gb_9d201141.aYR(-3997543779765898199L, 6302167764031353379L, MethodHandles.lookup().lookupClass()).a(35836888017871L);
                            Class_ca_75c833b3.mckkR = new HashMap<K, V>(13);
                            Class_ca_75c833b3.OW(false);
                            var16 = Class_ca_75c833b3.PHZMk ^ 33888719175133L;
                            var18_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                            v0 = SecretKeyFactory.getInstance("DES");
                            v1 = new byte[8];
                            v2 = v1;
                            v1[0] = (byte)(var16 >>> 56);
                            for (var19_2 = 1; var19_2 < 8; ++var19_2) {
                                v2 = v2;
                                v2[var19_2] = (byte)(var16 << var19_2 * 8 >>> 56);
                            }
                            var18_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                            var25_3 = new String[23];
                            var23_4 = 0;
                            var22_5 = "\u001d\u0084'G\u0011\u00e5\u00e46\u00b6n\u00e3\u0086@\u0007\u0017\u0095x\r?\u00de\u00cf\u007f__ \u007f\u00b6\u00ab>\u00dcA\u00e4 \u00ae\u00e5YE\b\u0084\u00b6a\u00a3\u00e5\u0004X\u00c7h\u001bI\u00d4\u00d7\f{s\b~'\u0010S\u00a1\u00a6\u00ff\u00fe\u000e\u00af\u00cb\u00eb\u0004\u0002\u009fa\u00db\u0094\u0006\u0010\u0016\u00ac\u00a4\u008b1\u00dfQ\u00das\u008d\u008c\u009f\u00da\u0092\u00a9N\u0010\u00b5e\u0017\u00e4l\u001a\u001e\u0084\u0000\u00c0\u000f6\u00ff\u00b0\u00ce] \u00e4\u0088\u00e5c@\u00c3\u00a8\u00f6\u0014ea1\u00a8_g\u0016\u00ca\u0098..\u001c\u00c3\u0015\u000f\n.z\u009f\u00b4\u00d3\u00b1N\u0010\u001a\u00ffz\u0005?\u0092\u00ad\u00d6\u0090\u00ad\u0094q\u0091\u00c3\u000f\u009f\u0010<\u0003\u000bk\u00f7\u0091\u0004\u0088M`\u00c6\u00b6\u00c4\u0005\u00a1\u00af\u0018\u0001\u00e24@\u00a6\u00c4Y\u009f\u009fa\u0013\u00fem+Z?+\u00d8\u00dd\u00ad\u00ae\u0092q\u00bb\u0010\u00d2\u00f2(\u00ca\u00fd|P\u0013p\u00feQ\u00eb\u00d2\u00ee\"?\u0010\u00bf~w\u000f\r\u00f3 \u0019\u0090\u00f7W\u00b3\u00b5\u00ba\u00c1f\u0010P\u00b5\u00db\u0096'\u00d7\u00e7T3\u00ac\u0092(\bC\u0080\u00b7\u0010\u00f3\u0000V\u00dc\u00e3BE#ci\tG\u00ce>~m\u0010\u00ee\u00b4\u0019\u00fd5\u00c8\u00d9B\u00bf\u00abM\u0005\u00bf\u009bF\u00ad(\u00da\u0083w\u0096{G\u0098Q\u00e0Y\u00a9\u00c3\u00ac\u00eb\u0090\u00ffvma\u0093\u00f3\u0007\u001b\u00da\u0090\u00b3\u00c9\u0016j\u00b0\u00f9\u00de.\u00da\u00fd\u001f\u00eb-r\t\u0010\u0083\u00fe\u00b9\u00f5#\u00fc\u00adP\n\u008bx\u00f7\u00d4\t(s\u00104q\u00a2\u00cf\u0095\u008e\u00893\u00ffy\r\u0081&F\u00fc\u0018 \u0012\u00eb\u00e8\u00bf\u00d6\u00a4\u0015\u00cc\u00d5U\u00c8S\u00c4\u00ddDG~\u00a7\u00ca\u00db\u00a5&E\u0096\u00b6\u00f6/\u0084\u0082\u00f7\u0002s\u0018_\u00a2\u0083U\u00c6${\u00afE\u00ec\f\u00ed`\u00c7\u00e8\u00a2\u00ee~\u009a\u0010\"q\u00ec\u00df\u0010\u0000Kt\u00d3}\u00f6\u008e9\u0006e\u00e8<\u0084=\u00d2\u008f\u0010\u0002\u00ec\b\u00c2\u00f2\u00134\u001e\u0010\u00a0\u00ed\b\"\u0098\u00d3\u0082";
                            var24_6 = "\u001d\u0084'G\u0011\u00e5\u00e46\u00b6n\u00e3\u0086@\u0007\u0017\u0095x\r?\u00de\u00cf\u007f__ \u007f\u00b6\u00ab>\u00dcA\u00e4 \u00ae\u00e5YE\b\u0084\u00b6a\u00a3\u00e5\u0004X\u00c7h\u001bI\u00d4\u00d7\f{s\b~'\u0010S\u00a1\u00a6\u00ff\u00fe\u000e\u00af\u00cb\u00eb\u0004\u0002\u009fa\u00db\u0094\u0006\u0010\u0016\u00ac\u00a4\u008b1\u00dfQ\u00das\u008d\u008c\u009f\u00da\u0092\u00a9N\u0010\u00b5e\u0017\u00e4l\u001a\u001e\u0084\u0000\u00c0\u000f6\u00ff\u00b0\u00ce] \u00e4\u0088\u00e5c@\u00c3\u00a8\u00f6\u0014ea1\u00a8_g\u0016\u00ca\u0098..\u001c\u00c3\u0015\u000f\n.z\u009f\u00b4\u00d3\u00b1N\u0010\u001a\u00ffz\u0005?\u0092\u00ad\u00d6\u0090\u00ad\u0094q\u0091\u00c3\u000f\u009f\u0010<\u0003\u000bk\u00f7\u0091\u0004\u0088M`\u00c6\u00b6\u00c4\u0005\u00a1\u00af\u0018\u0001\u00e24@\u00a6\u00c4Y\u009f\u009fa\u0013\u00fem+Z?+\u00d8\u00dd\u00ad\u00ae\u0092q\u00bb\u0010\u00d2\u00f2(\u00ca\u00fd|P\u0013p\u00feQ\u00eb\u00d2\u00ee\"?\u0010\u00bf~w\u000f\r\u00f3 \u0019\u0090\u00f7W\u00b3\u00b5\u00ba\u00c1f\u0010P\u00b5\u00db\u0096'\u00d7\u00e7T3\u00ac\u0092(\bC\u0080\u00b7\u0010\u00f3\u0000V\u00dc\u00e3BE#ci\tG\u00ce>~m\u0010\u00ee\u00b4\u0019\u00fd5\u00c8\u00d9B\u00bf\u00abM\u0005\u00bf\u009bF\u00ad(\u00da\u0083w\u0096{G\u0098Q\u00e0Y\u00a9\u00c3\u00ac\u00eb\u0090\u00ffvma\u0093\u00f3\u0007\u001b\u00da\u0090\u00b3\u00c9\u0016j\u00b0\u00f9\u00de.\u00da\u00fd\u001f\u00eb-r\t\u0010\u0083\u00fe\u00b9\u00f5#\u00fc\u00adP\n\u008bx\u00f7\u00d4\t(s\u00104q\u00a2\u00cf\u0095\u008e\u00893\u00ffy\r\u0081&F\u00fc\u0018 \u0012\u00eb\u00e8\u00bf\u00d6\u00a4\u0015\u00cc\u00d5U\u00c8S\u00c4\u00ddDG~\u00a7\u00ca\u00db\u00a5&E\u0096\u00b6\u00f6/\u0084\u0082\u00f7\u0002s\u0018_\u00a2\u0083U\u00c6${\u00afE\u00ec\f\u00ed`\u00c7\u00e8\u00a2\u00ee~\u009a\u0010\"q\u00ec\u00df\u0010\u0000Kt\u00d3}\u00f6\u008e9\u0006e\u00e8<\u0084=\u00d2\u008f\u0010\u0002\u00ec\b\u00c2\u00f2\u00134\u001e\u0010\u00a0\u00ed\b\"\u0098\u00d3\u0082".length();
                            var21_7 = 24;
                            var20_8 = -1;
lbl21:
                            // 2 sources

                            while (true) {
                                v3 = ++var20_8;
                                v4 = var22_5.substring(v3, v3 + var21_7);
                                v5 = -1;
                                break block20;
                                break;
                            }
lbl26:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = Class_ca_75c833b3.Pa(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                var22_5 = "\u0089\u00f5z\u008d\u00f0\u00e3\u00f9\u00dfa\u00965\u0080U}kS0\u00cfCZ\u0087J\u0089\u0092\u00ae\u0093\u00b1\u00f3\u00ed\u0090\u00c5G\u00a2UM\u0005\u00bd\u00f6\u0089\u0010\u0080=\u00f4\u00e7\u0087\u00d1\u00da\u001e\u00feg\n\u00c2S\u00f9G\u000e\u00ec\u008f\u00df\u00ecQ\u00cc\u00cc\u00c0o";
                                var24_6 = "\u0089\u00f5z\u008d\u00f0\u00e3\u00f9\u00dfa\u00965\u0080U}kS0\u00cfCZ\u0087J\u0089\u0092\u00ae\u0093\u00b1\u00f3\u00ed\u0090\u00c5G\u00a2UM\u0005\u00bd\u00f6\u0089\u0010\u0080=\u00f4\u00e7\u0087\u00d1\u00da\u001e\u00feg\n\u00c2S\u00f9G\u000e\u00ec\u008f\u00df\u00ecQ\u00cc\u00cc\u00c0o".length();
                                var21_7 = 16;
                                var20_8 = -1;
lbl35:
                                // 2 sources

                                while (true) {
                                    v6 = ++var20_8;
                                    v4 = var22_5.substring(v6, v6 + var21_7);
                                    v5 = 0;
                                    break block20;
                                    break;
                                }
                                break;
                            }
lbl40:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = Class_ca_75c833b3.Pa(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                break block21;
                                break;
                            }
                        }
                        var26_9 = var18_1.doFinal(v4.getBytes("ISO-8859-1"));
                        switch (v5) {
                            default: {
                                ** continue;
                            }
                            ** case 0:
lbl52:
                            // 1 sources

                            ** continue;
                        }
                    }
                    Class_ca_75c833b3.pbFOM = var25_3;
                    Class_ca_75c833b3.qtBBV = new String[23];
                    Class_ca_75c833b3.WQoAo = new HashMap<K, V>(13);
                    var5_10 = Cipher.getInstance("DES/CBC/NoPadding");
                    v7 = SecretKeyFactory.getInstance("DES");
                    v8 = new byte[8];
                    v9 = v8;
                    v8[0] = (byte)(var16 >>> 56);
                    for (var6_11 = 1; var6_11 < 8; ++var6_11) {
                        v9 = v9;
                        v9[var6_11] = (byte)(var16 << var6_11 * 8 >>> 56);
                    }
                    var5_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                    var11_12 = new long[17];
                    var8_13 = 0;
                    var9_14 = "\u008c\u00d2\u00ed\u00ad\u00e6A\u00c6\u008e\u00b3\u0006 \u00fc{*\u00e2\u0015\u00cd\u00a1\u00cf\u00e6mQ\u00c7\u00d0\u00af9hW\u00ee\u008d\u00a88\u009f\u00d9\u00ed[\u00eb\u00a9\u00d8\u0099\u0003s\u00f2m\u0003\u00bcDu\u009d6l\u0092S\u00b7\u0010^wA: \u00f2J\u0017\u0088b\u0018\u00ad<\u00f3\u00fc\"\u0006@\u00f3)\u00e2@\u00e5kM>#8\u00ef-\u0085\u00f6\u0082\u00eb\u00f7\u0080\u00a2\u00d2\u0012^\u00d83@\u0007y`UA\u0095\u0085\u00da\u00ff\u00b8\u0084\u00d0\u0010\u00c6\u00a7 U\u00fa\u00d3h\u00a4\u00d9";
                    var10_15 = "\u008c\u00d2\u00ed\u00ad\u00e6A\u00c6\u008e\u00b3\u0006 \u00fc{*\u00e2\u0015\u00cd\u00a1\u00cf\u00e6mQ\u00c7\u00d0\u00af9hW\u00ee\u008d\u00a88\u009f\u00d9\u00ed[\u00eb\u00a9\u00d8\u0099\u0003s\u00f2m\u0003\u00bcDu\u009d6l\u0092S\u00b7\u0010^wA: \u00f2J\u0017\u0088b\u0018\u00ad<\u00f3\u00fc\"\u0006@\u00f3)\u00e2@\u00e5kM>#8\u00ef-\u0085\u00f6\u0082\u00eb\u00f7\u0080\u00a2\u00d2\u0012^\u00d83@\u0007y`UA\u0095\u0085\u00da\u00ff\u00b8\u0084\u00d0\u0010\u00c6\u00a7 U\u00fa\u00d3h\u00a4\u00d9".length();
                    var7_16 = 0;
                    while (true) {
                        var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                        v10 = var11_12;
                        v11 = var8_13++;
                        v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                        v13 = -1;
                        break block22;
                        break;
                    }
lbl79:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        var9_14 = "\u0094b\u001a\u00f0\u00b9+W\u0001\u001fu\u00cc\u0004\u0007\u00b4U\u0086";
                        var10_15 = "\u0094b\u001a\u00f0\u00b9+W\u0001\u001fu\u00cc\u0004\u0007\u00b4U\u0086".length();
                        var7_16 = 0;
                        while (true) {
                            var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                            v10 = var11_12;
                            v11 = var8_13++;
                            v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                            v13 = 0;
                            break block22;
                            break;
                        }
                        break;
                    }
lbl92:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        break block23;
                        break;
                    }
                }
                var13_18 = v12;
                var15_19 = var5_10.doFinal(new byte[]{(byte)(var13_18 >>> 56), (byte)(var13_18 >>> 48), (byte)(var13_18 >>> 40), (byte)(var13_18 >>> 32), (byte)(var13_18 >>> 24), (byte)(var13_18 >>> 16), (byte)(var13_18 >>> 8), (byte)var13_18});
                v14 = ((long)var15_19[0] & 255L) << 56 | ((long)var15_19[1] & 255L) << 48 | ((long)var15_19[2] & 255L) << 40 | ((long)var15_19[3] & 255L) << 32 | ((long)var15_19[4] & 255L) << 24 | ((long)var15_19[5] & 255L) << 16 | ((long)var15_19[6] & 255L) << 8 | (long)var15_19[7] & 255L;
                switch (v13) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl105:
                    // 1 sources

                    ** continue;
                }
            }
            Class_ca_75c833b3.zZGgU = var11_12;
            Class_ca_75c833b3.vMfEW = new Integer[17];
            var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
            v15 = SecretKeyFactory.getInstance("DES");
            v16 = new byte[8];
            v17 = v16;
            v16[0] = (byte)(var16 >>> 56);
            for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                v17 = v17;
                v17[var1_21] = (byte)(var16 << var1_21 * 8 >>> 56);
            }
            break block24;
lbl119:
            // 1 sources

            while (true) {
                continue;
                break;
            }
        }
        var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
        var2_22 = -3313581412779160603L;
        var4_23 = var0_20.doFinal(new byte[]{(byte)(var2_22 >>> 56), (byte)(var2_22 >>> 48), (byte)(var2_22 >>> 40), (byte)(var2_22 >>> 32), (byte)(var2_22 >>> 24), (byte)(var2_22 >>> 16), (byte)(var2_22 >>> 8), (byte)var2_22});
        ** while (true)
        Class_ca_75c833b3.pgXwp = ((long)var4_23[0] & 255L) << 56 | ((long)var4_23[1] & 255L) << 48 | ((long)var4_23[2] & 255L) << 40 | ((long)var4_23[3] & 255L) << 32 | ((long)var4_23[4] & 255L) << 24 | ((long)var4_23[5] & 255L) << 16 | ((long)var4_23[6] & 255L) << 8 | (long)var4_23[7] & 255L;
    }

    private static CallSite Pd(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_ca_75c833b3" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int Pe(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x68C6;
        if (vMfEW[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = zZGgU[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])WQoAo.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    WQoAo.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_ca_75c833b3", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_ca_75c833b3.vMfEW[n2] = n3;
        }
        return vMfEW[n2];
    }

    private static Object Pc(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_ca_75c833b3.Pb(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static int Pf(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_ca_75c833b3.Pe(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private List<Class_ca_sl_9d1d6eea> OP() {
        ClientPlayNetworkHandler clientPlayNetworkHandler;
        boolean bl;
        ArrayList<Class_ca_sl_9d1d6eea> arrayList;
        long l;
        block10: {
            block11: {
                block8: {
                    MinecraftClient minecraftClient;
                    block9: {
                        block7: {
                            l = PHZMk ^ 0x2416CD540C26L;
                            arrayList = new ArrayList<Class_ca_sl_9d1d6eea>();
                            bl = Class_ca_75c833b3.OY();
                            minecraftClient = ClientMain.dlmvG;
                            if (!bl) break block7;
                            if (minecraftClient.world == null) break block8;
                            minecraftClient = ClientMain.dlmvG;
                        }
                        if (!bl) break block9;
                        if (minecraftClient.isConnectedToLocalServer()) break block8;
                        minecraftClient = ClientMain.dlmvG;
                    }
                    clientPlayNetworkHandler = minecraftClient.getNetworkHandler();
                    if (!bl) break block10;
                    if (clientPlayNetworkHandler != null) break block11;
                }
                return arrayList;
            }
            clientPlayNetworkHandler = ClientMain.dlmvG.getNetworkHandler();
        }
        for (PlayerListEntry playerListEntry : clientPlayNetworkHandler.getPlayerList()) {
            String string;
            Team team = playerListEntry.getScoreboardTeam();
            if (bl) {
                if (team == null && bl) continue;
                team = playerListEntry.getScoreboardTeam();
            }
            Team team2 = team;
            Text text = team2.getPrefix();
            String string2 = Class_ru_937c8ae6.djG(text.getString());
            String string3 = string = Formatting.strip((String)string2);
            if (bl) {
                if (string3 == null && bl) continue;
                string3 = string = Class_ru_937c8ae6.djG(string).toLowerCase();
            }
            if (bl) {
                if (!Class_ca_75c833b3.OR(string3) && bl) continue;
                string3 = String.join((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)16931, (long)(0x44FDF920F3C0B519L ^ l))), team2.getPlayerList());
            }
            String string4 = string3;
            Class_mG_52c8d386 class_mG_52c8d386 = this.OS(text, team2);
            CallSite callSite = playerListEntry.getGameMode() == GameMode.SPECTATOR ? Class_ca_75c833b3.Pd("m", (int)27778, (long)(0x62ED9DB6E54F9BAFL ^ l)) : Class_ca_75c833b3.Pd("m", (int)25768, (long)(0x2AD88D747C6A139BL ^ l));
            arrayList.add(new Class_ca_sl_9d1d6eea(string4, string2, class_mG_52c8d386, (String)((Object)callSite)));
            if (bl) continue;
        }
        return arrayList;
    }

    @Override
    protected void NV(Class_lC_5322e8cf class_lC_5322e8cf) {
        block5: {
            Object object;
            long l = PHZMk ^ 0x2056BB9F05CAL;
            boolean bl = Class_ca_75c833b3.OY();
            super.NV(class_lC_5322e8cf);
            boolean bl2 = bl;
            Class_ii_9b427eda class_ii_9b427eda = ClientMain.dlM();
            Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.joxgd.bYM(7.0f);
            float f = 22.0f;
            zXCXX.bUa(class_lq_87a74641);
            Object object2 = null;
            for (Class_ca_sl_9d1d6eea class_ca_sl_9d1d6eea : this.BmYio.values()) {
                Class_rk_bf8630d1 class_rk_bf8630d1 = class_ca_sl_9d1d6eea.VoBja;
                object = class_rk_bf8630d1;
                if (bl2) {
                    float f2 = ((Class_rk_bf8630d1)object).dhj() - 0.0f;
                    float f3 = f2 == 0.0f ? 0 : (f2 > 0.0f ? 1 : -1);
                    if (bl2) {
                        if (f3 == false) {
                            object2 = class_ca_sl_9d1d6eea;
                            if (bl2) continue;
                        }
                        f3 = (float)class_ca_sl_9d1d6eea.BwIFl.equals(Class_ca_75c833b3.Pd("m", (int)28568, (long)(0x3053A18CA72F1141L ^ l)));
                    }
                    Class_lf_d247d983 class_lf_d247d983 = f3 != false ? Class_lf_d247d983.XzjRK : Class_lf_d247d983.DzxCD;
                    float f4 = -4.5f + 4.5f * class_rk_bf8630d1.dhj();
                    Class_mG_52c8d386 class_mG_52c8d386 = class_ii_9b427eda.bjb().coa(255.0f * class_rk_bf8630d1.dhj());
                    Class_mG_52c8d386 class_mG_52c8d3862 = class_ii_9b427eda.bjc().coa(255.0f * class_rk_bf8630d1.dhj());
                    float f5 = this.toIeR + 7.0f * class_rk_bf8630d1.dhj();
                    float f6 = this.QWaAn + f + f4 + Class_jf_d1c4f950.bAH(8.0f, 18.0f);
                    class_lC_5322e8cf.cem(class_lf_d247d983, f5, f6, 8.0f, class_mG_52c8d3862);
                    float f7 = this.toIeR + 13.0f + 7.0f * class_rk_bf8630d1.dhj();
                    float f8 = this.QWaAn + f + f4 + Class_jf_d1c4f950.bAH(class_lq_87a74641.cat(), 18.0f);
                    class_lC_5322e8cf.cer(class_lq_87a74641, class_ca_sl_9d1d6eea.sliuY, f7, f8, class_ca_sl_9d1d6eea.iIDDI);
                    float f9 = this.toIeR + this.jTsqG - 7.0f * class_rk_bf8630d1.dhj();
                    class_lC_5322e8cf.cev(class_lq_87a74641, class_ca_sl_9d1d6eea.EVJUd, f9, f8, class_mG_52c8d386);
                    f += 18.0f;
                    if (bl2) continue;
                }
                break block5;
            }
            zXCXX.endBatch();
            object = object2;
            if (bl2 && object != null) {
                object = this.BmYio.remove(((Class_ca_sl_9d1d6eea)object2).EVJUd);
            }
        }
    }

    @Override
    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        block18: {
            boolean bl;
            block25: {
                block24: {
                    Class_ca_75c833b3 class_ca_75c833b3;
                    boolean bl2;
                    block17: {
                        long l = PHZMk ^ 0x34ED519AEA0AL;
                        this.jTsqG = 92.0f;
                        this.Xtjvx = 20.0f;
                        bl = Class_ca_75c833b3.OX();
                        Class_ca_75c833b3 class_ca_75c833b32 = this;
                        if (!bl) {
                            if (class_ca_75c833b32.kkoKC.cpC(pgXwp)) {
                                this.SZBrr.clear();
                                this.SZBrr.addAll(this.OP());
                                this.SZBrr.addAll(this.OQ());
                                this.kkoKC.cpB();
                            }
                            class_ca_75c833b32 = this;
                        }
                        for (Class_ca_sl_9d1d6eea object : class_ca_75c833b32.SZBrr) {
                            block23: {
                                String string;
                                Map<String, Class_ca_sl_9d1d6eea> map;
                                block19: {
                                    block20: {
                                        block22: {
                                            Class_rk_bf8630d1 class_rk_bf8630d1;
                                            block21: {
                                                Class_rk_bf8630d1 class_rk_bf8630d12;
                                                map = this.BmYio;
                                                string = object.EVJUd;
                                                if (bl) break block19;
                                                bl2 = map.containsKey(string);
                                                if (bl) break block17;
                                                if (!bl2) break block20;
                                                this.BmYio.replace(object.EVJUd, object);
                                                class_rk_bf8630d1 = class_rk_bf8630d12 = object.VoBja;
                                                if (bl) break block21;
                                                if (class_rk_bf8630d1.dhj() != 0.0f) break block22;
                                                class_rk_bf8630d1 = class_rk_bf8630d12;
                                            }
                                            class_rk_bf8630d1.dhe(1.0f);
                                        }
                                        if (!bl) break block23;
                                    }
                                    map = this.BmYio;
                                    string = object.EVJUd;
                                }
                                map.put(string, object);
                                object.VoBja.dhe(1.0f);
                            }
                            if (!bl) continue;
                        }
                        class_ca_75c833b3 = this;
                        if (bl) break block24;
                        bl2 = class_ca_75c833b3.BmYio.isEmpty();
                    }
                    if (bl2) break block25;
                    class_ca_75c833b3 = this;
                }
                class_ca_75c833b3.Xtjvx += 5.0f;
            }
            Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.joxgd.bYM(7.0f);
            for (Class_ca_sl_9d1d6eea class_ca_sl_9d1d6eea2 : this.BmYio.values()) {
                Class_rk_bf8630d1 class_rk_bf8630d1 = class_ca_sl_9d1d6eea2.VoBja;
                String string = class_ca_sl_9d1d6eea2.EVJUd;
                String string2 = class_ca_sl_9d1d6eea2.sliuY;
                class_rk_bf8630d1.dhc(this.SZBrr.stream().anyMatch(class_ca_sl_9d1d6eea -> class_ca_sl_9d1d6eea.EVJUd.equals(string)));
                class_rk_bf8630d1.dhs(Class_rj_b691f4f7.XzDkv);
                this.jTsqG = Math.max(class_lq_87a74641.cao(string) + class_lq_87a74641.cao(string2) + 30.0f, this.jTsqG);
                this.Xtjvx += 18.0f * class_rk_bf8630d1.dhj();
                if (!bl) {
                    if (!bl) continue;
                }
                break block18;
            }
            super.LX(class_lC_5322e8cf);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean OR(String string) {
        long l = PHZMk ^ 0x51546B3DBE9EL;
        boolean bl = Class_ca_75c833b3.OX();
        boolean bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)14372, (long)(0x731B7200F2E3FDB5L ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)1576, (long)(0x1AF34CB2970C3AFL ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)28453, (long)(0x59B578F2A76C2AACL ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)3997, (long)(0x33EC871097294A1EL ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)13311, (long)(0x52134305008DF66FL ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)26701, (long)(0x36EE9ECD6F832DC3L ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)18675, (long)(0x3B2D44707AF0D7CL ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)24200, (long)(0x55EF931E80339B0EL ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)17848, (long)(0x70ACA42BD1538030L ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)26272, (long)(0x472F0CDC2DEFA324L ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)8505, (long)(0x1E986A8A782964B8L ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)18944, (long)(0xC859AC24DDF8F96L ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)9306, (long)(0x66544089A91B61D6L ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)16267, (long)(0x5AA55CE92556FA01L ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)551, (long)(0x573B428D785AC7B5L ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)16447, (long)(0x71161D5E180B05BFL ^ l))));
        if (bl) return bl2;
        if (bl2) return true;
        bl2 = string.contains((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)2457, (long)(0x593807783C2F4C1CL ^ l))));
        if (bl) return bl2;
        if (!bl2) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean Om() {
        long l = PHZMk ^ 0x23DB2D1F40E0L;
        boolean bl = Class_ca_75c833b3.OY();
        boolean bl2 = this.BmYio.isEmpty();
        if (bl) {
            bl2 = !bl2;
        }
        boolean bl3 = bl2;
        boolean bl4 = ClientMain.dlmvG.currentScreen instanceof ChatScreen;
        boolean bl5 = bl3;
        if (!bl) return bl5;
        if (bl5) return true;
        bl5 = bl4;
        if (!bl) return bl5;
        if (!bl5) return false;
        return true;
    }

    public static void OW(boolean bl) {
        tONvf = bl;
    }

    public static boolean OX() {
        return tONvf;
    }

    private static CallSite Pg(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_ca_75c833b3" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static MatchException OZ(MatchException matchException) {
        return matchException;
    }

    private List<Class_ca_sl_9d1d6eea> OQ() {
        Object object;
        boolean bl;
        ArrayList<Class_ca_sl_9d1d6eea> arrayList;
        long l;
        block15: {
            block16: {
                block13: {
                    MinecraftClient minecraftClient;
                    block14: {
                        block12: {
                            l = PHZMk ^ 0x21CD1CD1FE86L;
                            arrayList = new ArrayList<Class_ca_sl_9d1d6eea>();
                            bl = Class_ca_75c833b3.OX();
                            minecraftClient = ClientMain.dlmvG;
                            if (bl) break block12;
                            if (minecraftClient.world == null) break block13;
                            minecraftClient = ClientMain.dlmvG;
                        }
                        if (bl) break block14;
                        if (minecraftClient.isConnectedToLocalServer()) break block13;
                        minecraftClient = ClientMain.dlmvG;
                    }
                    object = minecraftClient.getNetworkHandler();
                    if (bl) break block15;
                    if (object != null) break block16;
                }
                return arrayList;
            }
            object = ClientMain.dlmvG.getNetworkHandler().getPlayerList().stream().map(playerListEntry -> playerListEntry.getProfile().name()).collect(Collectors.toSet());
        }
        Set set = (Set)object;
        for (Team team : ClientMain.dlmvG.world.getScoreboard().getTeams()) {
            String string;
            boolean bl2;
            String string22;
            Collection collection;
            block11: {
                collection = team.getPlayerList();
                boolean bl3 = collection.isEmpty();
                if (!bl) {
                    if (bl3 && !bl) continue;
                    bl3 = false;
                }
                boolean bl4 = bl3;
                for (String string22 : collection) {
                    block18: {
                        block17: {
                            bl2 = set.contains(string22);
                            if (bl) break block11;
                            if (bl) break block17;
                            if (!bl2) break block18;
                            boolean bl5 = bl4 = true;
                        }
                        if (!bl) break;
                    }
                    if (!bl) continue;
                }
                bl2 = bl4;
            }
            if (bl2 && !bl) continue;
            Text text = team.getPrefix();
            String string3 = string22 = text.getString();
            if (!bl) {
                if (string3.isEmpty() && !bl) continue;
                string3 = Class_ru_937c8ae6.djG(Formatting.strip((String)string22)).toLowerCase();
            }
            String string4 = string = string3;
            if (!bl) {
                if (!Class_ca_75c833b3.OR(string4) && !bl) continue;
                string4 = String.join((CharSequence)((Object)Class_ca_75c833b3.Pd("m", (int)14959, (long)(0x54B959E952493FE0L ^ l))), collection);
            }
            String string5 = string4;
            arrayList.add(new Class_ca_sl_9d1d6eea(string5, string22, this.OS(text, team), (String)((Object)Class_ca_75c833b3.Pd("m", (int)18353, (long)(0x4DA0E13580A2423DL ^ l)))));
            if (!bl) continue;
        }
        return arrayList;
    }

    private Class_mG_52c8d386 OS(Text text, Team team) {
        block6: {
            Integer n;
            block8: {
                Integer n2;
                Formatting formatting;
                boolean bl;
                block7: {
                    Team team2;
                    block5: {
                        long l = PHZMk ^ 0x1165E401B19L;
                        TextColor textColor = text.getStyle().getColor();
                        bl = Class_ca_75c833b3.OX();
                        if (textColor != null) {
                            return Class_mG_52c8d386.cnQ(Class_ca_75c833b3.Pg("e", (int)9687, (long)(0x658305D02B80BA19L ^ l)) | textColor.getRgb());
                        }
                        TextColor[] textColorArray = new TextColor[1];
                        text.visit((style, string) -> {
                            block0: {
                                long l = PHZMk ^ 0x21323B7DC382L;
                                if (style.getColor() == null) break block0;
                                textColorArray[0] = style.getColor();
                            }
                            return Optional.empty();
                        }, Style.EMPTY);
                        if (textColorArray[0] != null) {
                            return Class_mG_52c8d386.cnQ(Class_ca_75c833b3.Pg("e", (int)9834, (long)(0x531D1B49149BB9AAL ^ l)) | textColorArray[0].getRgb());
                        }
                        team2 = team;
                        if (bl) break block5;
                        if (team2 == null) break block6;
                        team2 = team;
                    }
                    formatting = team2.getColor();
                    if (bl) break block7;
                    if (!formatting.isModifier()) break block6;
                    formatting = team.getColor();
                }
                n = n2 = formatting.getColorValue();
                if (bl) break block8;
                if (n == null) break block6;
                n = n2;
            }
            return Class_mG_52c8d386.cnQ(n);
        }
        return Class_mG_52c8d386.hoGuU;
    }

    private static String Pb(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x1704;
        if (qtBBV[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])mckkR.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    mckkR.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_ca_75c833b3", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = pbFOM[n2].getBytes("ISO-8859-1");
            Class_ca_75c833b3.qtBBV[n2] = Class_ca_75c833b3.Pa(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return qtBBV[n2];
    }

    private static String Pa(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public static boolean OY() {
        boolean bl = Class_ca_75c833b3.OX();
        return !bl;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_ca_75c833b3.class, "Pc", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_ca_75c833b3.class, "Pf", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

