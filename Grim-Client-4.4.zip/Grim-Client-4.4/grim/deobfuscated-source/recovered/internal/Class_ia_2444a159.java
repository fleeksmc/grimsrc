/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.context.StringRange
 *  com.mojang.brigadier.suggestion.Suggestion
 *  com.mojang.brigadier.suggestion.Suggestions
 */
package recovered.internal;

import com.mojang.brigadier.context.StringRange;
import com.mojang.brigadier.suggestion.Suggestion;
import com.mojang.brigadier.suggestion.Suggestions;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import recovered.core.NativeLoader;
import recovered.internal.Class_gU_9448080d;
import recovered.internal.Class_hG_d70cdb00;
import recovered.internal.Class_hM_a36d442e;
import recovered.internal.Class_hZ_076851ce;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ia_tF_2f11a7e4;

public class Class_ia_2444a159 {
    private static Object UckPC;
    private final List<Class_hZ_076851ce> HjCSP;
    private String MHBfP;
    private static String zBIZu;
    private static long MYMbZ;
    private static String[] MKAAg;
    private static String[] bmPjW;
    private static Map uujNg;
    private static long HuQOe;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ia_2444a159() {
        long l = MYMbZ ^ 0x16B1FBF10686L;
        String string = Class_ia_2444a159.bgL();
        String string2 = string;
        try {
            this.HjCSP = new ArrayList<Class_hZ_076851ce>();
            this.MHBfP = ".";
            if (Class_iS_888f260e.bwL() == null) {
                Class_ia_2444a159.bgK("A8PTpc");
            }
        }
        catch (MatchException matchException) {
            throw Class_ia_2444a159.bgM(matchException);
        }
    }

    static {
        NativeLoader.doInit(Class_ia_2444a159.class);
        Class_ia_2444a159._960882a417015a51b6e696ca2a69b59b();
    }

    public static native String bgL();

    public static native void bgK(String var0);

    public native boolean bgz(String var1);

    private native Object bgD(Class_hM_a36d442e<?> var1, String var2);

    private static native String bgN(byte[] var0);

    public native String bgI();

    private static native String bgH(String var0);

    private static native Object bgP(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native List<Object> bgC(Class_hZ_076851ce var1, String[] var2, int var3);

    private native Class_hZ_076851ce bgG(List<Class_hZ_076851ce> var1, String var2);

    public native void bgu();

    private static native MatchException bgM(MatchException var0);

    private native Class_ia_tF_2f11a7e4 bgB(List<String> var1, Class_hZ_076851ce var2, int var3);

    private static native CallSite bgQ(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native void bgv();

    public native void bgx(Class_hZ_076851ce var1);

    public native void bgJ(String var1);

    private static native String bgO(int var0, long var1);

    @Class_hG_d70cdb00
    public native void bgw(Class_gU_9448080d var1);

    private native Class_hM_a36d442e<?> bgF(List<Class_hM_a36d442e<?>> var1, int var2, boolean var3);

    private native void bgE(List<Class_hZ_076851ce> var1, String var2, StringRange var3, List<Suggestion> var4);

    public native CompletableFuture<Suggestions> bgA(String var1, int var2);

    public native List<Class_hZ_076851ce> bgy();

    private static native void _960882a417015a51b6e696ca2a69b59b();
}

