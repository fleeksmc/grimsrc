/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_ah_02444db4
extends Class_az_a4990dcf {
    private double jHuGT;
    private double TCqpd;
    private double spjLF;
    private double sZwZd;
    private double UUSmJ;
    private final Class_rk_bf8630d1 xyejr;
    private static final long DnwET;
    private static final long[] Ewwsz;
    private static final Integer[] MFJtF;
    private static final Map yjZJj;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ah_02444db4() {
        long l = DnwET ^ 0x2C7BB6337FB5L;
        this.TCqpd = 0.0;
        this.spjLF = 0.0;
        this.sZwZd = 20.0;
        this.UUSmJ = 0.0;
        this.xyejr = new Class_rk_bf8630d1((int)Class_ah_02444db4.nY("d", (int)27226, (long)(0x56D05FFF79B059A1L ^ l))).dhs(Class_rj_b691f4f7.XzDkv);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_ah_02444db4.DnwET = Class_gb_9d201141.aYR(3253819375579256058L, -242973308182835243L, MethodHandles.lookup().lookupClass()).a(112643053348745L);
                Class_ah_02444db4.yjZJj = new HashMap<K, V>(13);
                var0 = Class_ah_02444db4.DnwET ^ 96048043455601L;
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[5];
                var5_4 = 0;
                var6_5 = "\u00d7\u0099@\u00f4\u00e8\u0001\u0014\u00c2\u00b9*\u00ff\u00f7H\u0014l\u0080\u00bfI\u00ce\u00b4\u001b\u00f8\u00c3\u0003";
                var7_6 = "\u00d7\u0099@\u00f4\u00e8\u0001\u0014\u00c2\u00b9*\u00ff\u00f7H\u0014l\u0080\u00bfI\u00ce\u00b4\u001b\u00f8\u00c3\u0003".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl26:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = "y`V?\u00ab\u008f\u009f\u0094e\u0011\u00a7R\u00bf\u00fd\u00a2\u00c0";
                    var7_6 = "y`V?\u00ab\u008f\u009f\u0094e\u0011\u00a7R\u00bf\u00fd\u00a2\u00c0".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl52:
                // 1 sources

                ** continue;
            }
        }
        Class_ah_02444db4.Ewwsz = var8_3;
        Class_ah_02444db4.MFJtF = new Integer[5];
    }

    @Override
    public boolean dm(int n, int n2, int n3) {
        boolean bl;
        block6: {
            CallSite callSite;
            block5: {
                long l = DnwET ^ 0x32FE639A1C7L;
                String[] stringArray = Class_aj_95d0a719.oA();
                bl = n;
                callSite = Class_ah_02444db4.nY("d", (int)16454, (long)(0x2C2BA9749025ADCCL ^ l));
                if (stringArray == null) break block5;
                if (bl == callSite) {
                    this.nJ(1.0);
                    return true;
                }
                bl = n;
                if (stringArray == null) break block6;
                callSite = Class_ah_02444db4.nY("d", (int)17877, (long)(0x7D6109240D9BA85DL ^ l));
            }
            if (bl == callSite) {
                this.nJ(-1.0);
                return true;
            }
            bl = super.dm(n, n2, n3);
        }
        return bl;
    }

    @Override
    protected void bV(Class_lC_5322e8cf class_lC_5322e8cf) {
        Class_ah_02444db4 class_ah_02444db4;
        block4: {
            block5: {
                block3: {
                    double d;
                    block2: {
                        long l = DnwET ^ 0x786293EDF108L;
                        String[] stringArray = Class_aj_95d0a719.oA();
                        double d2 = this.UUSmJ - (double)this.WjISQ;
                        d = d2 == 0.0 ? 0 : (d2 < 0.0 ? -1 : 1);
                        if (stringArray == null) break block2;
                        if (d <= 0) break block3;
                        class_ah_02444db4 = this;
                        if (stringArray == null) break block4;
                        double d3 = class_ah_02444db4.jHuGT - 0.0;
                        d = d3 == 0.0 ? 0 : (d3 < 0.0 ? -1 : 1);
                    }
                    if (d > 0) break block5;
                }
                return;
            }
            class_ah_02444db4 = this;
        }
        float f = class_ah_02444db4.WjISQ / (float)this.UUSmJ;
        float f2 = Math.max(24.0f, this.WjISQ * f);
        double d = this.nH();
        d = Math.max(0.0, Math.min(d, this.jHuGT));
        float f3 = this.WjISQ - f2;
        float f4 = (float)(d / this.jHuGT);
    }

    private static int nW(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0xF79;
        if (MFJtF[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = Ewwsz[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])yjZJj.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    yjZJj.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_ah_02444db4", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_ah_02444db4.MFJtF[n2] = n3;
        }
        return MFJtF[n2];
    }

    public void nG() {
        long l = DnwET ^ 0x271AC9925F79L;
        this.spjLF = Math.max(0.0, Math.min(this.spjLF, this.jHuGT));
        double d = this.spjLF - this.TCqpd;
        this.TCqpd += d;
        String[] stringArray = Class_aj_95d0a719.oA();
        double d2 = Math.abs(d);
        if (stringArray != null) {
            if (d2 > 0.0) {
                this.xyejr.dhs(d2 > 21.0 ? Class_rj_b691f4f7.JbGQS : Class_rj_b691f4f7.XzDkv);
                CallSite callSite = Class_ah_02444db4.nY("d", (int)30077, (long)(0x120FB0FE01106648L ^ l));
                int n = (int)Math.ceil((d2 - 61.0) / 20.0);
                n = Math.max(0, Math.min(3, n));
                reference var10_7 = callSite + n * Class_ah_02444db4.nY("d", (int)27501, (long)(0x39F0A68E7E1DF85DL ^ l));
                this.xyejr.dhq((int)var10_7);
            }
            this.xyejr.dhd((float)this.TCqpd);
        }
    }

    public void nI() {
        this.TCqpd = 0.0;
        this.spjLF = 0.0;
        this.xyejr.dhg();
    }

    public Class_ah_02444db4 nQ(double d) {
        this.jHuGT = d;
        return this;
    }

    public double nH() {
        return this.xyejr.dhj();
    }

    public void nJ(double d) {
        this.spjLF -= d * this.sZwZd;
    }

    public double nN() {
        return this.sZwZd;
    }

    public double nK() {
        return this.jHuGT;
    }

    public double nO() {
        return this.UUSmJ;
    }

    public Class_rk_bf8630d1 nP() {
        return this.xyejr;
    }

    public Class_ah_02444db4 nR(double d) {
        this.TCqpd = d;
        return this;
    }

    private static MatchException nV(MatchException matchException) {
        return matchException;
    }

    private static int nX(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_ah_02444db4.nW(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public Class_ah_02444db4 nS(double d) {
        this.spjLF = d;
        return this;
    }

    public double nM() {
        return this.spjLF;
    }

    public Class_ah_02444db4 nU(double d) {
        this.UUSmJ = d;
        return this;
    }

    private static CallSite nY(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_ah_02444db4" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public double nL() {
        return this.TCqpd;
    }

    public Class_ah_02444db4 nT(double d) {
        this.sZwZd = d;
        return this;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_ah_02444db4.class, "nX", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

