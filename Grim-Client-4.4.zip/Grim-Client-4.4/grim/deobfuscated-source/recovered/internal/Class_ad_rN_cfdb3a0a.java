/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

class Class_ad_rN_cfdb3a0a {
    final boolean Zwieh;
    int icNLz;
    int NHSnT;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ad_rN_cfdb3a0a(boolean bl, int n, int n2) {
        this.Zwieh = bl;
        this.icNLz = n;
        this.NHSnT = n2;
    }

    static {
        NativeLoader.doInit(Class_ad_rN_cfdb3a0a.class);
    }

    native int dmL();

    native int dmM();
}

