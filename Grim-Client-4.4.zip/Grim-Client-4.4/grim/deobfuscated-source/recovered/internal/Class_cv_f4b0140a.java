/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 */
package recovered.internal;

import com.google.gson.JsonElement;
import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_cw_dbcad330;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mr_7eac5189;

public class Class_cv_f4b0140a
extends Class_cB_67aec11c {
    private final List<Class_cw_dbcad330> jjOKZ = new ArrayList<Class_cw_dbcad330>();
    private final List<Class_cw_dbcad330> JIvPe = new ArrayList<Class_cw_dbcad330>();
    private int jHVbQ;
    private boolean tsRCd = false;
    private static final long MorJn = Class_gb_9d201141.aYR(-3429635470523625339L, 2516146184062335452L, MethodHandles.lookup().lookupClass()).a(270174065979058L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cv_f4b0140a(Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_mr_7eac5189);
    }

    public Class_cv_f4b0140a(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    public void To(Class_cw_dbcad330 class_cw_dbcad330) {
        List<Class_cw_dbcad330> list;
        int n;
        block7: {
            int n2;
            int[] nArray;
            block10: {
                block11: {
                    block8: {
                        block9: {
                            long l = MorJn ^ 0x2263389ED0EBL;
                            nArray = Class_cw_dbcad330.TL();
                            if (class_cw_dbcad330 == null) break block8;
                            n2 = this.jjOKZ.contains(class_cw_dbcad330);
                            if (nArray == null) break block9;
                            if (n2 == 0) break block8;
                            n2 = this.JIvPe.contains(class_cw_dbcad330);
                        }
                        if (nArray == null) break block10;
                        if (n2 == 0) break block11;
                    }
                    return;
                }
                n2 = this.jjOKZ.indexOf(class_cw_dbcad330);
            }
            int n3 = n2;
            n = this.JIvPe.size();
            for (int i = 0; i < this.JIvPe.size(); ++i) {
                list = this.jjOKZ;
                if (nArray != null) {
                    int n4 = list.indexOf(this.JIvPe.get(i));
                    if (nArray != null) {
                        if (n4 <= n3) continue;
                        n4 = n = i;
                    }
                    if (nArray != null) break;
                    if (nArray != null) continue;
                }
                break block7;
            }
            list = this.JIvPe;
        }
        list.add(n, class_cw_dbcad330);
        this.Vk();
    }

    private static MatchException Tw(MatchException matchException) {
        return matchException;
    }

    public Class_cv_f4b0140a Tl(boolean bl) {
        this.tsRCd = bl;
        return this;
    }

    public Class_cv_f4b0140a Tm(int n) {
        this.jHVbQ = n;
        return this;
    }

    public boolean Tn(Class_cw_dbcad330 class_cw_dbcad330) {
        return this.JIvPe.contains(class_cw_dbcad330);
    }

    public boolean Tq(int[] nArray) {
        boolean bl;
        block3: {
            long l = MorJn ^ 0xA1D1BE94211L;
            Iterator<Class_cw_dbcad330> iterator = this.jjOKZ.iterator();
            int[] nArray2 = Class_cw_dbcad330.TL();
            while (iterator.hasNext()) {
                block5: {
                    boolean bl2;
                    block4: {
                        Class_cw_dbcad330 class_cw_dbcad330 = iterator.next();
                        bl = Arrays.equals(class_cw_dbcad330.TE(), nArray);
                        if (nArray2 == null) break block3;
                        if (nArray2 == null) break block4;
                        if (!bl) break block5;
                        bl2 = true;
                    }
                    return bl2;
                }
                if (nArray2 != null) continue;
            }
            bl = false;
        }
        return bl;
    }

    @Override
    public void SS(JsonElement jsonElement) {
        block7: {
            int n;
            int[] nArray;
            ArrayList arrayList;
            block6: {
                long l = MorJn ^ 0x133816D8AF6FL;
                arrayList = new ArrayList();
                nArray = Class_cw_dbcad330.TL();
                for (JsonElement jsonElement2 : jsonElement.getAsJsonArray()) {
                    int n2;
                    n = n2 = jsonElement2.getAsInt();
                    if (nArray != null) {
                        int n3;
                        if (nArray != null) {
                            if (n < 0) continue;
                            n3 = n2;
                        }
                        if (nArray != null) {
                            if (n3 >= this.jjOKZ.size() && nArray != null) continue;
                            n3 = arrayList.add(this.jjOKZ.get(n2)) ? 1 : 0;
                        }
                        if (nArray != null) continue;
                    }
                    break block6;
                }
                n = arrayList.equals(this.JIvPe);
            }
            if (nArray != null) {
                if (n != 0) {
                    return;
                }
                this.JIvPe.clear();
                n = this.JIvPe.addAll(arrayList) ? 1 : 0;
            }
            this.Vk();
            if (Class_iS_888f260e.bwL() != null) break block7;
            Class_cw_dbcad330.TK(new int[1]);
        }
    }

    @Override
    public void SR(Map<String, Object> map) {
        map.put(Arrays.toString(this.NwlSF), this.Tr());
    }

    public void Tp(Class_cw_dbcad330 class_cw_dbcad330) {
        block3: {
            Class_cv_f4b0140a class_cv_f4b0140a;
            block2: {
                long l = MorJn ^ 0x3BF34236CD90L;
                int[] nArray = Class_cw_dbcad330.TL();
                class_cv_f4b0140a = this;
                if (nArray == null) break block2;
                if (!class_cv_f4b0140a.JIvPe.remove(class_cw_dbcad330)) break block3;
                class_cv_f4b0140a = this;
            }
            class_cv_f4b0140a.Vk();
        }
    }

    public List<Class_cw_dbcad330> Ts() {
        return this.jjOKZ;
    }

    public List<Class_cw_dbcad330> Tt() {
        return this.JIvPe;
    }

    public boolean Tv() {
        return this.tsRCd;
    }

    public int Tu() {
        return this.jHVbQ;
    }

    public List<Integer> Tr() {
        ArrayList<Integer> arrayList;
        block2: {
            long l = MorJn ^ 0x4650F01A8D9EL;
            ArrayList<Integer> arrayList2 = new ArrayList<Integer>();
            int[] nArray = Class_cw_dbcad330.TL();
            for (Class_cw_dbcad330 class_cw_dbcad330 : this.JIvPe) {
                arrayList = arrayList2;
                if (nArray != null) {
                    arrayList.add(this.jjOKZ.indexOf(class_cw_dbcad330));
                    if (nArray != null) continue;
                }
                break block2;
            }
            arrayList = arrayList2;
        }
        return arrayList;
    }
}

