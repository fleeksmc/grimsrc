/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screen.ChatScreen
 *  net.minecraft.client.network.ClientPlayerEntity
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec2f;
import recovered.core.ClientMain;
import recovered.internal.Class_av_ffcf74a1;
import recovered.internal.Class_bJ_24f874fc;
import recovered.internal.Class_bK_09e62c90;
import recovered.internal.Class_bL_258db0cf;
import recovered.internal.Class_bM_7ea5ddc9;
import recovered.internal.Class_bN_1c0f9dd5;
import recovered.internal.Class_bO_f2df95f3;
import recovered.internal.Class_bP_025253dc;
import recovered.internal.Class_bQ_fa2df2b4;
import recovered.internal.Class_bS_979bca5c;
import recovered.internal.Class_bT_3a1e4a37;
import recovered.internal.Class_bV_61960ba1;
import recovered.internal.Class_cr_3ba4ae18;
import recovered.internal.Class_cv_f4b0140a;
import recovered.internal.Class_cw_dbcad330;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_hF_7bd1921e;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jG_69891630;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_jg_83a87f1c;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_le_52ba6de2;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mT_db06bea0;
import recovered.internal.Class_mr_7eac5189;
import recovered.internal.Class_ri_288534d5;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.internal.Class_rm_d861be3b;

public class Class_bU_714b1dad
extends Class_cr_3ba4ae18 {
    private final Class_cv_f4b0140a MAeMK;
    private final Class_bT_3a1e4a37 GExeP;
    private boolean fpgBD;
    private final Class_rk_bf8630d1 poKgg;
    private final Class_rk_bf8630d1 Elfgo;
    private final Class_rk_bf8630d1 axCzv;
    private final Class_rk_bf8630d1 eAzvd;
    private final Class_ri_288534d5 DIVJZ;
    private final Class_ri_288534d5 wMPQQ;
    private final Class_mT_db06bea0 nYkeq;
    private boolean lQdhK;
    private static final long wYIcR;
    private static final String wQtIy;
    private static final long[] xQGbF;
    private static final Integer[] xtGND;
    private static final Map jRiyL;
    private static final long cZlpv;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bU_714b1dad() {
        block0: {
            long l = wYIcR ^ 0x68B0A94F8DA0L;
            int[] nArray = new int[Class_bU_714b1dad.Oi("b", (int)8650, (long)(0x3A8F767F31C0956DL ^ l))];
            nArray[0] = (int)Class_bU_714b1dad.Oi("b", (int)8379, (long)(0x48E685F834E5940CL ^ l));
            nArray[1] = (int)Class_bU_714b1dad.Oi("b", (int)5437, (long)(0x36F52D4F92BFA194L ^ l));
            nArray[2] = (int)Class_bU_714b1dad.Oi("b", (int)22953, (long)(0x7AAAE2906B2BED01L ^ l));
            nArray[3] = (int)Class_bU_714b1dad.Oi("b", (int)32692, (long)(0x4C6B5B1068584B07L ^ l));
            nArray[4] = (int)Class_bU_714b1dad.Oi("b", (int)6189, (long)(0x6EA32402CAFDAC82L ^ l));
            nArray[5] = (int)Class_bU_714b1dad.Oi("b", (int)17234, (long)(0x56AF69777EFF7FCL ^ l));
            super(nArray, Class_lf_d247d983.IcQeZ);
            int[] nArray2 = new int[Class_bU_714b1dad.Oi("b", (int)29686, (long)(0x23F4C59BAB8DC742L ^ l))];
            nArray2[0] = (int)Class_bU_714b1dad.Oi("b", (int)28358, (long)(0x6929138483505A6DL ^ l));
            nArray2[1] = (int)Class_bU_714b1dad.Oi("b", (int)15453, (long)(0x6A5805BA16BB08FBL ^ l));
            nArray2[2] = (int)Class_bU_714b1dad.Oi("b", (int)23890, (long)(0x1244580BDC6DE9F3L ^ l));
            nArray2[3] = (int)Class_bU_714b1dad.Oi("b", (int)21420, (long)(0x57FDDC74033D6709L ^ l));
            nArray2[4] = (int)Class_bU_714b1dad.Oi("b", (int)27567, (long)(0x4C8E8464F25C5F05L ^ l));
            nArray2[5] = (int)Class_bU_714b1dad.Oi("b", (int)32437, (long)(0x59E6587A15A8CA18L ^ l));
            nArray2[Class_bU_714b1dad.Oi("b", (int)9997, (long)(0x6DADF7A0475313A9L ^ l))] = (int)Class_bU_714b1dad.Oi("b", (int)17771, (long)(0x185B7C3AB5F7F1C7L ^ l));
            nArray2[Class_bU_714b1dad.Oi("b", (int)19925, (long)(0x1A83DED295C0F963L ^ l))] = (int)Class_bU_714b1dad.Oi("b", (int)32437, (long)(0x59E6587A15A8CA18L ^ l));
            this.MAeMK = new Class_cv_f4b0140a(this, Class_mr_7eac5189.clS(nArray2));
            this.GExeP = new Class_bT_3a1e4a37(48.0f, 15.0f);
            this.poKgg = new Class_rk_bf8630d1((int)Class_bU_714b1dad.Oi("b", (int)25793, (long)(0x56D3BE49CBE6D062L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
            this.Elfgo = new Class_rk_bf8630d1((int)Class_bU_714b1dad.Oi("b", (int)22691, (long)(0x39FC6F53D78A6C16L ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
            this.axCzv = new Class_rk_bf8630d1((int)Class_bU_714b1dad.Oi("b", (int)24535, (long)(0x5E8D5CBFBCA36B77L ^ l))).dhs(Class_rj_b691f4f7.NJlxm);
            this.eAzvd = new Class_rk_bf8630d1((int)Class_bU_714b1dad.Oi("b", (int)24535, (long)(0x5E8D5CBFBCA36B77L ^ l))).dhs(Class_rj_b691f4f7.Zotpp);
            this.DIVJZ = new Class_ri_288534d5((int)Class_bU_714b1dad.Oi("b", (int)31786, (long)(0x5F75FC5D3BEAC888L ^ l)), Class_mG_52c8d386.QHTxQ).dfW(Class_rj_b691f4f7.ceYgU);
            this.wMPQQ = new Class_ri_288534d5((int)Class_bU_714b1dad.Oi("b", (int)31786, (long)(0x5F75FC5D3BEAC888L ^ l)), Class_mG_52c8d386.hoGuU).dfW(Class_rj_b691f4f7.Xmkbr);
            this.nYkeq = Class_mT_db06bea0.cpz();
            new Class_bK_09e62c90(this.MAeMK);
            new Class_bN_1c0f9dd5(this.MAeMK);
            new Class_bQ_fa2df2b4(this.MAeMK);
            int n = Class_bS_979bca5c.NR();
            new Class_bO_f2df95f3(this.MAeMK);
            new Class_bM_7ea5ddc9(this.MAeMK);
            new Class_bJ_24f874fc(this.MAeMK);
            new Class_bL_258db0cf(this.MAeMK);
            new Class_bP_025253dc(this.MAeMK);
            Class_hF_7bd1921e.bdI(this);
            if (n != 0) break block0;
            Class_iS_888f260e.bwK("jhtNIc");
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block15: {
            block13: {
                block12: {
                    block14: {
                        Class_bU_714b1dad.wYIcR = Class_gb_9d201141.aYR(8221421259207978705L, 5707684393802880957L, MethodHandles.lookup().lookupClass()).a(6772413656756L);
                        var16 = Class_bU_714b1dad.wYIcR ^ 76202549229364L;
                        var18_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var16 >>> 56);
                        for (var19_2 = 1; var19_2 < 8; ++var19_2) {
                            v2 = v2;
                            v2[var19_2] = (byte)(var16 << var19_2 * 8 >>> 56);
                        }
                        break block14;
lbl13:
                        // 1 sources

                        while (true) {
                            continue;
                            break;
                        }
                    }
                    var18_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                    var20_3 = var18_1.doFinal("\u00af\u00f9\u00ca\u00bdmp\u00ac\u00c5".getBytes("ISO-8859-1"));
                    ** while (true)
                    Class_bU_714b1dad.wQtIy = Class_bU_714b1dad.Of(var20_3).intern();
                    Class_bU_714b1dad.jRiyL = new HashMap<K, V>(13);
                    var5_4 = Cipher.getInstance("DES/CBC/NoPadding");
                    v3 = SecretKeyFactory.getInstance("DES");
                    v4 = new byte[8];
                    v5 = v4;
                    v4[0] = (byte)(var16 >>> 56);
                    for (var6_5 = 1; var6_5 < 8; ++var6_5) {
                        v5 = v5;
                        v5[var6_5] = (byte)(var16 << var6_5 * 8 >>> 56);
                    }
                    var5_4.init(2, (Key)v3.generateSecret(new DESKeySpec(v5)), new IvParameterSpec(new byte[8]));
                    var11_6 = new long[21];
                    var8_7 = 0;
                    var9_8 = "\u00f5\u00c5@\u009f\u0083\u00eeW\u001a\u0013T\u00b7\u00aa\u00c5|\\8\u00ea\u00b3i{\u00c4\"\u000f\u0001\u00c8X\u00d9\u0086\f\u00e1\u0005\u00d7Iy\u00d7\u00bd\u0098e \u0095\u00cd\u00da\n\u008f\u0015\u0094\u000fk\u0010F\u00da\u0086\\\u0012\u0083aD\u00b4\u0001\u00aa\u00d3\u0080c|\u00c6\u0081\u0095\u00a7\u0089\u00db%C\u00d3Rg\u008fe\f!\u00df\u001f]@P\u00e6@\u008b\u00a8ds\u00afV\u001b\u0081\u00cc\u0083\u0007\u00ff%\u0005\u00f1\u00ec\u0097\u00ac[G\u00f7w\u0096\u00fd\u00a5{6c \u00d0\u00c1\u00c5\u00bd\u00bd\u00d8\u00a7\u0015\u00b4\u0091E\u00b0\u000f\u00b5\u0090\u0086\u00a1\u00d0\u000f\u0006\u0094\u00d5:l\u00a1\u00a8\u000b.\u008e\u00a1\u0095\u00bf#X\u00bc\u00c4b";
                    var10_9 = "\u00f5\u00c5@\u009f\u0083\u00eeW\u001a\u0013T\u00b7\u00aa\u00c5|\\8\u00ea\u00b3i{\u00c4\"\u000f\u0001\u00c8X\u00d9\u0086\f\u00e1\u0005\u00d7Iy\u00d7\u00bd\u0098e \u0095\u00cd\u00da\n\u008f\u0015\u0094\u000fk\u0010F\u00da\u0086\\\u0012\u0083aD\u00b4\u0001\u00aa\u00d3\u0080c|\u00c6\u0081\u0095\u00a7\u0089\u00db%C\u00d3Rg\u008fe\f!\u00df\u001f]@P\u00e6@\u008b\u00a8ds\u00afV\u001b\u0081\u00cc\u0083\u0007\u00ff%\u0005\u00f1\u00ec\u0097\u00ac[G\u00f7w\u0096\u00fd\u00a5{6c \u00d0\u00c1\u00c5\u00bd\u00bd\u00d8\u00a7\u0015\u00b4\u0091E\u00b0\u000f\u00b5\u0090\u0086\u00a1\u00d0\u000f\u0006\u0094\u00d5:l\u00a1\u00a8\u000b.\u008e\u00a1\u0095\u00bf#X\u00bc\u00c4b".length();
                    var7_10 = 0;
                    while (true) {
                        var12_11 = var9_8.substring(var7_10, var7_10 += 8).getBytes("ISO-8859-1");
                        v6 = var11_6;
                        v7 = var8_7++;
                        v8 = ((long)var12_11[0] & 255L) << 56 | ((long)var12_11[1] & 255L) << 48 | ((long)var12_11[2] & 255L) << 40 | ((long)var12_11[3] & 255L) << 32 | ((long)var12_11[4] & 255L) << 24 | ((long)var12_11[5] & 255L) << 16 | ((long)var12_11[6] & 255L) << 8 | (long)var12_11[7] & 255L;
                        v9 = -1;
                        break block12;
                        break;
                    }
lbl44:
                    // 1 sources

                    while (true) {
                        v6[v7] = v10;
                        if (var7_10 < var10_9) ** continue;
                        var9_8 = "f\u00ee\u00a1\u000f\u00e6\u00a0?\u00f4\u00fa\u00ce\u0007\u00ff\u00ca8\u008cB";
                        var10_9 = "f\u00ee\u00a1\u000f\u00e6\u00a0?\u00f4\u00fa\u00ce\u0007\u00ff\u00ca8\u008cB".length();
                        var7_10 = 0;
                        while (true) {
                            var12_11 = var9_8.substring(var7_10, var7_10 += 8).getBytes("ISO-8859-1");
                            v6 = var11_6;
                            v7 = var8_7++;
                            v8 = ((long)var12_11[0] & 255L) << 56 | ((long)var12_11[1] & 255L) << 48 | ((long)var12_11[2] & 255L) << 40 | ((long)var12_11[3] & 255L) << 32 | ((long)var12_11[4] & 255L) << 24 | ((long)var12_11[5] & 255L) << 16 | ((long)var12_11[6] & 255L) << 8 | (long)var12_11[7] & 255L;
                            v9 = 0;
                            break block12;
                            break;
                        }
                        break;
                    }
lbl57:
                    // 1 sources

                    while (true) {
                        v6[v7] = v10;
                        if (var7_10 < var10_9) ** continue;
                        break block13;
                        break;
                    }
                }
                var13_12 = v8;
                var15_13 = var5_4.doFinal(new byte[]{(byte)(var13_12 >>> 56), (byte)(var13_12 >>> 48), (byte)(var13_12 >>> 40), (byte)(var13_12 >>> 32), (byte)(var13_12 >>> 24), (byte)(var13_12 >>> 16), (byte)(var13_12 >>> 8), (byte)var13_12});
                v10 = ((long)var15_13[0] & 255L) << 56 | ((long)var15_13[1] & 255L) << 48 | ((long)var15_13[2] & 255L) << 40 | ((long)var15_13[3] & 255L) << 32 | ((long)var15_13[4] & 255L) << 24 | ((long)var15_13[5] & 255L) << 16 | ((long)var15_13[6] & 255L) << 8 | (long)var15_13[7] & 255L;
                switch (v9) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl70:
                    // 1 sources

                    ** continue;
                }
            }
            Class_bU_714b1dad.xQGbF = var11_6;
            Class_bU_714b1dad.xtGND = new Integer[21];
            var0_14 = Cipher.getInstance("DES/CBC/NoPadding");
            v11 = SecretKeyFactory.getInstance("DES");
            v12 = new byte[8];
            v13 = v12;
            v12[0] = (byte)(var16 >>> 56);
            for (var1_15 = 1; var1_15 < 8; ++var1_15) {
                v13 = v13;
                v13[var1_15] = (byte)(var16 << var1_15 * 8 >>> 56);
            }
            break block15;
lbl84:
            // 1 sources

            while (true) {
                continue;
                break;
            }
        }
        var0_14.init(2, (Key)v11.generateSecret(new DESKeySpec(v13)), new IvParameterSpec(new byte[8]));
        var2_16 = -7674394883744559495L;
        var4_17 = var0_14.doFinal(new byte[]{(byte)(var2_16 >>> 56), (byte)(var2_16 >>> 48), (byte)(var2_16 >>> 40), (byte)(var2_16 >>> 32), (byte)(var2_16 >>> 24), (byte)(var2_16 >>> 16), (byte)(var2_16 >>> 8), (byte)var2_16});
        ** while (true)
        Class_bU_714b1dad.cZlpv = ((long)var4_17[0] & 255L) << 56 | ((long)var4_17[1] & 255L) << 48 | ((long)var4_17[2] & 255L) << 40 | ((long)var4_17[3] & 255L) << 32 | ((long)var4_17[4] & 255L) << 24 | ((long)var4_17[5] & 255L) << 16 | ((long)var4_17[6] & 255L) << 8 | (long)var4_17[7] & 255L;
    }

    public List<Class_bS_979bca5c> NY() {
        return this.MAeMK.Ts().stream().filter(class_cw_dbcad330 -> {
            long l = wYIcR ^ 0x2D69A7F057CCL;
            int n = Class_bS_979bca5c.NR();
            boolean bl = ((Class_bS_979bca5c)class_cw_dbcad330).MH();
            if (n != 0) {
                if (!bl) return false;
                bl = class_cw_dbcad330.TC();
            }
            if (n == 0) return bl;
            if (!bl) return false;
            return true;
        }).map(class_cw_dbcad330 -> (Class_bS_979bca5c)class_cw_dbcad330).toList().reversed();
    }

    @Override
    protected void NV(Class_lC_5322e8cf class_lC_5322e8cf) {
        block38: {
            int n;
            block37: {
                block36: {
                    Class_bU_714b1dad class_bU_714b1dad;
                    block35: {
                        int n2;
                        block33: {
                            block34: {
                                block24: {
                                    Class_bS_979bca5c class_bS_979bca5c;
                                    Class_rk_bf8630d1 class_rk_bf8630d1;
                                    Class_bS_979bca5c class_bS_979bca5c2;
                                    block23: {
                                        block32: {
                                            Class_ii_9b427eda class_ii_9b427eda;
                                            block31: {
                                                Class_bS_979bca5c class_bS_979bca5c3;
                                                block30: {
                                                    Class_ld_bb1690e1 class_ld_bb1690e1;
                                                    block25: {
                                                        ClientPlayerEntity clientPlayerEntity;
                                                        Class_lq_87a74641 class_lq_87a74641;
                                                        Class_mG_52c8d386 class_mG_52c8d386;
                                                        block28: {
                                                            block29: {
                                                                block26: {
                                                                    block27: {
                                                                        long l = wYIcR ^ 0x65DCFB3A9BA0L;
                                                                        this.jTsqG = this.GExeP.WbmKd;
                                                                        this.Xtjvx = this.GExeP.Joctj;
                                                                        class_ii_9b427eda = ClientMain.dlM();
                                                                        class_ld_bb1690e1 = Class_ld_bb1690e1.all(7.0f + 8.0f * this.poKgg.dhj());
                                                                        String string = Class_jf_d1c4f950.bBa();
                                                                        n = Class_bS_979bca5c.NR();
                                                                        Class_bU_714b1dad class_bU_714b1dad2 = this;
                                                                        if (n != 0) {
                                                                            if (class_bU_714b1dad2.nYkeq.cpC(cZlpv)) {
                                                                                float f = (float)ClientMain.dlmvG.getWindow().getFramebufferWidth() / 2.0f;
                                                                                float f2 = (float)ClientMain.dlmvG.getWindow().getFramebufferHeight() - (this.QWaAn + 5.0f);
                                                                                Class_mG_52c8d386 class_mG_52c8d3862 = Class_mG_52c8d386.cop(f, f2);
                                                                                float f4 = (class_mG_52c8d3862.cor() + class_mG_52c8d3862.cos() + class_mG_52c8d3862.cot()) / 3.0f - 70.0f;
                                                                                f4 = f4 == 0.0f ? 0 : (f4 > 0.0f ? 1 : -1);
                                                                                if (n != 0) {
                                                                                    f4 = f4 > 0 ? 1.0f : 0.0f;
                                                                                }
                                                                                this.lQdhK = f4;
                                                                                this.nYkeq.cpB();
                                                                            }
                                                                            class_bU_714b1dad2 = this;
                                                                        }
                                                                        class_bU_714b1dad2.wMPQQ.dfT(this.lQdhK ? Class_mG_52c8d386.QHTxQ : Class_mG_52c8d386.hoGuU);
                                                                        class_mG_52c8d386 = this.wMPQQ.dfU().coa(255.0f * (1.0f - this.poKgg.dhj()));
                                                                        if (ClientMain.dlmvG.player == null) break block25;
                                                                        class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
                                                                        class_lC_5322e8cf.cez(class_lq_87a74641, string, this.toIeR - Class_lE_06fbe260.WTzbi.bYM(9.0f).cao(string) - 4.0f, this.QWaAn + 5.0f, class_mG_52c8d386);
                                                                        if (n == 0) break block26;
                                                                        if (ClientMain.dlmvG.isConnectedToLocalServer()) break block27;
                                                                        clientPlayerEntity = ClientMain.dlmvG.player;
                                                                        if (n == 0) break block28;
                                                                        if (clientPlayerEntity.networkHandler.getPlayerListEntry(ClientMain.dlmvG.player.getUuid()) != null) break block29;
                                                                    }
                                                                    class_lC_5322e8cf.cem(Class_lf_d247d983.knMYk, this.toIeR + this.jTsqG + 8.0f, this.QWaAn + 2.5f, 10.0f, class_mG_52c8d386);
                                                                }
                                                                if (n != 0) break block25;
                                                            }
                                                            this.eAzvd.dhc(Class_jf_d1c4f950.bAG(class_lC_5322e8cf, this.toIeR + this.jTsqG + 4.0f + 4.0f * this.eAzvd.dhj(), this.QWaAn + 5.0f, 12.8f, 7.0));
                                                            clientPlayerEntity = ClientMain.dlmvG.player;
                                                        }
                                                        int n3 = Class_jg_83a87f1c.bBx((PlayerEntity)clientPlayerEntity);
                                                        class_lC_5322e8cf.cez(class_lq_87a74641, n3 + wQtIy, this.toIeR + this.jTsqG + 4.0f + 4.0f * this.eAzvd.dhj(), this.QWaAn + 5.0f, class_mG_52c8d386.cob(this.eAzvd.dhj()));
                                                        Class_le_52ba6de2.bXO(class_lC_5322e8cf, this.toIeR + this.jTsqG + 9.0f + 4.0f * this.eAzvd.dhj(), this.QWaAn + 5.0f, 1.0f, n3, class_mG_52c8d386.cob(1.0f - this.eAzvd.dhj()));
                                                    }
                                                    class_bS_979bca5c2 = this.NX();
                                                    this.DIVJZ.dfT(class_bS_979bca5c2.MI());
                                                    float f = 2.0f;
                                                    Class_mG_52c8d386 class_mG_52c8d386 = class_ii_9b427eda.bjd().coc(this.DIVJZ.dfU(), 0.05f).coa(191.25f);
                                                    class_lC_5322e8cf.cej(this.toIeR, this.QWaAn, this.jTsqG, this.Xtjvx, f, class_ld_bb1690e1, 1.0f);
                                                    class_lC_5322e8cf.cdm(this.toIeR, this.QWaAn, this.jTsqG, this.Xtjvx, f, class_ld_bb1690e1, class_mG_52c8d386);
                                                    for (Class_cw_dbcad330 class_cw_dbcad330 : this.MAeMK.Ts()) {
                                                        class_rk_bf8630d1 = ((Class_bS_979bca5c)class_cw_dbcad330).NP();
                                                        class_bS_979bca5c = class_bS_979bca5c2;
                                                        if (n != 0) {
                                                            class_rk_bf8630d1.dhd(class_bS_979bca5c == class_cw_dbcad330 ? 1.0f : 0.0f);
                                                            if (n != 0) continue;
                                                        }
                                                        break block23;
                                                    }
                                                    Class_jG_69891630.bHK(class_lC_5322e8cf, this.toIeR, this.QWaAn, this.jTsqG, this.Xtjvx);
                                                    class_bS_979bca5c3 = class_bS_979bca5c2;
                                                    if (n == 0) break block30;
                                                    if (class_bS_979bca5c3.NP().dhj() != 1.0f) break block31;
                                                    class_bS_979bca5c3 = class_bS_979bca5c2;
                                                }
                                                class_bS_979bca5c3.MG(class_lC_5322e8cf, class_ii_9b427eda);
                                                if (n != 0) break block32;
                                            }
                                            for (Class_cw_dbcad330 class_cw_dbcad330 : this.MAeMK.Ts()) {
                                                Class_bS_979bca5c class_bS_979bca5c4 = (Class_bS_979bca5c)class_cw_dbcad330;
                                                if (n != 0) {
                                                    float f = class_bS_979bca5c4.NP().dhj() - 0.0f;
                                                    n2 = f == 0.0f ? 0 : (f > 0.0f ? 1 : -1);
                                                    if (n == 0) break block24;
                                                    if (n2 <= 0 && n != 0) continue;
                                                    class_bS_979bca5c4 = (Class_bS_979bca5c)class_cw_dbcad330;
                                                }
                                                class_bS_979bca5c4.NN(class_lC_5322e8cf, class_ii_9b427eda);
                                                if (n != 0) continue;
                                            }
                                        }
                                        Class_jG_69891630.bHN();
                                        this.Elfgo.dhd(class_bS_979bca5c2.fGWTH.WbmKd);
                                        class_rk_bf8630d1 = this.axCzv;
                                        class_bS_979bca5c = class_bS_979bca5c2;
                                    }
                                    class_rk_bf8630d1.dhd(class_bS_979bca5c.fGWTH.Joctj);
                                    this.GExeP.NU(this.Elfgo.dhj(), this.axCzv.dhj());
                                    this.poKgg.dhc(this.fpgBD);
                                    n2 = class_bS_979bca5c2 instanceof Class_bV_61960ba1;
                                }
                                if (n != 0) {
                                    if (n2 == 0) {
                                        this.fpgBD = false;
                                    }
                                    n2 = ClientMain.dlmvG.currentScreen instanceof ChatScreen;
                                }
                                if (n == 0) break block33;
                                if (n2 != 0) break block34;
                                n2 = ClientMain.dlmvG.currentScreen instanceof Class_av_ffcf74a1;
                                if (n == 0) break block33;
                                if (n2 == 0 && ClientMain.dlmvG.player != null) break block35;
                            }
                            class_bU_714b1dad = this;
                            if (n == 0) break block36;
                            n2 = class_bU_714b1dad.vCMYc;
                        }
                        if (n2 == 0) break block37;
                    }
                    class_bU_714b1dad = this;
                }
                class_bU_714b1dad.fpgBD = false;
            }
            if (Class_iS_888f260e.bwL() != null) break block38;
            Class_bS_979bca5c.NQ(++n);
        }
    }

    @Override
    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        super.LX(class_lC_5322e8cf);
        this.jTsqG = this.GExeP.WbmKd;
        this.Xtjvx = this.GExeP.Joctj;
        Vec2f vec2f = Class_rm_d861be3b.dip();
        this.toIeR = vec2f.x / 2.0f - this.RU() / 2.0f;
        this.QWaAn = 7.0f;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean NW(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        long l = wYIcR ^ 0x3E3A9A7B18C2L;
        int n = Class_bS_979bca5c.NS();
        if (class_mA_32d8a5f2 != Class_mA_32d8a5f2.sCBUa) return false;
        boolean bl = this.fpgBD;
        if (n == 0) {
            if (bl) {
                if (!Class_jf_d1c4f950.bAE(d, d2, this.toIeR, this.QWaAn, this.jTsqG, this.Xtjvx)) {
                    this.fpgBD = false;
                    if (n == 0) return true;
                }
                this.NX().Ne(d, d2, class_mA_32d8a5f2);
                return true;
            }
            bl = Class_jf_d1c4f950.bAE(d, d2, this.toIeR, this.QWaAn, this.jTsqG, this.Xtjvx);
        }
        if (n != 0) return bl;
        if (!bl) return false;
        bl = this.NX() instanceof Class_bV_61960ba1;
        if (n != 0) return bl;
        if (!bl) return false;
        this.fpgBD = true;
        return true;
    }

    public Class_bT_3a1e4a37 NZ() {
        return this.GExeP;
    }

    private static int Oh(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bU_714b1dad.Og(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static CallSite Oi(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bU_714b1dad" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public Class_bS_979bca5c NX() {
        return this.NY().getLast();
    }

    private static MatchException Oe(MatchException matchException) {
        return matchException;
    }

    public Class_rk_bf8630d1 Ob() {
        return this.poKgg;
    }

    private static int Og(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x4B73;
        if (xtGND[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = xQGbF[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])jRiyL.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    jRiyL.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bU_714b1dad", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bU_714b1dad.xtGND[n2] = n3;
        }
        return xtGND[n2];
    }

    private static String Of(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public boolean Oa() {
        return this.fpgBD;
    }

    @Override
    public boolean onMouseClicked(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        long l = wYIcR ^ 0x6EAF0BEC2988L;
        int n = Class_bS_979bca5c.NR();
        boolean bl = this.NW(d, d2, class_mA_32d8a5f2);
        if (n != 0) {
            if (bl) {
                return true;
            }
            bl = super.onMouseClicked(d, d2, class_mA_32d8a5f2);
        }
        return bl;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bU_714b1dad.class, "Oh", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

