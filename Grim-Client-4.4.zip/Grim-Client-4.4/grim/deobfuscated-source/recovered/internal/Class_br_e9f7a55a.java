/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import recovered.core.ClientMain;
import recovered.core.NativeLoader;
import recovered.internal.Class_O_5a11f410;
import recovered.internal.Class_ah_02444db4;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bm_4fcab5e6;
import recovered.internal.Class_bn_2f1533de;
import recovered.internal.Class_bo_326bc24c;
import recovered.internal.Class_bp_bf401c6e;
import recovered.internal.Class_bq_8edccbef;
import recovered.internal.Class_bz_8cac7329;
import recovered.internal.Class_cy_687dcdb6;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_iy_c88c0f4f;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_nc_29712bc0;
import recovered.internal.Class_nd_e33facc7;
import recovered.internal.Class_ne_ce4c798b;
import recovered.internal.Class_nf_8f40fc48;
import recovered.internal.Class_ng_91317468;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_br_e9f7a55a
extends Class_aj_95d0a719 {
    private final Class_rk_bf8630d1 jUBZP;
    private final List<Class_az_a4990dcf> HCkpb;
    private final Class_ah_02444db4 pVdHS;
    private Class_nf_8f40fc48 hQySR;
    private boolean dgquq;
    private Class_bo_326bc24c ndiLl;
    private Class_bm_4fcab5e6 GNISa;
    private Class_cy_687dcdb6 LYYTu;
    private Class_cy_687dcdb6 pxwWX;
    private Class_cy_687dcdb6 FHLen;
    private Class_bn_2f1533de FRxyo;
    private Class_bp_bf401c6e DihOV;
    private Class_bq_8edccbef ToVbN;
    private final Class_O_5a11f410 pWDHg;
    private float FObrV;
    private static long hDPVr;
    private static String[] MRsWc;
    private static String[] MeRqB;
    private static Map kzoMe;
    private static long[] fWbAC;
    private static Integer[] AYJyS;
    private static Map MQBha;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private static native void _cec499d427fc658d5969d7b4553e7195();

    private native float GE();

    public Class_br_e9f7a55a(Class_nf_8f40fc48 class_nf_8f40fc48) {
        long l = hDPVr ^ 0x6CCB55681B3EL;
        this.jUBZP = new Class_rk_bf8630d1((int)Class_br_e9f7a55a.Hl("u", (int)25511, (long)(0x9FF5A9C73A1A1EFL ^ l))).dhs(Class_rj_b691f4f7.MBpuQ);
        this.HCkpb = new ArrayList<Class_az_a4990dcf>();
        this.pVdHS = new Class_ah_02444db4();
        Class_bz_8cac7329 class_bz_8cac7329 = Class_bz_8cac7329.KH();
        Class_lc_b8480f87 class_lc_b8480f87 = class_bz_8cac7329.KI();
        this.FObrV = class_lc_b8480f87.bXz() + 10.0f;
        this.MCnYt = this.FObrV + 24.0f;
        this.pNyTQ = class_lc_b8480f87.bXG();
        this.BcpIo = 140.0f;
        this.WjISQ = class_lc_b8480f87.bXI() + 10.0f + class_bz_8cac7329.KJ().bXI();
        this.jUBZP.dhe(this.MCnYt);
        this.IzFhM = 2.0f;
        Class_ig_ca326427 class_ig_ca326427 = ClientMain.dlM().bjG();
        this.pWDHg = Class_O_5a11f410.hE((String)((Object)Class_br_e9f7a55a.Hi("h", (int)3032, (long)(0x273056FAA345227DL ^ l)))).je(true).jf(Class_ld_bb1690e1.M).jk(class_ig_ca326427.bio().coe(0.9f)).jq(class_ig_ca326427.bis()).jr(class_ig_ca326427.bis().cog(0.85f)).jb(this::Hd);
        this.GC(class_nf_8f40fc48);
        this.FHbTC = true;
    }

    public Class_br_e9f7a55a() {
        this(null);
    }

    static {
        NativeLoader.doInit(Class_br_e9f7a55a.class);
        Class_br_e9f7a55a._cec499d427fc658d5969d7b4553e7195();
    }

    @Override
    public native void dl(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    public native boolean dm(int var1, int var2, int var3);

    public native Class_bp_bf401c6e GT();

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private native List<Class_ng_91317468> GB(List<Class_ng_91317468> var1);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native boolean fC(double var1, double var3, double var5);

    private native float GG();

    private static native CallSite Hi(MethodHandles.Lookup var0, String var1, MethodType var2);

    @Override
    protected native float gb();

    private native /* synthetic */ void GZ(Class_iy_c88c0f4f var1);

    @Override
    public native boolean dB(double var1, double var3, Class_mA_32d8a5f2 var5, double var6, double var8);

    @Override
    public native boolean eK(char var1);

    public native Class_ah_02444db4 GL();

    private native float GD();

    @Override
    protected native boolean od();

    public native void Gn(float var1, float var2, float var3);

    public native Class_br_e9f7a55a Go(Class_nf_8f40fc48 var1);

    private static native CallSite Hl(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native List<Class_az_a4990dcf> GK();

    public native Class_bm_4fcab5e6 GO();

    public native float GW();

    private native /* synthetic */ boolean GX(Class_ng_91317468 var1);

    private static native String Hf(byte[] var0);

    private native Class_ne_ce4c798b Gz(Class_ne_ce4c798b var1);

    private native /* synthetic */ void Hc(Class_lC_5322e8cf var1);

    private native /* synthetic */ boolean GY(Class_nd_e33facc7 var1);

    private static native NumberFormatException He(NumberFormatException var0);

    public native Class_cy_687dcdb6 GR();

    private native void GC(Class_nf_8f40fc48 var1);

    private native float GI(Class_az_a4990dcf var1);

    public native Class_bo_326bc24c GN();

    private native /* synthetic */ void Ha(Class_iy_c88c0f4f var1);

    private native Optional<Class_iy_c88c0f4f> Gs();

    public native Class_bn_2f1533de GS();

    private native /* synthetic */ void Hb(Class_lC_5322e8cf var1, float var2);

    private static native Object Hh(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native /* synthetic */ void Hd(Class_O_5a11f410 var1);

    private static native int Hk(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public native Class_rk_bf8630d1 GJ();

    private native List<Class_nd_e33facc7> GA(List<Class_nd_e33facc7> var1);

    private native Class_nd_e33facc7 Gy(Class_nd_e33facc7 var1);

    public native Class_nf_8f40fc48 GM();

    public native Class_cy_687dcdb6 GP();

    public native Class_cy_687dcdb6 GQ();

    private native void GH(float var1);

    private static native int Hj(int var0, long var1);

    private native long Gu(String var1) throws NumberFormatException;

    private native void Gp();

    private static native String Hg(int var0, long var1);

    private native float GF();

    private native Class_nc_29712bc0 Gx(Class_nc_29712bc0 var1);

    public native Class_bq_8edccbef GU();

    private native boolean Gr();

    private native Class_ne_ce4c798b Gw(String var1) throws NumberFormatException;

    public native Class_O_5a11f410 GV();

    private native String Gv(String var1);

    private native void Gq();

    private native long Gt(String var1) throws NumberFormatException;
}

