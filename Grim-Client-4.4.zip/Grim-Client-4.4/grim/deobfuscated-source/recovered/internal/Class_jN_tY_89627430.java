/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

class Class_jN_tY_89627430 {
    static int[] gCqNy;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_jN_tY_89627430.class);
        Class_jN_tY_89627430._1237f65a23b9ad58566a7485d28194b4();
    }

    private static native void _1237f65a23b9ad58566a7485d28194b4();
}

