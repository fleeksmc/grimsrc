/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_cy_687dcdb6;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_nc_29712bc0;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bm_4fcab5e6
extends Class_az_a4990dcf {
    private final Class_nc_29712bc0 lBVqw;
    private final Class_az_a4990dcf XOmFR;
    private final Class_rk_bf8630d1 rYqmq;
    private static boolean mddAz;
    private static long ILQMi;
    private static String[] GaHJp;
    private static String[] TyKLp;
    private static Map KTJbD;
    private static long[] kVLgE;
    private static Integer[] ONeTB;
    private static Map bLkZb;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bm_4fcab5e6(Class_nc_29712bc0 class_nc_29712bc0, Class_az_a4990dcf class_az_a4990dcf) {
        long l = ILQMi ^ 0x753F7CC823CFL;
        this.rYqmq = new Class_rk_bf8630d1((int)Class_bm_4fcab5e6.Fi("u", (int)28095, (long)(0x6EF95CEB0B24B3A0L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.lBVqw = class_nc_29712bc0;
        this.XOmFR = class_az_a4990dcf;
    }

    static {
        NativeLoader.doInit(Class_bm_4fcab5e6.class);
        Class_bm_4fcab5e6._620c6a3cba54f7577c9dfae4624e2c56();
    }

    @Override
    public native float dn();

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    @Override
    public native void dY();

    private native void ET(double var1, double var3);

    private static native void _620c6a3cba54f7577c9dfae4624e2c56();

    public native Class_nc_29712bc0 EU();

    private static native Object Fe(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native MatchException Fb(MatchException var0);

    private native /* synthetic */ void EX(Class_cy_687dcdb6 var1, Class_cJ_2ae1a557 var2, Class_cJ_2ae1a557 var3, Class_aj_95d0a719 var4);

    private static native CallSite Fi(MethodHandles.Lookup var0, String var1, MethodType var2);

    public static native void EY(boolean var0);

    public static native boolean EZ();

    private static native String Fd(int var0, long var1);

    public native Class_rk_bf8630d1 EW();

    private static native String Fc(byte[] var0);

    public static native boolean Fa();

    private static native CallSite Ff(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native int Fg(int var0, long var1);

    private static native int Fh(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public native Class_az_a4990dcf EV();
}

