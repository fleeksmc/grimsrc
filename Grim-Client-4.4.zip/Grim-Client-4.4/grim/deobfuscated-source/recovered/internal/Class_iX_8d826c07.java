/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.option.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.LivingEntity
 *  net.minecraft.entity.effect.StatusEffects
 *  net.minecraft.entity.player.PlayerEntity
 *  net.minecraft.util.math.Vec2f
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_jg_83a87f1c;
import recovered.internal.Class_mF_189ad7bc;

public class Class_iX_8d826c07 {
    private static Class_mF_189ad7bc jomCs;
    public static final KeyBinding[] Ergzg;
    public static final KeyBinding[] HpSlL;
    private static final long UWCYb;
    private static final long[] uATfM;
    private static final Integer[] arYfW;
    private static final Map gTDLH;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_iX_8d826c07.UWCYb = Class_gb_9d201141.aYR(6647284026903975892L, -9119464849414617501L, MethodHandles.lookup().lookupClass()).a(244743953533058L);
                var11 = Class_iX_8d826c07.UWCYb ^ 5648240925718L;
                Class_iX_8d826c07.gTDLH = new HashMap<K, V>(13);
                var0_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var11 >>> 56);
                for (var1_2 = 1; var1_2 < 8; ++var1_2) {
                    v2 = v2;
                    v2[var1_2] = (byte)(var11 << var1_2 * 8 >>> 56);
                }
                var0_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var6_3 = new long[6];
                var3_4 = 0;
                var4_5 = "\u009b\u00c3jq\u00b5\u00b4\u00c6\u00ba\u00e8\u00dd\u00f7\u0091Z\u00e2^w\u0011\u00bd\u0091w&\r\u0089>\u00fa\u0003\u00da\u00c2@g\u00e2\u00cf";
                var5_6 = "\u009b\u00c3jq\u00b5\u00b4\u00c6\u00ba\u00e8\u00dd\u00f7\u0091Z\u00e2^w\u0011\u00bd\u0091w&\r\u0089>\u00fa\u0003\u00da\u00c2@g\u00e2\u00cf".length();
                var2_7 = 0;
                while (true) {
                    var7_8 = var4_5.substring(var2_7, var2_7 += 8).getBytes("ISO-8859-1");
                    v3 = var6_3;
                    v4 = var3_4++;
                    v5 = ((long)var7_8[0] & 255L) << 56 | ((long)var7_8[1] & 255L) << 48 | ((long)var7_8[2] & 255L) << 40 | ((long)var7_8[3] & 255L) << 32 | ((long)var7_8[4] & 255L) << 24 | ((long)var7_8[5] & 255L) << 16 | ((long)var7_8[6] & 255L) << 8 | (long)var7_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl26:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var2_7 < var5_6) ** continue;
                    var4_5 = "!\u00ea\u00a2\u0000<+G\u00b5\u0011\u00e9\u00c8\u0004\u00a0\fV\u00a3";
                    var5_6 = "!\u00ea\u00a2\u0000<+G\u00b5\u0011\u00e9\u00c8\u0004\u00a0\fV\u00a3".length();
                    var2_7 = 0;
                    while (true) {
                        var7_8 = var4_5.substring(var2_7, var2_7 += 8).getBytes("ISO-8859-1");
                        v3 = var6_3;
                        v4 = var3_4++;
                        v5 = ((long)var7_8[0] & 255L) << 56 | ((long)var7_8[1] & 255L) << 48 | ((long)var7_8[2] & 255L) << 40 | ((long)var7_8[3] & 255L) << 32 | ((long)var7_8[4] & 255L) << 24 | ((long)var7_8[5] & 255L) << 16 | ((long)var7_8[6] & 255L) << 8 | (long)var7_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var2_7 < var5_6) ** continue;
                    break block9;
                    break;
                }
            }
            var8_9 = v5;
            var10_10 = var0_1.doFinal(new byte[]{(byte)(var8_9 >>> 56), (byte)(var8_9 >>> 48), (byte)(var8_9 >>> 40), (byte)(var8_9 >>> 32), (byte)(var8_9 >>> 24), (byte)(var8_9 >>> 16), (byte)(var8_9 >>> 8), (byte)var8_9});
            v7 = ((long)var10_10[0] & 255L) << 56 | ((long)var10_10[1] & 255L) << 48 | ((long)var10_10[2] & 255L) << 40 | ((long)var10_10[3] & 255L) << 32 | ((long)var10_10[4] & 255L) << 24 | ((long)var10_10[5] & 255L) << 16 | ((long)var10_10[6] & 255L) << 8 | (long)var10_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl52:
                // 1 sources

                ** continue;
            }
        }
        Class_iX_8d826c07.uATfM = var6_3;
        Class_iX_8d826c07.arYfW = new Integer[6];
        Class_iX_8d826c07.jomCs = new Class_mF_189ad7bc(false, false, false, false);
        Class_iX_8d826c07.Ergzg = new KeyBinding[]{ClientMain.dlmvG.options.forwardKey, ClientMain.dlmvG.options.backKey, ClientMain.dlmvG.options.rightKey, ClientMain.dlmvG.options.leftKey};
        v8 = new KeyBinding[Class_iX_8d826c07.bxW("f", (int)28084, (long)(756953401922601219L ^ var11))];
        v8[0] = ClientMain.dlmvG.options.forwardKey;
        v8[1] = ClientMain.dlmvG.options.backKey;
        v8[2] = ClientMain.dlmvG.options.leftKey;
        v8[3] = ClientMain.dlmvG.options.rightKey;
        v8[4] = ClientMain.dlmvG.options.jumpKey;
        v8[5] = ClientMain.dlmvG.options.sneakKey;
        v8[Class_iX_8d826c07.bxW("f", (int)9070, (long)(2424658367421812698L ^ var11))] = ClientMain.dlmvG.options.sprintKey;
        Class_iX_8d826c07.HpSlL = v8;
    }

    public static void bxF(Class_mF_189ad7bc class_mF_189ad7bc) {
        long l = UWCYb ^ 0x1598EE66F839L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        Class_mF_189ad7bc class_mF_189ad7bc2 = class_mF_189ad7bc;
        if (stringArray != null) {
            class_mF_189ad7bc2 = class_mF_189ad7bc2 == null ? new Class_mF_189ad7bc(false, false, false, false) : class_mF_189ad7bc;
        }
        jomCs = class_mF_189ad7bc2;
    }

    public static double bxE() {
        Vec3d vec3d = ClientMain.dlmvG.player.getVelocity();
        return Math.hypot(vec3d.x, vec3d.z);
    }

    public static boolean bxD(Entity entity) {
        long l = UWCYb ^ 0x41248C605FF7L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        double d = entity.getVelocity().lengthSquared() - 0.08;
        double d2 = d == 0.0 ? 0 : (d > 0.0 ? 1 : -1);
        if (stringArray != null) {
            d2 = d2 >= 0 ? 1.0 : 0.0;
        }
        return (boolean)d2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean bxC() {
        long l = UWCYb ^ 0x2C295F495065L;
        Vec2f vec2f = ClientMain.dlmvG.player.input.getMovementInput();
        String[] stringArray = Class_jf_d1c4f950.bBe();
        float f = vec2f.x - 0.0f;
        float f2 = f == 0.0f ? 0 : (f > 0.0f ? 1 : -1);
        if (stringArray == null) return (boolean)f2;
        if (f2 == false) {
            float f3 = vec2f.y - 0.0f;
            f2 = f3 == 0.0f ? 0 : (f3 > 0.0f ? 1 : -1);
            if (stringArray == null) return (boolean)f2;
            if (f2 == false) {
                f2 = 0.0f;
                return (boolean)f2;
            }
        }
        f2 = 1.0f;
        return (boolean)f2;
    }

    private static MatchException bxT(MatchException matchException) {
        return matchException;
    }

    public static Class_mF_189ad7bc bxG() {
        return jomCs;
    }

    public static Vec2f bxO(double d) {
        double d2;
        float f;
        double d3;
        double d4;
        block10: {
            block11: {
                double d5;
                block16: {
                    String[] stringArray;
                    block17: {
                        block15: {
                            block14: {
                                long l;
                                block12: {
                                    double d6;
                                    block13: {
                                        l = UWCYb ^ 0x6F771DC86C6BL;
                                        Vec2f vec2f = ClientMain.dlmvG.player.input.getMovementInput();
                                        d4 = vec2f.y;
                                        d3 = vec2f.x;
                                        f = ClientMain.dlX().dbC().cGI();
                                        stringArray = Class_jf_d1c4f950.bBe();
                                        d2 = d4;
                                        if (stringArray == null) break block10;
                                        if (d2 == 0.0) break block11;
                                        double d7 = d3 - 0.0;
                                        d5 = d7 == 0.0 ? 0 : (d7 > 0.0 ? 1 : -1);
                                        if (stringArray == null) break block12;
                                        if (d5 <= 0) break block13;
                                        double d8 = d4 - 0.0;
                                        Object object = d8 == 0.0 ? 0 : (d8 > 0.0 ? 1 : -1);
                                        if (stringArray != null) {
                                            object = object > 0 ? (Object)Class_iX_8d826c07.bxW("f", (int)26366, (long)(0x496BA844265E7A36L ^ l)) : (Object)Class_iX_8d826c07.bxW("f", (int)3313, (long)(0x355BD4F635DB903CL ^ l));
                                        }
                                        f += (float)object;
                                        if (stringArray != null) break block14;
                                    }
                                    d5 = (d6 = d3 - 0.0) == 0.0 ? 0 : (d6 < 0.0 ? -1 : 1);
                                }
                                if (stringArray == null) break block15;
                                if (d5 < 0) {
                                    double d9 = d4 - 0.0;
                                    Object object = d9 == 0.0 ? 0 : (d9 > 0.0 ? 1 : -1);
                                    if (stringArray != null) {
                                        object = object > 0 ? (Object)Class_iX_8d826c07.bxW("f", (int)14791, (long)(0x243EBBF77622A50CL ^ l)) : (Object)Class_iX_8d826c07.bxW("f", (int)21932, (long)(0xCC5B3605E614960L ^ l));
                                    }
                                    f += (float)object;
                                }
                            }
                            d3 = 0.0;
                            double d10 = d4 - 0.0;
                            d5 = d10 == 0.0 ? 0 : (d10 > 0.0 ? 1 : -1);
                        }
                        if (stringArray == null) break block16;
                        if (d5 <= 0) break block17;
                        d4 = 1.0;
                        if (stringArray != null) break block11;
                    }
                    d2 = d4;
                    if (stringArray == null) break block10;
                    double d11 = d2 - 0.0;
                    d5 = d11 == 0.0 ? 0 : (d11 < 0.0 ? -1 : 1);
                }
                if (d5 < 0) {
                    d4 = -1.0;
                }
            }
            d2 = Math.sin(Math.toRadians(f + 90.0f));
        }
        double d12 = d2;
        double d13 = Math.cos(Math.toRadians(f + 90.0f));
        double d14 = d4 * d * d13 + d3 * d * d12;
        double d15 = d4 * d * d12 - d3 * d * d13;
        return new Vec2f((float)d14, (float)d15);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean bxH(Class_mF_189ad7bc class_mF_189ad7bc) {
        long l = UWCYb ^ 0x334443BB31EFL;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        Class_mF_189ad7bc class_mF_189ad7bc2 = class_mF_189ad7bc;
        if (stringArray != null) {
            if (class_mF_189ad7bc2 == null) return false;
            class_mF_189ad7bc2 = class_mF_189ad7bc;
        }
        boolean bl = class_mF_189ad7bc2.cnH() ^ class_mF_189ad7bc.cnI();
        if (stringArray == null) return bl;
        if (bl) return true;
        bl = class_mF_189ad7bc.cnJ() ^ class_mF_189ad7bc.cnK();
        if (stringArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    public static float bxS() {
        double d = Math.sqrt(Math.pow(ClientMain.dlmvG.player.getX() - ClientMain.dlmvG.player.lastRenderX, 2.0) + Math.pow(ClientMain.dlmvG.player.getY() - ClientMain.dlmvG.player.lastRenderY, 2.0) + Math.pow(ClientMain.dlmvG.player.getZ() - ClientMain.dlmvG.player.lastRenderZ, 2.0));
        float f = (float)(d * 20.0);
        return (float)Math.round(f * 10.0f) / 10.0f;
    }

    public static Vec3d bxJ(Vec3d vec3d, double d) {
        return Class_iX_8d826c07.bxK(vec3d, d, 1.0);
    }

    public static Vec3d bxI(Vec3d vec3d) {
        return Class_iX_8d826c07.bxJ(vec3d, Math.hypot(vec3d.x, vec3d.z));
    }

    private static int bxV(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_iX_8d826c07.bxU(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static CallSite bxW(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_iX_8d826c07" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean bxM(PlayerEntity playerEntity) {
        long l = UWCYb ^ 0x1FF81C8E96B0L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        boolean bl = playerEntity.hasStatusEffect(StatusEffects.BLINDNESS);
        if (stringArray == null) return bl;
        if (bl) return true;
        bl = playerEntity.hasStatusEffect(StatusEffects.LEVITATION);
        if (stringArray == null) return bl;
        if (bl) return true;
        bl = Class_jg_83a87f1c.bBs((LivingEntity)playerEntity);
        if (stringArray == null) return bl;
        if (bl) return true;
        bl = playerEntity.isSubmergedInWater();
        if (stringArray == null) return bl;
        if (bl) return true;
        bl = playerEntity.isInLava();
        if (stringArray == null) return bl;
        if (bl) return true;
        bl = playerEntity.isClimbing();
        if (stringArray == null) return bl;
        if (bl) return true;
        bl = playerEntity.getAbilities().flying;
        if (stringArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    public static float bxQ() {
        return Class_iX_8d826c07.bxR(jomCs);
    }

    public static Vec3d bxL(Vec3d vec3d, double d, double d2, Class_mF_189ad7bc class_mF_189ad7bc) {
        long l = UWCYb ^ 0x7A0F7F57740EL;
        if (!Class_iX_8d826c07.bxH(class_mF_189ad7bc)) {
            return new Vec3d(0.0, vec3d.y, 0.0);
        }
        double d3 = 1.0 - d2;
        double d4 = vec3d.x * d3;
        double d5 = vec3d.z * d3;
        double d6 = d * d2;
        double d7 = Math.toRadians(Class_iX_8d826c07.bxR(class_mF_189ad7bc));
        double d8 = d4 - Math.sin(d7) * d6;
        double d9 = d5 + Math.cos(d7) * d6;
        return new Vec3d(d8, vec3d.y, d9);
    }

    public static float bxR(Class_mF_189ad7bc class_mF_189ad7bc) {
        float f;
        block19: {
            boolean bl;
            float f2;
            block18: {
                String[] stringArray;
                block16: {
                    block17: {
                        block13: {
                            block15: {
                                boolean bl2;
                                block14: {
                                    block11: {
                                        block12: {
                                            long l = UWCYb ^ 0x1BA794EDB8E7L;
                                            f = ClientMain.dlmvG.player.getYaw();
                                            stringArray = Class_jf_d1c4f950.bBe();
                                            bl2 = class_mF_189ad7bc.cnI();
                                            if (stringArray == null) break block11;
                                            if (!bl2) break block12;
                                            bl2 = class_mF_189ad7bc.cnH();
                                            if (stringArray == null) break block11;
                                            if (bl2) break block12;
                                            f += 180.0f;
                                            f2 = -0.5f;
                                            if (stringArray != null) break block13;
                                        }
                                        bl2 = class_mF_189ad7bc.cnH();
                                    }
                                    if (stringArray == null) break block14;
                                    if (!bl2) break block15;
                                    bl2 = class_mF_189ad7bc.cnI();
                                }
                                if (bl2) break block15;
                                f2 = 0.5f;
                                if (stringArray != null) break block13;
                            }
                            f2 = 1.0f;
                        }
                        bl = class_mF_189ad7bc.cnJ();
                        if (stringArray == null) break block16;
                        if (!bl) break block17;
                        bl = class_mF_189ad7bc.cnK();
                        if (stringArray == null) break block16;
                        if (!bl) {
                            f -= 90.0f * f2;
                        }
                    }
                    bl = class_mF_189ad7bc.cnK();
                }
                if (stringArray == null) break block18;
                if (!bl) break block19;
                bl = class_mF_189ad7bc.cnJ();
            }
            if (!bl) {
                f += 90.0f * f2;
            }
        }
        return f;
    }

    public static Vec3d bxK(Vec3d vec3d, double d, double d2) {
        return Class_iX_8d826c07.bxL(vec3d, d, d2, jomCs);
    }

    public static double bxP(boolean bl) {
        float f;
        float f2;
        String[] stringArray;
        float f3;
        block13: {
            float f4;
            block12: {
                block10: {
                    float f5;
                    block11: {
                        long l = UWCYb ^ 0x6895BE6F065L;
                        f3 = ClientMain.dlX().dbC().cGI();
                        stringArray = Class_jf_d1c4f950.bBe();
                        float f6 = ClientMain.dlmvG.player.forwardSpeed;
                        if (stringArray != null) {
                            if (f6 < 0.0f) {
                                f3 += 180.0f;
                            }
                            f6 = 1.0f;
                        }
                        f2 = f6;
                        float f7 = ClientMain.dlmvG.player.forwardSpeed - 0.0f;
                        f = f7 == 0.0f ? 0 : (f7 < 0.0f ? -1 : 1);
                        if (stringArray == null) break block10;
                        if (f >= 0) break block11;
                        f2 = -0.5f;
                        if (stringArray != null) break block12;
                    }
                    f = (f5 = ClientMain.dlmvG.player.forwardSpeed - 0.0f) == 0.0f ? 0 : (f5 > 0.0f ? 1 : -1);
                }
                if (stringArray == null) break block13;
                if (f > 0) {
                    f2 = 0.5f;
                }
            }
            f = (f4 = ClientMain.dlmvG.player.sidewaysSpeed - 0.0f) == 0.0f ? 0 : (f4 > 0.0f ? 1 : -1);
        }
        if (stringArray != null) {
            float f8;
            if (f > 0) {
                f3 -= 90.0f * f2;
            }
            f = (f8 = ClientMain.dlmvG.player.sidewaysSpeed - 0.0f) == 0.0f ? 0 : (f8 < 0.0f ? -1 : 1);
        }
        if (stringArray != null) {
            if (f < 0) {
                f3 += 90.0f * f2;
            }
            f = (float)bl;
        }
        return f != false ? Math.toRadians(f3) : (double)f3;
    }

    public static void bxN(double d) {
        long l = UWCYb ^ 0x201010968E48L;
        String[] stringArray = Class_jf_d1c4f950.bBe();
        boolean bl = Class_iX_8d826c07.bxC();
        if (stringArray != null) {
            if (!bl) {
                return;
            }
            bl = true;
        }
        double d2 = Class_iX_8d826c07.bxP(bl);
        ClientMain.dlmvG.player.setVelocity(-Math.sin(d2) * d, ClientMain.dlmvG.player.getVelocity().y, Math.cos(d2) * d);
    }

    private static int bxU(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x705A;
        if (arYfW[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = uATfM[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])gTDLH.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    gTDLH.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_iX_8d826c07", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_iX_8d826c07.arYfW[n2] = n3;
        }
        return arYfW[n2];
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_iX_8d826c07.class, "bxV", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

