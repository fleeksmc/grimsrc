/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.equipment.EquipmentType
 */
package recovered.internal;

import net.minecraft.item.equipment.EquipmentType;
import recovered.core.NativeLoader;

final class Class_fv_sS_1fa7cf0c
extends Record {
    private final int armorIndex;
    private final EquipmentType armorType;
    private final int sourceSlot;
    private final boolean currentArmorEmpty;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_fv_sS_1fa7cf0c(int n, EquipmentType equipmentType, int n2, boolean bl) {
        this.armorIndex = n;
        this.armorType = equipmentType;
        this.sourceSlot = n2;
        this.currentArmorEmpty = bl;
    }

    static {
        NativeLoader.doInit(Class_fv_sS_1fa7cf0c.class);
    }

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    public native int sourceSlot();

    public native int armorIndex();

    public native EquipmentType armorType();

    public native boolean currentArmorEmpty();
}

