/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import recovered.internal.Class_hF_7bd1921e;
import recovered.internal.Class_hI_068ee9a3;

public abstract class Class_hH_ae8f8f77 {
    private boolean QQqas;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public void bdX(boolean bl) {
        this.QQqas = bl;
    }

    public void bdV() {
        List<Class_hI_068ee9a3> list = Class_hF_7bd1921e.bdO(this.getClass());
        if (list.isEmpty() || !Class_hF_7bd1921e.BQuMu) {
            return;
        }
        for (Class_hI_068ee9a3 class_hI_068ee9a3 : list) {
            try {
                class_hI_068ee9a3.target().invokeWithArguments(class_hI_068ee9a3.source(), this);
            }
            catch (Throwable throwable) {
                throwable.printStackTrace();
            }
        }
    }

    public boolean bdW() {
        return this.QQqas;
    }
}

