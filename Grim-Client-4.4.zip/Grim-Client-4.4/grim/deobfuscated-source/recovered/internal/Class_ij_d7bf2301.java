/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package recovered.internal;

import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.NativeLoader;
import recovered.internal.Class_cJ_2ae1a557;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_id_3eb7ad7a;
import recovered.internal.Class_ie_4a6d16b6;
import recovered.internal.Class_if_dd7ae04e;
import recovered.internal.Class_ig_ca326427;
import recovered.internal.Class_rp_2e61368f;

public class Class_ij_d7bf2301
extends Class_ig_ca326427
implements Class_rp_2e61368f {
    String FiCDY;
    String hXfMy;
    private static long fkfrj;
    private static String[] aLucX;
    private static String[] qdFFd;
    private static Map LajUB;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public native Class_ij_d7bf2301 bke(String var1);

    private static native MatchException bkg(MatchException var0);

    public native Class_ij_d7bf2301 bkf(String var1);

    private static native Object bkj(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    public native String bkd();

    private static native String bki(int var0, long var1);

    private static native String bkh(byte[] var0);

    private static native CallSite bkk(MethodHandles.Lookup var0, String var1, MethodType var2);

    public Class_ij_d7bf2301() {
    }

    public Class_ij_d7bf2301(String string, String string2, int[] nArray, Class_ie_4a6d16b6 class_ie_4a6d16b6, Class_if_dd7ae04e class_if_dd7ae04e, Class_id_3eb7ad7a class_id_3eb7ad7a) {
        block4: {
            boolean bl;
            block6: {
                block5: {
                    long l = fkfrj ^ 0x594A0020D2DFL;
                    super(nArray, class_ie_4a6d16b6, class_if_dd7ae04e, class_id_3eb7ad7a);
                    this.FiCDY = string;
                    boolean bl2 = Class_cJ_2ae1a557.WH();
                    try {
                        try {
                            this.hXfMy = string2;
                            if (Class_iS_888f260e.bwL() != null) break block4;
                            if (!bl2) break block5;
                        }
                        catch (MatchException matchException) {
                            throw Class_ij_d7bf2301.bkg(matchException);
                        }
                        bl = false;
                        break block6;
                    }
                    catch (MatchException matchException) {
                        throw Class_ij_d7bf2301.bkg(matchException);
                    }
                }
                bl = true;
            }
            Class_cJ_2ae1a557.WG(bl);
        }
    }

    static {
        NativeLoader.doInit(Class_ij_d7bf2301.class);
        Class_ij_d7bf2301._f2b524f8e76a56962fb3b97ccefaac45();
    }

    @Override
    public native String bit();

    @Override
    public native void fromJson(JsonObject var1);

    @Override
    public native JsonObject toJson();

    @Override
    public native boolean biu();

    private static native void _f2b524f8e76a56962fb3b97ccefaac45();
}

