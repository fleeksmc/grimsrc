/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lq_87a74641;

public class Class_ax_3a65ba66 {
    public static final Class_lq_87a74641 aqGSY = Class_lE_06fbe260.joxgd.bYM(8.0f);
    public static final float gBfnc = 9.0f;
    public static final float oLKeu = 18.0f;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

