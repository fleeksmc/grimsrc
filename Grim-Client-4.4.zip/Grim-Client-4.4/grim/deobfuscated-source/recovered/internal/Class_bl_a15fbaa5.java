/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mixin.accessors.MinecraftAccessor
 *  net.minecraft.client.gui.hud.ChatHud$ChatMethod
 *  net.minecraft.client.gui.screen.Screen
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import mixin.accessors.MinecraftAccessor;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.math.Vec2f;
import recovered.core.ClientMain;
import recovered.internal.Class_R_e15da82d;
import recovered.internal.Class_W_5d5befd4;
import recovered.internal.Class_aJ_1c28c0cb;
import recovered.internal.Class_aR_f155c393;
import recovered.internal.Class_ad_d4e95a2c;
import recovered.internal.Class_ah_02444db4;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_al_68896891;
import recovered.internal.Class_ap_f3b7a87f;
import recovered.internal.Class_av_ffcf74a1;
import recovered.internal.Class_aw_dcb9764f;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_bc_f7ef99a1;
import recovered.internal.Class_bd_8faff9cb;
import recovered.internal.Class_bi_a63df9c8;
import recovered.internal.Class_bl_sd_eb769ac3;
import recovered.internal.Class_cq_827f2687;
import recovered.internal.Class_g_bd7b3df3;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jF_38b68c76;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_k_759fe111;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_od_f9118ebf;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rm_d861be3b;

public class Class_bl_a15fbaa5
extends Class_av_ffcf74a1
implements Class_aw_dcb9764f {
    private static Class_bl_a15fbaa5 VyQNu;
    private final Class_lc_b8480f87 CEIOv;
    private final Class_ah_02444db4 WOOwr;
    private final Class_ad_d4e95a2c TUFvs;
    private final Class_aJ_1c28c0cb wraGo;
    private final Class_al_68896891 ZmUwR;
    private final Class_bi_a63df9c8 cjnmJ;
    private final Class_g_bd7b3df3 lDPYv;
    private final Class_az_a4990dcf vjKVl;
    private boolean TCMij;
    private float bvjoR;
    private float dKaMJ;
    private boolean ncerH;
    private final Class_R_e15da82d uuFQh;
    private static Class_iS_888f260e[] rxHWS;
    private static final long AGQWN;
    private static final String afmPV;
    private static final long[] iSqCx;
    private static final Integer[] VgeZy;
    private static final Map sBqsw;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public static void EM(Class_iS_888f260e[] class_iS_888f260eArray) {
        rxHWS = class_iS_888f260eArray;
    }

    public Class_bl_a15fbaa5() {
        block0: {
            long l = AGQWN ^ 0x53E00267D255L;
            this.lDPYv = new Class_g_bd7b3df3();
            VyQNu = this;
            this.lDPYv.aV(() -> this.sg());
            float f = 465.0f;
            float f2 = 305.5f;
            Vec2f vec2f = Class_rm_d861be3b.diq();
            this.CEIOv = new Class_lc_b8480f87(vec2f.x / 2.0f - f / 2.0f, vec2f.y / 2.0f - f2 / 2.0f, f, f2);
            this.WOOwr = new Class_ah_02444db4();
            this.TUFvs = new Class_ad_d4e95a2c(Class_lE_06fbe260.WTzbi.bYM(6.0f));
            this.wraGo = new Class_aJ_1c28c0cb();
            this.ZmUwR = new Class_al_68896891();
            this.cjnmJ = new Class_bi_a63df9c8();
            this.uuFQh = (Class_R_e15da82d)new Class_R_e15da82d(Class_od_f9118ebf.cBQ(afmPV)).iA(Class_W_5d5befd4.igoQj).jb(class_R_e15da82d -> this.Er()).sX(20.0f, 20.0f);
            Class_iS_888f260e[] class_iS_888f260eArray = Class_bl_a15fbaa5.EN();
            this.vjKVl = new Class_bl_sd_eb769ac3(this);
            this.vjKVl.sI(this.wraGo);
            this.vjKVl.sI(this.ZmUwR);
            this.vjKVl.sI(this.uuFQh);
            this.vjKVl.sI(this.cjnmJ);
            Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
            this.lDPYv.aE(this.vjKVl);
            if (class_iS_888f260eArray2 == null) break block0;
            Class_iS_888f260e.bwK("sWBKJ");
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                block12: {
                    Class_bl_a15fbaa5.AGQWN = Class_gb_9d201141.aYR(6184744718404640296L, 5828307648978400804L, MethodHandles.lookup().lookupClass()).a(200750414847398L);
                    var11 = Class_bl_a15fbaa5.AGQWN ^ 2541012324948L;
                    Class_bl_a15fbaa5.EM(null);
                    var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                    v0 = SecretKeyFactory.getInstance("DES");
                    v1 = new byte[8];
                    v2 = v1;
                    v1[0] = (byte)(var11 >>> 56);
                    for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                        v2 = v2;
                        v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                    }
                    break block12;
lbl14:
                    // 1 sources

                    while (true) {
                        continue;
                        break;
                    }
                }
                var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var15_3 = var13_1.doFinal("I\u00a5\u00c5l\u00ff\u000bp\t".getBytes("ISO-8859-1"));
                ** while (true)
                Class_bl_a15fbaa5.afmPV = Class_bl_a15fbaa5.EP(var15_3).intern();
                Class_bl_a15fbaa5.sBqsw = new HashMap<K, V>(13);
                var0_4 = Cipher.getInstance("DES/CBC/NoPadding");
                v3 = SecretKeyFactory.getInstance("DES");
                v4 = new byte[8];
                v5 = v4;
                v4[0] = (byte)(var11 >>> 56);
                for (var1_5 = 1; var1_5 < 8; ++var1_5) {
                    v5 = v5;
                    v5[var1_5] = (byte)(var11 << var1_5 * 8 >>> 56);
                }
                var0_4.init(2, (Key)v3.generateSecret(new DESKeySpec(v5)), new IvParameterSpec(new byte[8]));
                var6_6 = new long[7];
                var3_7 = 0;
                var4_8 = "\u00e4\u00cfn\u00ac\u0090\u00c2\u001a\u001da\u00c6\u00dcBN\u00aa\u0010\u00a0\u009f\u00d6\u00a2\u00fa5U6`.\u00d2Y6{\u0080\u00cc\u00d1\u00fb\u00c6\u00de#\u00e0_\u007f\u00f9";
                var5_9 = "\u00e4\u00cfn\u00ac\u0090\u00c2\u001a\u001da\u00c6\u00dcBN\u00aa\u0010\u00a0\u009f\u00d6\u00a2\u00fa5U6`.\u00d2Y6{\u0080\u00cc\u00d1\u00fb\u00c6\u00de#\u00e0_\u007f\u00f9".length();
                var2_10 = 0;
                while (true) {
                    var7_11 = var4_8.substring(var2_10, var2_10 += 8).getBytes("ISO-8859-1");
                    v6 = var6_6;
                    v7 = var3_7++;
                    v8 = ((long)var7_11[0] & 255L) << 56 | ((long)var7_11[1] & 255L) << 48 | ((long)var7_11[2] & 255L) << 40 | ((long)var7_11[3] & 255L) << 32 | ((long)var7_11[4] & 255L) << 24 | ((long)var7_11[5] & 255L) << 16 | ((long)var7_11[6] & 255L) << 8 | (long)var7_11[7] & 255L;
                    v9 = -1;
                    break block10;
                    break;
                }
lbl45:
                // 1 sources

                while (true) {
                    v6[v7] = v10;
                    if (var2_10 < var5_9) ** continue;
                    var4_8 = "\u000562\u0083\u0002\u000e\u00f7\u000e\u00a3\u0080\u00d1Zft\u0086\u00d7";
                    var5_9 = "\u000562\u0083\u0002\u000e\u00f7\u000e\u00a3\u0080\u00d1Zft\u0086\u00d7".length();
                    var2_10 = 0;
                    while (true) {
                        var7_11 = var4_8.substring(var2_10, var2_10 += 8).getBytes("ISO-8859-1");
                        v6 = var6_6;
                        v7 = var3_7++;
                        v8 = ((long)var7_11[0] & 255L) << 56 | ((long)var7_11[1] & 255L) << 48 | ((long)var7_11[2] & 255L) << 40 | ((long)var7_11[3] & 255L) << 32 | ((long)var7_11[4] & 255L) << 24 | ((long)var7_11[5] & 255L) << 16 | ((long)var7_11[6] & 255L) << 8 | (long)var7_11[7] & 255L;
                        v9 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl58:
                // 1 sources

                while (true) {
                    v6[v7] = v10;
                    if (var2_10 < var5_9) ** continue;
                    break block11;
                    break;
                }
            }
            var8_12 = v8;
            var10_13 = var0_4.doFinal(new byte[]{(byte)(var8_12 >>> 56), (byte)(var8_12 >>> 48), (byte)(var8_12 >>> 40), (byte)(var8_12 >>> 32), (byte)(var8_12 >>> 24), (byte)(var8_12 >>> 16), (byte)(var8_12 >>> 8), (byte)var8_12});
            v10 = ((long)var10_13[0] & 255L) << 56 | ((long)var10_13[1] & 255L) << 48 | ((long)var10_13[2] & 255L) << 40 | ((long)var10_13[3] & 255L) << 32 | ((long)var10_13[4] & 255L) << 24 | ((long)var10_13[5] & 255L) << 16 | ((long)var10_13[6] & 255L) << 8 | (long)var10_13[7] & 255L;
            switch (v9) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl71:
                // 1 sources

                ** continue;
            }
        }
        Class_bl_a15fbaa5.iSqCx = var6_6;
        Class_bl_a15fbaa5.VgeZy = new Integer[7];
    }

    @Override
    protected Vec2f n() {
        return new Vec2f(this.CEIOv.bXH() + 14.0f, this.CEIOv.bXI() + 14.0f);
    }

    @Override
    public void m(Class_lC_5322e8cf class_lC_5322e8cf) {
        block3: {
            long l = AGQWN ^ 0x36EDF9286577L;
            Class_iS_888f260e[] class_iS_888f260eArray = Class_bl_a15fbaa5.EN();
            boolean bl = this.VWsmm;
            if (class_iS_888f260eArray == null) {
                bl = !bl;
            }
            this.Weytw.dhc(bl);
            this.Weytw.dhs(!this.VWsmm ? Class_rj_b691f4f7.XzDkv : Class_rj_b691f4f7.AYqck);
            this.WOOwr.nG();
            Class_bl_a15fbaa5 class_bl_a15fbaa5 = this;
            if (class_iS_888f260eArray == null) {
                if (class_bl_a15fbaa5.TCMij) {
                    this.CEIOv.bXt((float)class_lC_5322e8cf.cff() - this.bvjoR, (float)class_lC_5322e8cf.cfg() - this.dKaMJ);
                }
                this.Et();
                this.vjKVl.sZ(this.CEIOv);
                class_bl_a15fbaa5 = this;
            }
            class_bl_a15fbaa5.lDPYv.aL(class_lC_5322e8cf);
            if (Class_iS_888f260e.bwL() != null) break block3;
            Class_bl_a15fbaa5.EM(new Class_iS_888f260e[5]);
        }
    }

    private static int EQ(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x22E4;
        if (VgeZy[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = iSqCx[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])sBqsw.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    sBqsw.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bl_a15fbaa5", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bl_a15fbaa5.VgeZy[n2] = n3;
        }
        return VgeZy[n2];
    }

    @Override
    public Class_g_bd7b3df3 manager() {
        return this.lDPYv;
    }

    public Class_al_68896891 EC() {
        return this.ZmUwR;
    }

    public static Class_iS_888f260e[] EN() {
        return rxHWS;
    }

    private static CallSite ES(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bl_a15fbaa5" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public Class_bi_a63df9c8 ED() {
        return this.cjnmJ;
    }

    public Class_ah_02444db4 Ez() {
        return this.WOOwr;
    }

    public boolean EF() {
        return this.TCMij;
    }

    @Override
    public boolean onMouseDragged(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2, double d3, double d4) {
        return this.lDPYv.aP(d, d2, class_mA_32d8a5f2, d3, d4);
    }

    @Override
    public boolean onCharTyped(char c) {
        return this.lDPYv.aT(c);
    }

    @Override
    public boolean onMouseClicked(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        return this.lDPYv.aN(d, d2, class_mA_32d8a5f2);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    @Override
    public boolean onKeyPressed(int var1_1, int var2_2, int var3_3) {
        block15: {
            block16: {
                block17: {
                    var4_4 = Class_bl_a15fbaa5.AGQWN ^ 13873581510973L;
                    var6_5 = Class_bl_a15fbaa5.EN();
                    v0 = var1_1;
                    if (var6_5 != null) break block15;
                    if (v0 != Class_bl_a15fbaa5.ES("u", (int)2482, (long)(8696227825315521541L ^ var4_4))) break block16;
                    v1 /* !! */  = var7_6 = (Class_bc_f7ef99a1)this.lDPYv.ba(Class_bc_f7ef99a1.class).orElse(null);
                    if (var6_5 != null) break block17;
                    if (v1 /* !! */  == null) break block16;
                    var7_6.Bv().ly();
                    v1 /* !! */  = var7_6.oj(false);
                }
                return true;
            }
            v0 = ClientMain.dlmvG.isCtrlPressed();
        }
        if (var6_5 == null) {
            if (v0) {
                v0 = var1_1;
                if (var6_5 == null) {
                    if (v0 == Class_bl_a15fbaa5.ES("u", (int)3701, (long)(2994959173415445447L ^ var4_4))) {
                        this.Er();
                        return true;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                v0 = this.lDPYv.aS(var1_1, var2_2, var3_3);
            }
        }
        if (var6_5 == null) {
            if (v0) {
                return true;
            }
            v0 = this.WOOwr.dm(var1_1, var2_2, var3_3);
        }
        if (var6_5 == null) {
            if (v0) {
                return true;
            }
            v0 = var1_1;
        }
        if (var6_5 == null) {
            if (v0 == Class_bl_a15fbaa5.ES("u", (int)24648, (long)(6967017233858481662L ^ var4_4))) {
                this.Ew();
                return true;
            }
            v0 = false;
        }
        return v0;
    }

    @Override
    public boolean onMouseReleased(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        return this.lDPYv.aO(d, d2, class_mA_32d8a5f2);
    }

    @Override
    public boolean onMouseScrolled(double d, double d2, double d3) {
        return this.lDPYv.aQ(d, d2, d3);
    }

    @Override
    public void addOverlay(Class_aj_95d0a719 class_aj_95d0a719) {
        this.addOverlay(class_aj_95d0a719, true);
    }

    @Override
    public void addOverlay(Class_aj_95d0a719 class_aj_95d0a719, boolean bl) {
        long l = AGQWN ^ 0x2F568669E605L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_bl_a15fbaa5.EN();
        class_aj_95d0a719.sP((int)Class_bl_a15fbaa5.ES("u", (int)22170, (long)(0x339C356A39AECC11L ^ l))).sT(true);
        Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
        Class_g_bd7b3df3 class_g_bd7b3df3 = this.lDPYv;
        if (class_iS_888f260eArray2 == null) {
            class_g_bd7b3df3.aF(class_aj_95d0a719);
            if (!bl) {
                return;
            }
            class_g_bd7b3df3 = this.lDPYv;
        }
        Iterator<Class_aj_95d0a719> iterator = class_g_bd7b3df3.aY(Class_aj_95d0a719.class).iterator();
        while (iterator.hasNext()) {
            block8: {
                Class_aj_95d0a719 class_aj_95d0a7192;
                Class_aj_95d0a719 class_aj_95d0a7193;
                block7: {
                    class_aj_95d0a7192 = class_aj_95d0a7193 = iterator.next();
                    if (class_iS_888f260eArray2 != null) break block7;
                    if (class_aj_95d0a7192 == class_aj_95d0a719) break block8;
                    class_aj_95d0a7192 = class_aj_95d0a7193;
                }
                if (class_iS_888f260eArray2 == null && class_aj_95d0a7192.tz()) {
                    class_aj_95d0a7192 = class_aj_95d0a7193.oj(false);
                }
            }
            if (class_iS_888f260eArray2 == null) continue;
        }
    }

    @Override
    public void addTooltip(Class_k_759fe111 class_k_759fe111) {
        block3: {
            Class_az_a4990dcf class_az_a4990dcf;
            long l = AGQWN ^ 0x5C30C71F1AE5L;
            Iterator<Class_k_759fe111> iterator = this.lDPYv.aY(Class_k_759fe111.class).iterator();
            Class_iS_888f260e[] class_iS_888f260eArray = Class_bl_a15fbaa5.EN();
            while (iterator.hasNext()) {
                Class_k_759fe111 class_k_759fe1112 = iterator.next();
                class_az_a4990dcf = class_k_759fe1112.cn();
                if (class_iS_888f260eArray == null) {
                    if (class_az_a4990dcf == class_k_759fe111.cn()) {
                        return;
                    }
                    if (class_iS_888f260eArray == null) continue;
                }
                break block3;
            }
            class_k_759fe111.sS(true);
            class_az_a4990dcf = this.lDPYv.aF(class_k_759fe111);
        }
    }

    @Override
    public void addPopup(Class_ap_f3b7a87f class_ap_f3b7a87f) {
        long l = AGQWN ^ 0x71AA7174A97CL;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_bl_a15fbaa5.EN();
        class_ap_f3b7a87f.sP((int)Class_bl_a15fbaa5.ES("u", (int)2566, (long)(0x7DB853A46D5BDFF3L ^ l))).sT(false);
        this.lDPYv.aF(class_ap_f3b7a87f);
        Iterator<Class_ap_f3b7a87f> iterator = this.lDPYv.aY(Class_ap_f3b7a87f.class).iterator();
        Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
        while (iterator.hasNext()) {
            block6: {
                Class_ap_f3b7a87f class_ap_f3b7a87f2;
                int n;
                Class_ap_f3b7a87f class_ap_f3b7a87f3;
                block7: {
                    Class_ap_f3b7a87f class_ap_f3b7a87f4;
                    block5: {
                        class_ap_f3b7a87f4 = class_ap_f3b7a87f3 = iterator.next();
                        if (class_iS_888f260eArray2 != null) break block5;
                        if (class_ap_f3b7a87f4 == class_ap_f3b7a87f) break block6;
                        class_ap_f3b7a87f4 = class_ap_f3b7a87f3;
                    }
                    n = class_ap_f3b7a87f4.sN();
                    if (class_iS_888f260eArray2 != null) break block7;
                    if (n <= 0) break block6;
                    class_ap_f3b7a87f2 = class_ap_f3b7a87f3;
                    if (class_iS_888f260eArray2 != null) break block6;
                    n = class_ap_f3b7a87f2.tz() ? 1 : 0;
                }
                if (n == 0) {
                    class_ap_f3b7a87f2 = class_ap_f3b7a87f3.oj(false);
                }
            }
            if (class_iS_888f260eArray2 == null) continue;
        }
    }

    public Class_lc_b8480f87 Ey() {
        return this.CEIOv;
    }

    @Override
    public void addPopupComponent(Class_aj_95d0a719 class_aj_95d0a719) {
        long l = AGQWN ^ 0x5A925AC0DA93L;
        class_aj_95d0a719.sP((int)Class_bl_a15fbaa5.ES("u", (int)9009, (long)(0x12A0087CF694852AL ^ l))).sT(false);
        this.lDPYv.aF(class_aj_95d0a719);
    }

    public void close() {
        block6: {
            Class_bl_a15fbaa5 class_bl_a15fbaa5;
            block7: {
                int n;
                Class_iS_888f260e[] class_iS_888f260eArray;
                block5: {
                    long l = AGQWN ^ 0x1E0C00FA6282L;
                    class_iS_888f260eArray = Class_bl_a15fbaa5.EN();
                    n = this.VWsmm;
                    if (class_iS_888f260eArray != null) break block5;
                    if (n == 0) break block6;
                    this.Weytw.dhd(0.0f);
                    float f = this.Weytw.dhj() - 0.0f;
                    n = f == 0.0f ? 0 : (f < 0.0f ? -1 : 1);
                }
                if (n > 0) break block6;
                Class_ad_d4e95a2c class_ad_d4e95a2c = Class_ad_d4e95a2c.rmmkh;
                if (class_iS_888f260eArray == null && class_ad_d4e95a2c != null) {
                    class_ad_d4e95a2c = Class_ad_d4e95a2c.rmmkh.lQ(false);
                }
                super.close();
                class_bl_a15fbaa5 = this;
                if (class_iS_888f260eArray != null) break block7;
                if (!class_bl_a15fbaa5.ncerH) break block6;
                ((MinecraftAccessor)ClientMain.dlmvG).callOpenChatScreen(ChatHud.ChatMethod.MESSAGE);
                this.ncerH = false;
                class_bl_a15fbaa5 = this;
            }
            class_bl_a15fbaa5.wraGo.we();
            Class_cq_827f2687 class_cq_827f2687 = ClientMain.dlK();
            if (class_cq_827f2687.Rw().isEmpty()) {
                return;
            }
            float f = 90.0f;
            Vec2f vec2f = Class_rm_d861be3b.diq();
            class_cq_827f2687.Ru(Class_jf_d1c4f950.bAH(f, vec2f.x), vec2f.y / 4.0f);
        }
    }

    public void init() {
        this.TCMij = false;
        this.VWsmm = false;
    }

    public void tick() {
        this.si();
        this.close();
    }

    public static void Eu() {
        long l = AGQWN ^ 0x746B6E6712C2L;
        if (ClientMain.dlmvG.world == null) {
            return;
        }
        Class_bl_a15fbaa5 class_bl_a15fbaa5 = Class_bl_a15fbaa5.Ex();
        class_bl_a15fbaa5.VWsmm = false;
        class_bl_a15fbaa5.Weytw.dhg();
        ClientMain.dlmvG.setScreen((Screen)class_bl_a15fbaa5);
    }

    public static Class_bl_a15fbaa5 Ex() {
        long l = AGQWN ^ 0x39CF948E2375L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_bl_a15fbaa5.EN();
        Class_bl_a15fbaa5 class_bl_a15fbaa5 = VyQNu;
        if (class_iS_888f260eArray == null) {
            if (class_bl_a15fbaa5 == null) {
                new Class_bl_a15fbaa5();
            }
            class_bl_a15fbaa5 = VyQNu;
        }
        return class_bl_a15fbaa5;
    }

    public void Eq(Class_bd_8faff9cb class_bd_8faff9cb) {
        class_bd_8faff9cb.sP(0).sT(false);
        this.lDPYv.aF(class_bd_8faff9cb);
    }

    public Class_aJ_1c28c0cb EB() {
        return this.wraGo;
    }

    private static MatchException EO(MatchException matchException) {
        return matchException;
    }

    public Class_bc_f7ef99a1 Er() {
        Class_bc_f7ef99a1 class_bc_f7ef99a1 = this.lDPYv.aX(Class_bc_f7ef99a1.class, () -> {
            long l = AGQWN ^ 0x3B62549A50FEL;
            Class_bc_f7ef99a1 class_bc_f7ef99a1 = new Class_bc_f7ef99a1();
            class_bc_f7ef99a1.sP((int)Class_bl_a15fbaa5.ES("u", (int)10990, (long)(0x44CF0F60DDF2869CL ^ l))).sT(true);
            return class_bc_f7ef99a1;
        });
        class_bc_f7ef99a1.Bv().lx();
        class_bc_f7ef99a1.oj(true);
        return class_bc_f7ef99a1;
    }

    public void Es() {
        this.ncerH = true;
    }

    private void Ep(Class_lC_5322e8cf class_lC_5322e8cf) {
        Class_ii_9b427eda class_ii_9b427eda = ClientMain.dlM();
        float f = Math.min(1.0f, this.Weytw.dhj());
        Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, f);
        Class_jH_c1172273.bId(class_lC_5322e8cf, this.CEIOv.bXF() + this.CEIOv.bXH() / 2.0f, this.CEIOv.bXG() + this.CEIOv.bXI() / 2.0f, this.sf());
        class_lC_5322e8cf.cej(this.CEIOv.bXF(), this.CEIOv.bXG(), this.CEIOv.bXH(), this.CEIOv.bXI(), 5.0f, Class_ld_bb1690e1.all(11.0f), this.Weytw.dhj());
        class_lC_5322e8cf.cdm(this.CEIOv.bXF(), this.CEIOv.bXG(), this.CEIOv.bXH(), this.CEIOv.bXI(), 5.0f, Class_ld_bb1690e1.all(6.0f + 5.0f * f), class_ii_9b427eda.bjd().coa(255.0f * f).coc(class_ii_9b427eda.bje(), 0.3f).coc(class_ii_9b427eda.bjd().cob(0.75f), f));
        float f2 = 7.0f;
        float f3 = 28.0f;
        float f4 = 100.0f;
        float f5 = f3 + 2.0f * f2;
        this.wraGo.sW(this.CEIOv.bXF(), this.CEIOv.bXG());
        this.wraGo.sX(this.CEIOv.bXH() - f4, this.CEIOv.bXI());
        this.wraGo.su(class_lC_5322e8cf);
        float f6 = this.CEIOv.bXH() - f4 - 10.0f;
        this.ZmUwR.sW(this.CEIOv.bXF() + f4, this.CEIOv.bXG() + f2);
        this.ZmUwR.sX(f6, f3);
        this.ZmUwR.su(class_lC_5322e8cf);
        this.uuFQh.sW(this.ZmUwR.tc() - this.uuFQh.kN() - 7.0f, this.ZmUwR.ts() + Class_jf_d1c4f950.bAH(this.uuFQh.dn(), f3));
        this.uuFQh.su(class_lC_5322e8cf);
        this.cjnmJ.sW(this.CEIOv.bXF() + f4, this.CEIOv.bXG() + f5);
        this.cjnmJ.sX(f6, this.CEIOv.bXI() - f5);
        this.cjnmJ.su(class_lC_5322e8cf);
        Class_jH_c1172273.bIf();
        Class_jF_38b68c76.bHz(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public void Ew() {
        this.VWsmm = true;
        this.lDPYv.bb(Class_aj_95d0a719.class);
        this.lDPYv.bb(Class_bd_8faff9cb.class);
        this.lDPYv.bb(Class_aR_f155c393.class);
    }

    public static void Ev() {
        Class_bl_a15fbaa5.Ex().Ew();
    }

    public Class_ad_d4e95a2c EA() {
        return this.TUFvs;
    }

    private void Et() {
        Vec2f vec2f = Class_rm_d861be3b.diq();
        float f = 0.0f;
        float f2 = 0.0f;
        float f3 = Math.max(0.0f, vec2f.x - this.CEIOv.bXH());
        float f4 = Math.max(0.0f, vec2f.y - this.CEIOv.bXI());
        this.CEIOv.bXt(Math.clamp(this.CEIOv.bXF(), f, f3), Math.clamp(this.CEIOv.bXG(), f2, f4));
    }

    public Class_R_e15da82d EI() {
        return this.uuFQh;
    }

    public float EG() {
        return this.bvjoR;
    }

    public float EH() {
        return this.dKaMJ;
    }

    private static String EP(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static int ER(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bl_a15fbaa5.EQ(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    public Class_az_a4990dcf EE() {
        return this.vjKVl;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bl_a15fbaa5.class, "ER", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

