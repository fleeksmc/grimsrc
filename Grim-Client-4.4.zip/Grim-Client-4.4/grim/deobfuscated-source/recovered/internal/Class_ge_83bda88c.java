/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import recovered.core.ModuleBase;
import recovered.core.NativeLoader;
import recovered.internal.Class_gA_41c494e2;
import recovered.internal.Class_hG_d70cdb00;
import recovered.internal.Class_mw_6a6543f5;
import recovered.modules.AntiBotModule;

public class Class_ge_83bda88c {
    private Map<Class<? extends ModuleBase>, ModuleBase> apUTc;
    private static boolean ETFQC;
    private static long VYEoF;
    private static String[] tNmEx;
    private static String[] SYVIY;
    private static Map gPDHA;
    private static long[] SOFUQ;
    private static Integer[] tqrBW;
    private static Map XnczB;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_ge_83bda88c.class);
        Class_ge_83bda88c._a98ef9fceb6c88f8af19b70052dc846c();
    }

    public native AntiBotModule aZv();

    public native void aZu(ModuleBase var1);

    private static native String aZF(int var0, long var1);

    private static native int aZI(int var0, long var1);

    private native void aZs();

    private static native Object aZG(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native int aZJ(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    @Class_hG_d70cdb00(priority=Class_mw_6a6543f5.CRITICAL)
    public native void aZt(Class_gA_41c494e2 var1);

    public native ModuleBase aZy(int var1);

    public native Map<Class<? extends ModuleBase>, ModuleBase> aZz();

    public static native boolean aZC();

    private static native String aZE(byte[] var0);

    public native List<ModuleBase> aZw(Predicate<ModuleBase> var1);

    private static native CallSite aZH(MethodHandles.Lookup var0, String var1, MethodType var2);

    public native void aZq(String var1);

    private native void aZr(String var1);

    public static native void aZA(boolean var0);

    public static native boolean aZB();

    private static native Exception aZD(Exception var0);

    private static native CallSite aZK(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native void _a98ef9fceb6c88f8af19b70052dc846c();

    public <T extends ModuleBase> T aZx(Class<T> clazz) {
        return (T)((ModuleBase)clazz.cast(this.apUTc.get(clazz)));
    }
}

