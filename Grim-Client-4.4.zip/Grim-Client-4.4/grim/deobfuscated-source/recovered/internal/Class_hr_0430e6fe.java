/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package recovered.internal;

import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_hr_0430e6fe
extends Class_hH_ae8f8f77 {
    private Entity HztkT;
    private CallbackInfoReturnable<Float> hdBkc;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public CallbackInfoReturnable<Float> bdc() {
        return this.hdBkc;
    }

    public Entity bdb() {
        return this.HztkT;
    }

    public Class_hr_0430e6fe(Entity entity, CallbackInfoReturnable<Float> callbackInfoReturnable) {
        this.HztkT = entity;
        this.hdBkc = callbackInfoReturnable;
    }
}

