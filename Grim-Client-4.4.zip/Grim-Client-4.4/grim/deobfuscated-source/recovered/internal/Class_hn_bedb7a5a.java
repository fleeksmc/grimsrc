/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.LivingEntity
 */
package recovered.internal;

import net.minecraft.entity.LivingEntity;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_hn_bedb7a5a
extends Class_hH_ae8f8f77 {
    private LivingEntity pvQEw;
    private float kunOe;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public float bcU() {
        return this.kunOe;
    }

    public LivingEntity bcT() {
        return this.pvQEw;
    }

    public Class_hn_bedb7a5a(LivingEntity livingEntity, float f) {
        this.pvQEw = livingEntity;
        this.kunOe = f;
    }
}

