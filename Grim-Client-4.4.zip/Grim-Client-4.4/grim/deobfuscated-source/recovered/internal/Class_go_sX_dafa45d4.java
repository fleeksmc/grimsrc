/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.math.MatrixStack
 */
package recovered.internal;

import net.minecraft.client.util.math.MatrixStack;
import recovered.internal.Class_go_72b5d3a1;

public class Class_go_sX_dafa45d4
extends Class_go_72b5d3a1 {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_go_sX_dafa45d4(MatrixStack matrixStack, float f) {
        super(matrixStack, f);
    }
}

