/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.core.ClientMain;
import recovered.internal.Class_R_e15da82d;
import recovered.internal.Class_W_5d5befd4;
import recovered.internal.Class_Z_a19ce218;
import recovered.internal.Class_aF_88ec985e;
import recovered.internal.Class_al_68896891;
import recovered.internal.Class_aq_9e8149f3;
import recovered.internal.Class_aw_dcb9764f;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_be_a4fb5c5c;
import recovered.internal.Class_bf_b8c92e87;
import recovered.internal.Class_bi_a63df9c8;
import recovered.internal.Class_bl_a15fbaa5;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jG_69891630;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mE_e0ac7db3;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_od_f9118ebf;
import recovered.internal.Class_rj_b691f4f7;

public class Class_aB_ac16df9e
extends Class_aF_88ec985e {
    private final List<Class_bf_b8c92e87> AUdhE;
    private final Class_Z_a19ce218 RzEBK;
    private final Class_R_e15da82d tZXAh;
    private final Class_aq_9e8149f3 EPfGw;
    private static final long ZGbQs;
    private static final String[] oUFpP;
    private static final String[] wsktb;
    private static final Map loIRo;
    private static final long[] sPLxc;
    private static final Integer[] eXrVy;
    private static final Map xqEzU;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aB_ac16df9e() {
        block2: {
            long l = ZGbQs ^ 0x6E080684504EL;
            Class_iS_888f260e[] class_iS_888f260eArray = Class_lc_b8480f87.bXK();
            int[] nArray = new int[Class_aB_ac16df9e.uf("d", (int)32194, (long)(0x353E756E5D1CCC85L ^ l))];
            nArray[0] = (int)Class_aB_ac16df9e.uf("d", (int)823, (long)(0x7D11A90A25E1327FL ^ l));
            nArray[1] = (int)Class_aB_ac16df9e.uf("d", (int)7375, (long)(0x180E6DBA778AAD84L ^ l));
            nArray[2] = (int)Class_aB_ac16df9e.uf("d", (int)14762, (long)(0xC029F4D8D2808E7L ^ l));
            nArray[3] = (int)Class_aB_ac16df9e.uf("d", (int)5763, (long)(0x69F4B113F96FA7CDL ^ l));
            nArray[4] = (int)Class_aB_ac16df9e.uf("d", (int)9014, (long)(0x21A28EB5083F127AL ^ l));
            nArray[5] = (int)Class_aB_ac16df9e.uf("d", (int)12121, (long)(0x53FDDCFC6EBE9E13L ^ l));
            nArray[Class_aB_ac16df9e.uf("d", (int)22509, (long)(0x65ACC53612C9E6ABL ^ l))] = (int)Class_aB_ac16df9e.uf("d", (int)21618, (long)(0x786324C684E53BL ^ l));
            super(nArray);
            Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
            this.AUdhE = new ArrayList<Class_bf_b8c92e87>();
            this.EPfGw = new Class_aq_9e8149f3((String)((Object)Class_aB_ac16df9e.uc("c", (int)7774, (long)(0x5AF1134907B82F15L ^ l))), (String)((Object)Class_aB_ac16df9e.uc("c", (int)31973, (long)(0x5726B665B3254DADL ^ l)))).qC(Class_lE_06fbe260.WTzbi.bYM(12.0f)).qD(Class_lE_06fbe260.joxgd.bYM(9.0f)).qE(30.0f);
            for (Class_mE_e0ac7db3 class_mE_e0ac7db3 : ClientMain.dmc().ddE()) {
                Class_bf_b8c92e87 class_bf_b8c92e87 = new Class_bf_b8c92e87(class_mE_e0ac7db3);
                this.AUdhE.add(class_bf_b8c92e87);
                if (class_iS_888f260eArray2 != null) {
                    if (class_iS_888f260eArray2 != null) continue;
                }
                break block2;
            }
            this.RzEBK = new Class_Z_a19ce218().kJ(Class_lE_06fbe260.joxgd.bYM(7.0f)).kK(5.0f).kL((int)Class_aB_ac16df9e.uf("d", (int)13067, (long)(0x3E7C1C40B8450244L ^ l))).kM(Class_rj_b691f4f7.UPXqT);
            this.tZXAh = (Class_R_e15da82d)new Class_R_e15da82d(Class_od_f9118ebf.cBQ((String)((Object)Class_aB_ac16df9e.uc("c", (int)16062, (long)(0x7BAE4E895D910FF4L ^ l))))).iA(Class_W_5d5befd4.igoQj).sX(20.0f, 20.0f);
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Class_aB_ac16df9e.ZGbQs = Class_gb_9d201141.aYR(-3499594539942174950L, -7895749289035004343L, MethodHandles.lookup().lookupClass()).a(169079032966189L);
                        Class_aB_ac16df9e.loIRo = new HashMap<K, V>(13);
                        var11 = Class_aB_ac16df9e.ZGbQs ^ 106123193346128L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[5];
                        var18_4 = 0;
                        var17_5 = "Y\u0000\u00e9\u00aa\u00a0[\t\u00f0Zn~\u00bcz\u00c0\u00e27\u00ca\u008f\u0095+\u0096\u0007\u00cc_\u0085\u009f\u0089\u00dd\u00efno\u00cd\u007f;\u0080\u0012\u00d0\u00e7\u009cw\u00cd\u0094\u0014\u00e9/\t\u00c6\u00db\u0017\u008a\u00f1o\u00ae]\u001aI\u008b\u00a5\u001f\u00d8\u0011.\u007f\u00a1\u00b7 \u0080k\u00ebC-_\u0099D\u00a8i\u00a6\u007f\u0018\u00ee\u0018\u00ff,\u00c0\u00b8\u0017\u0012\u00a4\u008f`\\\u00cc\u00ae2\u00eb@\u00b1\u00e8<R\u00c0\u00917\u00d0\u00fd\u0010yn\u00a8\u00de\u00a5s-\u0004\u007f\u00acu\u00d9P\u0086L.";
                        var19_6 = "Y\u0000\u00e9\u00aa\u00a0[\t\u00f0Zn~\u00bcz\u00c0\u00e27\u00ca\u008f\u0095+\u0096\u0007\u00cc_\u0085\u009f\u0089\u00dd\u00efno\u00cd\u007f;\u0080\u0012\u00d0\u00e7\u009cw\u00cd\u0094\u0014\u00e9/\t\u00c6\u00db\u0017\u008a\u00f1o\u00ae]\u001aI\u008b\u00a5\u001f\u00d8\u0011.\u007f\u00a1\u00b7 \u0080k\u00ebC-_\u0099D\u00a8i\u00a6\u007f\u0018\u00ee\u0018\u00ff,\u00c0\u00b8\u0017\u0012\u00a4\u008f`\\\u00cc\u00ae2\u00eb@\u00b1\u00e8<R\u00c0\u00917\u00d0\u00fd\u0010yn\u00a8\u00de\u00a5s-\u0004\u007f\u00acu\u00d9P\u0086L.".length();
                        var16_7 = 80;
                        var15_8 = -1;
lbl20:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl25:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Class_aB_ac16df9e.tZ(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = ".15-\u00c0\u0012\u00b6\u00e1>\u00ecR\u00e5;k\u0014$\u00a3m\u00e9\u00defE\u00be\u00be\u00f5#\u00a5\u00a2T\u00bb\u0084\u00af\u00d6\u007fJ\u00a4\u00dc\u0017\u00bc\u00d7\u0093\u00c8\u00da:\u00afu\u00ba\u00ecT*\u00d6\u0006\u0084r4\u0099 \u00deN6\f\u00a6\u0012\u00e0\u0094(E\u00b2\u00a6\u000e\u00ad\u001d\u001a\u0016\u00a6\u001f}\u00ae\u00c3\u0018\u00f0\u00dd\u00bam\u00d8\u0013\u00ff\u0099=";
                            var19_6 = ".15-\u00c0\u0012\u00b6\u00e1>\u00ecR\u00e5;k\u0014$\u00a3m\u00e9\u00defE\u00be\u00be\u00f5#\u00a5\u00a2T\u00bb\u0084\u00af\u00d6\u007fJ\u00a4\u00dc\u0017\u00bc\u00d7\u0093\u00c8\u00da:\u00afu\u00ba\u00ecT*\u00d6\u0006\u0084r4\u0099 \u00deN6\f\u00a6\u0012\u00e0\u0094(E\u00b2\u00a6\u000e\u00ad\u001d\u001a\u0016\u00a6\u001f}\u00ae\u00c3\u0018\u00f0\u00dd\u00bam\u00d8\u0013\u00ff\u0099=".length();
                            var16_7 = 56;
                            var15_8 = -1;
lbl34:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl39:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Class_aB_ac16df9e.tZ(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl51:
                        // 1 sources

                        ** continue;
                    }
                }
                Class_aB_ac16df9e.oUFpP = var20_3;
                Class_aB_ac16df9e.wsktb = new String[5];
                Class_aB_ac16df9e.xqEzU = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[10];
                var3_13 = 0;
                var4_14 = "\u00f0H@\u008a\u00d8\u00b9n\u008f\u00fbrsfn\u00c0\u00c5zR\u00b5\u00fbp\u00d4(\u00ec\u00a0GH\u0003r\u000f\u008fY\u00a2\u00dcn\u00e7\u000fV\u00e7\b\u00e7T\u00d9\u00f0\u00f3Z\u008a\u0091\u00a2\u00a2E\u0000\u0015\u00e1\u00c4;\u00f0\u00fe\u0001\u00feM\u00b3\u0096^\u00bf";
                var5_15 = "\u00f0H@\u008a\u00d8\u00b9n\u008f\u00fbrsfn\u00c0\u00c5zR\u00b5\u00fbp\u00d4(\u00ec\u00a0GH\u0003r\u000f\u008fY\u00a2\u00dcn\u00e7\u000fV\u00e7\b\u00e7T\u00d9\u00f0\u00f3Z\u008a\u0091\u00a2\u00a2E\u0000\u0015\u00e1\u00c4;\u00f0\u00fe\u0001\u00feM\u00b3\u0096^\u00bf".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl78:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "/J\u00a6\u00ca\u00c61_\u00c5\u00ac\u00aaM\u0083n\u0015\u00a9\u001c";
                    var5_15 = "/J\u00a6\u00ca\u00c61_\u00c5\u00ac\u00aaM\u0083n\u0015\u00a9\u001c".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl91:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl104:
                // 1 sources

                ** continue;
            }
        }
        Class_aB_ac16df9e.sPLxc = var6_12;
        Class_aB_ac16df9e.eXrVy = new Integer[10];
    }

    private static CallSite uc(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_aB_ac16df9e" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static String ua(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x2A5F;
        if (wsktb[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])loIRo.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    loIRo.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_aB_ac16df9e", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = oUFpP[n2].getBytes("ISO-8859-1");
            Class_aB_ac16df9e.wsktb[n2] = Class_aB_ac16df9e.tZ(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return wsktb[n2];
    }

    private static int ud(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x2A59;
        if (eXrVy[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = sPLxc[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])xqEzU.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    xqEzU.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_aB_ac16df9e", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_aB_ac16df9e.eXrVy[n2] = n3;
        }
        return eXrVy[n2];
    }

    @Override
    public boolean dk(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        boolean bl;
        block18: {
            Class_bi_a63df9c8 class_bi_a63df9c8;
            Class_iS_888f260e[] class_iS_888f260eArray;
            block22: {
                boolean bl2;
                block21: {
                    block20: {
                        boolean bl3;
                        block19: {
                            long l = ZGbQs ^ 0x47F5787BADA1L;
                            class_iS_888f260eArray = Class_lc_b8480f87.bXK();
                            bl3 = this.tZXAh.dk(d, d2, class_mA_32d8a5f2);
                            if (class_iS_888f260eArray == null) break block19;
                            if (!bl3) break block20;
                            this.tQ(d, d2);
                            bl3 = true;
                        }
                        return bl3;
                    }
                    class_bi_a63df9c8 = Class_bl_a15fbaa5.Ex().ED();
                    bl2 = class_bi_a63df9c8.Dw(d, d2);
                    if (class_iS_888f260eArray == null) break block21;
                    if (bl2) break block22;
                    bl2 = false;
                }
                return bl2;
            }
            for (Class_az_a4990dcf class_az_a4990dcf : this.LGwHI) {
                block24: {
                    boolean bl4;
                    block23: {
                        bl = class_az_a4990dcf.tf();
                        if (class_iS_888f260eArray == null) break block18;
                        if (class_iS_888f260eArray != null) {
                            if (bl) {
                                bl4 = class_bi_a63df9c8.Dv(class_az_a4990dcf);
                                if (class_iS_888f260eArray != null) {
                                    if (!bl4 && class_iS_888f260eArray != null) continue;
                                }
                            } else {
                                bl4 = class_az_a4990dcf.dk(d, d2, class_mA_32d8a5f2);
                            }
                        }
                        if (class_iS_888f260eArray == null) break block23;
                        if (!bl4) break block24;
                        bl4 = true;
                    }
                    return bl4;
                }
                if (class_iS_888f260eArray != null) continue;
            }
            if (class_mA_32d8a5f2 == Class_mA_32d8a5f2.frWTZ) {
                this.tQ(d, d2);
                return true;
            }
            bl = super.dk(d, d2, class_mA_32d8a5f2);
        }
        return bl;
    }

    private static int ue(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_aB_ac16df9e.ud(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    @Override
    public void bV(Class_lC_5322e8cf class_lC_5322e8cf) {
        block7: {
            List list;
            Class_iS_888f260e[] class_iS_888f260eArray;
            block5: {
                block6: {
                    long l = ZGbQs ^ 0x1A60B0D27965L;
                    class_iS_888f260eArray = Class_lc_b8480f87.bXK();
                    list = this.LGwHI;
                    if (class_iS_888f260eArray == null) break block5;
                    if (!list.isEmpty()) break block6;
                    this.EPfGw.sY(this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ);
                    this.EPfGw.su(class_lC_5322e8cf);
                    if (class_iS_888f260eArray != null) break block7;
                }
                list = this.LGwHI;
            }
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                Class_az_a4990dcf class_az_a4990dcf;
                Class_az_a4990dcf class_az_a4990dcf2 = class_az_a4990dcf = (Class_az_a4990dcf)iterator.next();
                if (class_iS_888f260eArray != null) {
                    if (!Class_jG_69891630.bHY(class_az_a4990dcf2) && class_iS_888f260eArray != null) continue;
                    class_az_a4990dcf2 = class_az_a4990dcf;
                }
                class_az_a4990dcf2.su(class_lC_5322e8cf);
                if (class_iS_888f260eArray != null) continue;
            }
        }
    }

    private static Object ub(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_aB_ac16df9e.ua(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    @Override
    public void dY() {
        long l = ZGbQs ^ 0x5F2089B6D044L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_lc_b8480f87.bXK();
        super.dY();
        List<Class_mE_e0ac7db3> list = ClientMain.dmc().ddE();
        Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
        this.EPfGw.qB();
        this.LGwHI.clear();
        for (Class_mE_e0ac7db3 class_mE_e0ac7db3 : list) {
            Class_bf_b8c92e87 class_bf_b8c92e872;
            Class_bf_b8c92e87 class_bf_b8c92e873 = class_bf_b8c92e872 = (Class_bf_b8c92e87)this.AUdhE.stream().filter(class_bf_b8c92e87 -> class_bf_b8c92e87.CE().cnD().equals(class_mE_e0ac7db3.cnD())).findFirst().orElse(null);
            if (class_iS_888f260eArray2 != null) {
                if (class_bf_b8c92e873 == null) {
                    class_bf_b8c92e872 = new Class_bf_b8c92e87(class_mE_e0ac7db3);
                    this.AUdhE.add(class_bf_b8c92e872);
                }
                class_bf_b8c92e872.dY();
                class_bf_b8c92e873 = class_bf_b8c92e872;
            }
            class_bf_b8c92e873.CC().dhg();
            this.LGwHI.add(class_bf_b8c92e872);
            if (class_iS_888f260eArray2 != null) continue;
        }
    }

    @Override
    public void fX(Class_lC_5322e8cf class_lC_5322e8cf) {
        super.fX(class_lC_5322e8cf);
        this.LGwHI.removeIf(var1_1 -> {
            /*
             * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
             * 
             * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
             *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
             *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
             *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
             *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1050)
             *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
             *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
             *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
             *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
             *     at org.benf.cfr.reader.Main.main(Main.java:54)
             */
            throw new IllegalStateException("Decompilation failed");
        });
    }

    @Override
    public void tP(Class_lC_5322e8cf class_lC_5322e8cf, float f, Class_al_68896891 class_al_68896891) {
        long l = ZGbQs ^ 0x54132D20F43CL;
        List<Class_mE_e0ac7db3> list = ClientMain.dmc().ddE();
        Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.joxgd.bYM(7.0f);
        Class_mG_52c8d386 class_mG_52c8d386 = this.CtPwV.bjb().cob(0.5f);
        float f2 = class_al_68896891.ts() + Class_jf_d1c4f950.bAH(class_lq_87a74641.cat(), class_al_68896891.dn());
        CallSite callSite = Class_aB_ac16df9e.uc("c", (int)30394, (long)(0x3BF28E709177E381L ^ l));
        class_lC_5322e8cf.cez(class_lq_87a74641, (String)((Object)callSite), f, f2, class_mG_52c8d386);
        this.RzEBK.kO(list.size());
        this.RzEBK.kS(false, class_mG_52c8d386);
        this.RzEBK.sW(f + class_lq_87a74641.cao((String)((Object)callSite)), f2);
        this.RzEBK.su(class_lC_5322e8cf);
        float f3 = class_al_68896891.tc() - 7.0f - Class_bl_a15fbaa5.Ex().EI().kN() - 7.0f - this.tZXAh.kN();
        float f4 = class_al_68896891.ts() + Class_jf_d1c4f950.bAH(this.tZXAh.dn(), class_al_68896891.dn());
        this.tZXAh.sW(f3, f4);
        this.tZXAh.su(class_lC_5322e8cf);
    }

    @Override
    protected int tR() {
        return 3;
    }

    private static MatchException tY(MatchException matchException) {
        return matchException;
    }

    private void tQ(double d, double d2) {
        long l = ZGbQs ^ 0x4270B07902EBL;
        Class_be_a4fb5c5c class_be_a4fb5c5c = new Class_be_a4fb5c5c((float)d, (float)d2, 6.0f, (String)((Object)Class_aB_ac16df9e.uc("c", (int)7887, (long)(0x32A9A59405997D26L ^ l))));
        Class_aw_dcb9764f.route(class_be_a4fb5c5c);
    }

    private static CallSite uf(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_aB_ac16df9e" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public List<Class_bf_b8c92e87> tS() {
        return this.AUdhE;
    }

    public Class_Z_a19ce218 tT() {
        return this.RzEBK;
    }

    public Class_R_e15da82d tU() {
        return this.tZXAh;
    }

    public Class_aq_9e8149f3 tV() {
        return this.EPfGw;
    }

    private static String tZ(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_aB_ac16df9e.class, "ub", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Class_aB_ac16df9e.class, "ue", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

