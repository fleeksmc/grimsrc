/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import recovered.core.NativeLoader;
import recovered.internal.Class_iA_8ae60526;
import recovered.internal.Class_iC_1c31d05c;
import recovered.internal.Class_iD_f0bb28c7;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_iu_bf2db566;
import recovered.internal.Class_iv_eaeaeb9a;
import recovered.internal.Class_ix_05f2a225;
import recovered.internal.Class_iy_c88c0f4f;
import recovered.internal.Class_iz_2ddebd14;
import recovered.internal.Class_nf_8f40fc48;

public class Class_iB_7f1bc3b4 {
    private final Class_iA_8ae60526 NeyGX;
    private final Class_ix_05f2a225 CJxKq;
    private final Class_iv_eaeaeb9a sTdzs;
    private final Class_iC_1c31d05c WtxwN;
    private final String gQoVO;
    private boolean skPbg;
    private static Class_iS_888f260e[] mKwrj;
    private static long SaDmh;
    private static String[] qKAOd;
    private static String[] hlrVF;
    private static Map cUKLP;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_iB_7f1bc3b4(Class_ix_05f2a225 class_ix_05f2a225, Class_iv_eaeaeb9a class_iv_eaeaeb9a) {
        long l = SaDmh ^ 0x6881C03FDD30L;
        this.gQoVO = Class_iB_7f1bc3b4.bqH("m", (int)3863, (long)(0x787591C11C7C4D1FL ^ l));
        this.skPbg = false;
        this.CJxKq = class_ix_05f2a225;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_iB_7f1bc3b4.bqC();
        try {
            this.sTdzs = class_iv_eaeaeb9a;
            this.NeyGX = new Class_iA_8ae60526();
            this.WtxwN = new Class_iC_1c31d05c();
            class_iv_eaeaeb9a.bnI(this::bqd);
            if (Class_iS_888f260e.bwL() == null) {
                Class_iB_7f1bc3b4.bqB(new Class_iS_888f260e[1]);
            }
        }
        catch (MatchException matchException) {
            throw Class_iB_7f1bc3b4.bqD(matchException);
        }
    }

    static {
        NativeLoader.doInit(Class_iB_7f1bc3b4.class);
        Class_iB_7f1bc3b4._492103ed719575fed4a2d58088d5c153();
    }

    public static native Class_iS_888f260e[] bqC();

    private static native MatchException bqD(MatchException var0);

    public static native void bqB(Class_iS_888f260e[] var0);

    private static native CallSite bqH(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native void bqd();

    private native void bpU();

    private native void bpV();

    private native /* synthetic */ CompletionStage bqo(String var1, Class_iy_c88c0f4f var2);

    private static native /* synthetic */ void bqy();

    public native CompletableFuture<Boolean> bpY(String var1);

    private native /* synthetic */ void bqA(List var1);

    public native CompletableFuture<Class_iy_c88c0f4f> bpX(Class_iD_f0bb28c7 var1);

    private native /* synthetic */ void bqs(String var1);

    private static native /* synthetic */ Void bqx(Throwable var0);

    private native /* synthetic */ Boolean bqn(Class_iu_bf2db566 var1);

    public native String bqi();

    private native /* synthetic */ void bqu(Class_iy_c88c0f4f var1);

    private native /* synthetic */ void bqw(Class_iz_2ddebd14 var1);

    private static native Object bqG(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native /* synthetic */ Class_iy_c88c0f4f bqt(Class_iy_c88c0f4f var1);

    private static native String bqE(byte[] var0);

    public native Class_iv_eaeaeb9a bqg();

    private native /* synthetic */ void bqv(String var1, Class_iz_2ddebd14 var2, Throwable var3);

    private native /* synthetic */ Class_iy_c88c0f4f bqp(Class_iy_c88c0f4f var1);

    private native /* synthetic */ void bqq(Class_iy_c88c0f4f var1);

    public native CompletableFuture<Boolean> bpZ(String var1);

    private native /* synthetic */ Class_iy_c88c0f4f bql(Class_iy_c88c0f4f var1);

    public native Class_ix_05f2a225 bqf();

    private native /* synthetic */ void bqm(Class_iy_c88c0f4f var1);

    public native Class_iA_8ae60526 bqe();

    private native /* synthetic */ void bqz(List var1);

    public native boolean bqj();

    private native /* synthetic */ Boolean bqr(String var1, Class_iu_bf2db566 var2);

    private native /* synthetic */ Boolean bqk(Class_iy_c88c0f4f var1, Class_iu_bf2db566 var2);

    private static native String bqF(int var0, long var1);

    private static native void _492103ed719575fed4a2d58088d5c153();

    public native Class_iC_1c31d05c bqh();

    public native void bpW();

    public native CompletableFuture<Class_iy_c88c0f4f> bqb(Class_iy_c88c0f4f var1, List<Class_nf_8f40fc48> var2);

    public native CompletableFuture<Boolean> bqc(Class_iy_c88c0f4f var1);

    public native CompletableFuture<Class_iy_c88c0f4f> bqa(String var1, Class_iD_f0bb28c7 var2);
}

