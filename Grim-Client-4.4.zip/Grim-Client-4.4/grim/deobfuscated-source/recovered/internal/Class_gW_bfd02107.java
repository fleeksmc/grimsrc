/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemUsageContext
 */
package recovered.internal;

import net.minecraft.item.ItemUsageContext;
import recovered.internal.Class_hH_ae8f8f77;

public abstract class Class_gW_bfd02107
extends Class_hH_ae8f8f77 {
    private ItemUsageContext QXNUv;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gW_bfd02107(ItemUsageContext itemUsageContext) {
        this.QXNUv = itemUsageContext;
    }

    public ItemUsageContext bcm() {
        return this.QXNUv;
    }
}

