/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_ab_035d8734;

public interface Class_aa_5f3e46cf {
    public void run(Class_ab_035d8734 var1);
}

