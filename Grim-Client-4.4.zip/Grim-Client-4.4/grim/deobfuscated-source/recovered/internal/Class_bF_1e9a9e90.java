/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.core.ClientMain;
import recovered.internal.Class_bH_2433d459;
import recovered.internal.Class_cn_4308f1f5;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jd_8956ed6c;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_mr_7eac5189;

public class Class_bF_1e9a9e90
extends Class_cn_4308f1f5 {
    private final Class_bH_2433d459 rMeCH;
    private final Class_bH_2433d459 uTLas;
    private static final long SlbGB;
    private static final String lnImF;
    private static final long[] nuUmx;
    private static final Integer[] Gjkur;
    private static final Map AUlej;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bF_1e9a9e90() {
        long l = SlbGB ^ 0x2A1F6A83025AL;
        int[] nArray = new int[Class_bF_1e9a9e90.Mg("p", (int)31495, (long)(0x7E149F656E79EAB6L ^ l))];
        nArray[0] = (int)Class_bF_1e9a9e90.Mg("p", (int)30538, (long)(0x78F7E3DD796466FDL ^ l));
        nArray[1] = (int)Class_bF_1e9a9e90.Mg("p", (int)15720, (long)(0x45B1A9B306072CDBL ^ l));
        nArray[2] = (int)Class_bF_1e9a9e90.Mg("p", (int)17883, (long)(0x78CEB315F6475465L ^ l));
        nArray[3] = (int)Class_bF_1e9a9e90.Mg("p", (int)18717, (long)(0x45AA7200629958ABL ^ l));
        nArray[4] = (int)Class_bF_1e9a9e90.Mg("p", (int)9291, (long)(0x2E2CF7D2752CB5F1L ^ l));
        nArray[5] = (int)Class_bF_1e9a9e90.Mg("p", (int)6599, (long)(0x4B68FF82416F8878L ^ l));
        super(nArray, Class_lf_d247d983.JliAr);
        int[] nArray2 = new int[Class_bF_1e9a9e90.Mg("p", (int)12891, (long)(0x1962E32F98AFA3E0L ^ l))];
        nArray2[0] = (int)Class_bF_1e9a9e90.Mg("p", (int)23762, (long)(0x30D5B409699CD60L ^ l));
        nArray2[1] = (int)Class_bF_1e9a9e90.Mg("p", (int)5136, (long)(0x738D210EE87185A4L ^ l));
        nArray2[2] = (int)Class_bF_1e9a9e90.Mg("p", (int)20980, (long)(0x18D8E37499AAC04DL ^ l));
        nArray2[3] = (int)Class_bF_1e9a9e90.Mg("p", (int)6599, (long)(0x4B68FF82416F8878L ^ l));
        nArray2[4] = (int)Class_bF_1e9a9e90.Mg("p", (int)9291, (long)(0x2E2CF7D2752CB5F1L ^ l));
        nArray2[5] = (int)Class_bF_1e9a9e90.Mg("p", (int)26322, (long)(0x582D0E43D3A5776FL ^ l));
        nArray2[Class_bF_1e9a9e90.Mg("p", (int)16334, (long)(0x3581AB7E1142E7EL ^ l))] = (int)Class_bF_1e9a9e90.Mg("p", (int)20179, (long)(0x13B50B97F7AB5F66L ^ l));
        this.rMeCH = new Class_bH_2433d459(this.ZpVra, Class_mr_7eac5189.clS(nArray2));
        this.uTLas = new Class_bH_2433d459(this.ZpVra, Class_mr_7eac5189.clS(new int[]{(int)Class_bF_1e9a9e90.Mg("p", (int)4478, (long)(0x71767A9F73A400DDL ^ l)), (int)Class_bF_1e9a9e90.Mg("p", (int)6873, (long)(0x7039CF79B550B61L ^ l)), (int)Class_bF_1e9a9e90.Mg("p", (int)8245, (long)(0x7274597F6986B189L ^ l))}), lnImF);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                block12: {
                    Class_bF_1e9a9e90.SlbGB = Class_gb_9d201141.aYR(7165212067470311943L, -3106068011897424739L, MethodHandles.lookup().lookupClass()).a(1403987934215L);
                    var11 = Class_bF_1e9a9e90.SlbGB ^ 123093412689874L;
                    var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                    v0 = SecretKeyFactory.getInstance("DES");
                    v1 = new byte[8];
                    v2 = v1;
                    v1[0] = (byte)(var11 >>> 56);
                    for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                        v2 = v2;
                        v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                    }
                    break block12;
lbl13:
                    // 1 sources

                    while (true) {
                        continue;
                        break;
                    }
                }
                var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var15_3 = var13_1.doFinal("\u00fa:#\u0092\u00ae\u00ff\u00c1g".getBytes("ISO-8859-1"));
                ** while (true)
                Class_bF_1e9a9e90.lnImF = Class_bF_1e9a9e90.Md(var15_3).intern();
                Class_bF_1e9a9e90.AUlej = new HashMap<K, V>(13);
                var0_4 = Cipher.getInstance("DES/CBC/NoPadding");
                v3 = SecretKeyFactory.getInstance("DES");
                v4 = new byte[8];
                v5 = v4;
                v4[0] = (byte)(var11 >>> 56);
                for (var1_5 = 1; var1_5 < 8; ++var1_5) {
                    v5 = v5;
                    v5[var1_5] = (byte)(var11 << var1_5 * 8 >>> 56);
                }
                var0_4.init(2, (Key)v3.generateSecret(new DESKeySpec(v5)), new IvParameterSpec(new byte[8]));
                var6_6 = new long[17];
                var3_7 = 0;
                var4_8 = "R.\u0094\bR\u00bfK\u00c8X\u0014\u00bdG\u00e1\u00a3L\u0086\u00bbW\u0001\u00de\u00d2u\u0092\u0098\u0099\u00cc\u00c1\u0081\u00efV\u00afM\u0081\u00fa\u00be\u00a9\u00e5\u0082.\u009f>\u001b\u00bd\u00db\u00f5\u00cf\u000f\u00dc\u00e8\u00b7\u00f14\u00144\u00a4\u0095L\u00caB\u0095\u0095\u001a?\u0097\u00cb4nS\u00fd7\u0007\u0007u\u0082\u00c2A\u009b\u00f3\u00fb\u00ab\u00fb\u00f2E\u0001\u009b-!\u00ea\u00c0\u00d8[\u00b8\u0019\u0015\u00ca\u00d6\u00e0\u00e0\u00c5\u001db\u00ec4\u008e\u00a2Y\u0096\u00d2\u0004_\u0084Rgy\u00a3{ \u00b6?\u00a1";
                var5_9 = "R.\u0094\bR\u00bfK\u00c8X\u0014\u00bdG\u00e1\u00a3L\u0086\u00bbW\u0001\u00de\u00d2u\u0092\u0098\u0099\u00cc\u00c1\u0081\u00efV\u00afM\u0081\u00fa\u00be\u00a9\u00e5\u0082.\u009f>\u001b\u00bd\u00db\u00f5\u00cf\u000f\u00dc\u00e8\u00b7\u00f14\u00144\u00a4\u0095L\u00caB\u0095\u0095\u001a?\u0097\u00cb4nS\u00fd7\u0007\u0007u\u0082\u00c2A\u009b\u00f3\u00fb\u00ab\u00fb\u00f2E\u0001\u009b-!\u00ea\u00c0\u00d8[\u00b8\u0019\u0015\u00ca\u00d6\u00e0\u00e0\u00c5\u001db\u00ec4\u008e\u00a2Y\u0096\u00d2\u0004_\u0084Rgy\u00a3{ \u00b6?\u00a1".length();
                var2_10 = 0;
                while (true) {
                    var7_11 = var4_8.substring(var2_10, var2_10 += 8).getBytes("ISO-8859-1");
                    v6 = var6_6;
                    v7 = var3_7++;
                    v8 = ((long)var7_11[0] & 255L) << 56 | ((long)var7_11[1] & 255L) << 48 | ((long)var7_11[2] & 255L) << 40 | ((long)var7_11[3] & 255L) << 32 | ((long)var7_11[4] & 255L) << 24 | ((long)var7_11[5] & 255L) << 16 | ((long)var7_11[6] & 255L) << 8 | (long)var7_11[7] & 255L;
                    v9 = -1;
                    break block10;
                    break;
                }
lbl44:
                // 1 sources

                while (true) {
                    v6[v7] = v10;
                    if (var2_10 < var5_9) ** continue;
                    var4_8 = "U\u0091\u0000\u00cb\u00dc\u00dd\u0001\u00ff\u00bb\u00e5\u007f\u0094l\u00ce\u0002\u00a0";
                    var5_9 = "U\u0091\u0000\u00cb\u00dc\u00dd\u0001\u00ff\u00bb\u00e5\u007f\u0094l\u00ce\u0002\u00a0".length();
                    var2_10 = 0;
                    while (true) {
                        var7_11 = var4_8.substring(var2_10, var2_10 += 8).getBytes("ISO-8859-1");
                        v6 = var6_6;
                        v7 = var3_7++;
                        v8 = ((long)var7_11[0] & 255L) << 56 | ((long)var7_11[1] & 255L) << 48 | ((long)var7_11[2] & 255L) << 40 | ((long)var7_11[3] & 255L) << 32 | ((long)var7_11[4] & 255L) << 24 | ((long)var7_11[5] & 255L) << 16 | ((long)var7_11[6] & 255L) << 8 | (long)var7_11[7] & 255L;
                        v9 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl57:
                // 1 sources

                while (true) {
                    v6[v7] = v10;
                    if (var2_10 < var5_9) ** continue;
                    break block11;
                    break;
                }
            }
            var8_12 = v8;
            var10_13 = var0_4.doFinal(new byte[]{(byte)(var8_12 >>> 56), (byte)(var8_12 >>> 48), (byte)(var8_12 >>> 40), (byte)(var8_12 >>> 32), (byte)(var8_12 >>> 24), (byte)(var8_12 >>> 16), (byte)(var8_12 >>> 8), (byte)var8_12});
            v10 = ((long)var10_13[0] & 255L) << 56 | ((long)var10_13[1] & 255L) << 48 | ((long)var10_13[2] & 255L) << 40 | ((long)var10_13[3] & 255L) << 32 | ((long)var10_13[4] & 255L) << 24 | ((long)var10_13[5] & 255L) << 16 | ((long)var10_13[6] & 255L) << 8 | (long)var10_13[7] & 255L;
            switch (v9) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl70:
                // 1 sources

                ** continue;
            }
        }
        Class_bF_1e9a9e90.nuUmx = var6_6;
        Class_bF_1e9a9e90.Gjkur = new Integer[17];
    }

    private static int Me(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x2646;
        if (Gjkur[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = nuUmx[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])AUlej.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    AUlej.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bF_1e9a9e90", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bF_1e9a9e90.Gjkur[n2] = n3;
        }
        return Gjkur[n2];
    }

    @Override
    public void LX(Class_lC_5322e8cf class_lC_5322e8cf) {
        super.LX(class_lC_5322e8cf);
        this.rMeCH.Mo(Class_jd_8956ed6c.bAl());
        this.uTLas.Mo(Class_jf_d1c4f950.bAM(ClientMain.dmf().daM()));
    }

    private static CallSite Mg(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bF_1e9a9e90" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int Mf(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bF_1e9a9e90.Me(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static String Md(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bF_1e9a9e90.class, "Mf", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

