/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_gC_1f010b94;

public class Class_gC_tc_ba0adb10
extends Class_gC_1f010b94 {
    private final String NTGis;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gC_tc_ba0adb10(String string) {
        this.NTGis = string;
    }

    public String dpf() {
        return this.NTGis;
    }
}

