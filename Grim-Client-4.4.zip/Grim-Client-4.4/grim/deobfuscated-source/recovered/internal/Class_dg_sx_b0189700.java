/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Items
 *  net.minecraft.util.math.Vec2f
 *  net.minecraft.util.math.Vec3d
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jH_c1172273;
import recovered.internal.Class_jI_616cf0dd;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;
import recovered.modules.AmbienceModule;

class Class_dg_sx_b0189700 {
    private final Vec3d BQXcJ;
    private final int SDjuQ;
    private final int EVltR;
    private final int rSDHs;
    private boolean sDPfY;
    private final Class_rk_bf8630d1 iAudN;
    private static final long PLZSI = Class_gb_9d201141.aYR(3324331490446598336L, -997322021819081517L, MethodHandles.lookup().lookupClass()).a(239710145818019L);
    private static final String NkcQX;
    private static final long[] UKhvu;
    private static final Integer[] hhkIM;
    private static final Map JoHyM;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_dg_sx_b0189700(Vec3d vec3d, int n, int n2) {
        long l = PLZSI ^ 0xFF21A0C2DA9L;
        this.sDPfY = false;
        this.iAudN = new Class_rk_bf8630d1((int)Class_dg_sx_b0189700.dou("z", (int)4745, (long)(0x63C6E40F8D23F68FL ^ l)));
        this.BQXcJ = vec3d;
        this.SDjuQ = n;
        this.EVltR = n2;
        this.rSDHs = ClientMain.dlmvG.player.age;
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = PLZSI ^ 0x35534BA8332L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        byte[] byArray3 = cipher.doFinal("\u00e37\u00a7\u00bbIi\u00b8\u00ca".getBytes("ISO-8859-1"));
        NkcQX = Class_dg_sx_b0189700.dor(byArray3).intern();
        JoHyM = new HashMap(13);
        Cipher cipher2 = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory2 = SecretKeyFactory.getInstance("DES");
        byte[] byArray4 = new byte[8];
        byte[] byArray5 = byArray4;
        byArray4[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray5 = byArray5;
            byArray5[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher2.init(2, (Key)secretKeyFactory2.generateSecret(new DESKeySpec(byArray5)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "\u00f5Kh\u00f6\u00f0<\u00cd\u00c9\u0098\u00fa\u00d9\u00c6~\u00d0qz";
        int n2 = "\u00f5Kh\u00f6\u00f0<\u00cd\u00c9\u0098\u00fa\u00d9\u00c6~\u00d0qz".length();
        int n3 = 0;
        do {
            byte[] byArray6 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray6[0] & 0xFFL) << 56 | ((long)byArray6[1] & 0xFFL) << 48 | ((long)byArray6[2] & 0xFFL) << 40 | ((long)byArray6[3] & 0xFFL) << 32 | ((long)byArray6[4] & 0xFFL) << 24 | ((long)byArray6[5] & 0xFFL) << 16 | ((long)byArray6[6] & 0xFFL) << 8 | (long)byArray6[7] & 0xFFL;
            byte[] byArray7 = cipher2.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray7[0] & 0xFFL) << 56 | ((long)byArray7[1] & 0xFFL) << 48 | ((long)byArray7[2] & 0xFFL) << 40 | ((long)byArray7[3] & 0xFFL) << 32 | ((long)byArray7[4] & 0xFFL) << 24 | ((long)byArray7[5] & 0xFFL) << 16 | ((long)byArray7[6] & 0xFFL) << 8 | (long)byArray7[7] & 0xFFL;
        } while (n3 < n2);
        UKhvu = lArray;
        hhkIM = new Integer[2];
    }

    private static int dot(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_dg_sx_b0189700.dos(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static int dos(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0xC4D;
        if (hhkIM[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = UKhvu[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])JoHyM.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    JoHyM.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_dg_sx_b0189700", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_dg_sx_b0189700.hhkIM[n2] = n3;
        }
        return hhkIM[n2];
    }

    private static MatchException doq(MatchException matchException) {
        return matchException;
    }

    private static CallSite dou(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_dg_sx_b0189700" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private int don() {
        int n = ClientMain.dlmvG.player.age - this.rSDHs;
        return Math.max(this.EVltR - n, 0);
    }

    private static String dor(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean dop() {
        float f;
        block5: {
            Class_iS_888f260e[] class_iS_888f260eArray;
            block4: {
                long l = PLZSI ^ 0x38B14EC885BL;
                class_iS_888f260eArray = AmbienceModule.afl();
                float f2 = this.iAudN.dhj() - 0.0f;
                f = f2 == 0.0f ? 0 : (f2 > 0.0f ? 1 : -1);
                if (class_iS_888f260eArray != null) break block4;
                if (f != false) break block5;
                f = (float)this.sDPfY;
            }
            if (class_iS_888f260eArray != null) return (boolean)f;
            if (f != false) {
                f = 1.0f;
                return (boolean)f;
            }
        }
        f = 0.0f;
        return (boolean)f;
    }

    public void doo(Class_lC_5322e8cf class_lC_5322e8cf, boolean bl) {
        block7: {
            float f;
            float f2;
            block5: {
                float f3;
                float f4;
                float f5;
                float f6;
                block6: {
                    long l = PLZSI ^ 0x5410FA96C662L;
                    Class_iS_888f260e[] class_iS_888f260eArray = AmbienceModule.afl();
                    boolean bl2 = this.sDPfY;
                    if (class_iS_888f260eArray == null) {
                        bl2 = !bl2;
                    }
                    this.iAudN.dhc(bl2);
                    this.iAudN.dhs(!this.sDPfY ? Class_rj_b691f4f7.XzDkv : Class_rj_b691f4f7.AYqck);
                    Vec2f vec2f = Class_jI_616cf0dd.bIw(this.BQXcJ);
                    if (vec2f == null) {
                        return;
                    }
                    Class_mG_52c8d386 class_mG_52c8d386 = ClientMain.dlM().bjb();
                    f6 = 25.0f;
                    f5 = vec2f.x - f6 / 2.0f;
                    f4 = vec2f.y;
                    f2 = f5 + Class_jf_d1c4f950.bAH(16.0f, f6);
                    f = f4 + Class_jf_d1c4f950.bAH(16.0f, f6);
                    f3 = this.iAudN.dhj();
                    Class_jH_c1172273.bId(class_lC_5322e8cf, f5 + f6 / 2.0f, f4 + f6 / 2.0f, 0.5f + 0.5f * f3);
                    if (class_iS_888f260eArray != null) break block5;
                    if (!bl) break block6;
                    float f7 = 35.0f;
                    Class_lq_87a74641 class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
                    int n = this.don();
                    double d = (double)(n * Class_dg_sx_b0189700.dou("z", (int)28533, (long)(0x6566FC0AFDA060B9L ^ l))) / 1000.0;
                    String string = String.format(NkcQX, d);
                    class_lC_5322e8cf.ccW(f5, f4, f6, f7, f3, 0.0f, Class_ld_bb1690e1.all(8.0f), 3.0f);
                    class_lC_5322e8cf.cdZ(Items.ENDER_PEARL, f2, f, 1.0f).bGv();
                    class_lC_5322e8cf.cez(class_lq_87a74641, string, f5 + Class_jf_d1c4f950.bAH(class_lq_87a74641.cao(string), f6), f + 18.0f, class_mG_52c8d386);
                    if (class_iS_888f260eArray == null) break block7;
                }
                class_lC_5322e8cf.ccW(f5, f4, f6, f6, f3, 0.0f, Class_ld_bb1690e1.all(f6 / 2.0f), 3.0f);
            }
            class_lC_5322e8cf.cdZ(Items.ENDER_PEARL, f2, f, 1.0f).bGv();
        }
        Class_jH_c1172273.bIf();
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_dg_sx_b0189700.class, "dot", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

