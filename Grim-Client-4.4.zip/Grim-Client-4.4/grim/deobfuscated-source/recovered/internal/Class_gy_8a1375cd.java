/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;
import recovered.internal.Class_mA_32d8a5f2;

public class Class_gy_8a1375cd
extends Class_hH_ae8f8f77 {
    private Class_mA_32d8a5f2 MtWid;
    private int JQvRt;
    private int rolKx;
    private double UkPKN;
    private double JqQni;
    private double AxWTh;
    private double ZwaoY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gy_8a1375cd(Class_mA_32d8a5f2 class_mA_32d8a5f2, int n, int n2, double d, double d2, double d3, double d4) {
        this.MtWid = class_mA_32d8a5f2;
        this.JQvRt = n;
        this.rolKx = n2;
        this.UkPKN = d;
        this.JqQni = d2;
        this.AxWTh = d3;
        this.ZwaoY = d4;
    }

    public double bbF() {
        return this.UkPKN;
    }

    public double bbH() {
        return this.AxWTh;
    }

    public Class_mA_32d8a5f2 bbC() {
        return this.MtWid;
    }

    public double bbI() {
        return this.ZwaoY;
    }

    public int bbE() {
        return this.rolKx;
    }

    public int bbD() {
        return this.JQvRt;
    }

    public double bbG() {
        return this.JqQni;
    }
}

