/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap
 *  net.minecraft.client.render.OutlineVertexConsumerProvider
 *  net.minecraft.client.render.RenderLayer
 *  net.minecraft.client.render.VertexConsumerProvider
 *  net.minecraft.client.render.VertexConsumerProvider$Immediate
 *  net.minecraft.client.render.command.OrderedRenderCommandQueueImpl
 *  net.minecraft.client.render.command.RenderDispatcher
 *  net.minecraft.client.util.BufferAllocator
 */
package recovered.internal;

import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.SequencedMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.render.OutlineVertexConsumerProvider;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.command.OrderedRenderCommandQueueImpl;
import net.minecraft.client.render.command.RenderDispatcher;
import net.minecraft.client.util.BufferAllocator;
import recovered.core.ClientMain;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jE_23f766de;

public final class Class_jC_6c1c779b {
    private final OrderedRenderCommandQueueImpl lADha;
    private final VertexConsumerProvider.Immediate mHZnS;
    private final OutlineVertexConsumerProvider pLFTe;
    private final VertexConsumerProvider.Immediate vhDNR;
    private final RenderDispatcher DidxG;
    private static int HavuN;
    private static final long eCiTv;
    private static final long[] rIGBZ;
    private static final Integer[] prVKV;
    private static final Map XyFfc;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public static int bHc() {
        int n = Class_jC_6c1c779b.bHb();
        if (n == 0) {
            return 74;
        }
        return 0;
    }

    public Class_jC_6c1c779b() {
        block0: {
            long l = eCiTv ^ 0x498D4D7D563CL;
            int n = Class_jC_6c1c779b.bHc();
            this.lADha = new OrderedRenderCommandQueueImpl();
            int n2 = n;
            this.mHZnS = Class_jC_6c1c779b.bGZ();
            this.pLFTe = new OutlineVertexConsumerProvider();
            this.vhDNR = VertexConsumerProvider.immediate((BufferAllocator)new BufferAllocator((int)Class_jC_6c1c779b.bHg("y", (int)32665, (long)(0x3E4AACA9D5558AL ^ l))));
            this.DidxG = new RenderDispatcher(this.lADha, ClientMain.dlmvG.getBlockRenderManager(), this.mHZnS, ClientMain.dlmvG.getAtlasManager(), this.pLFTe, this.vhDNR, ClientMain.dlmvG.textRenderer);
            if (n2 == 0) break block0;
            Class_iS_888f260e.bwK("NVTpf");
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        eCiTv = Class_gb_9d201141.aYR(-4632865524948931423L, 4039314851654012638L, MethodHandles.lookup().lookupClass()).a(170019180082689L);
        XyFfc = new HashMap(13);
        Class_jC_6c1c779b.bHa(59);
        long l = eCiTv ^ 0x1E75CAB00972L;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "N\u00dfk\u0084[\u00c4E\u00ac\u0010S\u0089\u00dd\u0011\u00f0\u00bb\u00c0";
        int n2 = "N\u00dfk\u0084[\u00c4E\u00ac\u0010S\u0089\u00dd\u0011\u00f0\u00bb\u00c0".length();
        int n3 = 0;
        do {
            byte[] byArray3 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l2 = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
            byte[] byArray4 = cipher.doFinal(new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2});
            lArray[n4] = ((long)byArray4[0] & 0xFFL) << 56 | ((long)byArray4[1] & 0xFFL) << 48 | ((long)byArray4[2] & 0xFFL) << 40 | ((long)byArray4[3] & 0xFFL) << 32 | ((long)byArray4[4] & 0xFFL) << 24 | ((long)byArray4[5] & 0xFFL) << 16 | ((long)byArray4[6] & 0xFFL) << 8 | (long)byArray4[7] & 0xFFL;
        } while (n3 < n2);
        rIGBZ = lArray;
        prVKV = new Integer[2];
    }

    public OrderedRenderCommandQueueImpl bGT() {
        return this.lADha;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void bGY() {
        block23: {
            int n = Class_jC_6c1c779b.bHb();
            try {
                try {
                    this.DidxG.render();
                }
                finally {
                    this.DidxG.endLayeredCustoms();
                }
            }
            finally {
                try {
                    this.mHZnS.draw();
                }
                finally {
                    try {
                        this.vhDNR.draw();
                    }
                    finally {
                        this.pLFTe.draw();
                    }
                }
            }
            if (Class_iS_888f260e.bwL() != null) break block23;
            Class_jC_6c1c779b.bHa(++n);
        }
    }

    public RenderDispatcher bGX() {
        return this.DidxG;
    }

    public VertexConsumerProvider.Immediate bGU() {
        return this.mHZnS;
    }

    private static CallSite bHg(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jC_6c1c779b" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static VertexConsumerProvider.Immediate bGZ() {
        long l = eCiTv ^ 0x41FAD44A6381L;
        Object2ObjectLinkedOpenHashMap object2ObjectLinkedOpenHashMap = new Object2ObjectLinkedOpenHashMap();
        Class_jE_23f766de.bHu((Object2ObjectLinkedOpenHashMap<RenderLayer, BufferAllocator>)object2ObjectLinkedOpenHashMap);
        return VertexConsumerProvider.immediate((SequencedMap)object2ObjectLinkedOpenHashMap, (BufferAllocator)new BufferAllocator((int)Class_jC_6c1c779b.bHg("y", (int)422, (long)(0x69037F8A5561E09L ^ l))));
    }

    private static int bHe(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x4CE3;
        if (prVKV[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = rIGBZ[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])XyFfc.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    XyFfc.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jC_6c1c779b", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_jC_6c1c779b.prVKV[n2] = n3;
        }
        return prVKV[n2];
    }

    public VertexConsumerProvider.Immediate bGW() {
        return this.vhDNR;
    }

    public static int bHb() {
        return HavuN;
    }

    public static void bHa(int n) {
        HavuN = n;
    }

    private static MatchException bHd(MatchException matchException) {
        return matchException;
    }

    public OutlineVertexConsumerProvider bGV() {
        return this.pLFTe;
    }

    private static int bHf(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_jC_6c1c779b.bHe(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jC_6c1c779b.class, "bHf", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

