/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

public interface Class_ga_05c8213e {
    public void b(long var1);

    public int[] b();

    public boolean b(Class_ga_05c8213e var1);

    public void a(Class_ga_05c8213e var1);

    public long a(long var1);
}

