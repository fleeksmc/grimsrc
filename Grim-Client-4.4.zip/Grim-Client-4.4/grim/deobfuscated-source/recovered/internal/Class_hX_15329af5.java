/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import recovered.core.NativeLoader;
import recovered.internal.Class_hZ_076851ce;

public final class Class_hX_15329af5
extends Record {
    private final Class_hZ_076851ce command;
    private final List<Object> arguments;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hX_15329af5(Class_hZ_076851ce class_hZ_076851ce, List<Object> list) {
        this.command = class_hZ_076851ce;
        this.arguments = list;
    }

    static {
        NativeLoader.doInit(Class_hX_15329af5.class);
    }

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    public native List<Object> arguments();

    public native Class_hZ_076851ce command();
}

