/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_aR_f155c393;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_lC_5322e8cf;

class Class_aR_rY_47ff8b41
extends Class_az_a4990dcf {
    final Class_aR_f155c393 huYrS;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    Class_aR_rY_47ff8b41(Class_aR_f155c393 class_aR_f155c393) {
        this.huYrS = class_aR_f155c393;
    }

    static {
        NativeLoader.doInit(Class_aR_rY_47ff8b41.class);
    }

    @Override
    public native boolean oi();

    @Override
    protected native void bV(Class_lC_5322e8cf var1);
}

