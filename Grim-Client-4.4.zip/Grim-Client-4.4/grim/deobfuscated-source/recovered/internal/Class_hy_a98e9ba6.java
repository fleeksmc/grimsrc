/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;
import recovered.internal.Class_mA_32d8a5f2;

public class Class_hy_a98e9ba6
extends Class_hH_ae8f8f77 {
    private final double QPbcF;
    private final double svIVi;
    private final Class_mA_32d8a5f2 CASgb;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hy_a98e9ba6(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        this.QPbcF = d;
        this.svIVi = d2;
        this.CASgb = class_mA_32d8a5f2;
    }

    public double bdq() {
        return this.QPbcF;
    }

    public Class_mA_32d8a5f2 bds() {
        return this.CASgb;
    }

    public double bdr() {
        return this.svIVi;
    }
}

