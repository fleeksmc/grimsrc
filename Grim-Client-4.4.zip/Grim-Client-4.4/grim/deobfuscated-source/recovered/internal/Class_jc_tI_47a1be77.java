/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

class Class_jc_tI_47a1be77 {
    static int[] Wxgue;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_jc_tI_47a1be77.class);
        Class_jc_tI_47a1be77._f1b27ce0ecd890eb5121903a245a0c07();
    }

    private static native void _f1b27ce0ecd890eb5121903a245a0c07();
}

