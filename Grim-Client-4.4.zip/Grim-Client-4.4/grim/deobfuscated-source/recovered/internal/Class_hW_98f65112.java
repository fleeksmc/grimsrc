/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hX_15329af5;

public interface Class_hW_98f65112 {
    public void execute(Class_hX_15329af5 var1);
}

