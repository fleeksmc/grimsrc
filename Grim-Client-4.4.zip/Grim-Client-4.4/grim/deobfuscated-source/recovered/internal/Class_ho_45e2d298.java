/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.LivingEntity
 */
package recovered.internal;

import net.minecraft.entity.LivingEntity;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_ho_45e2d298
extends Class_hH_ae8f8f77 {
    LivingEntity jvnTs;
    byte rKsOL;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_ho_45e2d298(LivingEntity livingEntity, byte by) {
        this.jvnTs = livingEntity;
        this.rKsOL = by;
    }

    public LivingEntity bcV() {
        return this.jvnTs;
    }

    public byte bcW() {
        return this.rKsOL;
    }
}

