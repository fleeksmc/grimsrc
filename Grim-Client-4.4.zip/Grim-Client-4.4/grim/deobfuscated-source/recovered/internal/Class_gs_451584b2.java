/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockState
 */
package recovered.internal;

import net.minecraft.block.BlockState;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_gs_451584b2
extends Class_hH_ae8f8f77 {
    private BlockState qDXnp;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gs_451584b2(BlockState blockState) {
        this.qDXnp = blockState;
    }

    public BlockState bbs() {
        return this.qDXnp;
    }
}

