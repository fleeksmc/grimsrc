/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import recovered.internal.Class_in_57efefb0;
import recovered.internal.Class_ir_8e0d90e0;
import recovered.internal.Class_iu_bf2db566;

public interface Class_il_0e543c73 {
    public CompletableFuture<Class_ir_8e0d90e0> fetchPreset(String var1);

    public CompletableFuture<Class_iu_bf2db566> importPreset(String var1);

    public CompletableFuture<Class_iu_bf2db566> deletePreset(String var1);

    public CompletableFuture<List<Class_ir_8e0d90e0>> fetchPresets();

    public CompletableFuture<Class_ir_8e0d90e0> createPreset(Class_in_57efefb0 var1);

    public CompletableFuture<Class_iu_bf2db566> loadPreset(Class_in_57efefb0 var1);
}

