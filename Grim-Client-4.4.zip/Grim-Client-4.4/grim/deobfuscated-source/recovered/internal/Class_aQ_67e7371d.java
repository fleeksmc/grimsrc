/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;
import recovered.core.NativeLoader;
import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_lf_d247d983;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_pF_d0757029;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_aQ_67e7371d
extends Class_az_a4990dcf {
    private static float hreJU = 16.0f;
    private static float eHeVG = 10.0f;
    private static float RdBvg = 6.0f;
    private static float XLRfk = 3.0f;
    private static float OSudz = 4.0f;
    private final Class_rk_bf8630d1 dBTyX;
    private final Class_rk_bf8630d1 ydHvt;
    private final Class_rk_bf8630d1 GRHtk;
    private final Class_rk_bf8630d1 uEFtu;
    private final Supplier<Class_pF_d0757029> EisLc;
    private final Consumer<Class_pF_d0757029> GVlEe;
    private final Class_lc_b8480f87 lGyOR;
    private final Class_lc_b8480f87 GDfoc;
    private static long vagoX;
    private static long[] CTEUW;
    private static Integer[] XGqWO;
    private static Map oONiw;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_aQ_67e7371d(Supplier<Class_pF_d0757029> supplier, Consumer<Class_pF_d0757029> consumer) {
        long l = vagoX ^ 0x13BF4B45FE11L;
        this.dBTyX = new Class_rk_bf8630d1((int)Class_aQ_67e7371d.xU("g", (int)15972, (long)(0x28561C84DB91A55DL ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.ydHvt = new Class_rk_bf8630d1((int)Class_aQ_67e7371d.xU("g", (int)13342, (long)(0x61DA88A642EDAF26L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.GRHtk = new Class_rk_bf8630d1((int)Class_aQ_67e7371d.xU("g", (int)13342, (long)(0x61DA88A642EDAF26L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.uEFtu = new Class_rk_bf8630d1((int)Class_aQ_67e7371d.xU("g", (int)13342, (long)(0x61DA88A642EDAF26L ^ l))).dhs(Class_rj_b691f4f7.UPXqT);
        this.lGyOR = new Class_lc_b8480f87(0.0f, 0.0f, 0.0f, 0.0f);
        this.GDfoc = new Class_lc_b8480f87(0.0f, 0.0f, 0.0f, 0.0f);
        this.EisLc = supplier;
        this.GVlEe = consumer;
    }

    static {
        NativeLoader.doInit(Class_aQ_67e7371d.class);
        Class_aQ_67e7371d._1c050f99bf3b127a20c32d9ec8cc6a4b();
    }

    @Override
    public native float dn();

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    private static native void _1c050f99bf3b127a20c32d9ec8cc6a4b();

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    public native float xO();

    private static native MatchException xR(MatchException var0);

    private static native int xT(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native float xQ(Class_lq_87a74641 var1, String var2, float var3);

    private static native int xS(int var0, long var1);

    private native void xP(Class_lC_5322e8cf var1, Class_lq_87a74641 var2, Class_lc_b8480f87 var3, Class_pF_d0757029 var4, Class_lf_d247d983 var5, float var6, float var7);

    private static native CallSite xU(MethodHandles.Lookup var0, String var1, MethodType var2);
}

