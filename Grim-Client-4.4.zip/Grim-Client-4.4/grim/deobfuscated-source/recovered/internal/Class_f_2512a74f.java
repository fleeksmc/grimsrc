/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_az_a4990dcf;
import recovered.internal.Class_f_rF_b8400651;
import recovered.internal.Class_i_a489cc15;
import recovered.internal.Class_mA_32d8a5f2;

public class Class_f_2512a74f {
    private final Class_f_rF_b8400651 nvHyY;
    private final double VvjnH;
    private final double uYeHZ;
    private final Class_mA_32d8a5f2 UWrlR;
    private final double XGKLz;
    private final double kDhGL;
    private final double ZcRJh;
    private Class_i_a489cc15 zyNVF;
    private Class_az_a4990dcf oXhOi;
    private Class_az_a4990dcf CzPkV;
    private boolean HgiKa;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_f_rF_b8400651 ap() {
        return this.nvHyY;
    }

    private Class_f_2512a74f(Class_f_rF_b8400651 class_f_rF_b8400651, double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2, double d3, double d4, double d5) {
        this.nvHyY = class_f_rF_b8400651;
        this.VvjnH = d;
        this.uYeHZ = d2;
        this.UWrlR = class_mA_32d8a5f2;
        this.XGKLz = d3;
        this.kDhGL = d4;
        this.ZcRJh = d5;
    }

    public void ao() {
        this.HgiKa = true;
    }

    public double at() {
        return this.XGKLz;
    }

    public static Class_f_2512a74f ak(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        return new Class_f_2512a74f(Class_f_rF_b8400651.aMhng, d, d2, class_mA_32d8a5f2, 0.0, 0.0, 0.0);
    }

    public double av() {
        return this.ZcRJh;
    }

    public Class_mA_32d8a5f2 as() {
        return this.UWrlR;
    }

    public boolean az() {
        return this.HgiKa;
    }

    public Class_az_a4990dcf ax() {
        return this.oXhOi;
    }

    public Class_az_a4990dcf ay() {
        return this.CzPkV;
    }

    public Class_i_a489cc15 aw() {
        return this.zyNVF;
    }

    public static Class_f_2512a74f am(double d, double d2, double d3) {
        return new Class_f_2512a74f(Class_f_rF_b8400651.dHaRm, d, d2, null, 0.0, 0.0, d3);
    }

    public static Class_f_2512a74f al(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2, double d3, double d4) {
        return new Class_f_2512a74f(Class_f_rF_b8400651.TvRJf, d, d2, class_mA_32d8a5f2, d3, d4, 0.0);
    }

    public static Class_f_2512a74f an(double d, double d2) {
        return new Class_f_2512a74f(Class_f_rF_b8400651.CjcqV, d, d2, null, 0.0, 0.0, 0.0);
    }

    public Class_f_2512a74f aC(Class_az_a4990dcf class_az_a4990dcf) {
        this.CzPkV = class_az_a4990dcf;
        return this;
    }

    public Class_f_2512a74f aB(Class_az_a4990dcf class_az_a4990dcf) {
        this.oXhOi = class_az_a4990dcf;
        return this;
    }

    public double aq() {
        return this.VvjnH;
    }

    public double au() {
        return this.kDhGL;
    }

    public double ar() {
        return this.uYeHZ;
    }

    public Class_f_2512a74f aA(Class_i_a489cc15 class_i_a489cc15) {
        this.zyNVF = class_i_a489cc15;
        return this;
    }

    public static Class_f_2512a74f aj(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        return new Class_f_2512a74f(Class_f_rF_b8400651.feLzE, d, d2, class_mA_32d8a5f2, 0.0, 0.0, 0.0);
    }
}

