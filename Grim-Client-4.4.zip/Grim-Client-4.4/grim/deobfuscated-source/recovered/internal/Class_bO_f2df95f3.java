/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.MathHelper
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.util.math.MathHelper;
import recovered.core.ClientMain;
import recovered.internal.Class_bR_961dd2c9;
import recovered.internal.Class_cv_f4b0140a;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mr_7eac5189;
import recovered.modules.FakeLagModule;

public class Class_bO_f2df95f3
extends Class_bR_961dd2c9 {
    private static final long LgPVz;
    private static final String BgLMg;
    private static final long[] KfhLo;
    private static final Integer[] LpqIJ;
    private static final Map ApbQa;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bO_f2df95f3(Class_cv_f4b0140a class_cv_f4b0140a) {
        long l = LgPVz ^ 0x2EF784207599L;
        int[] nArray = new int[Class_bO_f2df95f3.NA("a", (int)7431, (long)(0x4C9A806AF024DD99L ^ l))];
        nArray[0] = (int)Class_bO_f2df95f3.NA("a", (int)16490, (long)(0x114F6729137700E6L ^ l));
        nArray[1] = (int)Class_bO_f2df95f3.NA("a", (int)9978, (long)(0x2112F1AB875667EL ^ l));
        nArray[2] = (int)Class_bO_f2df95f3.NA("a", (int)17997, (long)(0x7BF0E26A242D86C6L ^ l));
        nArray[3] = (int)Class_bO_f2df95f3.NA("a", (int)32347, (long)(0x5084EFB96BC3ECBL ^ l));
        nArray[4] = (int)Class_bO_f2df95f3.NA("a", (int)29767, (long)(0x56EB3BA0D9D8B4C4L ^ l));
        nArray[5] = (int)Class_bO_f2df95f3.NA("a", (int)26334, (long)(0x7C71DFC3570BA65BL ^ l));
        nArray[Class_bO_f2df95f3.NA("a", (int)20898, (long)(0x7ADDA14962ED912FL ^ l))] = (int)Class_bO_f2df95f3.NA("a", (int)9978, (long)(0x2112F1AB875667EL ^ l));
        nArray[Class_bO_f2df95f3.NA("a", (int)15207, (long)(0x4CE70B2DD1247BEFL ^ l))] = (int)Class_bO_f2df95f3.NA("a", (int)21977, (long)(0x549991AAE2399557L ^ l));
        nArray[Class_bO_f2df95f3.NA("a", (int)32664, (long)(0x6036C07AD3E0BF1FL ^ l))] = (int)Class_bO_f2df95f3.NA("a", (int)29767, (long)(0x56EB3BA0D9D8B4C4L ^ l));
        nArray[Class_bO_f2df95f3.NA("a", (int)11596, (long)(0x58F75F9331EDC6L ^ l))] = (int)Class_bO_f2df95f3.NA("a", (int)29152, (long)(0x2E84BDACB4433171L ^ l));
        nArray[Class_bO_f2df95f3.NA("a", (int)6956, (long)(0x1A90BFD3B0A45BB6L ^ l))] = (int)Class_bO_f2df95f3.NA("a", (int)3438, (long)(0x3315DA5D935CCDE1L ^ l));
        nArray[Class_bO_f2df95f3.NA("a", (int)7261, (long)(0x1317387AC821DCC0L ^ l))] = (int)Class_bO_f2df95f3.NA("a", (int)9978, (long)(0x2112F1AB875667EL ^ l));
        nArray[Class_bO_f2df95f3.NA("a", (int)15460, (long)(0x96CA2FDD6E87CFFL ^ l))] = (int)Class_bO_f2df95f3.NA("a", (int)18029, (long)(0x162108D29D9886EBL ^ l));
        nArray[Class_bO_f2df95f3.NA("a", (int)19800, (long)(0x289A6826261C0DCDL ^ l))] = (int)Class_bO_f2df95f3.NA("a", (int)24001, (long)(0x6F6565EFE2391D5EL ^ l));
        nArray[Class_bO_f2df95f3.NA("a", (int)11414, (long)(0x1A30ACE8E3CB6C02L ^ l))] = (int)Class_bO_f2df95f3.NA("a", (int)7465, (long)(0x38AF1DC7B8A0DDB5L ^ l));
        super(class_cv_f4b0140a, Class_mr_7eac5189.clS(nArray));
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                block12: {
                    Class_bO_f2df95f3.LgPVz = Class_gb_9d201141.aYR(7691661973948649615L, -4839454869264544168L, MethodHandles.lookup().lookupClass()).a(256711264222585L);
                    var11 = Class_bO_f2df95f3.LgPVz ^ 70820342341631L;
                    var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                    v0 = SecretKeyFactory.getInstance("DES");
                    v1 = new byte[8];
                    v2 = v1;
                    v1[0] = (byte)(var11 >>> 56);
                    for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                        v2 = v2;
                        v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                    }
                    break block12;
lbl13:
                    // 1 sources

                    while (true) {
                        continue;
                        break;
                    }
                }
                var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var15_3 = var13_1.doFinal("a\u001bt\u00cdo\u0002G\u0015".getBytes("ISO-8859-1"));
                ** while (true)
                Class_bO_f2df95f3.BgLMg = Class_bO_f2df95f3.Nx(var15_3).intern();
                Class_bO_f2df95f3.ApbQa = new HashMap<K, V>(13);
                var0_4 = Cipher.getInstance("DES/CBC/NoPadding");
                v3 = SecretKeyFactory.getInstance("DES");
                v4 = new byte[8];
                v5 = v4;
                v4[0] = (byte)(var11 >>> 56);
                for (var1_5 = 1; var1_5 < 8; ++var1_5) {
                    v5 = v5;
                    v5[var1_5] = (byte)(var11 << var1_5 * 8 >>> 56);
                }
                var0_4.init(2, (Key)v3.generateSecret(new DESKeySpec(v5)), new IvParameterSpec(new byte[8]));
                var6_6 = new long[32];
                var3_7 = 0;
                var4_8 = "\u007f\u00da\u00e9\u00a0\u00edUo9\u0002\u00aa\u000b\u0080A\u00a0\u00f4|(\u00d170\u00e2\u00a5(\u00a4\u001ci2;\u0004v\u00bd\u00dcf\u00f9\u000f\u001f+\u0003g\u000b[\u00be\u00d0\u00d9\u00f6F\b\u00af\u00dc\u00bf8\u0004\u0098\u001b<K\u00b2l!>KQ\u0019\u00a5\u00a1\u00d8?K\u00e2\u0097n\u0018-\u00b8L1\u00d9\u0099i\u0088\u0089\u00f6\u0089x\u00b6njD\u008b\u000b\u0088_\u00ff_I\u00e1\u00b6\u00d8\u0016\u0001\u00fe\u0010]ikj\u00e6\u00ba\u0096\u009aD{=6\u0016\u00b2\u00d4\u00b9\u00f1\u00f9;\u0098\u00de^\u00cb\u00fb\u000bTq\u00bbH\u00c9\u00e0\u00e0\u00c7W\u00e3\u0082\u00e8B\u008e HD\u008c\u00ba\u00c0\u00b4O\u001c\u0017\u00c7J\u0086S\u00a7GK3\u00ca\u0085\u00c9\u00d4\u0084\u007fSd~`1\u00cb(F\u00c3\u00cb&RN.\u0004\u00b1\u0098|\u0094\u0095\u0095\u00946\u00a1\u00d1n\u00bb\u001c\ru0\u00dd\u0010>\u00b2\u008d\u00deKd\u0096\u00d6\u0092#\u00beN(\u008dc\u00eb\u0014\u00b3g\u00d7\u00d14XL\u00d4s\u0019\u0082\u00c1Y\u008a\u001bv\u009b\u0015\u00bc7\u0005>}b\u00fb";
                var5_9 = "\u007f\u00da\u00e9\u00a0\u00edUo9\u0002\u00aa\u000b\u0080A\u00a0\u00f4|(\u00d170\u00e2\u00a5(\u00a4\u001ci2;\u0004v\u00bd\u00dcf\u00f9\u000f\u001f+\u0003g\u000b[\u00be\u00d0\u00d9\u00f6F\b\u00af\u00dc\u00bf8\u0004\u0098\u001b<K\u00b2l!>KQ\u0019\u00a5\u00a1\u00d8?K\u00e2\u0097n\u0018-\u00b8L1\u00d9\u0099i\u0088\u0089\u00f6\u0089x\u00b6njD\u008b\u000b\u0088_\u00ff_I\u00e1\u00b6\u00d8\u0016\u0001\u00fe\u0010]ikj\u00e6\u00ba\u0096\u009aD{=6\u0016\u00b2\u00d4\u00b9\u00f1\u00f9;\u0098\u00de^\u00cb\u00fb\u000bTq\u00bbH\u00c9\u00e0\u00e0\u00c7W\u00e3\u0082\u00e8B\u008e HD\u008c\u00ba\u00c0\u00b4O\u001c\u0017\u00c7J\u0086S\u00a7GK3\u00ca\u0085\u00c9\u00d4\u0084\u007fSd~`1\u00cb(F\u00c3\u00cb&RN.\u0004\u00b1\u0098|\u0094\u0095\u0095\u00946\u00a1\u00d1n\u00bb\u001c\ru0\u00dd\u0010>\u00b2\u008d\u00deKd\u0096\u00d6\u0092#\u00beN(\u008dc\u00eb\u0014\u00b3g\u00d7\u00d14XL\u00d4s\u0019\u0082\u00c1Y\u008a\u001bv\u009b\u0015\u00bc7\u0005>}b\u00fb".length();
                var2_10 = 0;
                while (true) {
                    var7_11 = var4_8.substring(var2_10, var2_10 += 8).getBytes("ISO-8859-1");
                    v6 = var6_6;
                    v7 = var3_7++;
                    v8 = ((long)var7_11[0] & 255L) << 56 | ((long)var7_11[1] & 255L) << 48 | ((long)var7_11[2] & 255L) << 40 | ((long)var7_11[3] & 255L) << 32 | ((long)var7_11[4] & 255L) << 24 | ((long)var7_11[5] & 255L) << 16 | ((long)var7_11[6] & 255L) << 8 | (long)var7_11[7] & 255L;
                    v9 = -1;
                    break block10;
                    break;
                }
lbl44:
                // 1 sources

                while (true) {
                    v6[v7] = v10;
                    if (var2_10 < var5_9) ** continue;
                    var4_8 = "\u00f5\n+rm\u0011\u00d4\u00c3\u00de:C\u00a3\u00ce\u00a7\u00e0^";
                    var5_9 = "\u00f5\n+rm\u0011\u00d4\u00c3\u00de:C\u00a3\u00ce\u00a7\u00e0^".length();
                    var2_10 = 0;
                    while (true) {
                        var7_11 = var4_8.substring(var2_10, var2_10 += 8).getBytes("ISO-8859-1");
                        v6 = var6_6;
                        v7 = var3_7++;
                        v8 = ((long)var7_11[0] & 255L) << 56 | ((long)var7_11[1] & 255L) << 48 | ((long)var7_11[2] & 255L) << 40 | ((long)var7_11[3] & 255L) << 32 | ((long)var7_11[4] & 255L) << 24 | ((long)var7_11[5] & 255L) << 16 | ((long)var7_11[6] & 255L) << 8 | (long)var7_11[7] & 255L;
                        v9 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl57:
                // 1 sources

                while (true) {
                    v6[v7] = v10;
                    if (var2_10 < var5_9) ** continue;
                    break block11;
                    break;
                }
            }
            var8_12 = v8;
            var10_13 = var0_4.doFinal(new byte[]{(byte)(var8_12 >>> 56), (byte)(var8_12 >>> 48), (byte)(var8_12 >>> 40), (byte)(var8_12 >>> 32), (byte)(var8_12 >>> 24), (byte)(var8_12 >>> 16), (byte)(var8_12 >>> 8), (byte)var8_12});
            v10 = ((long)var10_13[0] & 255L) << 56 | ((long)var10_13[1] & 255L) << 48 | ((long)var10_13[2] & 255L) << 40 | ((long)var10_13[3] & 255L) << 32 | ((long)var10_13[4] & 255L) << 24 | ((long)var10_13[5] & 255L) << 16 | ((long)var10_13[6] & 255L) << 8 | (long)var10_13[7] & 255L;
            switch (v9) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl70:
                // 1 sources

                ** continue;
            }
        }
        Class_bO_f2df95f3.KfhLo = var6_6;
        Class_bO_f2df95f3.LpqIJ = new Integer[32];
    }

    @Override
    public boolean MH() {
        FakeLagModule fakeLagModule = ClientMain.dlJ().aZx(FakeLagModule.class);
        return fakeLagModule.bag();
    }

    private static CallSite NA(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bO_f2df95f3" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    @Override
    public void MG(Class_lC_5322e8cf class_lC_5322e8cf, Class_ii_9b427eda class_ii_9b427eda) {
        long l = LgPVz ^ 0x18CCBDB96F00L;
        FakeLagModule fakeLagModule = ClientMain.dlJ().aZx(FakeLagModule.class);
        long l2 = fakeLagModule.aIE().cpF();
        int n = (int)MathHelper.clamp((long)((long)fakeLagModule.aIH() - l2), (long)0L, (long)fakeLagModule.aIH());
        int n2 = Class_jf_d1c4f950.bBb(Math.max(fakeLagModule.aIH(), Class_jf_d1c4f950.bBb(fakeLagModule.aIw().UU())));
        int[] nArray = new int[Class_bO_f2df95f3.NA("a", (int)28552, (long)(0x61DE824C86653582L ^ l))];
        nArray[0] = (int)Class_bO_f2df95f3.NA("a", (int)8372, (long)(0x24E6034587CD7AAFL ^ l));
        nArray[1] = (int)Class_bO_f2df95f3.NA("a", (int)26837, (long)(0x70764B08B9E1B2DEL ^ l));
        nArray[2] = (int)Class_bO_f2df95f3.NA("a", (int)4347, (long)(0x14F467F696CAE3L ^ l));
        nArray[3] = (int)Class_bO_f2df95f3.NA("a", (int)21703, (long)(0x3F8CBA92E89B0EC7L ^ l));
        nArray[4] = (int)Class_bO_f2df95f3.NA("a", (int)32552, (long)(0x29008BFDE2392527L ^ l));
        nArray[5] = (int)Class_bO_f2df95f3.NA("a", (int)13069, (long)(0x6244383C2925E90CL ^ l));
        nArray[Class_bO_f2df95f3.NA("a", (int)23016, (long)(0x314DB7F63B7C03E6L ^ l))] = (int)Class_bO_f2df95f3.NA("a", (int)9978, (long)(0x211192181EC7CE7L ^ l));
        nArray[Class_bO_f2df95f3.NA("a", (int)26906, (long)(0x399ECD74186B30AL ^ l))] = (int)Class_bO_f2df95f3.NA("a", (int)26609, (long)(0x3A4071438E283DE8L ^ l));
        this.NJ(BgLMg, n, nArray, Class_mG_52c8d386.cnP(185.0f, 28.0f, 28.0f), false, n2);
        super.MG(class_lC_5322e8cf, class_ii_9b427eda);
    }

    private static String Nx(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static int Nz(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bO_f2df95f3.Ny(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static int Ny(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x78D3;
        if (LpqIJ[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = KfhLo[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])ApbQa.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    ApbQa.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bO_f2df95f3", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bO_f2df95f3.LpqIJ[n2] = n3;
        }
        return LpqIJ[n2];
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bO_f2df95f3.class, "Nz", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

