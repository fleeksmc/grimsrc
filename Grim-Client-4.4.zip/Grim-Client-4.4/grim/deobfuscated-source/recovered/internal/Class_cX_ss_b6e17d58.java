/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;

public final class Class_cX_ss_b6e17d58
extends Enum<Class_cX_ss_b6e17d58> {
    public static final /* enum */ Class_cX_ss_b6e17d58 uksqJ;
    public static final /* enum */ Class_cX_ss_b6e17d58 RymlV;
    public static final /* enum */ Class_cX_ss_b6e17d58 vNDXP;
    private static final Class_cX_ss_b6e17d58[] usYdY;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = Class_gb_9d201141.aYR(5597449029412440980L, -2635443635666165560L, MethodHandles.lookup().lookupClass()).a(143267300656769L) ^ 0x3A7B50E5F85BL;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[3];
        int n = 0;
        String string = "\u00a1\u00ab\u00bd\u00e3\u0099\u00d5\u00db:\bR\u00ecw\u0001\u00daPM\u00bd\bBoap\u0002v\u00eb\u009d";
        int n2 = "\u00a1\u00ab\u00bd\u00e3\u0099\u00d5\u00db:\bR\u00ecw\u0001\u00daPM\u00bd\bBoap\u0002v\u00eb\u009d".length();
        int n3 = 8;
        int n4 = -1;
        while (true) {
            int n5 = ++n4;
            byte[] byArray3 = cipher.doFinal(string.substring(n5, n5 + n3).getBytes("ISO-8859-1"));
            stringArray[n++] = Class_cX_ss_b6e17d58.dnT(byArray3).intern();
            if ((n4 += n3) >= n2) {
                uksqJ = new Class_cX_ss_b6e17d58();
                RymlV = new Class_cX_ss_b6e17d58();
                vNDXP = new Class_cX_ss_b6e17d58();
                usYdY = Class_cX_ss_b6e17d58.dnS();
                return;
            }
            n3 = string.charAt(n4);
        }
    }

    public static Class_cX_ss_b6e17d58[] values() {
        return (Class_cX_ss_b6e17d58[])usYdY.clone();
    }

    public static Class_cX_ss_b6e17d58 valueOf(String string) {
        return Enum.valueOf(Class_cX_ss_b6e17d58.class, string);
    }

    private static Class_cX_ss_b6e17d58[] dnS() {
        return new Class_cX_ss_b6e17d58[]{uksqJ, RymlV, vNDXP};
    }

    private static String dnT(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }
}

