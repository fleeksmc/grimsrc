/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.util.List;
import recovered.core.NativeLoader;
import recovered.internal.Class_hM_a36d442e;
import recovered.internal.Class_hW_98f65112;
import recovered.internal.Class_hZ_076851ce;

final class Class_hY_tE_a70bd0b8
extends Record
implements Class_hZ_076851ce {
    private final List<String> names;
    private final String description;
    private final List<Class_hM_a36d442e<?>> parameters;
    private final List<Class_hZ_076851ce> subcommands;
    private final boolean executable;
    private final Class_hW_98f65112 handler;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    @Override
    public native boolean executable();

    private Class_hY_tE_a70bd0b8(List<String> list, String string, List<Class_hM_a36d442e<?>> list2, List<Class_hZ_076851ce> list3, boolean bl, Class_hW_98f65112 class_hW_98f65112) {
        this.names = list;
        this.description = string;
        this.parameters = list2;
        this.subcommands = list3;
        this.executable = bl;
        this.handler = class_hW_98f65112;
    }

    static {
        NativeLoader.doInit(Class_hY_tE_a70bd0b8.class);
    }

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    @Override
    public native Class_hW_98f65112 handler();

    @Override
    public native List<Class_hM_a36d442e<?>> parameters();

    @Override
    public native List<String> names();

    @Override
    public native String description();

    @Override
    public native List<Class_hZ_076851ce> subcommands();
}

