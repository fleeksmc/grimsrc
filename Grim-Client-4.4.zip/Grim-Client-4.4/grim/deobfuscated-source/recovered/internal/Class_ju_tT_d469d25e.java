/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;

final class Class_ju_tT_d469d25e
extends Enum<Class_ju_tT_d469d25e> {
    public static final /* enum */ Class_ju_tT_d469d25e yDoOO;
    public static final /* enum */ Class_ju_tT_d469d25e IHKNQ;
    private static final Class_ju_tT_d469d25e[] COXpQ;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = Class_gb_9d201141.aYR(6285034763905464312L, 3006126702871903171L, MethodHandles.lookup().lookupClass()).a(26321797801578L) ^ 0x527A25180A74L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[2];
        int n = 0;
        String string = "\u00aa\u00adp(I\u00d65\u000e\b\u00e6g\u00ae\u00da\u00cc\u00afg\u0012";
        int n2 = "\u00aa\u00adp(I\u00d65\u000e\b\u00e6g\u00ae\u00da\u00cc\u00afg\u0012".length();
        int n3 = 8;
        int n4 = -1;
        while (true) {
            int n5 = ++n4;
            byte[] byArray3 = cipher.doFinal(string.substring(n5, n5 + n3).getBytes("ISO-8859-1"));
            stringArray[n++] = Class_ju_tT_d469d25e.dpX(byArray3).intern();
            if ((n4 += n3) >= n2) {
                yDoOO = new Class_ju_tT_d469d25e();
                IHKNQ = new Class_ju_tT_d469d25e();
                COXpQ = Class_ju_tT_d469d25e.dpW();
                return;
            }
            n3 = string.charAt(n4);
        }
    }

    public static Class_ju_tT_d469d25e[] values() {
        return (Class_ju_tT_d469d25e[])COXpQ.clone();
    }

    public static Class_ju_tT_d469d25e valueOf(String string) {
        return Enum.valueOf(Class_ju_tT_d469d25e.class, string);
    }

    private static String dpX(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static Class_ju_tT_d469d25e[] dpW() {
        return new Class_ju_tT_d469d25e[]{yDoOO, IHKNQ};
    }
}

