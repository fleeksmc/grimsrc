/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.damage.DamageSource
 */
package recovered.internal;

import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_hv_812667d6
extends Class_hH_ae8f8f77 {
    private final Entity gVQJL;
    private final DamageSource OCbXf;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hv_812667d6(Entity entity, DamageSource damageSource) {
        this.gVQJL = entity;
        this.OCbXf = damageSource;
    }

    public DamageSource bdl() {
        return this.OCbXf;
    }

    public Entity bdk() {
        return this.gVQJL;
    }
}

