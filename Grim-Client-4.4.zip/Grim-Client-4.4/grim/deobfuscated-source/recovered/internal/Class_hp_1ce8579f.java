/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.Entity$RemovalReason
 */
package recovered.internal;

import net.minecraft.entity.Entity;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_hp_1ce8579f
extends Class_hH_ae8f8f77 {
    private Entity tKLCE;
    private Entity.RemovalReason NKJiw;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hp_1ce8579f(Entity entity, Entity.RemovalReason removalReason) {
        this.tKLCE = entity;
        this.NKJiw = removalReason;
    }

    public Entity bcX() {
        return this.tKLCE;
    }

    public Entity.RemovalReason bcY() {
        return this.NKJiw;
    }
}

