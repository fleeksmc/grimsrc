/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.texture.AbstractTexture
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import net.minecraft.client.texture.AbstractTexture;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jO_1924117a;
import recovered.internal.Class_jO_tZ_935a142d;
import recovered.internal.Class_jP_e494f9c7;
import recovered.internal.Class_kd_dfbdd90e;
import recovered.internal.Class_kf_f68d320f;
import recovered.internal.Class_kg_ue_8ab30edd;
import recovered.internal.Class_lA_428877cb;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lF_27593463;
import recovered.internal.Class_lJ_e4c3455b;
import recovered.internal.Class_lN_5af116ef;
import recovered.internal.Class_la_8f67ae40;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_mG_52c8d386;

public class Class_kg_0dd28bdb
implements Class_lA_428877cb,
Class_lJ_e4c3455b<Class_kg_0dd28bdb> {
    private final Class_lC_5322e8cf DefNT;
    private final Class_kd_dfbdd90e LxPkh;
    private final float KFtMh;
    private final float UGftP;
    private final float lKsUl;
    private final float eHPWe;
    private Class_kf_f68d320f slzIe;
    private Class_ld_bb1690e1 aHnxw;
    private Class_mG_52c8d386 xIknw;
    private Class_la_8f67ae40 aNPKC;
    private AbstractTexture gEcsA;
    private float DeOtF;
    private float KfgfI;
    private float txGdU;
    private float tfPBr;
    private float KeWGi;
    private float jzZGr;
    private float nMccj;
    private float XPiOH;
    private boolean zCNEN;
    private boolean AWfNt;
    private float QpnEL;
    private float ddWOd;
    private float JxAXL;
    private float vjsav;
    private float MRKmz;
    private float pRDcN;
    private float JVdZg;
    private float LkPhO;
    private float JOxbl;
    private float grPFu;
    private float Myblt;
    private float icfCV;
    private float NKhaE;
    private float tkEVM;
    private float koBfv;
    private Class_mG_52c8d386 bUTfh;
    private Class_mG_52c8d386 OcxDq;
    private Class_kg_ue_8ab30edd Zheqi;
    private static final long yDeom = Class_gb_9d201141.aYR(-9079208359225598629L, -850822177590378140L, MethodHandles.lookup().lookupClass()).a(14424794711991L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_kg_0dd28bdb(Class_lC_5322e8cf class_lC_5322e8cf, Class_kd_dfbdd90e class_kd_dfbdd90e, float f, float f2, float f3, float f4) {
        block1: {
            long l = yDeom ^ 0x58565D97875DL;
            Class_iS_888f260e[] class_iS_888f260eArray = Class_kd_dfbdd90e.bOg();
            this.slzIe = Class_kf_f68d320f.viqyh;
            this.aHnxw = Class_ld_bb1690e1.NONE;
            this.xIknw = Class_mG_52c8d386.hoGuU;
            Class_iS_888f260e[] class_iS_888f260eArray2 = class_iS_888f260eArray;
            this.DeOtF = 0.75f;
            this.KfgfI = 0.75f;
            this.txGdU = 1.0f;
            this.tfPBr = 7.0f;
            this.KeWGi = 0.0f;
            this.jzZGr = 0.0f;
            this.nMccj = 0.0f;
            this.XPiOH = (float)Math.PI * 2;
            this.QpnEL = 0.0f;
            this.ddWOd = 0.0f;
            this.JxAXL = 0.5f;
            this.vjsav = 0.0f;
            this.MRKmz = 0.0f;
            this.pRDcN = 1.0f;
            this.JVdZg = 1.0f;
            this.LkPhO = 0.0f;
            this.JOxbl = 100.0f;
            this.grPFu = 100.0f;
            this.Myblt = 100.0f;
            this.icfCV = 0.0f;
            this.NKhaE = 80.0f;
            this.tkEVM = -45.0f;
            this.koBfv = 1.5f;
            this.bUTfh = Class_mG_52c8d386.hoGuU;
            this.OcxDq = Class_mG_52c8d386.UhgnI;
            this.Zheqi = Class_kg_ue_8ab30edd.ubqbG;
            this.DefNT = class_lC_5322e8cf;
            Class_kd_dfbdd90e class_kd_dfbdd90e2 = class_kd_dfbdd90e;
            if (class_iS_888f260eArray2 != null) {
                class_kd_dfbdd90e2 = class_kd_dfbdd90e2 == null ? Class_kd_dfbdd90e.AhlXN : class_kd_dfbdd90e;
            }
            this.LxPkh = class_kd_dfbdd90e2;
            this.KFtMh = f;
            this.UGftP = f2;
            this.lKsUl = f3;
            this.eHPWe = f4;
            if (class_iS_888f260eArray2 != null) break block1;
            Class_iS_888f260e.bwK("FxruEc");
        }
    }

    public Class_kg_0dd28bdb(Class_lC_5322e8cf class_lC_5322e8cf, Class_kd_dfbdd90e class_kd_dfbdd90e, Class_lc_b8480f87 class_lc_b8480f87) {
        this(class_lC_5322e8cf, class_kd_dfbdd90e, class_lc_b8480f87.bXF(), class_lc_b8480f87.bXG(), class_lc_b8480f87.bXH(), class_lc_b8480f87.bXI());
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void execute() {
        var1_1 = Class_kg_0dd28bdb.yDeom ^ 50990991015499L;
        var3_2 = Class_kd_dfbdd90e.bOg();
        if (var3_2 == null) ** GOTO lbl7
        switch (this.Zheqi.ordinal()) {
            case 0: {
                Class_kg_0dd28bdb.ntCFX.bMM(this.bPd(this.DeOtF));
lbl7:
                // 2 sources

                if (var3_2 != null) break;
            }
            case 1: {
                Class_kg_0dd28bdb.axbSm.bNz(this.bPf(this.xIknw, 0.1f));
                if (var3_2 != null) break;
            }
            case 2: {
                Class_kg_0dd28bdb.VWaRK.bNg(this.bPg());
                break;
            }
        }
    }

    public Class_kg_0dd28bdb bOR(float f) {
        this.icfCV = f;
        return this;
    }

    public Class_kg_0dd28bdb bON(float f) {
        this.LkPhO = f;
        return this;
    }

    public Class_kg_0dd28bdb bOX() {
        this.Zheqi = Class_kg_ue_8ab30edd.ubqbG;
        Class_lF_27593463.cfA(this);
        return this;
    }

    public Class_kg_0dd28bdb bOQ(float f) {
        this.Myblt = f;
        return this;
    }

    public Class_kg_0dd28bdb bPc() {
        this.Zheqi = Class_kg_ue_8ab30edd.KXgXu;
        Class_lF_27593463.cfA(this);
        return this;
    }

    public Class_kg_0dd28bdb bOW(Class_mG_52c8d386 class_mG_52c8d386) {
        long l = yDeom ^ 0x6B579844FAC4L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_kd_dfbdd90e.bOg();
        Class_mG_52c8d386 class_mG_52c8d3862 = class_mG_52c8d386;
        if (class_iS_888f260eArray != null) {
            class_mG_52c8d3862 = class_mG_52c8d3862 == null ? Class_mG_52c8d386.UhgnI : class_mG_52c8d386;
        }
        this.OcxDq = class_mG_52c8d3862;
        return this;
    }

    public Class_kg_0dd28bdb bOU(float f) {
        this.koBfv = f;
        return this;
    }

    public Class_kg_0dd28bdb bOu(Class_ld_bb1690e1 class_ld_bb1690e1) {
        long l = yDeom ^ 0x3B72DCB1E620L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_kd_dfbdd90e.bOg();
        Class_ld_bb1690e1 class_ld_bb1690e12 = class_ld_bb1690e1;
        if (class_iS_888f260eArray != null) {
            class_ld_bb1690e12 = class_ld_bb1690e12 == null ? Class_ld_bb1690e1.NONE : class_ld_bb1690e1;
        }
        this.aHnxw = class_ld_bb1690e12;
        return this;
    }

    public Class_kg_0dd28bdb bOY() {
        this.bOZ();
        this.bOX();
        return this;
    }

    public Class_kg_0dd28bdb bOE(float f) {
        this.tfPBr = f;
        return this;
    }

    public Class_kg_0dd28bdb bOO(float f) {
        this.JOxbl = f;
        return this;
    }

    public Class_kg_0dd28bdb bOv(Class_mG_52c8d386 class_mG_52c8d386) {
        long l = yDeom ^ 0xA50458DEC28L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_kd_dfbdd90e.bOg();
        Class_mG_52c8d386 class_mG_52c8d3862 = class_mG_52c8d386;
        if (class_iS_888f260eArray != null) {
            class_mG_52c8d3862 = class_mG_52c8d3862 == null ? Class_mG_52c8d386.hoGuU : class_mG_52c8d386;
        }
        this.xIknw = class_mG_52c8d3862;
        return this;
    }

    public Class_kg_0dd28bdb bOA(float f) {
        this.slzIe = Class_kf_f68d320f.nvgmg;
        this.txGdU = f;
        return this;
    }

    public Class_kg_0dd28bdb bOV(Class_mG_52c8d386 class_mG_52c8d386) {
        long l = yDeom ^ 0x53E0C112FF59L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_kd_dfbdd90e.bOg();
        Class_mG_52c8d386 class_mG_52c8d3862 = class_mG_52c8d386;
        if (class_iS_888f260eArray != null) {
            class_mG_52c8d3862 = class_mG_52c8d3862 == null ? Class_mG_52c8d386.hoGuU : class_mG_52c8d386;
        }
        this.bUTfh = class_mG_52c8d3862;
        return this;
    }

    public Class_kg_0dd28bdb bOP(float f) {
        this.grPFu = f;
        return this;
    }

    public Class_kg_0dd28bdb bOw(Class_la_8f67ae40 class_la_8f67ae40) {
        this.aNPKC = class_la_8f67ae40;
        this.gEcsA = null;
        return this;
    }

    @Override
    public Class_lN_5af116ef batchKey() {
        return Class_lN_5af116ef.immediate();
    }

    public Class_kg_0dd28bdb bPb() {
        this.Zheqi = Class_kg_ue_8ab30edd.risei;
        Class_lF_27593463.cfA(this);
        return this;
    }

    public Class_kg_0dd28bdb bOC(float f) {
        this.DeOtF = f;
        return this;
    }

    public Class_kg_0dd28bdb bOG(float f) {
        this.jzZGr = f;
        return this;
    }

    public Class_kg_0dd28bdb bOH(float f) {
        this.nMccj = f;
        return this;
    }

    public Class_kg_0dd28bdb bOI(float f) {
        this.XPiOH = f;
        return this;
    }

    public Class_kg_0dd28bdb bOF(float f) {
        this.KeWGi = f;
        return this;
    }

    public Class_kg_0dd28bdb bOK(float f) {
        this.AWfNt = true;
        this.QpnEL = f;
        return this;
    }

    public Class_kg_0dd28bdb bOx(AbstractTexture abstractTexture) {
        this.gEcsA = abstractTexture;
        this.aNPKC = null;
        return this;
    }

    public Class_kg_0dd28bdb bOy(float f, float f2, float f3, float f4) {
        this.vjsav = f;
        this.MRKmz = f2;
        this.pRDcN = f3;
        this.JVdZg = f4;
        return this;
    }

    public Class_kg_0dd28bdb bOL(float f) {
        this.ddWOd = f;
        return this;
    }

    private Class_jP_e494f9c7 bPg() {
        return Class_jP_e494f9c7.bKA(this.DefNT.cfc(), this.KFtMh, this.UGftP, this.lKsUl, this.eHPWe).dqK(this.LxPkh).dqL(this.slzIe).dqM(this.aHnxw).dqN(this.xIknw).dqO(this.KfgfI).dqP(this.txGdU).dqQ(this.tfPBr * 0.1f).dqR(this.KeWGi).dqS(this.jzZGr).dqT(this.nMccj).dqU(this.XPiOH).dqV(this.zCNEN).dqW(this.LkPhO).dqX(this.JOxbl).dqY(this.grPFu).dqZ(this.Myblt).dra(this.icfCV).drb(this.NKhaE).drc(this.tkEVM).drd(this.koBfv).dre(this.bUTfh).drf(this.OcxDq).drg();
    }

    public Class_kg_0dd28bdb bOZ() {
        this.bPb();
        return this;
    }

    public Class_kg_0dd28bdb bPa() {
        this.bPc();
        return this;
    }

    private Class_jO_1924117a bPf(Class_mG_52c8d386 class_mG_52c8d386, float f) {
        return this.bPe(class_mG_52c8d386, f).dqz();
    }

    private Class_jO_tZ_935a142d bPe(Class_mG_52c8d386 class_mG_52c8d386, float f) {
        Class_jO_tZ_935a142d class_jO_tZ_935a142d;
        block2: {
            long l = yDeom ^ 0x8B8D31F4B8BL;
            class_jO_tZ_935a142d = Class_jO_1924117a.bJI(this.DefNT.cfc(), this.KFtMh, this.UGftP, this.lKsUl, this.eHPWe).dqh(this.LxPkh).dqi(this.slzIe).dqj(this.aHnxw).dqk(class_mG_52c8d386).dqo(f).dqp(this.KfgfI).dqq(this.txGdU).dqr(this.tfPBr);
            Class_iS_888f260e[] class_iS_888f260eArray = Class_kd_dfbdd90e.bOg();
            Class_kg_0dd28bdb class_kg_0dd28bdb = this;
            if (class_iS_888f260eArray != null) {
                if (class_kg_0dd28bdb.aNPKC != null) {
                    class_jO_tZ_935a142d.dql(this.aNPKC);
                }
                class_kg_0dd28bdb = this;
            }
            if (class_kg_0dd28bdb.gEcsA == null) break block2;
            class_jO_tZ_935a142d.dqm(this.gEcsA);
        }
        return class_jO_tZ_935a142d;
    }

    public Class_kg_0dd28bdb bOB(float f) {
        this.txGdU = f;
        return this;
    }

    public Class_kg_0dd28bdb bOJ(boolean bl) {
        this.zCNEN = bl;
        return this;
    }

    public Class_kg_0dd28bdb bOM(float f) {
        this.JxAXL = f;
        return this;
    }

    public Class_kg_0dd28bdb bOD(float f) {
        this.KfgfI = f;
        return this;
    }

    public Class_kg_0dd28bdb bOS(float f) {
        this.NKhaE = f;
        return this;
    }

    private static MatchException bPh(MatchException matchException) {
        return matchException;
    }

    public Class_kg_0dd28bdb bOz(Class_kf_f68d320f class_kf_f68d320f) {
        long l = yDeom ^ 0x50A9AABCDD15L;
        Class_iS_888f260e[] class_iS_888f260eArray = Class_kd_dfbdd90e.bOg();
        Class_kf_f68d320f class_kf_f68d320f2 = class_kf_f68d320f;
        if (class_iS_888f260eArray != null) {
            class_kf_f68d320f2 = class_kf_f68d320f2 == null ? Class_kf_f68d320f.viqyh : class_kf_f68d320f;
        }
        this.slzIe = class_kf_f68d320f2;
        return this;
    }

    public Class_kg_0dd28bdb bOT(float f) {
        this.tkEVM = f;
        return this;
    }

    private Class_jO_1924117a bPd(float f) {
        return this.bPe(this.xIknw, f).dqn(this.AWfNt).dqs(this.QpnEL).dqt(this.ddWOd).dqu(this.JxAXL).dqv(this.vjsav).dqw(this.MRKmz).dqx(this.pRDcN).dqy(this.JVdZg).dqz();
    }
}

