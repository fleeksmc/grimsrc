/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import recovered.internal.Class_mw_6a6543f5;

@Target(value={ElementType.METHOD})
@Retention(value=RetentionPolicy.RUNTIME)
public @interface Class_hG_d70cdb00 {
    public Class_mw_6a6543f5 priority() default Class_mw_6a6543f5.NORMAL;
}

