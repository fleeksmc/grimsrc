/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 */
package recovered.internal;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jk_a0800133;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mr_7eac5189;

public class Class_cG_6e1ba021
extends Class_cB_67aec11c {
    private Class_mG_52c8d386 HYLiK = Class_mG_52c8d386.hoGuU;
    private Class_mG_52c8d386 mbUpG = Class_mG_52c8d386.hoGuU;
    private boolean nfBAC = false;
    private boolean xPYck;
    private boolean CDdOA = false;
    private static boolean XqhhV;
    private static final long QtQoN;
    private static final String[] TatDI;
    private static final String[] zfSXE;
    private static final Map GtaeP;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cG_6e1ba021(Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_mr_7eac5189);
    }

    public Class_cG_6e1ba021(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_cG_6e1ba021.QtQoN = Class_gb_9d201141.aYR(-6159334118562630845L, -6107607831421606237L, MethodHandles.lookup().lookupClass()).a(54622285838946L);
                Class_cG_6e1ba021.GtaeP = new HashMap<K, V>(13);
                Class_cG_6e1ba021.Wm(false);
                var0 = Class_cG_6e1ba021.QtQoN ^ 77473402780386L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[8];
                var7_4 = 0;
                var6_5 = "\u000e\u00a5h\u00b4\u00d9e~\u00edm\u001c>\u0006\u00a4\u0085\u00a0\u00df&\t\u00e5L\u00f3Y^$\u0093{\u0015\u00d1\u0001fm\u00d0 \u00be\u00d3\u00c0o\u0097\u00bf\u0014N\u001bZDM\u00cb=/9\r\u00ab\u00dd/d\u00a5\u0017r\u008b\u009a\u00bdt>z\u00e7\u00ab\u0010MR\u00ee)\u0096zC\u009bK\u00ef\u0003\u00be\u00e8\u001dL\u00a8\u0018\u00ecA\u0090N\u00a8p\u0080,\u0001\u00eb\u0000\u00bb\u0003\u00fd\u00f8A\u00878\u00c3SJ\u0091}\u00b6 F\u00acO=\u009d\u00d0\u00b2\u00e4\u00e5 6\u00eeTcpe\u00a50\u00d96\u00b9\u00f7\u0083\u00c3\u00da\u00bc\u0086A\u0092aC\u0093\u0010\u00aa0\u00bbM<\u00e1C\u00c0\u0011[\u0010\u00f4Vy\u009e\u00ec";
                var8_6 = "\u000e\u00a5h\u00b4\u00d9e~\u00edm\u001c>\u0006\u00a4\u0085\u00a0\u00df&\t\u00e5L\u00f3Y^$\u0093{\u0015\u00d1\u0001fm\u00d0 \u00be\u00d3\u00c0o\u0097\u00bf\u0014N\u001bZDM\u00cb=/9\r\u00ab\u00dd/d\u00a5\u0017r\u008b\u009a\u00bdt>z\u00e7\u00ab\u0010MR\u00ee)\u0096zC\u009bK\u00ef\u0003\u00be\u00e8\u001dL\u00a8\u0018\u00ecA\u0090N\u00a8p\u0080,\u0001\u00eb\u0000\u00bb\u0003\u00fd\u00f8A\u00878\u00c3SJ\u0091}\u00b6 F\u00acO=\u009d\u00d0\u00b2\u00e4\u00e5 6\u00eeTcpe\u00a50\u00d96\u00b9\u00f7\u0083\u00c3\u00da\u00bc\u0086A\u0092aC\u0093\u0010\u00aa0\u00bbM<\u00e1C\u00c0\u0011[\u0010\u00f4Vy\u009e\u00ec".length();
                var5_7 = 32;
                var4_8 = -1;
lbl21:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl26:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_cG_6e1ba021.Wq(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "\u0092\u00eb\u00dezqb\u00ebQ\u00f3\u007f\u00d2\u00e6\u00ca\u0092\u0004* uD\u00dd1N\u00e6\u001c\t\u00d02\u00a6\u00aa\u00cf\u00a3\u00de\u00c1\u00e6\u0013\u00e3\u0094\u00ba\\\u0082b|\u00f0\u00e0\u0083\u001b\u00c2\u00f7\u00dd";
                    var8_6 = "\u0092\u00eb\u00dezqb\u00ebQ\u00f3\u007f\u00d2\u00e6\u00ca\u0092\u0004* uD\u00dd1N\u00e6\u001c\t\u00d02\u00a6\u00aa\u00cf\u00a3\u00de\u00c1\u00e6\u0013\u00e3\u0094\u00ba\\\u0082b|\u00f0\u00e0\u0083\u001b\u00c2\u00f7\u00dd".length();
                    var5_7 = 16;
                    var4_8 = -1;
lbl35:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl40:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_cG_6e1ba021.Wq(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl52:
                // 1 sources

                ** continue;
            }
        }
        Class_cG_6e1ba021.TatDI = var9_3;
        Class_cG_6e1ba021.zfSXE = new String[8];
    }

    /*
     * Enabled aggressive block sorting
     */
    public Class_mG_52c8d386 Wf() {
        Class_mG_52c8d386 class_mG_52c8d386;
        long l = QtQoN ^ 0x5BC31A83EA96L;
        boolean bl = Class_cB_67aec11c.Vt();
        Class_cG_6e1ba021 class_cG_6e1ba021 = this;
        if (bl) {
            if (class_cG_6e1ba021.xPYck) {
                class_mG_52c8d386 = Class_jk_a0800133.bDk();
                return class_mG_52c8d386;
            }
            class_cG_6e1ba021 = this;
        }
        class_mG_52c8d386 = class_cG_6e1ba021.HYLiK;
        return class_mG_52c8d386;
    }

    @Override
    public void SS(JsonElement jsonElement) {
        block8: {
            long l = QtQoN ^ 0x6B0BE11795B0L;
            boolean bl = Class_cB_67aec11c.Vt();
            JsonElement jsonElement2 = jsonElement;
            if (bl) {
                if (!jsonElement2.isJsonObject()) {
                    this.Uc(jsonElement.getAsInt());
                    return;
                }
                jsonElement2 = jsonElement;
            }
            JsonObject jsonObject = jsonElement2.getAsJsonObject();
            boolean bl2 = jsonObject.has((String)((Object)Class_cG_6e1ba021.Wt("h", (int)15358, (long)(0x5CA2F983DAC742C5L ^ l))));
            if (bl) {
                if (bl2) {
                    this.Uc(jsonObject.get((String)((Object)Class_cG_6e1ba021.Wt("h", (int)9713, (long)(0x24DC5DAC7D17DCCBL ^ l)))).getAsInt());
                }
                bl2 = jsonObject.has((String)((Object)Class_cG_6e1ba021.Wt("h", (int)15521, (long)(0x79B9E258C7D1459FL ^ l))));
            }
            if (bl) {
                if (bl2) {
                    this.Ud(jsonObject.get((String)((Object)Class_cG_6e1ba021.Wt("h", (int)21463, (long)(0x3D7C5E024CC82AEAL ^ l)))).getAsInt());
                }
                bl2 = jsonObject.has((String)((Object)Class_cG_6e1ba021.Wt("h", (int)17132, (long)(0x72771D219E913BD4L ^ l))));
            }
            if (bl) {
                if (bl2) {
                    this.Ug(jsonObject.get((String)((Object)Class_cG_6e1ba021.Wt("h", (int)23921, (long)(0x37C24DB6BDC5A448L ^ l)))).getAsBoolean());
                }
                bl2 = jsonObject.has((String)((Object)Class_cG_6e1ba021.Wt("h", (int)18307, (long)(0x45B7B1E9974A3EBCL ^ l))));
            }
            if (!bl2) break block8;
            this.Uh(jsonObject.get((String)((Object)Class_cG_6e1ba021.Wt("h", (int)6439, (long)(0x1F1C83FD97E601BL ^ l)))).getAsBoolean());
        }
    }

    @Override
    public void SR(Map<String, Object> map) {
        long l = QtQoN ^ 0x38726B75081CL;
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty((String)((Object)Class_cG_6e1ba021.Wt("h", (int)9713, (long)(0x24DC0ED5F7754167L ^ l))), (Number)this.HYLiK.coh());
        jsonObject.addProperty((String)((Object)Class_cG_6e1ba021.Wt("h", (int)21463, (long)(0x3D7C0D7BC6AAB746L ^ l))), (Number)this.mbUpG.coh());
        jsonObject.addProperty((String)((Object)Class_cG_6e1ba021.Wt("h", (int)23921, (long)(0x37C21ECF37A739E4L ^ l))), Boolean.valueOf(this.nfBAC));
        jsonObject.addProperty((String)((Object)Class_cG_6e1ba021.Wt("h", (int)6439, (long)(0x1F19B46531CFDB7L ^ l))), Boolean.valueOf(this.xPYck));
        map.put(Arrays.toString(this.NwlSF), jsonObject);
    }

    public Class_cG_6e1ba021 Uh(boolean bl) {
        long l = QtQoN ^ 0x3A60A0CE37D9L;
        boolean bl2 = Class_cB_67aec11c.Vt();
        Class_cG_6e1ba021 class_cG_6e1ba021 = this;
        if (bl2) {
            if (class_cG_6e1ba021.xPYck == bl) {
                return this;
            }
            this.xPYck = bl;
            this.Vk();
            class_cG_6e1ba021 = this;
        }
        return class_cG_6e1ba021;
    }

    public Class_cG_6e1ba021 We() {
        this.CDdOA = true;
        return this;
    }

    /*
     * Unable to fully structure code
     */
    public Class_cG_6e1ba021 Ue(Class_mG_52c8d386 var1_1) {
        var2_2 = Class_cG_6e1ba021.QtQoN ^ 98485881981846L;
        var4_3 = Class_cB_67aec11c.Vt();
        v0 = var1_1;
        if (!var4_3) ** GOTO lbl9
        if (v0 == null) {
            v1 = 0;
        } else {
            v0 = var1_1;
lbl9:
            // 2 sources

            v1 = v0.coh();
        }
        var5_4 = v1;
        v2 = this.mbUpG;
        if (!var4_3) ** GOTO lbl17
        if (v2 == null) {
            v3 = 0;
        } else {
            v2 = this.mbUpG;
lbl17:
            // 2 sources

            v3 = var6_5 = v2.coh();
        }
        if (var4_3) {
            if (var6_5 == var5_4) {
                return this;
            }
            this.mbUpG = var1_1;
            this.Vk();
        }
        return this;
    }

    /*
     * Unable to fully structure code
     */
    public Class_cG_6e1ba021 Uc(int var1_1) {
        var2_2 = Class_cG_6e1ba021.QtQoN ^ 28183360502667L;
        var4_3 = Class_cB_67aec11c.Vu();
        v0 = this.HYLiK;
        if (var4_3) ** GOTO lbl9
        if (v0 == null) {
            v1 = 0;
        } else {
            v0 = this.HYLiK;
lbl9:
            // 2 sources

            v1 = var5_4 = v0.coh();
        }
        if (!var4_3) {
            if (var5_4 == var1_1) {
                return this;
            }
            this.HYLiK = Class_mG_52c8d386.cnQ(var1_1);
            this.Vk();
        }
        return this;
    }

    public Class_cG_6e1ba021 Ub(boolean bl) {
        this.CDdOA = bl;
        return this;
    }

    public static boolean Wo() {
        boolean bl = Class_cG_6e1ba021.Wn();
        return !bl;
    }

    private static MatchException Wp(MatchException matchException) {
        return matchException;
    }

    private static Object Ws(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_cG_6e1ba021.Wr(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static String Wr(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x5192;
        if (zfSXE[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])GtaeP.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    GtaeP.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cG_6e1ba021", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = TatDI[n2].getBytes("ISO-8859-1");
            Class_cG_6e1ba021.zfSXE[n2] = Class_cG_6e1ba021.Wq(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return zfSXE[n2];
    }

    private static String Wq(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    public static void Wm(boolean bl) {
        XqhhV = bl;
    }

    public boolean Wk() {
        return this.xPYck;
    }

    public boolean Wl() {
        return this.CDdOA;
    }

    /*
     * Unable to fully structure code
     */
    public Class_cG_6e1ba021 Ud(int var1_1) {
        var2_2 = Class_cG_6e1ba021.QtQoN ^ 131312772721744L;
        var4_3 = Class_cB_67aec11c.Vu();
        v0 = this.mbUpG;
        if (var4_3) ** GOTO lbl9
        if (v0 == null) {
            v1 = 0;
        } else {
            v0 = this.mbUpG;
lbl9:
            // 2 sources

            v1 = var5_4 = v0.coh();
        }
        if (!var4_3) {
            if (var5_4 == var1_1) {
                return this;
            }
            this.mbUpG = Class_mG_52c8d386.cnQ(var1_1);
            this.Vk();
        }
        return this;
    }

    public static boolean Wn() {
        return XqhhV;
    }

    public Class_mG_52c8d386 Wg() {
        return this.HYLiK;
    }

    public Class_mG_52c8d386 Wi() {
        return this.mbUpG;
    }

    private static CallSite Wt(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cG_6e1ba021" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    public boolean Wj() {
        return this.nfBAC;
    }

    public Class_cG_6e1ba021 Ug(boolean bl) {
        long l = QtQoN ^ 0x19EB9E4C6D92L;
        boolean bl2 = Class_cB_67aec11c.Vu();
        Class_cG_6e1ba021 class_cG_6e1ba021 = this;
        if (!bl2) {
            if (class_cG_6e1ba021.nfBAC == bl) {
                return this;
            }
            this.nfBAC = bl;
            this.Vk();
            class_cG_6e1ba021 = this;
        }
        return class_cG_6e1ba021;
    }

    /*
     * Unable to fully structure code
     */
    public Class_cG_6e1ba021 Uf(Class_mG_52c8d386 var1_1) {
        var2_2 = Class_cG_6e1ba021.QtQoN ^ 31027954742809L;
        var4_3 = Class_cB_67aec11c.Vt();
        v0 = var1_1;
        if (!var4_3) ** GOTO lbl9
        if (v0 == null) {
            v1 = 0;
        } else {
            v0 = var1_1;
lbl9:
            // 2 sources

            v1 = v0.coh();
        }
        var5_4 = v1;
        v2 = this.HYLiK;
        if (!var4_3) ** GOTO lbl17
        if (v2 == null) {
            v3 = 0;
        } else {
            v2 = this.HYLiK;
lbl17:
            // 2 sources

            v3 = var6_5 = v2.coh();
        }
        if (var4_3) {
            if (var6_5 == var5_4) {
                return this;
            }
            this.HYLiK = var1_1;
            this.Vk();
        }
        return this;
    }

    /*
     * Enabled aggressive block sorting
     */
    public int Wh() {
        int n;
        long l = QtQoN ^ 0x6E98AE6C83F5L;
        boolean bl = Class_cB_67aec11c.Vu();
        Class_cG_6e1ba021 class_cG_6e1ba021 = this;
        if (!bl) {
            if (class_cG_6e1ba021.xPYck) {
                n = Class_jk_a0800133.bDk().coh();
                return n;
            }
            class_cG_6e1ba021 = this;
        }
        n = class_cG_6e1ba021.HYLiK.coh();
        return n;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cG_6e1ba021.class, "Ws", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

