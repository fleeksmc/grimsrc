/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.sun.jna.Pointer
 *  com.sun.jna.Structure
 *  com.sun.jna.Structure$ByReference
 */
package recovered.internal;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;

public final class Class_jm_tO_d3d6e05e
extends Structure
implements Structure.ByReference {
    public int pqLqB;
    public Pointer QEuUZ;
    public int zJceD;
    private static final long vVATW = Class_gb_9d201141.aYR(8385221217247945627L, 4410544488706773396L, MethodHandles.lookup().lookupClass()).a(115177570977523L);
    private static final String[] MNsZG;
    private static final String[] gUsVY;
    private static final Map KCtum;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    static {
        KCtum = new HashMap(13);
        long l = vVATW ^ 0x1A32B45E2769L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[3];
        int n = 0;
        String string = "\u00e6\u00b9\u00d6\u00faI9'.\u0091\u00ac2\u00f0\u00f9\u00f3;\u008b\u0018\u00a9\u00d1\u00d4\u00cf\u00ed+S\u00fbPP\u0083\u00de\u00f0\u00e0(\u00f5\u00e1\u00db]\u00d9\u00bc\u00bf\u00fc\u00a1 \u0017r\u00b4j&\u00a2^Hn\u00ec\u00fe\u00e9Gs\u00b4L\u00c2\u00d0\u001e\u0019\u009e\u00be\u00daW\u008b\u00db\u000f\u0012\u00f2f\u00e5t";
        int n2 = "\u00e6\u00b9\u00d6\u00faI9'.\u0091\u00ac2\u00f0\u00f9\u00f3;\u008b\u0018\u00a9\u00d1\u00d4\u00cf\u00ed+S\u00fbPP\u0083\u00de\u00f0\u00e0(\u00f5\u00e1\u00db]\u00d9\u00bc\u00bf\u00fc\u00a1 \u0017r\u00b4j&\u00a2^Hn\u00ec\u00fe\u00e9Gs\u00b4L\u00c2\u00d0\u001e\u0019\u009e\u00be\u00daW\u008b\u00db\u000f\u0012\u00f2f\u00e5t".length();
        int n3 = 16;
        int n4 = -1;
        while (true) {
            int n5 = ++n4;
            byte[] byArray3 = cipher.doFinal(string.substring(n5, n5 + n3).getBytes("ISO-8859-1"));
            stringArray[n++] = Class_jm_tO_d3d6e05e.dpK(byArray3).intern();
            if ((n4 += n3) >= n2) {
                MNsZG = stringArray;
                gUsVY = new String[3];
                return;
            }
            n3 = string.charAt(n4);
        }
    }

    protected List<String> getFieldOrder() {
        long l = vVATW ^ 0x63C78492EF44L;
        return List.of(Class_jm_tO_d3d6e05e.dpN("k", (int)19180, (long)(0x1304C1D4832E0400L ^ l)), Class_jm_tO_d3d6e05e.dpN("k", (int)23547, (long)(0x6DC7E9F52A211516L ^ l)), Class_jm_tO_d3d6e05e.dpN("k", (int)23067, (long)(0x3DBFF39337ED94F4L ^ l)));
    }

    private static String dpK(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static CallSite dpN(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jm_tO_d3d6e05e" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static String dpL(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x302C;
        if (gUsVY[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])KCtum.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    KCtum.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jm_tO_d3d6e05e", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = MNsZG[n2].getBytes("ISO-8859-1");
            Class_jm_tO_d3d6e05e.gUsVY[n2] = Class_jm_tO_d3d6e05e.dpK(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return gUsVY[n2];
    }

    private static Object dpM(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_jm_tO_d3d6e05e.dpL(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jm_tO_d3d6e05e.class, "dpM", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

