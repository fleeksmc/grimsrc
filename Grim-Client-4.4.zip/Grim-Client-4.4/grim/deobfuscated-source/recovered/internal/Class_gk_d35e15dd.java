/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;
import recovered.internal.Class_lC_5322e8cf;

public class Class_gk_d35e15dd
extends Class_hH_ae8f8f77 {
    private Class_lC_5322e8cf pUtcq;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gk_d35e15dd(Class_lC_5322e8cf class_lC_5322e8cf) {
        this.pUtcq = class_lC_5322e8cf;
    }

    public Class_lC_5322e8cf baT() {
        return this.pUtcq;
    }
}

