/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screen.ingame.HandledScreen
 */
package recovered.internal;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import recovered.internal.Class_hH_ae8f8f77;
import recovered.internal.Class_lC_5322e8cf;

public class Class_gq_992349f8
extends Class_hH_ae8f8f77 {
    private Class_lC_5322e8cf ZrosS;
    private HandledScreen<?> XKOye;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gq_992349f8(Class_lC_5322e8cf class_lC_5322e8cf, HandledScreen<?> handledScreen) {
        this.ZrosS = class_lC_5322e8cf;
        this.XKOye = handledScreen;
    }

    public Class_lC_5322e8cf bbp() {
        return this.ZrosS;
    }

    public HandledScreen<?> bbq() {
        return this.XKOye;
    }
}

