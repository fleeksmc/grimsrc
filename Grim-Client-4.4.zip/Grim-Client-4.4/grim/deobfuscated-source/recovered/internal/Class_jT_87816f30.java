/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderPass
 *  com.mojang.blaze3d.vertex.VertexFormat$DrawMode
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.VertexFormats
 *  net.minecraft.client.util.BufferAllocator
 */
package recovered.internal;

import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_jL_e8aba6a1;
import recovered.internal.Class_jO_1924117a;
import recovered.internal.Class_kR_e9b8cad1;
import recovered.internal.Class_ke_512fbaf0;
import recovered.internal.Class_kh_19daf527;
import recovered.internal.Class_lF_27593463;

public class Class_jT_87816f30
implements Class_kh_19daf527<Class_jO_1924117a> {
    private static boolean GRyFV;
    private static final long OqQyw;
    private static final String[] wCgeD;
    private static final String[] fxewg;
    private static final Map BMyRp;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    static {
        OqQyw = Class_gb_9d201141.aYR(-183791357870024740L, -5914521567213679317L, MethodHandles.lookup().lookupClass()).a(147815586986413L);
        BMyRp = new HashMap(13);
        long l = OqQyw ^ 0x512DC9CA9FDCL;
        Class_jT_87816f30.bMP(true);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[2];
        int n = 0;
        String string = "\u00e7F\u00b3\u00ab\u00ca\u0012\u009e\u00b7r\u00b2m\u00b7\u00b3\u00cf\u0084\u00d4\u00d6\u00a3~\u00ab\u00cb\u00bcR0\u00c3\u009a\u008d\u0002\u00c6GN^ \u0091\u00a1;\u0018\u009a>\u00d4\u00de\u00f1\u00cb\u0000s\u00c5\u00ce\u00ba9\u00c6\n$\u0086I\u0015g\u00eaE\u0085l\u0088z\u001e\u00ba&";
        int n2 = "\u00e7F\u00b3\u00ab\u00ca\u0012\u009e\u00b7r\u00b2m\u00b7\u00b3\u00cf\u0084\u00d4\u00d6\u00a3~\u00ab\u00cb\u00bcR0\u00c3\u009a\u008d\u0002\u00c6GN^ \u0091\u00a1;\u0018\u009a>\u00d4\u00de\u00f1\u00cb\u0000s\u00c5\u00ce\u00ba9\u00c6\n$\u0086I\u0015g\u00eaE\u0085l\u0088z\u001e\u00ba&".length();
        int n3 = 32;
        int n4 = -1;
        while (true) {
            int n5 = ++n4;
            byte[] byArray3 = cipher.doFinal(string.substring(n5, n5 + n3).getBytes("ISO-8859-1"));
            stringArray[n++] = Class_jT_87816f30.bMT(byArray3).intern();
            if ((n4 += n3) >= n2) {
                wCgeD = stringArray;
                fxewg = new String[2];
                return;
            }
            n3 = string.charAt(n4);
        }
    }

    public static void bMP(boolean bl) {
        GRyFV = bl;
    }

    private static String bMU(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x46ED;
        if (fxewg[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])BMyRp.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    BMyRp.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_jT_87816f30", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = wCgeD[n2].getBytes("ISO-8859-1");
            Class_jT_87816f30.fxewg[n2] = Class_jT_87816f30.bMT(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return fxewg[n2];
    }

    public static boolean bMQ() {
        return GRyFV;
    }

    private static /* synthetic */ void bMO(int n, Class_jO_1924117a class_jO_1924117a, RenderPass renderPass) {
        long l = OqQyw ^ 0x157195718C7L;
        boolean bl = Class_jT_87816f30.bMQ();
        if (bl) {
            if (n == 2) {
                renderPass.bindTexture((String)((Object)Class_jT_87816f30.bMW("o", (int)16606, (long)(0x50EFECA06467BED2L ^ l))), class_jO_1924117a.bKk().getGlTextureView(), class_jO_1924117a.bKk().getSampler());
            }
            Class_ke_512fbaf0.bOi(Class_jL_e8aba6a1.VBAOv, class_jO_1924117a, n);
            Class_jL_e8aba6a1.VBAOv.bJr((String)((Object)Class_jT_87816f30.bMW("o", (int)20233, (long)(0x729AC21F1BECB104L ^ l))), 0.0f, 0.0f);
        }
    }

    private static String bMT(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static Object bMV(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_jT_87816f30.bMU(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite bMW(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_jT_87816f30" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Unable to fully structure code
     */
    public void bMM(Class_jO_1924117a var1_1) {
        block25: {
            block24: {
                var2_2 = Class_jT_87816f30.OqQyw ^ 38261553496514L;
                var5_3 = this.bMN(var1_1);
                var4_4 = Class_jT_87816f30.bMR();
                if (var5_3 == 2) {
                    v0 = var1_1;
                    if (!var4_4) {
                        if (v0.bKk() == null) {
                            return;
                        } else {
                            ** GOTO lbl-1000
                        }
                    }
                } else lbl-1000:
                // 3 sources

                {
                    v0 = var1_1;
                }
                var6_5 = v0.bKi();
                v1 = var5_3;
                if (var4_4) break block24;
                if (v1 == 1) break block25;
                v1 = (int)var6_5.cnW();
            }
            if (v1 != 0) {
                return;
            }
        }
        var7_6 = var1_1.bKm();
        var8_7 = this.expandBySmoothness(var1_1.bKb(), var1_1.bKc(), var1_1.bKd(), var1_1.bKe(), var7_6);
        var9_8 = new BufferAllocator(VertexFormats.POSITION_TEXTURE_COLOR.getVertexSize() * 4);
        try {
            var10_9 = new BufferBuilder(var9_8, VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            Class_jT_87816f30.FroVm.uv_quad_region_color(var10_9, var1_1.bKa(), var8_7.bXF(), var8_7.bXG(), var8_7.bXH(), var8_7.bXI(), var1_1.bKt(), var1_1.bKu(), var1_1.bKv(), var1_1.bKw(), var6_5);
            var11_11 = var10_9.end();
            try {
                Class_lF_27593463.cfB(var5_3 == 2 ? Class_kR_e9b8cad1.alRAH : Class_kR_e9b8cad1.cbSJp, var11_11, (Consumer<RenderPass>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, bMO(int recovered.internal.Class_jO_1924117a com.mojang.blaze3d.systems.RenderPass ), (Lcom/mojang/blaze3d/systems/RenderPass;)V)((int)var5_3, (Class_jO_1924117a)var1_1));
                ** if (var4_4 || var11_11 == null) goto lbl-1000
            }
            catch (Throwable var12_13) {
                block26: {
                    v2 = var11_11;
                    if (var4_4) ** GOTO lbl38
                    if (v2 == null) break block26;
                    try {
                        v2 = var11_11;
lbl38:
                        // 2 sources

                        v2.close();
                    }
                    catch (Throwable var13_14) {
                        var12_13.addSuppressed(var13_14);
                    }
                }
                throw var12_13;
            }
lbl-1000:
            // 1 sources

            {
                var11_11.close();
            }
lbl-1000:
            // 2 sources

            {
            }
        }
        finally {
            var9_8.close();
        }
    }

    public static boolean bMR() {
        boolean bl = Class_jT_87816f30.bMQ();
        return !bl;
    }

    private int bMN(Class_jO_1924117a class_jO_1924117a) {
        long l = OqQyw ^ 0x624F567E77EFL;
        boolean bl = Class_jT_87816f30.bMQ();
        int n = class_jO_1924117a.bJH();
        if (bl) {
            if (n != 0) {
                return 2;
            }
            n = class_jO_1924117a.bJG();
        }
        if (bl) {
            if (n != 0) {
                return 1;
            }
            n = 0;
        }
        return n;
    }

    private static Throwable bMS(Throwable throwable) {
        return throwable;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_jT_87816f30.class, "bMV", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

