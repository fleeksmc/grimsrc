/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec2f
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import net.minecraft.util.math.Vec2f;
import recovered.core.ClientMain;
import recovered.internal.Class_ay_c070a086;
import recovered.internal.Class_az_rU_d532d676;
import recovered.internal.Class_f_2512a74f;
import recovered.internal.Class_g_bd7b3df3;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_h_d59300d0;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jG_69891630;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lc_b8480f87;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_mu_a94f6370;

public abstract class Class_az_a4990dcf
extends Class_iS_888f260e {
    private static long kRxcV;
    public static final Comparator<Class_az_a4990dcf> VjGAm;
    protected Class_ii_9b427eda CtPwV;
    protected float MCnYt;
    protected float pNyTQ;
    protected float BcpIo;
    protected float WjISQ;
    protected int mXtVF;
    protected int eWYPl;
    protected Class_az_a4990dcf DjJTP;
    protected final Class_mu_a94f6370<Class_az_a4990dcf> gJoaC;
    protected boolean tSjBL;
    protected boolean oTiGT;
    protected boolean VtZUv;
    protected boolean PGAcs;
    private final long tnbQU;
    private static String mqOlJ;
    private static final long smakX;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    protected Class_az_a4990dcf(float f, float f2, float f3, float f4) {
        block0: {
            long l = smakX ^ 0x2BB3E7DA6528L;
            this.CtPwV = ClientMain.dlM();
            this.gJoaC = new Class_mu_a94f6370();
            this.tSjBL = true;
            this.tnbQU = kRxcV++;
            String string = Class_az_a4990dcf.tE();
            this.MCnYt = f;
            this.pNyTQ = f2;
            this.BcpIo = f3;
            this.WjISQ = f4;
            if (Class_iS_888f260e.bwL() != null) break block0;
            Class_az_a4990dcf.tD("hV0mUc");
        }
    }

    protected Class_az_a4990dcf() {
        this(0.0f, 0.0f, 0.0f, 0.0f);
    }

    static {
        smakX = Class_gb_9d201141.aYR(-7198668780647983144L, 6866809431512737463L, MethodHandles.lookup().lookupClass()).a(139834532818023L);
        VjGAm = Comparator.comparingInt(class_az_a4990dcf -> class_az_a4990dcf.sN()).thenComparingInt(Class_az_a4990dcf::tt).thenComparingLong(Class_az_a4990dcf::tA);
        Class_az_a4990dcf.tD("lj13Ec");
    }

    public Class_mu_a94f6370<Class_az_a4990dcf> tv() {
        return this.gJoaC;
    }

    public boolean ta(Class_lc_b8480f87 class_lc_b8480f87) {
        return Class_jf_d1c4f950.bAW(class_lc_b8480f87, this);
    }

    public Class_az_a4990dcf to(float f) {
        this.WjISQ = f;
        return this;
    }

    public float tb() {
        return this.pNyTQ + this.WjISQ;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean tg(double d, double d2) {
        long l = smakX ^ 0x2ED5E1BA9913L;
        String string = Class_az_a4990dcf.tE();
        boolean bl = Class_ay_c070a086.sr();
        if (string != null) {
            if (!bl) return false;
            bl = Class_jf_d1c4f950.bAE(d, d2, this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ);
        }
        if (string == null) return bl;
        if (!bl) return false;
        return true;
    }

    public float dn() {
        return this.WjISQ;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean th(double d, double d2, double d3, double d4, double d5, double d6) {
        long l = smakX ^ 0x4DF58CFBC3FDL;
        String string = Class_az_a4990dcf.tE();
        boolean bl = Class_ay_c070a086.sr();
        if (string != null) {
            if (!bl) return false;
            bl = Class_jf_d1c4f950.bAE(d, d2, d3, d4, d5, d6);
        }
        if (string == null) return bl;
        if (!bl) return false;
        return true;
    }

    public float tc() {
        return this.MCnYt + this.BcpIo;
    }

    public void sw() {
    }

    public boolean hc(double d, double d2) {
        return this.PGAcs;
    }

    public float ts() {
        return this.pNyTQ;
    }

    public Class_az_a4990dcf tl(float f) {
        this.MCnYt = f;
        return this;
    }

    public float tr() {
        return this.MCnYt;
    }

    public Class_az_a4990dcf tp(Class_az_a4990dcf class_az_a4990dcf) {
        this.DjJTP = class_az_a4990dcf;
        return this;
    }

    public Class_az_a4990dcf tn(float f) {
        this.BcpIo = f;
        return this;
    }

    /*
     * Unable to fully structure code
     */
    public void sz(Class_f_2512a74f var1_1) {
        var2_2 = Class_az_a4990dcf.smakX ^ 42099134576451L;
        var4_3 = Class_az_a4990dcf.tE();
        v0 = Class_az_rU_d532d676.xmlDG[var1_1.ap().ordinal()];
        if (var4_3 == null) ** GOTO lbl8
        switch (v0) {
            case 1: {
                v0 = (int)this.dk(var1_1.aq(), var1_1.ar(), var1_1.as());
lbl8:
                // 2 sources

                if (v0 == 0) break;
                var1_1.ao();
                if (var4_3 != null) break;
            }
            case 2: {
                if (!this.dB(var1_1.aq(), var1_1.ar(), var1_1.as(), var1_1.at(), var1_1.au())) break;
                var1_1.ao();
                if (var4_3 != null) break;
            }
            case 3: {
                this.dl(var1_1.aq(), var1_1.ar(), var1_1.as());
                if (var4_3 != null) break;
            }
            case 4: {
                if (!this.fC(var1_1.aq(), var1_1.ar(), var1_1.av())) break;
                var1_1.ao();
                break;
            }
        }
    }

    public void dl(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean ti(Class_lC_5322e8cf class_lC_5322e8cf) {
        long l = smakX ^ 0x11AA75349030L;
        String string = Class_az_a4990dcf.tE();
        boolean bl = Class_ay_c070a086.sr();
        if (string != null) {
            if (!bl) return false;
            bl = Class_jG_69891630.bHZ(class_lC_5322e8cf);
        }
        if (string != null) {
            if (!bl) return false;
            bl = Class_jf_d1c4f950.bAG(class_lC_5322e8cf, this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ);
        }
        if (string == null) return bl;
        if (!bl) return false;
        return true;
    }

    public Class_az_a4990dcf tm(float f) {
        this.pNyTQ = f;
        return this;
    }

    public int tt() {
        return this.eWYPl;
    }

    public void sx() {
    }

    public boolean tz() {
        return this.PGAcs;
    }

    public boolean dm(int n, int n2, int n3) {
        return false;
    }

    public boolean dk(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2) {
        return false;
    }

    public Class_az_a4990dcf tk(Class_ii_9b427eda class_ii_9b427eda) {
        this.CtPwV = class_ii_9b427eda;
        return this;
    }

    private void sv(Class_lC_5322e8cf class_lC_5322e8cf) {
        this.fX(class_lC_5322e8cf);
        this.bV(class_lC_5322e8cf);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean tf() {
        long l = smakX ^ 0xEFCABA86653L;
        String string = Class_az_a4990dcf.tE();
        int n = Float.isFinite(this.BcpIo);
        if (string != null) {
            if (n == 0) return 0 != 0;
            n = Float.isFinite(this.WjISQ);
        }
        if (string != null) {
            if (n == 0) return 0 != 0;
            float f = this.BcpIo - 0.0f;
            n = f == 0.0f ? 0 : (f > 0.0f ? 1 : -1);
        }
        if (string != null) {
            if (n <= 0) return 0 != 0;
            float f = this.WjISQ - 0.0f;
            n = f == 0.0f ? 0 : (f > 0.0f ? 1 : -1);
        }
        if (string == null) return n != 0;
        if (n <= 0) return 0 != 0;
        return 1 != 0;
    }

    protected abstract void bV(Class_lC_5322e8cf var1);

    public boolean fC(double d, double d2, double d3) {
        return false;
    }

    public Class_lc_b8480f87 td() {
        return new Class_lc_b8480f87(this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ);
    }

    public boolean tw() {
        return this.tSjBL;
    }

    public Vec2f te() {
        return new Vec2f(this.BcpIo, this.WjISQ);
    }

    public void sy(Class_f_2512a74f class_f_2512a74f) {
    }

    public boolean ty() {
        return this.VtZUv;
    }

    public boolean tx() {
        return this.oTiGT;
    }

    public void dY() {
    }

    public boolean dB(double d, double d2, Class_mA_32d8a5f2 class_mA_32d8a5f2, double d3, double d4) {
        return false;
    }

    public void fX(Class_lC_5322e8cf class_lC_5322e8cf) {
    }

    public boolean eK(char c) {
        return false;
    }

    public void sB(Class_h_d59300d0 class_h_d59300d0) {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean tj(Class_lC_5322e8cf class_lC_5322e8cf, double d, double d2, double d3, double d4) {
        long l = smakX ^ 0x73B9FAC30D10L;
        String string = Class_az_a4990dcf.tE();
        boolean bl = Class_ay_c070a086.sr();
        if (string != null) {
            if (!bl) return false;
            bl = Class_jG_69891630.bHZ(class_lC_5322e8cf);
        }
        if (string != null) {
            if (!bl) return false;
            bl = Class_jf_d1c4f950.bAG(class_lC_5322e8cf, d, d2, d3, d4);
        }
        if (string == null) return bl;
        if (!bl) return false;
        return true;
    }

    private Class_lc_b8480f87 sH(Class_lc_b8480f87 class_lc_b8480f87, Class_lc_b8480f87 class_lc_b8480f872) {
        float f = Math.max(class_lc_b8480f87.bXF(), class_lc_b8480f872.bXF());
        float f2 = Math.max(class_lc_b8480f87.bXG(), class_lc_b8480f872.bXG());
        float f3 = Math.min(class_lc_b8480f87.bXz(), class_lc_b8480f872.bXz());
        float f4 = Math.min(class_lc_b8480f87.bXA(), class_lc_b8480f872.bXA());
        return new Class_lc_b8480f87(f, f2, Math.max(0.0f, f3 - f), Math.max(0.0f, f4 - f2));
    }

    public Class_az_a4990dcf sS(boolean bl) {
        this.VtZUv = bl;
        return this;
    }

    public Class_az_a4990dcf sM() {
        long l = smakX ^ 0x689B64A5C2DFL;
        Class_az_a4990dcf class_az_a4990dcf = this;
        String string = Class_az_a4990dcf.tE();
        while (class_az_a4990dcf != null) {
            Class_az_a4990dcf class_az_a4990dcf2 = class_az_a4990dcf;
            if (string != null) {
                if (class_az_a4990dcf2.nZ()) {
                    return class_az_a4990dcf;
                }
                class_az_a4990dcf2 = class_az_a4990dcf = class_az_a4990dcf.DjJTP;
            }
            if (string != null) continue;
        }
        return null;
    }

    public Class_ii_9b427eda tq() {
        return this.CtPwV;
    }

    public static void tD(String string) {
        mqOlJ = string;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean sE(double d, double d2) {
        long l = smakX ^ 0x4FBB3A4E0FB1L;
        String string = Class_az_a4990dcf.tE();
        boolean bl = this.tSjBL;
        if (string != null) {
            if (!bl) return false;
            bl = this.VtZUv;
        }
        if (string != null) {
            if (bl) return false;
            bl = this.tf();
        }
        if (string != null) {
            if (!bl) return false;
            bl = Class_jf_d1c4f950.bAE(d, d2, this.MCnYt, this.pNyTQ, this.BcpIo, this.WjISQ);
        }
        if (string == null) return bl;
        if (!bl) return false;
        return true;
    }

    public int sN() {
        return this.mXtVF;
    }

    public Class_az_a4990dcf sP(int n) {
        this.eWYPl = n;
        return this;
    }

    public Class_az_a4990dcf tu() {
        return this.DjJTP;
    }

    public long tA() {
        return this.tnbQU;
    }

    public float kN() {
        return this.BcpIo;
    }

    public void sA(Class_f_2512a74f class_f_2512a74f) {
    }

    /*
     * Unable to fully structure code
     */
    public void sC(Class_h_d59300d0 var1_1) {
        var2_2 = Class_az_a4990dcf.smakX ^ 29029992521302L;
        var4_3 = Class_az_a4990dcf.tE();
        v0 = Class_az_rU_d532d676.WjdnF[var1_1.bF().ordinal()];
        if (var4_3 == null) ** GOTO lbl8
        switch (v0) {
            case 1: {
                v0 = (int)this.dm(var1_1.bG(), var1_1.bH(), var1_1.bI());
lbl8:
                // 2 sources

                if (v0 == 0) break;
                var1_1.bE();
                if (var4_3 != null) break;
            }
            case 2: {
                if (!this.eK(var1_1.bJ())) break;
                var1_1.bE();
                break;
            }
        }
    }

    public Class_az_a4990dcf sR(boolean bl) {
        this.oTiGT = bl;
        return this;
    }

    /*
     * Unable to fully structure code
     */
    protected Class_az_a4990dcf sG(double var1_1, double var3_2, Class_lc_b8480f87 var5_3) {
        block17: {
            block19: {
                block21: {
                    block20: {
                        block18: {
                            var6_4 = Class_az_a4990dcf.smakX ^ 99531503222200L;
                            var8_5 = Class_az_a4990dcf.tE();
                            if (!this.tSjBL) {
                                return null;
                            }
                            v0 = var5_3;
                            if (var8_5 != null) {
                                if (v0 != null) {
                                    v0 = var5_3;
                                    if (var8_5 != null) {
                                        if (!v0.bXD(var1_1, var3_2)) {
                                            return null;
                                        } else {
                                            ** GOTO lbl-1000
                                        }
                                    }
                                } else lbl-1000:
                                // 3 sources

                                {
                                    v0 = var5_3;
                                }
                            }
                            var9_6 = v0;
                            v1 = this.oTiGT;
                            if (var8_5 == null) break block18;
                            if (!v1) break block19;
                            v1 = this.tf();
                        }
                        if (!v1) break block19;
                        v2 = var9_6;
                        if (var8_5 != null) {
                            v2 = v2 == null ? this.td() : this.sH(var9_6, this.td());
                        }
                        var9_6 = v2;
                        v3 = var9_6.bXD(var1_1, var3_2);
                        if (var8_5 == null) break block20;
                        if (v3) break block19;
                        v4 = this;
                        if (var8_5 == null) break block21;
                        v3 = v4.sE(var1_1, var3_2);
                    }
                    v4 = v3 != false ? this : null;
                }
                return v4;
            }
            var10_7 = new ArrayList<Class_az_a4990dcf>(this.gJoaC.cmj());
            var10_7.sort(Class_az_a4990dcf.VjGAm.reversed());
            for (Class_az_a4990dcf var12_9 : var10_7) {
                block23: {
                    block22: {
                        v5 = var13_10 = var12_9.sG(var1_1, var3_2, var9_6);
                        if (var8_5 == null) break block17;
                        if (var8_5 == null) break block22;
                        if (v5 == null) break block23;
                        v6 = var13_10;
                    }
                    return v6;
                }
                if (var8_5 != null) continue;
            }
            v5 = this;
        }
        if (var8_5 != null) {
            v5 = v5.sE(var1_1, var3_2) != false ? this : null;
        }
        return v5;
    }

    public boolean oi() {
        return false;
    }

    public Class_az_a4990dcf sL() {
        Class_az_a4990dcf class_az_a4990dcf;
        block2: {
            long l = smakX ^ 0x6502A3E6CAAFL;
            Class_az_a4990dcf class_az_a4990dcf2 = this;
            String string = Class_az_a4990dcf.tE();
            while (class_az_a4990dcf2.DjJTP != null) {
                class_az_a4990dcf = class_az_a4990dcf2.DjJTP;
                if (string != null) {
                    class_az_a4990dcf2 = class_az_a4990dcf;
                    if (string != null) continue;
                }
                break block2;
            }
            class_az_a4990dcf = class_az_a4990dcf2;
        }
        return class_az_a4990dcf;
    }

    public Class_az_a4990dcf sT(boolean bl) {
        this.PGAcs = bl;
        return this;
    }

    public static String tE() {
        return mqOlJ;
    }

    public void sD(Class_h_d59300d0 class_h_d59300d0) {
    }

    public void sU() {
        block3: {
            Class_g_bd7b3df3 class_g_bd7b3df3;
            block2: {
                long l = smakX ^ 0x710241FD0F09L;
                Class_g_bd7b3df3 class_g_bd7b3df32 = Class_g_bd7b3df3.aD();
                String string = Class_az_a4990dcf.tE();
                class_g_bd7b3df3 = class_g_bd7b3df32;
                if (string == null) break block2;
                if (class_g_bd7b3df3 == null) break block3;
                class_g_bd7b3df3 = class_g_bd7b3df32;
            }
            class_g_bd7b3df3.aU(this);
        }
    }

    public Class_az_a4990dcf sI(Class_az_a4990dcf class_az_a4990dcf) {
        Class_az_a4990dcf class_az_a4990dcf2;
        String string;
        block7: {
            block8: {
                Class_az_a4990dcf class_az_a4990dcf3;
                block5: {
                    block6: {
                        long l = smakX ^ 0x732442AC1E9L;
                        string = Class_az_a4990dcf.tE();
                        class_az_a4990dcf3 = class_az_a4990dcf;
                        if (string == null) break block5;
                        if (class_az_a4990dcf3 == null) break block6;
                        class_az_a4990dcf3 = class_az_a4990dcf;
                        if (string == null) break block5;
                        if (class_az_a4990dcf3 == this) break block6;
                        class_az_a4990dcf2 = this;
                        if (string == null) break block7;
                        if (!class_az_a4990dcf2.gJoaC.contains(class_az_a4990dcf)) break block8;
                    }
                    class_az_a4990dcf3 = this;
                }
                return class_az_a4990dcf3;
            }
            class_az_a4990dcf2 = class_az_a4990dcf.DjJTP;
        }
        if (string != null) {
            if (class_az_a4990dcf2 != null) {
                class_az_a4990dcf.DjJTP.gJoaC.remove(class_az_a4990dcf);
            }
            class_az_a4990dcf.DjJTP = this;
            this.gJoaC.add(class_az_a4990dcf);
            class_az_a4990dcf2 = this;
        }
        return class_az_a4990dcf2;
    }

    public void sV() {
        block3: {
            Class_g_bd7b3df3 class_g_bd7b3df3;
            block2: {
                long l = smakX ^ 0x5E4C8A5034BAL;
                Class_g_bd7b3df3 class_g_bd7b3df32 = Class_g_bd7b3df3.aD();
                String string = Class_az_a4990dcf.tE();
                class_g_bd7b3df3 = class_g_bd7b3df32;
                if (string == null) break block2;
                if (class_g_bd7b3df3 == null) break block3;
                class_g_bd7b3df3 = class_g_bd7b3df32;
            }
            class_g_bd7b3df3.aW(this);
        }
    }

    public Class_az_a4990dcf sJ(Class_az_a4990dcf class_az_a4990dcf) {
        long l = smakX ^ 0x495D129D4B3AL;
        String string = Class_az_a4990dcf.tE();
        Class_az_a4990dcf class_az_a4990dcf2 = class_az_a4990dcf;
        if (string != null) {
            if (class_az_a4990dcf2 == null) {
                return this;
            }
            class_az_a4990dcf2 = this;
        }
        if (string != null) {
            if (class_az_a4990dcf2.gJoaC.remove(class_az_a4990dcf)) {
                class_az_a4990dcf.DjJTP = null;
            }
            class_az_a4990dcf2 = this;
        }
        return class_az_a4990dcf2;
    }

    public Class_az_a4990dcf sY(float f, float f2, float f3, float f4) {
        this.MCnYt = f;
        this.pNyTQ = f2;
        this.BcpIo = f3;
        this.WjISQ = f4;
        return this;
    }

    public void su(Class_lC_5322e8cf class_lC_5322e8cf) {
        long l = smakX ^ 0xFF01DA78A9BL;
        String string = Class_az_a4990dcf.tE();
        Class_az_a4990dcf class_az_a4990dcf = this;
        if (string != null) {
            if (class_az_a4990dcf.nZ()) {
                Class_ay_c070a086.sq(this, () -> this.sv(class_lC_5322e8cf));
                return;
            }
            class_az_a4990dcf = this;
        }
        class_az_a4990dcf.sv(class_lC_5322e8cf);
    }

    public Class_az_a4990dcf sZ(Class_lc_b8480f87 class_lc_b8480f87) {
        this.MCnYt = class_lc_b8480f87.bXF();
        this.pNyTQ = class_lc_b8480f87.bXG();
        this.BcpIo = class_lc_b8480f87.bXH();
        this.WjISQ = class_lc_b8480f87.bXI();
        return this;
    }

    public Class_az_a4990dcf sF(double d, double d2) {
        return this.sG(d, d2, null);
    }

    public Class_az_a4990dcf sK() {
        block2: {
            long l = smakX ^ 0x6D60CA1CAA8CL;
            Iterator<Class_az_a4990dcf> iterator = this.gJoaC.cmj().iterator();
            String string = Class_az_a4990dcf.tE();
            while (iterator.hasNext()) {
                Class_az_a4990dcf class_az_a4990dcf = iterator.next();
                class_az_a4990dcf.DjJTP = null;
                if (string != null) {
                    if (string != null) continue;
                }
                break block2;
            }
            this.gJoaC.clear();
        }
        return this;
    }

    public Class_az_a4990dcf sO(int n) {
        this.mXtVF = Math.max(0, n);
        return this;
    }

    public Class_az_a4990dcf sQ(boolean bl) {
        this.tSjBL = bl;
        return this;
    }

    protected boolean nZ() {
        return false;
    }

    public Class_az_a4990dcf sW(float f, float f2) {
        this.MCnYt = f;
        this.pNyTQ = f2;
        return this;
    }

    public Class_az_a4990dcf sX(float f, float f2) {
        this.BcpIo = f;
        this.WjISQ = f2;
        return this;
    }

    private static MatchException tF(MatchException matchException) {
        return matchException;
    }
}

