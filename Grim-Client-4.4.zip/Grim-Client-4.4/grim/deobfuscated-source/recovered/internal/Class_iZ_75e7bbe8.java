/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.text.Text
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import recovered.core.NativeLoader;

public class Class_iZ_75e7bbe8 {
    private static Pattern SUbYg;
    private static long ggewT;
    private static String[] bWjiG;
    private static String[] esHGA;
    private static Map XvLvS;
    private static long[] wjwIg;
    private static Integer[] gzxDQ;
    private static Map tVVDD;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_iZ_75e7bbe8.class);
        Class_iZ_75e7bbe8._6f9fd9a2611811fe6f648e44740320a9();
    }

    private static native void _6f9fd9a2611811fe6f648e44740320a9();

    public static native LocalDate byr(List<String> var0);

    public static native List<String> byp(ItemStack var0);

    public static native List<Text> byn(ItemStack var0);

    private static native LocalDate bys(String var0);

    private static native int byt(int var0, int var1);

    public static native boolean byq(Text var0);

    public static native List<String> byo(ItemStack var0);

    private static native LocalDate byu(int var0, int var1, int var2, int var3);

    private static native String byx(int var0, long var1);

    private static native int byB(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native RuntimeException byv(RuntimeException var0);

    private static native int byA(int var0, long var1);

    private static native String byw(byte[] var0);

    private static native CallSite byC(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native Object byy(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite byz(MethodHandles.Lookup var0, String var1, MethodType var2);
}

