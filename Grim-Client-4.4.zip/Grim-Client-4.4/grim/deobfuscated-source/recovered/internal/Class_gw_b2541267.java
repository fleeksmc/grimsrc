/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_hH_ae8f8f77;
import recovered.internal.Class_mF_189ad7bc;

public class Class_gw_b2541267
extends Class_hH_ae8f8f77 {
    private Class_mF_189ad7bc KefNs;
    private boolean KnRQq;
    private boolean mQKQb;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gw_b2541267(Class_mF_189ad7bc class_mF_189ad7bc, boolean bl, boolean bl2) {
        this.KefNs = class_mF_189ad7bc;
        this.KnRQq = bl;
        this.mQKQb = bl2;
    }

    public Class_mF_189ad7bc bbw() {
        return this.KefNs;
    }

    public void bbB(boolean bl) {
        this.mQKQb = bl;
    }

    public boolean bbx() {
        return this.KnRQq;
    }

    public void bbA(boolean bl) {
        this.KnRQq = bl;
    }

    public void bbz(Class_mF_189ad7bc class_mF_189ad7bc) {
        this.KefNs = class_mF_189ad7bc;
    }

    public boolean bby() {
        return this.mQKQb;
    }
}

