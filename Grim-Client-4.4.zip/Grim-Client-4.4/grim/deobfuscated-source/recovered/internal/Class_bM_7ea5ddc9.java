/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.network.AbstractClientPlayerEntity
 *  net.minecraft.entity.player.PlayerEntity
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import recovered.core.ClientMain;
import recovered.internal.Class_bJ_24f874fc;
import recovered.internal.Class_bS_979bca5c;
import recovered.internal.Class_bU_714b1dad;
import recovered.internal.Class_cv_f4b0140a;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_ii_9b427eda;
import recovered.internal.Class_jf_d1c4f950;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_ld_bb1690e1;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mr_7eac5189;
import recovered.modules.NameProtectModule;
import recovered.modules.TargetLockModule;

public class Class_bM_7ea5ddc9
extends Class_bS_979bca5c {
    private PlayerEntity BChTb;
    private static final long wgjAG;
    private static final long[] GvhUT;
    private static final Integer[] jriia;
    private static final Map xzNLw;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bM_7ea5ddc9(Class_cv_f4b0140a class_cv_f4b0140a) {
        long l = wgjAG ^ 0xA7E79451652L;
        int[] nArray = new int[Class_bM_7ea5ddc9.Ns("x", (int)31088, (long)(0x4F5DF32B6CC71FAEL ^ l))];
        nArray[0] = (int)Class_bM_7ea5ddc9.Ns("x", (int)21757, (long)(0x7EA2D96F783C3228L ^ l));
        nArray[1] = (int)Class_bM_7ea5ddc9.Ns("x", (int)26933, (long)(0x1FAF96D4BD6D0FFCL ^ l));
        nArray[2] = (int)Class_bM_7ea5ddc9.Ns("x", (int)16993, (long)(0x693D39C625BE24A2L ^ l));
        nArray[3] = (int)Class_bM_7ea5ddc9.Ns("x", (int)4673, (long)(0xE9D3790E194749EL ^ l));
        nArray[4] = (int)Class_bM_7ea5ddc9.Ns("x", (int)15651, (long)(0x51DB779637695BEBL ^ l));
        nArray[5] = (int)Class_bM_7ea5ddc9.Ns("x", (int)22638, (long)(0x2D04158C2618BEBDL ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)17016, (long)(0x27DB96D46A30A4A4L ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)5820, (long)(0x2D13341D9C02F06BL ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)20971, (long)(0x7B056C4C2C61373DL ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)13672, (long)(0x227DCCE10A8A53ADL ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)20827, (long)(0x75FC05AD95DBB79CL ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)12381, (long)(0x48C6F1ACE6435692L ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)9462, (long)(0x5E7DB30B90994236L ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)10684, (long)(0x38A6C565FE02CF66L ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)4165, (long)(0x36E4E30A9154768BL ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)15895, (long)(0x244F866A761158CFL ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)3247, (long)(0x25618FE98069EA4EL ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)15116, (long)(0x72A1CF77714DDDDCL ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)22829, (long)(0x10ABDE99072FBFFCL ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)14690, (long)(0xFBCC0D9F5885F82L ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)9901, (long)(0x7F4AAC9EED584060L ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)10972, (long)(0x66E9D790883B4C05L ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)2578, (long)(0x569F644F939A6CDEL ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)27690, (long)(0x53494D3474BE8AE0L ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)19653, (long)(0x2E4D62E5E946AA1EL ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)31899, (long)(0x3F408B59E33B1A4FL ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)27843, (long)(0x446CA2E39E8F0A05L ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)12269, (long)(0x30A9E6E978DDC930L ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)15841, (long)(0x7A5E797CF79CDB25L ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)31899, (long)(0x3F408B59E33B1A4FL ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)27710, (long)(0x50288D0273918AECL ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)27259, (long)(0x79D8A8CD5C9E8CB0L ^ l));
        nArray[Class_bM_7ea5ddc9.Ns("x", (int)27161, (long)(0x3CFBEA0A1F130CD8L ^ l))] = (int)Class_bM_7ea5ddc9.Ns("x", (int)28505, (long)(0x55BE9B35035D099BL ^ l));
        super(class_cv_f4b0140a, Class_mr_7eac5189.clS(nArray));
    }

    /*
     * Unable to fully structure code
     */
    static {
        block9: {
            block8: {
                Class_bM_7ea5ddc9.wgjAG = Class_gb_9d201141.aYR(492535554697354735L, -6085061503076846657L, MethodHandles.lookup().lookupClass()).a(174947226645567L);
                Class_bM_7ea5ddc9.xzNLw = new HashMap<K, V>(13);
                var0 = Class_bM_7ea5ddc9.wgjAG ^ 57906051530428L;
                var2_1 = Cipher.getInstance("DES/CBC/NoPadding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var8_3 = new long[34];
                var5_4 = 0;
                var6_5 = "Q\u0018\u00d8W\u00f9b\u0002\u00f3\u00f7:m\u00b6\u00b79f\u00a5\u00d5G\u0002T\u00eb\u0013T\u0099\u008b\u0096Zw\u0089:\u000f\u00bb\u00e0\u00f2\u00cd\u000b\u00aa\u00e63!\u0095\u00a4{\u00a2\u001f\u00ac~\u0083\u001cS\u00ec\u00e3U\u0010z\u00ff2\u0012\u00cf\u0004\u00a8'[\u00af\u0098\u001d\u0002\u00db\u00d2x\u00c3/#:\u008d\u0090D\u0093\u00ba'\u0096\u00e9\u00ea\u0080\u00db\u00e9G1NsMD\u008cD\u00f3I\\\u00d5\u009eZ-\u00e1T\u0086v\u001bT\u00e5\u001dA\u00caE\u00e3\u00d8Wrh\u00e1=&&r\u009a]\u00d8;W)C\u00ea.<\u009d\u0090y\u009dj\u008alT\u0013W\u00e1\u00f4\u00e5\u00ce\u0084\u00ddM\u0094b&:U>\u0088\u0086\u00c7\u001b\u0002\u00f2\u008a\u001b\u000f\u00a3mj\u00d0\u00f9\u00c5\u00e9}BQ\u0003~\u00cf\u00c6\u00ff\u00ef|\u008b\u00ac\u008f\u00e1\u0085\u00a3\u00a0\u009a\u0016\u009f\u00bc\u00cf\u00ecO&\u000b\u0003\u00c8\u009b\u00db)\u00fb\u00e9\u00e8\u00ca\u0083\u0091U>\u00aen\u001a\u00e8\u00a7\u00b9\u001e:\u0080\u00bf{\u00df\u00ab`\u00cc\u00de\u00dd\u00f2\u008e\u00cd\u00ce7\u00b0J\u0010?\u001e\u00cdC\u0081n3\u00c5\u0092\u0086.*4\u00fb\u00ce\u00ee\u001d\u00f4\u000b8\u00fd";
                var7_6 = "Q\u0018\u00d8W\u00f9b\u0002\u00f3\u00f7:m\u00b6\u00b79f\u00a5\u00d5G\u0002T\u00eb\u0013T\u0099\u008b\u0096Zw\u0089:\u000f\u00bb\u00e0\u00f2\u00cd\u000b\u00aa\u00e63!\u0095\u00a4{\u00a2\u001f\u00ac~\u0083\u001cS\u00ec\u00e3U\u0010z\u00ff2\u0012\u00cf\u0004\u00a8'[\u00af\u0098\u001d\u0002\u00db\u00d2x\u00c3/#:\u008d\u0090D\u0093\u00ba'\u0096\u00e9\u00ea\u0080\u00db\u00e9G1NsMD\u008cD\u00f3I\\\u00d5\u009eZ-\u00e1T\u0086v\u001bT\u00e5\u001dA\u00caE\u00e3\u00d8Wrh\u00e1=&&r\u009a]\u00d8;W)C\u00ea.<\u009d\u0090y\u009dj\u008alT\u0013W\u00e1\u00f4\u00e5\u00ce\u0084\u00ddM\u0094b&:U>\u0088\u0086\u00c7\u001b\u0002\u00f2\u008a\u001b\u000f\u00a3mj\u00d0\u00f9\u00c5\u00e9}BQ\u0003~\u00cf\u00c6\u00ff\u00ef|\u008b\u00ac\u008f\u00e1\u0085\u00a3\u00a0\u009a\u0016\u009f\u00bc\u00cf\u00ecO&\u000b\u0003\u00c8\u009b\u00db)\u00fb\u00e9\u00e8\u00ca\u0083\u0091U>\u00aen\u001a\u00e8\u00a7\u00b9\u001e:\u0080\u00bf{\u00df\u00ab`\u00cc\u00de\u00dd\u00f2\u008e\u00cd\u00ce7\u00b0J\u0010?\u001e\u00cdC\u0081n3\u00c5\u0092\u0086.*4\u00fb\u00ce\u00ee\u001d\u00f4\u000b8\u00fd".length();
                var4_7 = 0;
                while (true) {
                    var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                    v3 = var8_3;
                    v4 = var5_4++;
                    v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                    v6 = -1;
                    break block8;
                    break;
                }
lbl26:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    var6_5 = "ny\u00bc\u00fd\u00fa=|\u00ca\u00d1\u0014~|z\u00f6\u00e1R";
                    var7_6 = "ny\u00bc\u00fd\u00fa=|\u00ca\u00d1\u0014~|z\u00f6\u00e1R".length();
                    var4_7 = 0;
                    while (true) {
                        var9_8 = var6_5.substring(var4_7, var4_7 += 8).getBytes("ISO-8859-1");
                        v3 = var8_3;
                        v4 = var5_4++;
                        v5 = ((long)var9_8[0] & 255L) << 56 | ((long)var9_8[1] & 255L) << 48 | ((long)var9_8[2] & 255L) << 40 | ((long)var9_8[3] & 255L) << 32 | ((long)var9_8[4] & 255L) << 24 | ((long)var9_8[5] & 255L) << 16 | ((long)var9_8[6] & 255L) << 8 | (long)var9_8[7] & 255L;
                        v6 = 0;
                        break block8;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    v3[v4] = v7;
                    if (var4_7 < var7_6) ** continue;
                    break block9;
                    break;
                }
            }
            var10_9 = v5;
            var12_10 = var2_1.doFinal(new byte[]{(byte)(var10_9 >>> 56), (byte)(var10_9 >>> 48), (byte)(var10_9 >>> 40), (byte)(var10_9 >>> 32), (byte)(var10_9 >>> 24), (byte)(var10_9 >>> 16), (byte)(var10_9 >>> 8), (byte)var10_9});
            v7 = ((long)var12_10[0] & 255L) << 56 | ((long)var12_10[1] & 255L) << 48 | ((long)var12_10[2] & 255L) << 40 | ((long)var12_10[3] & 255L) << 32 | ((long)var12_10[4] & 255L) << 24 | ((long)var12_10[5] & 255L) << 16 | ((long)var12_10[6] & 255L) << 8 | (long)var12_10[7] & 255L;
            switch (v6) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl52:
                // 1 sources

                ** continue;
            }
        }
        Class_bM_7ea5ddc9.GvhUT = var8_3;
        Class_bM_7ea5ddc9.jriia = new Integer[34];
    }

    @Override
    public boolean MH() {
        long l = wgjAG ^ 0x6BD3CFAF5BB1L;
        return this.No() != null;
    }

    private PlayerEntity No() {
        block3: {
            PlayerEntity playerEntity;
            block4: {
                TargetLockModule targetLockModule;
                boolean bl;
                TargetLockModule targetLockModule2;
                block2: {
                    long l = wgjAG ^ 0x556E8D561763L;
                    targetLockModule2 = ClientMain.dlJ().aZx(TargetLockModule.class);
                    bl = Class_bJ_24f874fc.MN();
                    targetLockModule = targetLockModule2;
                    if (bl) break block2;
                    if (!targetLockModule.bag()) break block3;
                    targetLockModule = targetLockModule2;
                }
                playerEntity = targetLockModule.aIU();
                if (bl) break block4;
                if (playerEntity == null) break block3;
                playerEntity = targetLockModule2.aIU();
            }
            return playerEntity;
        }
        return null;
    }

    @Override
    public void MG(Class_lC_5322e8cf class_lC_5322e8cf, Class_ii_9b427eda class_ii_9b427eda) {
        Object object;
        float f;
        String string;
        Class_lq_87a74641 class_lq_87a74641;
        float f2;
        float f3;
        block7: {
            PlayerEntity playerEntity;
            Class_mG_52c8d386 class_mG_52c8d386;
            float f4;
            float f5;
            block6: {
                PlayerEntity playerEntity2;
                long l = wgjAG ^ 0x64D3E7B5617EL;
                PlayerEntity playerEntity3 = this.No();
                boolean bl = Class_bJ_24f874fc.MN();
                PlayerEntity playerEntity4 = playerEntity3;
                if (!bl) {
                    if (playerEntity4 != null) {
                        this.BChTb = playerEntity3;
                    }
                    playerEntity4 = this.BChTb;
                }
                if (playerEntity4 == null) {
                    return;
                }
                Class_bU_714b1dad class_bU_714b1dad = ClientMain.dlK().RC();
                f3 = class_bU_714b1dad.RW();
                f2 = class_bU_714b1dad.RX();
                class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
                string = this.Nn();
                f = 10.0f;
                float f6 = 20.0f + f + class_lq_87a74641.cao(string);
                float f7 = 15.0f;
                this.fGWTH.NU(f6, f7);
                f5 = f3 - 6.0f + 10.0f * this.dExGi.dhj();
                f4 = f2 + Class_jf_d1c4f950.bAH(f, f7);
                class_mG_52c8d386 = Class_mG_52c8d386.hoGuU.cob(255.0f * this.dExGi.dhj());
                playerEntity = playerEntity2 = this.BChTb;
                if (bl) break block6;
                if (!(playerEntity instanceof AbstractClientPlayerEntity)) break block7;
                playerEntity = playerEntity2;
            }
            object = (AbstractClientPlayerEntity)playerEntity;
            class_lC_5322e8cf.ccZ((AbstractClientPlayerEntity)object, f5, f4, f, Class_ld_bb1690e1.all(4.0f), class_mG_52c8d386);
        }
        object = class_ii_9b427eda.bjb();
        float f8 = f3 + 25.0f - 10.0f * this.dExGi.dhj() + f;
        float f9 = f2 + 5.0f;
        class_lC_5322e8cf.cez(class_lq_87a74641, string, f8, f9, (Class_mG_52c8d386)object);
    }

    private static MatchException Np(MatchException matchException) {
        return matchException;
    }

    private static CallSite Ns(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_bM_7ea5ddc9" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private String Nn() {
        long l = wgjAG ^ 0x1105649FF122L;
        String string = this.BChTb.getGameProfile().name();
        if (this.BChTb == ClientMain.dlmvG.player) {
            string = ClientMain.dlJ().aZx(NameProtectModule.class).aWP(string);
        }
        return string;
    }

    private static int Nr(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        int n2 = Class_bM_7ea5ddc9.Nq(n, l);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n2;
    }

    private static int Nq(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x3324;
        if (jriia[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l >>> 56), (byte)(l >>> 48), (byte)(l >>> 40), (byte)(l >>> 32), (byte)(l >>> 24), (byte)(l >>> 16), (byte)(l >>> 8), (byte)l};
            long l2 = GvhUT[n2];
            byte[] byArray3 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            Long l3 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])xzNLw.get(l3);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    xzNLw.put(l3, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_bM_7ea5ddc9", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Class_bM_7ea5ddc9.jriia[n2] = n3;
        }
        return jriia[n2];
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_bM_7ea5ddc9.class, "Nr", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

