/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import recovered.core.ModuleBase;
import recovered.core.NativeLoader;
import recovered.internal.Class_J_da829033;
import recovered.internal.Class_ab_035d8734;
import recovered.internal.Class_aj_95d0a719;
import recovered.internal.Class_bg_0a91641c;
import recovered.internal.Class_gc_4c0dfe20;
import recovered.internal.Class_jb_fa6e084e;
import recovered.internal.Class_lC_5322e8cf;
import recovered.internal.Class_lE_06fbe260;
import recovered.internal.Class_lq_87a74641;
import recovered.internal.Class_mA_32d8a5f2;
import recovered.internal.Class_rj_b691f4f7;
import recovered.internal.Class_rk_bf8630d1;

public class Class_bh_f2f50881
extends Class_aj_95d0a719 {
    private Class_J_da829033 uWBQz;
    private final Class_ab_035d8734 aYcjN;
    private final Class_ab_035d8734 GluTT;
    private final Class_rk_bf8630d1 qNHZV;
    private final Class_rk_bf8630d1 ENqLr;
    private final ModuleBase puHqY;
    private static long iyHFM;
    private static String[] VhSun;
    private static String[] GKLQn;
    private static Map YBvpH;
    private static long[] lTlRr;
    private static Integer[] dpRyX;
    private static Map DUMCq;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_bh_f2f50881(float f, float f2, float f3, ModuleBase moduleBase) {
        Object object;
        Class_lq_87a74641 class_lq_87a74641;
        long l;
        block6: {
            int n;
            block4: {
                Class_gc_4c0dfe20 class_gc_4c0dfe20;
                block5: {
                    l = iyHFM ^ 0x4E3EAD020B78L;
                    super(f, f2, 110.0f, 80.0f);
                    this.IzFhM = f3;
                    this.puHqY = moduleBase;
                    this.GluTT = new Class_ab_035d8734(moduleBase.bai()).li(arg_0 -> Class_bh_f2f50881.Dm(moduleBase, arg_0));
                    this.aYcjN = new Class_ab_035d8734(moduleBase.baj()).li(arg_0 -> Class_bh_f2f50881.Dl(moduleBase, arg_0));
                    this.ENqLr = new Class_rk_bf8630d1((int)Class_bh_f2f50881.Du("s", (int)26729, (long)(0x776D151C40F0590DL ^ l)), this.BcpIo).dhs(Class_rj_b691f4f7.NJlxm);
                    int n2 = Class_bg_0a91641c.Dd();
                    class_lq_87a74641 = Class_lE_06fbe260.WTzbi.bYM(7.0f);
                    class_gc_4c0dfe20 = moduleBase.baf();
                    try {
                        try {
                            n = class_gc_4c0dfe20.aZf();
                            if (n2 != 0) break block4;
                            if (n == 0) break block5;
                        }
                        catch (MatchException matchException) {
                            throw Class_bh_f2f50881.Dn(matchException);
                        }
                        object = Class_bh_f2f50881.Dr("y", (int)21931, (long)(0x60B2B913D1E85213L ^ l));
                        break block6;
                    }
                    catch (MatchException matchException) {
                        throw Class_bh_f2f50881.Dn(matchException);
                    }
                }
                n = class_gc_4c0dfe20.aZh();
            }
            object = Class_jb_fa6e084e.byM(n);
        }
        String string = object;
        float f4 = class_lq_87a74641.cao(string) + 7.0f;
        this.qNHZV = new Class_rk_bf8630d1((int)Class_bh_f2f50881.Du("s", (int)11925, (long)(0x7060D01806E01FF0L ^ l)), f4).dhs(Class_rj_b691f4f7.UPXqT);
        this.BcpIo = Math.max(110.0f, this.bQoPs + class_lq_87a74641.cao((String)((Object)Class_bh_f2f50881.Dr("y", (int)16278, (long)(0x254CDC4423A6B829L ^ l)))) + this.bQoPs + f4 + this.bQoPs);
        this.FHbTC = true;
    }

    static {
        NativeLoader.doInit(Class_bh_f2f50881.class);
        Class_bh_f2f50881._e08a76d36db0a6ffacf3e754f4e33af5();
    }

    @Override
    public native boolean dk(double var1, double var3, Class_mA_32d8a5f2 var5);

    @Override
    protected native void bV(Class_lC_5322e8cf var1);

    private static native void _e08a76d36db0a6ffacf3e754f4e33af5();

    private static native int Dt(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native String Dp(int var0, long var1);

    private static native Object Dq(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private native void Dj(double var1, double var3);

    private static native MatchException Dn(MatchException var0);

    private static native String Do(byte[] var0);

    private native /* synthetic */ void Dk(Class_lC_5322e8cf var1);

    private static native CallSite Dr(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native int Ds(int var0, long var1);

    private static native CallSite Du(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native /* synthetic */ void Dl(ModuleBase var0, Class_ab_035d8734 var1);

    private static native /* synthetic */ void Dm(ModuleBase var0, Class_ab_035d8734 var1);
}

