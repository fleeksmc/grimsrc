/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.MethodHandles;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_gb_9d201141;

public final class Class_i_a489cc15
extends Enum<Class_i_a489cc15> {
    public static final /* enum */ Class_i_a489cc15 YdJtr;
    public static final /* enum */ Class_i_a489cc15 nKqnf;
    public static final /* enum */ Class_i_a489cc15 pEktq;
    private static final /* synthetic */ Class_i_a489cc15[] VbUZk;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    /*
     * Enabled aggressive block sorting
     */
    static {
        long l = Class_gb_9d201141.aYR(3519216035421042107L, 1378465119140037046L, MethodHandles.lookup().lookupClass()).a(246949947571654L) ^ 0x4DD4BC22E834L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l >>> 56);
        for (int i = 1; i < 8; ++i) {
            byArray2 = byArray2;
            byArray2[i] = (byte)(l << i * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[3];
        int n = 0;
        String string = "\u00a3.\fJ\f\u008c\u00d5\u008c\b)\u0084\u00d9\u00e6\u009b\u00ea\u0007\u0006\bPV\u00d9\u00ea\u00ea=\u00da/";
        int n2 = "\u00a3.\fJ\f\u008c\u00d5\u008c\b)\u0084\u00d9\u00e6\u009b\u00ea\u0007\u0006\bPV\u00d9\u00ea\u00ea=\u00da/".length();
        int n3 = 8;
        int n4 = -1;
        while (true) {
            int n5 = ++n4;
            byte[] byArray3 = cipher.doFinal(string.substring(n5, n5 + n3).getBytes("ISO-8859-1"));
            stringArray[n++] = Class_i_a489cc15.bS(byArray3).intern();
            if ((n4 += n3) >= n2) {
                YdJtr = new Class_i_a489cc15();
                nKqnf = new Class_i_a489cc15();
                pEktq = new Class_i_a489cc15();
                VbUZk = Class_i_a489cc15.bR();
                return;
            }
            n3 = string.charAt(n4);
        }
    }

    public static Class_i_a489cc15[] values() {
        return (Class_i_a489cc15[])VbUZk.clone();
    }

    public static Class_i_a489cc15 valueOf(String string) {
        return Enum.valueOf(Class_i_a489cc15.class, string);
    }

    private static /* synthetic */ Class_i_a489cc15[] bR() {
        return new Class_i_a489cc15[]{YdJtr, nKqnf, pEktq};
    }

    private static String bS(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }
}

