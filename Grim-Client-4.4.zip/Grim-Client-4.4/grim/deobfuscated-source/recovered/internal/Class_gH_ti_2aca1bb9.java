/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_gH_109f8392;

public class Class_gH_ti_2aca1bb9
extends Class_gH_109f8392 {
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;
}

