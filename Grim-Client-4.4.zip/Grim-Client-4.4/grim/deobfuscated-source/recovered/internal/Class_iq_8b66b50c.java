/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import recovered.core.NativeLoader;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_il_0e543c73;
import recovered.internal.Class_im_0fce3469;
import recovered.internal.Class_in_57efefb0;
import recovered.internal.Class_ip_62d4a8dd;
import recovered.internal.Class_ir_8e0d90e0;
import recovered.internal.Class_iu_bf2db566;
import recovered.internal.Class_iv_eaeaeb9a;

public class Class_iq_8b66b50c {
    private Class_in_57efefb0 lsCzm;
    private final Class_ip_62d4a8dd Logfc;
    private final Class_il_0e543c73 dgdgv;
    private final Class_iv_eaeaeb9a RBLhk;
    private final String PDCrp;
    private boolean iYzgC;
    private static boolean xZxfr;
    private static long yDzoy;
    private static String[] unsdy;
    private static String[] MFDwi;
    private static Map Rubgn;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_iq_8b66b50c(Class_il_0e543c73 class_il_0e543c73, Class_iv_eaeaeb9a class_iv_eaeaeb9a) {
        block4: {
            boolean bl;
            block6: {
                block5: {
                    long l = yDzoy ^ 0x4BACC1AFE17DL;
                    this.lsCzm = Class_in_57efefb0.FBjZE;
                    boolean bl2 = Class_iq_8b66b50c.bmv();
                    try {
                        try {
                            this.PDCrp = Class_iq_8b66b50c.bmA("o", (int)6878, (long)(0x52ADE20D4A33625EL ^ l));
                            this.iYzgC = false;
                            this.dgdgv = class_il_0e543c73;
                            this.RBLhk = class_iv_eaeaeb9a;
                            this.Logfc = new Class_ip_62d4a8dd();
                            class_iv_eaeaeb9a.bnI(this::blH);
                            if (Class_iS_888f260e.bwL() != null) break block4;
                            if (!bl2) break block5;
                        }
                        catch (MatchException matchException) {
                            throw Class_iq_8b66b50c.bmw(matchException);
                        }
                        bl = false;
                        break block6;
                    }
                    catch (MatchException matchException) {
                        throw Class_iq_8b66b50c.bmw(matchException);
                    }
                }
                bl = true;
            }
            Class_iq_8b66b50c.bmt(bl);
        }
    }

    static {
        NativeLoader.doInit(Class_iq_8b66b50c.class);
        Class_iq_8b66b50c._d9ce10a827bf62b322c566465ff2cb7c();
    }

    private native /* synthetic */ void bmf(Class_in_57efefb0 var1);

    private static native /* synthetic */ void bmr();

    private native /* synthetic */ List bms(List var1);

    private native /* synthetic */ void bmn(Class_ir_8e0d90e0 var1);

    public native void blX(boolean var1);

    public native Class_in_57efefb0 blM(Class_in_57efefb0 var1);

    public native String bmb();

    public native Class_il_0e543c73 blZ();

    public native CompletableFuture<Boolean> blQ(Class_in_57efefb0 var1);

    public native void blK(Class_in_57efefb0 var1);

    private native /* synthetic */ Class_ir_8e0d90e0 bmi(Class_ir_8e0d90e0 var1);

    private static native CallSite bmA(MethodHandles.Lookup var0, String var1, MethodType var2);

    private native /* synthetic */ CompletionStage bmh(String var1, Class_ir_8e0d90e0 var2);

    private native /* synthetic */ void bml(Class_ir_8e0d90e0 var1, Class_in_57efefb0 var2);

    public native CompletableFuture<Boolean> blO(Class_in_57efefb0 var1);

    private native String blS(String var1);

    private native void blH();

    public native void blW(Class_in_57efefb0 var1);

    private native /* synthetic */ Boolean bmg(Class_iu_bf2db566 var1);

    private native /* synthetic */ Class_ir_8e0d90e0 bmm(Class_ir_8e0d90e0 var1);

    private static native /* synthetic */ List bmq(Throwable var0);

    public static native boolean bmu();

    public native CompletableFuture<Class_ir_8e0d90e0> blN(int[] var1);

    private static native String bmy(int var0, long var1);

    private native /* synthetic */ Boolean bme(Class_in_57efefb0 var1, Class_iu_bf2db566 var2);

    private static native Object bmz(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native MatchException bmw(MatchException var0);

    public native boolean blL(Class_in_57efefb0 var1);

    private native boolean blT(String var1);

    private static native String bmx(byte[] var0);

    public native CompletableFuture<List<Class_ir_8e0d90e0>> blG();

    private native void blI(List<Class_ir_8e0d90e0> var1);

    private native void blJ();

    public native Class_ip_62d4a8dd blY();

    public native boolean bmc();

    private native Class_im_0fce3469 blV(Class_im_0fce3469 var1);

    public static native boolean bmv();

    private native Class_in_57efefb0 blU(String var1);

    public native Class_iv_eaeaeb9a bma();

    public static native void bmt(boolean var0);

    private native /* synthetic */ void bmj(Class_ir_8e0d90e0 var1);

    public native CompletableFuture<Boolean> blP(String var1);

    private native /* synthetic */ Boolean bmk(Class_ir_8e0d90e0 var1, Class_in_57efefb0 var2, Class_iu_bf2db566 var3);

    private native /* synthetic */ CompletionStage bmo(Class_ir_8e0d90e0 var1);

    private static native /* synthetic */ Class_ir_8e0d90e0 bmp(Class_ir_8e0d90e0 var0, Class_iu_bf2db566 var1);

    private static native void _d9ce10a827bf62b322c566465ff2cb7c();

    public native Class_in_57efefb0 bmd();

    public native Class_im_0fce3469 blR(float var1);
}

