/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_oH_f9b939d8;

final class Class_fx_sT_e79d0b57
extends Record {
    private final Class_oH_f9b939d8 slot;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public native Class_oH_f9b939d8 slot();

    private Class_fx_sT_e79d0b57(Class_oH_f9b939d8 class_oH_f9b939d8) {
        this.slot = class_oH_f9b939d8;
    }

    static {
        NativeLoader.doInit(Class_fx_sT_e79d0b57.class);
    }

    @Override
    public final native boolean equals(Object var1);

    @Override
    public final native String toString();

    @Override
    public final native int hashCode();

    private native int interactionSlot();
}

