/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityType
 */
package recovered.internal;

import com.google.gson.JsonElement;
import java.lang.invoke.MethodHandles;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_jg_83a87f1c;
import recovered.internal.Class_jg_tJ_fb687149;
import recovered.internal.Class_mr_7eac5189;

public class Class_cF_8338f0f7
extends Class_cB_67aec11c {
    private Set<EntityType<? extends Entity>> AcnID = new LinkedHashSet<EntityType<? extends Entity>>();
    private Set<EntityType<? extends Entity>> sulLA = new LinkedHashSet<EntityType<? extends Entity>>();
    private static final long MRNxb = Class_gb_9d201141.aYR(239314320164638091L, -21656609510465895L, MethodHandles.lookup().lookupClass()).a(162609858617285L);
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cF_8338f0f7(Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_mr_7eac5189);
        this.sulLA.add((EntityType<? extends Entity>)EntityType.PLAYER);
    }

    public Class_cF_8338f0f7(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    public Class_cF_8338f0f7 VS(Class_jg_tJ_fb687149 class_jg_tJ_fb687149) {
        long l = MRNxb ^ 0x53A0881DB5BAL;
        Set<EntityType<? extends Entity>> set = switch (class_jg_tJ_fb687149) {
            case Class_jg_tJ_fb687149.frJIr -> Class_jg_83a87f1c.fbEDU;
            case Class_jg_tJ_fb687149.OCdZM -> Class_jg_83a87f1c.skTlu;
            default -> Class_jg_83a87f1c.hZYeV;
        };
        this.AcnID.clear();
        this.AcnID.addAll(set);
        return this;
    }

    public void VU(EntityType<? extends Entity> entityType) {
        block3: {
            Class_cF_8338f0f7 class_cF_8338f0f7;
            block2: {
                long l = MRNxb ^ 0x91ECBAA929EL;
                boolean bl = Class_cB_67aec11c.Vt();
                class_cF_8338f0f7 = this;
                if (!bl) break block2;
                if (!class_cF_8338f0f7.sulLA.add(entityType)) break block3;
                class_cF_8338f0f7 = this;
            }
            class_cF_8338f0f7.Vk();
        }
    }

    public Set<EntityType<? extends Entity>> VZ() {
        return this.sulLA;
    }

    public Class_cF_8338f0f7 Wb(Set<EntityType<? extends Entity>> set) {
        this.sulLA = set;
        return this;
    }

    public Set<EntityType<? extends Entity>> VY() {
        return this.AcnID;
    }

    @Override
    public void SS(JsonElement jsonElement) {
        block13: {
            boolean bl;
            Set<EntityType<? extends Entity>> set;
            LinkedHashSet<EntityType<? extends Entity>> linkedHashSet;
            block10: {
                long l = MRNxb ^ 0x35999075919L;
                linkedHashSet = new LinkedHashSet<EntityType<? extends Entity>>();
                Iterator iterator = jsonElement.getAsJsonArray().iterator();
                boolean bl2 = Class_cB_67aec11c.Vt();
                block0: while (true) {
                    boolean bl3 = iterator.hasNext();
                    block1: while (bl3) {
                        JsonElement jsonElement2 = (JsonElement)iterator.next();
                        String string = jsonElement2.getAsString();
                        set = this.AcnID;
                        if (!bl2) break block10;
                        for (EntityType<? extends Entity> entityType : set) {
                            block12: {
                                block11: {
                                    bl3 = entityType.getName().getString().equals(string);
                                    if (!bl2) continue block1;
                                    if (!bl2) break block11;
                                    if (!bl3) break block12;
                                    linkedHashSet.add(entityType);
                                }
                                if (bl2) continue block0;
                            }
                            if (bl2) continue;
                        }
                        if (bl2) continue block0;
                    }
                    break;
                }
                bl = linkedHashSet.equals(this.sulLA);
                if (!bl2) break block13;
                if (bl) {
                    return;
                }
                this.sulLA.clear();
                set = this.sulLA;
            }
            bl = set.addAll(linkedHashSet);
        }
        this.Vk();
    }

    @SafeVarargs
    public final Class_cF_8338f0f7 VT(EntityType<? extends Entity> ... entityTypeArray) {
        this.AcnID.addAll(Set.of(entityTypeArray));
        return this;
    }

    public void VV(EntityType<? extends Entity> entityType) {
        block3: {
            Class_cF_8338f0f7 class_cF_8338f0f7;
            block2: {
                long l = MRNxb ^ 0x47DE1DA3E3L;
                boolean bl = Class_cB_67aec11c.Vu();
                class_cF_8338f0f7 = this;
                if (bl) break block2;
                if (!class_cF_8338f0f7.sulLA.remove(entityType)) break block3;
                class_cF_8338f0f7 = this;
            }
            class_cF_8338f0f7.Vk();
        }
    }

    public boolean VW(EntityType<? extends Entity> entityType) {
        return this.sulLA.contains(entityType);
    }

    private static MatchException Wd(MatchException matchException) {
        return matchException;
    }

    public Class_cF_8338f0f7 Wa(Set<EntityType<? extends Entity>> set) {
        this.AcnID = set;
        return this;
    }

    @Override
    public void SR(Map<String, Object> map) {
        Set set = this.sulLA.stream().map(entityType -> entityType.getName().getString()).collect(Collectors.toSet());
        map.put(Arrays.toString(this.NwlSF), set);
    }

    public boolean VX(Entity entity) {
        boolean bl;
        block4: {
            block5: {
                boolean bl2;
                block2: {
                    block3: {
                        long l = MRNxb ^ 0x76684FEE9B47L;
                        boolean bl3 = Class_cB_67aec11c.Vt();
                        bl2 = this.sulLA.isEmpty();
                        if (!bl3) break block2;
                        if (bl2) break block3;
                        bl = this.AcnID.contains(entity.getType());
                        if (!bl3) break block4;
                        if (bl) break block5;
                    }
                    bl2 = false;
                }
                return bl2;
            }
            bl = this.sulLA.contains(entity.getType());
        }
        return bl;
    }
}

