/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;
import recovered.internal.Class_gh_ecfd0cde;

public class Class_gf_c6fc2a98 {
    private final int KWKUa;
    private final boolean wFlUm;
    private final Class_gh_ecfd0cde pmYfS;
    private int gShLN;
    private boolean RdURd;
    private boolean lJHbl;
    private boolean dpXNd;
    private static String sNxjl;
    private static long cPNqH;
    private static long rgPRv;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    private Class_gf_c6fc2a98(int n, boolean bl, Class_gh_ecfd0cde class_gh_ecfd0cde) {
        long l = cPNqH ^ 0x44D5C7FCB880L;
        this.gShLN = (int)rgPRv;
        this.RdURd = true;
        this.KWKUa = n;
        this.wFlUm = bl;
        this.pmYfS = class_gh_ecfd0cde;
    }

    static {
        NativeLoader.doInit(Class_gf_c6fc2a98.class);
        Class_gf_c6fc2a98._9524245bee0a2041a28295dac8564415();
    }

    public native boolean aZN();

    public native boolean aZT();

    public native boolean aZV();

    public native int aZP();

    public native int aZM();

    public native boolean aZR();

    public native Class_gh_ecfd0cde aZO();

    public static native Class_gf_c6fc2a98 aZL(int var0, boolean var1, Class_gh_ecfd0cde var2);

    public static native String aZY();

    public native Class_gf_c6fc2a98 aZS(boolean var1);

    public static native void aZX(String var0);

    public native Class_gf_c6fc2a98 aZW(boolean var1);

    public native Class_gf_c6fc2a98 aZQ(int var1);

    public native Class_gf_c6fc2a98 aZU(boolean var1);

    private static native void _9524245bee0a2041a28295dac8564415();
}

