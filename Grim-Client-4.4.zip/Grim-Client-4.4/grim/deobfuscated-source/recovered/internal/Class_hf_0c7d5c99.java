/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.entity.BlockEntity
 */
package recovered.internal;

import net.minecraft.block.entity.BlockEntity;
import recovered.internal.Class_hH_ae8f8f77;

public class Class_hf_0c7d5c99
extends Class_hH_ae8f8f77 {
    private BlockEntity RETSo;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_hf_0c7d5c99(BlockEntity blockEntity) {
        this.RETSo = blockEntity;
    }

    public BlockEntity bcy() {
        return this.RETSo;
    }
}

