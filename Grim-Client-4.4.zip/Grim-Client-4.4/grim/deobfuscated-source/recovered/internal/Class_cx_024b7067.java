/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 */
package recovered.internal;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.security.Key;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import recovered.internal.Class_cB_67aec11c;
import recovered.internal.Class_cG_6e1ba021;
import recovered.internal.Class_gb_9d201141;
import recovered.internal.Class_iS_888f260e;
import recovered.internal.Class_mG_52c8d386;
import recovered.internal.Class_mr_7eac5189;

public class Class_cx_024b7067
extends Class_cG_6e1ba021 {
    private boolean rDHjA;
    private static final long ZzviL;
    private static final String[] klIkv;
    private static final String[] bkfAf;
    private static final Map LSeue;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_cx_024b7067(Class_mr_7eac5189 class_mr_7eac5189) {
        super(class_mr_7eac5189);
    }

    public Class_cx_024b7067(Class_iS_888f260e class_iS_888f260e, Class_mr_7eac5189 class_mr_7eac5189) {
        this(class_mr_7eac5189);
        this.Vg(class_iS_888f260e);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Class_cx_024b7067.ZzviL = Class_gb_9d201141.aYR(617550604232887679L, -5656378775418170534L, MethodHandles.lookup().lookupClass()).a(223291670411508L);
                Class_cx_024b7067.LSeue = new HashMap<K, V>(13);
                var0 = Class_cx_024b7067.ZzviL ^ 11499158449864L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[8];
                var7_4 = 0;
                var6_5 = "-\u001a\u00ab\u00a5\u009e$\u00a2=)(\u00dd\t{\u00a3[\u0089 HEr\u00c9\u00cc|\u0084\u00cfu\u00f8\u00cf\u0005\u0006\u00a7\u00e6\u0016NqU.\u00b0-D\u00f0\u00d2\u00a4??\u009c\u0019eO\u0018\u00e899Tu?dQy\u00c74m/G\u00abSN\u00ed=\u00beH\u00c0\u00f8\u00bb\u0010\u00fa\u00df<\u00de\u0011=y\u00f4!\u009fk\u00d2\u00fce/\u001e\u0010~\u00abs\u00d7\u00a0\u00a9\u00cf,=\u00ea\u00c9!u\u00f7\u00f5\u00a6\u0010B\u00be\u0013\u0097rW\u0088fU92<\u00d8]\u009d$";
                var8_6 = "-\u001a\u00ab\u00a5\u009e$\u00a2=)(\u00dd\t{\u00a3[\u0089 HEr\u00c9\u00cc|\u0084\u00cfu\u00f8\u00cf\u0005\u0006\u00a7\u00e6\u0016NqU.\u00b0-D\u00f0\u00d2\u00a4??\u009c\u0019eO\u0018\u00e899Tu?dQy\u00c74m/G\u00abSN\u00ed=\u00beH\u00c0\u00f8\u00bb\u0010\u00fa\u00df<\u00de\u0011=y\u00f4!\u009fk\u00d2\u00fce/\u001e\u0010~\u00abs\u00d7\u00a0\u00a9\u00cf,=\u00ea\u00c9!u\u00f7\u00f5\u00a6\u0010B\u00be\u0013\u0097rW\u0088fU92<\u00d8]\u009d$".length();
                var5_7 = 16;
                var4_8 = -1;
lbl20:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl25:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_cx_024b7067.Uj(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "\u00b5p{\u00a4\r\u0017\u00e4\u000e\u008d\u00a3c\u008c\u00a2B\u00cd\u00db\u0010\u0093>\b\u008f\u0087\u008b@\u00fc\u0085\u00f0\u00fey9\u00e4\u009b\u00c7";
                    var8_6 = "\u00b5p{\u00a4\r\u0017\u00e4\u000e\u008d\u00a3c\u008c\u00a2B\u00cd\u00db\u0010\u0093>\b\u008f\u0087\u008b@\u00fc\u0085\u00f0\u00fey9\u00e4\u009b\u00c7".length();
                    var5_7 = 16;
                    var4_8 = -1;
lbl34:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl39:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Class_cx_024b7067.Uj(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl51:
                // 1 sources

                ** continue;
            }
        }
        Class_cx_024b7067.klIkv = var9_3;
        Class_cx_024b7067.bkfAf = new String[8];
    }

    public Class_cx_024b7067 TW(boolean bl) {
        super.Ub(bl);
        return this;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void SS(JsonElement var1_1) {
        block13: {
            block11: {
                block12: {
                    block10: {
                        block8: {
                            block9: {
                                var2_2 = Class_cx_024b7067.ZzviL ^ 68468231693108L;
                                var4_3 = Class_cB_67aec11c.Vt();
                                v0 = var1_1.isJsonPrimitive();
                                if (!var4_3) break block8;
                                if (!v0) break block9;
                                v0 = var1_1.getAsJsonPrimitive().isBoolean();
                                if (var4_3) {
                                    if (v0) {
                                        this.TT(var1_1.getAsBoolean());
                                        return;
                                    } else {
                                        ** GOTO lbl13
                                    }
                                }
                                break block8;
                            }
                            super.SS(var1_1);
                            v1 = var1_1;
                            if (!var4_3) break block10;
                            v0 = v1.isJsonObject();
                        }
                        if (!v0) {
                            return;
                        }
                        v1 = var1_1;
                    }
                    var5_4 = v1.getAsJsonObject();
                    v2 = var5_4.has((String)Class_cx_024b7067.Um("a", (int)4600, (long)(5459649461606322431L ^ var2_2)));
                    if (!var4_3) break block11;
                    if (!v2) break block12;
                    this.TT(var5_4.get((String)Class_cx_024b7067.Um("a", (int)8421, (long)(9144851149669638631L ^ var2_2))).getAsBoolean());
                    if (var4_3) break block13;
                }
                v2 = var5_4.has((String)Class_cx_024b7067.Um("a", (int)28507, (long)(4810814609095814744L ^ var2_2)));
            }
            if (v2) {
                this.TT(var5_4.get((String)Class_cx_024b7067.Um("a", (int)17028, (long)(2853454483762824064L ^ var2_2))).getAsBoolean());
            }
        }
    }

    @Override
    public void SR(Map<String, Object> map) {
        block0: {
            long l = ZzviL ^ 0x6D3C0AC27E98L;
            boolean bl = Class_cB_67aec11c.Vu();
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty((String)((Object)Class_cx_024b7067.Um("a", (int)8421, (long)(0x7EE95AD2C1833C4BL ^ l))), Boolean.valueOf(this.rDHjA));
            boolean bl2 = bl;
            jsonObject.addProperty((String)((Object)Class_cx_024b7067.Um("a", (int)20886, (long)(0xA7F06CBA9D34D3AL ^ l))), (Number)this.Wg().coh());
            jsonObject.addProperty((String)((Object)Class_cx_024b7067.Um("a", (int)27600, (long)(0xB40A53C2B977779L ^ l))), (Number)this.Wi().coh());
            jsonObject.addProperty((String)((Object)Class_cx_024b7067.Um("a", (int)29235, (long)(0x240AF28279F86E99L ^ l))), Boolean.valueOf(this.Wj()));
            jsonObject.addProperty((String)((Object)Class_cx_024b7067.Um("a", (int)29083, (long)(0x35EEA6B90E5BED36L ^ l))), Boolean.valueOf(this.Wk()));
            map.put(Arrays.toString(this.NwlSF), jsonObject);
            if (!bl2) break block0;
            Class_iS_888f260e.bwK("qfKgSb");
        }
    }

    public Class_cx_024b7067 TY(int n) {
        super.Uc(n);
        return this;
    }

    public Class_cx_024b7067 TZ(Class_mG_52c8d386 class_mG_52c8d386) {
        super.Ue(class_mG_52c8d386);
        return this;
    }

    public Class_cx_024b7067 Ua(int n) {
        super.Ud(n);
        return this;
    }

    private static CallSite Um(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("recovered/internal/Class_cx_024b7067" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static String Uj(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c;
            int n3 = 0xFF & byArray[i];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++i];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (i >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++i];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static String Uk(int n, long l) {
        int n2 = n ^ (int)(l & 0x7FFFL) ^ 0x29AF;
        if (bkfAf[n2] == null) {
            Object[] objectArray;
            try {
                Long l2 = Thread.currentThread().threadId();
                objectArray = (Object[])LSeue.get(l2);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    LSeue.put(l2, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("recovered/internal/Class_cx_024b7067", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = klIkv[n2].getBytes("ISO-8859-1");
            Class_cx_024b7067.bkfAf[n2] = Class_cx_024b7067.Uj(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return bkfAf[n2];
    }

    public Class_cx_024b7067 TV(boolean bl) {
        super.Ug(bl);
        return this;
    }

    private static Object Ul(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l = (Long)objectArray[1];
        String string2 = Class_cx_024b7067.Uk(n, l);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    public Class_cx_024b7067 TS() {
        long l = ZzviL ^ 0x307A6292AA0CL;
        boolean bl = Class_cB_67aec11c.Vu();
        boolean bl2 = this.rDHjA;
        if (!bl) {
            bl2 = !bl2;
        }
        return this.TT(bl2);
    }

    private static MatchException Ui(MatchException matchException) {
        return matchException;
    }

    public Class_cx_024b7067 TX(Class_mG_52c8d386 class_mG_52c8d386) {
        super.Uf(class_mG_52c8d386);
        return this;
    }

    public boolean TR() {
        return this.rDHjA;
    }

    public Class_cx_024b7067 TT(boolean bl) {
        long l = ZzviL ^ 0x4173E8FFC4EAL;
        boolean bl2 = Class_cB_67aec11c.Vt();
        Class_cx_024b7067 class_cx_024b7067 = this;
        if (bl2) {
            if (class_cx_024b7067.rDHjA == bl) {
                return this;
            }
            this.rDHjA = bl;
            this.Vk();
            class_cx_024b7067 = this;
        }
        return class_cx_024b7067;
    }

    public Class_cx_024b7067 TU(boolean bl) {
        super.Uh(bl);
        return this;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Class_cx_024b7067.class, "Ul", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

