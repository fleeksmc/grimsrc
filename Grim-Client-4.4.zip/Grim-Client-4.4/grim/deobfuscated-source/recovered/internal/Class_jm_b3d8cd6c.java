/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.internal.Class_iS_888f260e;

public final class Class_jm_b3d8cd6c {
    private static Class_iS_888f260e[] qMwlV;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public static Class_iS_888f260e[] bDZ() {
        return qMwlV;
    }

    public static void bDY(Class_iS_888f260e[] class_iS_888f260eArray) {
        qMwlV = class_iS_888f260eArray;
    }

    static {
        if (Class_jm_b3d8cd6c.bDZ() == null) {
            Class_jm_b3d8cd6c.bDY(new Class_iS_888f260e[2]);
        }
    }
}

