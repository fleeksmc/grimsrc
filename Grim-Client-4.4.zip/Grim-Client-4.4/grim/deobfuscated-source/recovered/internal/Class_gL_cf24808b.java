/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.packet.Packet
 */
package recovered.internal;

import net.minecraft.network.packet.Packet;
import recovered.internal.Class_hH_ae8f8f77;

public abstract class Class_gL_cf24808b
extends Class_hH_ae8f8f77 {
    private Packet<?> AweKt;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    public Class_gL_cf24808b(Packet<?> packet) {
        this.AweKt = packet;
    }

    public Packet<?> bcf() {
        return this.AweKt;
    }
}

