/*
 * Decompiled with CFR 0.152.
 */
package recovered.internal;

import recovered.core.NativeLoader;

public final class Class_cl_0655ee76
extends Enum<Class_cl_0655ee76> {
    public static /* enum */ Class_cl_0655ee76 BisXp;
    public static /* enum */ Class_cl_0655ee76 zjBim;
    private static /* synthetic */ Class_cl_0655ee76[] kPIHw;
    private static final /* synthetic */ byte[] $mango$6dc686caab50ed59;

    static {
        NativeLoader.doInit(Class_cl_0655ee76.class);
        Class_cl_0655ee76._a944dbd9cc62ce6eb69c5bfb13cd6494();
    }

    public static native Class_cl_0655ee76[] values();

    public static native Class_cl_0655ee76 valueOf(String var0);

    private static native /* synthetic */ Class_cl_0655ee76[] QL();

    private static native String QM(byte[] var0);

    private static native void _a944dbd9cc62ce6eb69c5bfb13cd6494();
}

